var user_details =  {
  "screen_name" : "andyreagan",
  "location" : "Blacksburg, VA",
  "full_name" : "Andy Reagan",
  "bio" : "adding to my CVA every day #cirriculumviteaofawesomeness #comfortisoverrated",
  "id" : "55931868",
  "created_at" : "Sat Jul 11 21:13:56 +0000 2009"
}