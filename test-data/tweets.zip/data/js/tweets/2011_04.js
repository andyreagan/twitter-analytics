Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64397341511266304",
  "text" : "slept in for the first time in a really long time, felt good. but i dont like starting the day so late. cleaned the house, going mtb'ing now",
  "id" : 64397341511266304,
  "created_at" : "Sat Apr 30 18:34:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "John Sanders",
      "screen_name" : "Bugmanjg",
      "indices" : [ 14, 23 ],
      "id_str" : "253660652",
      "id" : 253660652
    }, {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 24, 31 ],
      "id_str" : "18177652",
      "id" : 18177652
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 103, 113 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64224376681271296",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium @bugmanjg @BenDUB hope the rumors abt Athens sororities were true ;) crush it tmrw guys! @vtcycling ftw",
  "id" : 64224376681271296,
  "created_at" : "Sat Apr 30 07:07:39 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64223286330011648",
  "text" : "g'night twitterati",
  "id" : 64223286330011648,
  "created_at" : "Sat Apr 30 07:03:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2303642, -80.4150262 ]
  },
  "id_str" : "64205961157558272",
  "text" : "just accompanying. race weight. (@ DP Dough's) http://4sq.com/kB35gU",
  "id" : 64205961157558272,
  "created_at" : "Sat Apr 30 05:54:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.231, -80.4148 ]
  },
  "id_str" : "64182255630827520",
  "text" : "Brooklyn Summer Ale: yes. Love brooklyn brewery (@ The Cellar) http://4sq.com/miU8A6",
  "id" : 64182255630827520,
  "created_at" : "Sat Apr 30 04:20:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.230636, -80.41503 ]
  },
  "id_str" : "64140861583273984",
  "text" : "Nice night out (@ Sharkey's Wing & Rib Joint w/ 4 others) http://4sq.com/iQzgCq",
  "id" : 64140861583273984,
  "created_at" : "Sat Apr 30 01:35:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 7, 16 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64103564099846144",
  "text" : "ziti w @dmreagan's spaghetti sauce 4 dinner, delic. takin a nap...",
  "id" : 64103564099846144,
  "created_at" : "Fri Apr 29 23:07:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64080292880719872",
  "geo" : {
  },
  "id_str" : "64084055649558529",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson dang man, you must be crazy allergic to that stuff. sorry to hear. i sure hope it heals up by the tour!",
  "id" : 64084055649558529,
  "in_reply_to_status_id" : 64080292880719872,
  "created_at" : "Fri Apr 29 21:50:04 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64047064874622976",
  "geo" : {
  },
  "id_str" : "64076279342841856",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson not the east coast..but I bet its sweet riding there. Do you want to mtb tmrw/are you able?",
  "id" : 64076279342841856,
  "in_reply_to_status_id" : 64047064874622976,
  "created_at" : "Fri Apr 29 21:19:10 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64075952744960000",
  "text" : "solid ride. Check out how I rode straight into my house: http://twitpic.com/4r4qmr",
  "id" : 64075952744960000,
  "created_at" : "Fri Apr 29 21:17:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 89, 99 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64038048173789184",
  "text" : "headed out for a MTB ride! goals: clean rock garden on old farm, avoid trees going down. @bdoyle613 i'll catch up to you",
  "id" : 64038048173789184,
  "created_at" : "Fri Apr 29 18:47:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64027488124276736",
  "geo" : {
  },
  "id_str" : "64037735521984512",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr it was good!! i think the steam from the rice basically cooks the egg",
  "id" : 64037735521984512,
  "in_reply_to_status_id" : 64027488124276736,
  "created_at" : "Fri Apr 29 18:46:00 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 35, 44 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "salmonella",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64020333354692608",
  "text" : "cooking rice and eggs for lunch... @vmhilljr i'm gonna try the raw egg thing, hello #salmonella",
  "id" : 64020333354692608,
  "created_at" : "Fri Apr 29 17:36:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64019448696283137",
  "text" : "just raced some sorority girls (in their car) up roanoke st on my fixie, and won. #winning. and they live in the next apt lol",
  "id" : 64019448696283137,
  "created_at" : "Fri Apr 29 17:33:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63981612995588096",
  "text" : "found my bike lock last night, but for 3 days didn't have one. it wouldve been entertaining to watch some try to steal a 61cm fixie",
  "id" : 63981612995588096,
  "created_at" : "Fri Apr 29 15:02:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63945548553666560",
  "text" : "two homeworks to finish up then I'm done till finals! taking a nap after class for sure",
  "id" : 63945548553666560,
  "created_at" : "Fri Apr 29 12:39:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63777351745540096",
  "text" : "http://twitpic.com/4qqonc",
  "id" : 63777351745540096,
  "created_at" : "Fri Apr 29 01:31:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63772533853396992",
  "text" : "Saluta! http://twitpic.com/4qqg6c",
  "id" : 63772533853396992,
  "created_at" : "Fri Apr 29 01:12:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63751319831314433",
  "text" : "next project: http://www.treehugger.com/files/2007/09/the_cutting_edg.php",
  "id" : 63751319831314433,
  "created_at" : "Thu Apr 28 23:47:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63751121948246016",
  "text" : "just sent over 400 emails, it was surprisingly very difficult... wanna know why? http://bit.ly/lO1v7z",
  "id" : 63751121948246016,
  "created_at" : "Thu Apr 28 23:47:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 91, 104 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63746188205236225",
  "text" : "headed over to Edoardo's with some of my \"beautiful beer\" for an authentic Italian dinner! @laurentappan who's fancier? haha",
  "id" : 63746188205236225,
  "created_at" : "Thu Apr 28 23:27:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63735137552175104",
  "text" : "went to Blacksburg's \"Up on the roof\" mixer, pretty cool. 8 kegs and gorgeous views!",
  "id" : 63735137552175104,
  "created_at" : "Thu Apr 28 22:43:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "63697112323473409",
  "text" : "yes, I've been at d2 for four hours now. no, I don't have an eating problem (@ Dietrick Dining Center) http://4sq.com/iNqqwF",
  "id" : 63697112323473409,
  "created_at" : "Thu Apr 28 20:12:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "63620036757164032",
  "text" : "Forgot to bring my printed out project to class, dang (@ McBryde Hall) http://4sq.com/jftwnR",
  "id" : 63620036757164032,
  "created_at" : "Thu Apr 28 15:06:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "surreal",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63480109897756672",
  "text" : "rising home with flashes of daylight #surreal",
  "id" : 63480109897756672,
  "created_at" : "Thu Apr 28 05:50:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63460674357035008",
  "text" : "RT @garyvee: VT i love u!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "63459613068111872",
    "text" : "VT i love u!",
    "id" : 63459613068111872,
    "created_at" : "Thu Apr 28 04:28:45 +0000 2011",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2686490082/def3702974d1d48abb19e04b8175beec_normal.jpeg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 63460674357035008,
  "created_at" : "Thu Apr 28 04:32:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63455213855571968",
  "text" : "Tornado Warning for Montgomery County until 0045",
  "id" : 63455213855571968,
  "created_at" : "Thu Apr 28 04:11:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63443671156133889",
  "geo" : {
  },
  "id_str" : "63444054905602048",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice express mail to Blacksburg",
  "id" : 63444054905602048,
  "in_reply_to_status_id" : 63443671156133889,
  "created_at" : "Thu Apr 28 03:26:56 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 32, 40 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63440122242277376",
  "text" : "incredible talk and giveways by @garyvee tonight! unbelievable prizes, what an awesome dude. 50k in prizes?? super bowl tix, 2 jobs...",
  "id" : 63440122242277376,
  "created_at" : "Thu Apr 28 03:11:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63321182837014528",
  "geo" : {
  },
  "id_str" : "63321418456248320",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr raw??",
  "id" : 63321418456248320,
  "in_reply_to_status_id" : 63321182837014528,
  "created_at" : "Wed Apr 27 19:19:37 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Students",
      "screen_name" : "googlestudents",
      "indices" : [ 9, 24 ],
      "id_str" : "30315557",
      "id" : 30315557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63320486158934016",
  "text" : "sick! RT @googlestudents Have you seen the Google Street View trike? See how engineers designed (and built!) the trike http://goo.gl/tDWyD",
  "id" : 63320486158934016,
  "created_at" : "Wed Apr 27 19:15:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "delicious",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63320309952028672",
  "text" : "an egg over easy and cheese on top of a place of rice for lunch.. wow #delicious",
  "id" : 63320309952028672,
  "created_at" : "Wed Apr 27 19:15:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 14, 22 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63301872655663104",
  "text" : "I'm attending @garyvee at Virginia Tech -- http://www.eventbrite.com/s/3WDV",
  "id" : 63301872655663104,
  "created_at" : "Wed Apr 27 18:01:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63242566551863298",
  "geo" : {
  },
  "id_str" : "63248303088869377",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 i've been wearing shorts for a month?",
  "id" : 63248303088869377,
  "in_reply_to_status_id" : 63242566551863298,
  "created_at" : "Wed Apr 27 14:29:05 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 22, 34 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63086504372740096",
  "text" : "fun swim practice and @VTTriathlon meeting. watch out, imma b a fish. bedtime yall",
  "id" : 63086504372740096,
  "created_at" : "Wed Apr 27 03:46:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Phinney",
      "screen_name" : "taylorphinney",
      "indices" : [ 21, 35 ],
      "id_str" : "16971072",
      "id" : 16971072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romandie",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62963870821654528",
  "text" : "sweet pic #Romandie: @taylorphinney second results-wise, but No. 1 in looking good. (c) Tim de Waele http://twitpic.com/4pupxa",
  "id" : 62963870821654528,
  "created_at" : "Tue Apr 26 19:38:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62962826901340161",
  "text" : "done with Numerical Analysis project! pretty cool stuff, solving ODE's how it's actually done http://twitpic.com/4puwvj",
  "id" : 62962826901340161,
  "created_at" : "Tue Apr 26 19:34:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "indices" : [ 3, 18 ],
      "id_str" : "63491769",
      "id" : 63491769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62945395021594624",
  "text" : "RT @usaccollegiate: Also, riding a fixie to class does not qualify you to race A's on the track, nor does beating someone to a town limi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "62922452652662784",
    "text" : "Also, riding a fixie to class does not qualify you to race A's on the track, nor does beating someone to a town limit sign on said fixie. :)",
    "id" : 62922452652662784,
    "created_at" : "Tue Apr 26 16:54:16 +0000 2011",
    "user" : {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "protected" : false,
      "id_str" : "63491769",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/351269245/USACycling_Collegiate_square_normal.JPG",
      "id" : 63491769,
      "verified" : false
    }
  },
  "id" : 62945395021594624,
  "created_at" : "Tue Apr 26 18:25:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "62904754057117697",
  "text" : "my legs are really sore, from running yesterday I think. Finished one hw...two more and almost done with my project, phew.",
  "id" : 62904754057117697,
  "created_at" : "Tue Apr 26 15:43:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62879808949985280",
  "geo" : {
  },
  "id_str" : "62885321389506560",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia then I'm coming back to Blacksburg for an summer research position. you'll have to come here!",
  "id" : 62885321389506560,
  "in_reply_to_status_id" : 62879808949985280,
  "created_at" : "Tue Apr 26 14:26:43 +0000 2011",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "randomtweet",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62718183999672320",
  "geo" : {
  },
  "id_str" : "62724542975574016",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 #randomtweet much?",
  "id" : 62724542975574016,
  "in_reply_to_status_id" : 62718183999672320,
  "created_at" : "Tue Apr 26 03:47:51 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62724458573606912",
  "text" : "enough matlab to drive on crazy. but plently left in the AM! callin it a night",
  "id" : 62724458573606912,
  "created_at" : "Tue Apr 26 03:47:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 15, 28 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62705247650447360",
  "text" : "just bought my @usatriathlon license, gonna be racing this summer!",
  "id" : 62705247650447360,
  "created_at" : "Tue Apr 26 02:31:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 83, 91 ],
      "id_str" : "84075278",
      "id" : 84075278
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 102, 112 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62694032903639040",
  "text" : "had a super awesome mtb ride today (pix of carnage coming later) followed by delic @Moes_HQ, fun last @VTCycling meeting. now homework time",
  "id" : 62694032903639040,
  "created_at" : "Tue Apr 26 01:46:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62693511870418945",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia how have you been gosh!?! I'll be back in Syr for three weeks, in two weeks :)",
  "id" : 62693511870418945,
  "created_at" : "Tue Apr 26 01:44:32 +0000 2011",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62692979718111232",
  "geo" : {
  },
  "id_str" : "62693333025300480",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia i agree! easy to think we're so advanced and everything in the bubble of college... anyway lol! got your @ before, i've been great!!",
  "id" : 62693333025300480,
  "in_reply_to_status_id" : 62692979718111232,
  "created_at" : "Tue Apr 26 01:43:50 +0000 2011",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62685271795314688",
  "geo" : {
  },
  "id_str" : "62692863955316736",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy that looks rediculous but sorta awesome! it was a thomson seatpost that broke...now what I need is a superfly, i got spoiled",
  "id" : 62692863955316736,
  "in_reply_to_status_id" : 62685271795314688,
  "created_at" : "Tue Apr 26 01:41:58 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62577451989090304",
  "geo" : {
  },
  "id_str" : "62595981484638208",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 sweet cya in 10",
  "id" : 62595981484638208,
  "in_reply_to_status_id" : 62577451989090304,
  "created_at" : "Mon Apr 25 19:16:59 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "62541976192557056",
  "text" : "class time...8 days left! three homework sets, two progamming projects, and four finals before I go home... http://4sq.com/eqWVwi",
  "id" : 62541976192557056,
  "created_at" : "Mon Apr 25 15:42:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 81, 94 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62504114780782593",
  "text" : "somehow felt great running, including after a half dozen donuts midway through w @williamenium, the only other person hard enough run @ 7am!",
  "id" : 62504114780782593,
  "created_at" : "Mon Apr 25 13:11:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62501110971248641",
  "geo" : {
  },
  "id_str" : "62503850417991680",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium hahah I feel great man...best stretch in awhile",
  "id" : 62503850417991680,
  "in_reply_to_status_id" : 62501110971248641,
  "created_at" : "Mon Apr 25 13:10:53 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 18, 30 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62468598706343936",
  "text" : "going for a run w @VTTriathlon to Carol Lee!",
  "id" : 62468598706343936,
  "created_at" : "Mon Apr 25 10:50:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62371133546184704",
  "text" : "gets really into programs when i'm trying to write them...too much. 500 lines of c++ down, and I've gotta force myself away. run @ 7am!",
  "id" : 62371133546184704,
  "created_at" : "Mon Apr 25 04:23:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62250804991635456",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin can't skype, i'm at vbi, my phone won't send you a txt back...you can call 540 231 5119",
  "id" : 62250804991635456,
  "created_at" : "Sun Apr 24 20:25:23 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 109, 123 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61907919729463297",
  "text" : "awesome mtb ride today with Emma: my seatpost broke, so her dad let me ride his carbon superfly with xtr and @ChrisKingBuzz wheels, schweet!",
  "id" : 61907919729463297,
  "created_at" : "Sat Apr 23 21:42:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61816643147407360",
  "text" : "ham and cheese omlette, big glass chocolate milk, mtb w emma as soon as I finish #winning http://twitpic.com/4ohqsx",
  "id" : 61816643147407360,
  "created_at" : "Sat Apr 23 15:40:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61486709199745024",
  "text" : "94 on number theory test, huzzah! and dr rogers is letting me email him the hw later, schweet. and good news abt my grad application!",
  "id" : 61486709199745024,
  "created_at" : "Fri Apr 22 17:49:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61447906238017536",
  "text" : "has relied on my biological clock to wake up all semester. today, it failed me.",
  "id" : 61447906238017536,
  "created_at" : "Fri Apr 22 15:14:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2342, -80.4198 ]
  },
  "id_str" : "61232556158365696",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan ill be at 622 soon! (@ El Rodeo) http://4sq.com/enqbO6",
  "id" : 61232556158365696,
  "created_at" : "Fri Apr 22 00:59:13 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61229145677496320",
  "text" : "veggie stir fry dinner, yup. headin to see the black diamond ramblers play! http://twitpic.com/4nsexj",
  "id" : 61229145677496320,
  "created_at" : "Fri Apr 22 00:45:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61220122173513728",
  "text" : "what a gorgeous night outside... http://twitpic.com/4ns1zv",
  "id" : 61220122173513728,
  "created_at" : "Fri Apr 22 00:09:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61214490536067072",
  "geo" : {
  },
  "id_str" : "61216248725381120",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice i'll be home in 17 days!",
  "id" : 61216248725381120,
  "in_reply_to_status_id" : 61214490536067072,
  "created_at" : "Thu Apr 21 23:54:25 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61208339949953024",
  "text" : "skipped swim practice...to finish and submit my GRAD SCHOOL APPLICATION! ahhh",
  "id" : 61208339949953024,
  "created_at" : "Thu Apr 21 23:23:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 34, 43 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61195828584382464",
  "text" : "best. care. package. EVER. thanks @dmreagan!",
  "id" : 61195828584382464,
  "created_at" : "Thu Apr 21 22:33:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "61155963490680832",
  "text" : "adv calc hw done! The weekend approaches... (@ Dietrick Dining Center) http://4sq.com/gn9V6d",
  "id" : 61155963490680832,
  "created_at" : "Thu Apr 21 19:54:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "61090466946494465",
  "text" : "my door -&gt; sitting in McBryde = 7 minutes on a fixed gear. try to beat that...on anything! (@ McBryde Hall) http://4sq.com/fGt8tp",
  "id" : 61090466946494465,
  "created_at" : "Thu Apr 21 15:34:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61080162002927616",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan could you guys proofread my personal statement for me today? emailed it to kreagan at twcny",
  "id" : 61080162002927616,
  "created_at" : "Thu Apr 21 14:53:40 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fact",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61077929911791617",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e That's intense, Moose kill more people than brown and black bears combined! #fact",
  "id" : 61077929911791617,
  "created_at" : "Thu Apr 21 14:44:47 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61063517427613696",
  "geo" : {
  },
  "id_str" : "61066483089936384",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 don't think you're getting out that easy! coach justin morrison may just make it a mandatory team workout",
  "id" : 61066483089936384,
  "in_reply_to_status_id" : 61063517427613696,
  "created_at" : "Thu Apr 21 13:59:18 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61063439291916288",
  "text" : "Ham and cheese omlette #winning http://yfrog.com/h6srmobj",
  "id" : 61063439291916288,
  "created_at" : "Thu Apr 21 13:47:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61063246597206016",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan awesome, I'll be checking the mail :)",
  "id" : 61063246597206016,
  "created_at" : "Thu Apr 21 13:46:27 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61062891847163904",
  "geo" : {
  },
  "id_str" : "61063160823689216",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 nah, I meant that the workout this fall with by \"5 X Farm\" aka climbing old farm five times",
  "id" : 61063160823689216,
  "in_reply_to_status_id" : 61062891847163904,
  "created_at" : "Thu Apr 21 13:46:06 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60867028122206208",
  "geo" : {
  },
  "id_str" : "61060975415144448",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 haha i know, i was kidding. workout for mtb\ning this fall: 5 by farm",
  "id" : 61060975415144448,
  "in_reply_to_status_id" : 60867028122206208,
  "created_at" : "Thu Apr 21 13:37:25 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61054448138584064",
  "geo" : {
  },
  "id_str" : "61058879018110976",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e find me a mathematician that isn't odd?",
  "id" : 61058879018110976,
  "in_reply_to_status_id" : 61054448138584064,
  "created_at" : "Thu Apr 21 13:29:05 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61020996177637376",
  "text" : "sunrise ride w Dave, 7am and headed for Dry Run!",
  "id" : 61020996177637376,
  "created_at" : "Thu Apr 21 10:58:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60809084303183872",
  "geo" : {
  },
  "id_str" : "60866691051171840",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 conquered = cleaned ? ha I'm jk...someday. its kinda my goal this summer",
  "id" : 60866691051171840,
  "in_reply_to_status_id" : 60809084303183872,
  "created_at" : "Thu Apr 21 00:45:24 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60859747737411584",
  "text" : "Disco time http://twitpic.com/4ndkx2",
  "id" : 60859747737411584,
  "created_at" : "Thu Apr 21 00:17:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60797955342467072",
  "text" : "just bought Shernita (research advisor) an awesome present for the year! can't wait. MTB fixed (thx Dave!), headed to Disco Race!!",
  "id" : 60797955342467072,
  "created_at" : "Wed Apr 20 20:12:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60797747548266496",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet good work bro!!",
  "id" : 60797747548266496,
  "created_at" : "Wed Apr 20 20:11:27 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60767104403636224",
  "geo" : {
  },
  "id_str" : "60789293060341760",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 gooood luck!",
  "id" : 60789293060341760,
  "in_reply_to_status_id" : 60767104403636224,
  "created_at" : "Wed Apr 20 19:37:51 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60789231567638528",
  "text" : "think I did well on number theory...as well as one can on 7 chapters of material. getting close on my personal statement!",
  "id" : 60789231567638528,
  "created_at" : "Wed Apr 20 19:37:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 85, 96 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60764320698609664",
  "text" : "RT @VTCycling: Men's C race VIDEO: http://www.youtube.com/watch?v=4zWVj0HsQ98 thx to @andyreagan",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 70, 81 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "60764202935140352",
    "text" : "Men's C race VIDEO: http://www.youtube.com/watch?v=4zWVj0HsQ98 thx to @andyreagan",
    "id" : 60764202935140352,
    "created_at" : "Wed Apr 20 17:58:09 +0000 2011",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 60764320698609664,
  "created_at" : "Wed Apr 20 17:58:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60717686539292672",
  "text" : "been studying all AM and ready to dominate this number theory exam!",
  "id" : 60717686539292672,
  "created_at" : "Wed Apr 20 14:53:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60520646374993920",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e maybe you could actually use this: http://www.stumbleupon.com/su/1CuZFS/www.touchtrigonometry.org/",
  "id" : 60520646374993920,
  "created_at" : "Wed Apr 20 01:50:21 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60520451981582336",
  "text" : "yes? http://www.thinkgeek.com/caffeine/wacky-edibles/ab3f/#tabs",
  "id" : 60520451981582336,
  "created_at" : "Wed Apr 20 01:49:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60511081617043456",
  "text" : "much needed nap in C++, delic open-face meatball subs 4 din, 500m PR in the pool, and won an ice cream competition on the way home #winning",
  "id" : 60511081617043456,
  "created_at" : "Wed Apr 20 01:12:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60366944259420160",
  "text" : "watching all of these tour groups today makes me remember when I was touring here on a gorgeous day in April, was that really 4 years ago...",
  "id" : 60366944259420160,
  "created_at" : "Tue Apr 19 15:39:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "60360258211676160",
  "text" : "it's Transportation Tuesday of Earth Week! Commuter challenge results + prizes, bike fixes, megabus giveaways on the drillfield till 3",
  "id" : 60360258211676160,
  "created_at" : "Tue Apr 19 15:13:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2314, -80.4154 ]
  },
  "id_str" : "60181520576552960",
  "text" : "Chyeah (@ Hokie House) http://4sq.com/g1oZ8t",
  "id" : 60181520576552960,
  "created_at" : "Tue Apr 19 03:22:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60179031890464768",
  "text" : "DONE with numerical analysis.",
  "id" : 60179031890464768,
  "created_at" : "Tue Apr 19 03:12:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60178963733032960",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium just making sure you've seen this: http://www.hetfairwheelpodium.com/16/spin-light-bike.html#content",
  "id" : 60178963733032960,
  "created_at" : "Tue Apr 19 03:12:37 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 64, 74 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 123, 135 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60153250791424001",
  "text" : "is now an official member of Pi Mu Epsilon, math honor society! @VTCycling meeting was fun, and my spine is now fine thx 2 @LeeRMatthis",
  "id" : 60153250791424001,
  "created_at" : "Tue Apr 19 01:30:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60064984603967488",
  "text" : "one more letter of recommendation, and finishing my personal statement and I'll be on my way to GRAD SCHOOL",
  "id" : 60064984603967488,
  "created_at" : "Mon Apr 18 19:39:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60036505762148352",
  "text" : "time to crush some HW",
  "id" : 60036505762148352,
  "created_at" : "Mon Apr 18 17:46:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59994283805130752",
  "text" : "now it's copying in real-time (35 minutes...awesome). wish they had an HD one avail, they can record str8 to SD card!! Oh well",
  "id" : 59994283805130752,
  "created_at" : "Mon Apr 18 14:58:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59991834239320064",
  "text" : "turns out it didn't work bc it recorded in the ultra-lowest quality setting. thanks for leaving it on the \"LP\" setting i had no idea abt....",
  "id" : 59991834239320064,
  "created_at" : "Mon Apr 18 14:49:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACC Cycling",
      "screen_name" : "ACCCycling",
      "indices" : [ 0, 11 ],
      "id_str" : "111463102",
      "id" : 111463102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59986085551423489",
  "geo" : {
  },
  "id_str" : "59987767186296833",
  "in_reply_to_user_id" : 111463102,
  "text" : "@ACCCycling i have a completely new idea. start the races with a swim, and then end them with a run. and score everyone on just their time",
  "id" : 59987767186296833,
  "in_reply_to_status_id" : 59986085551423489,
  "created_at" : "Mon Apr 18 14:32:52 +0000 2011",
  "in_reply_to_screen_name" : "ACCCycling",
  "in_reply_to_user_id_str" : "111463102",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59987233238822913",
  "text" : "trying to import video...but the mini dv player keeps blue screening with \"use cleaning cassette\" urrrggg",
  "id" : 59987233238822913,
  "created_at" : "Mon Apr 18 14:30:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59963719182061568",
  "text" : "sunrise bike and yoga was awesome. headed innovation space and office hours (grad letter of recommendation from dr brown)",
  "id" : 59963719182061568,
  "created_at" : "Mon Apr 18 12:57:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 31, 41 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59760537600401408",
  "text" : "awesome home race weekend with @VTCycling. sad the season is over, but probably still racing next weekend! time to catch up on HW...",
  "id" : 59760537600401408,
  "created_at" : "Sun Apr 17 23:29:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59212093676720128",
  "text" : "almost time to race bikes, cold and rainy but oh well",
  "id" : 59212093676720128,
  "created_at" : "Sat Apr 16 11:10:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59132628611248128",
  "text" : "\"This alarm is set for 2 hours and 48 minutes from now\"",
  "id" : 59132628611248128,
  "created_at" : "Sat Apr 16 05:54:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59110281179172864",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet know anything abt governers island?",
  "id" : 59110281179172864,
  "created_at" : "Sat Apr 16 04:26:03 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crazy",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58992065463336962",
  "text" : "just took a nice nap, and I only need one more signature on my grad school application #crazy",
  "id" : 58992065463336962,
  "created_at" : "Fri Apr 15 20:36:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 19, 30 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58982362133958656",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 RT @kreagannet metallica!",
  "id" : 58982362133958656,
  "created_at" : "Fri Apr 15 19:57:45 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "58922158960803842",
  "text" : "presentation went really well, and listened to some others that were very interesting. seminar/lunch abt grad school, then a meeting.",
  "id" : 58922158960803842,
  "created_at" : "Fri Apr 15 15:58:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 53, 69 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58877972593131520",
  "text" : "tie on and headed to the GLC. practice run this AM w @RumblinStumblin was great, thanks Dad. and biscuits with apple butter 4 brkfst mmmm",
  "id" : 58877972593131520,
  "created_at" : "Fri Apr 15 13:02:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58746793147633664",
  "text" : "andy's question of the day: number theory class or the conference luncheon? ...or earlier, go to other presentations or adv calc? toughtough",
  "id" : 58746793147633664,
  "created_at" : "Fri Apr 15 04:21:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58745668902207488",
  "text" : "ppt tweaked, good as it's gonna get. vid cam is on the gorrilapod. meeting with a prof from icam abt grad school tmrw as well!",
  "id" : 58745668902207488,
  "created_at" : "Fri Apr 15 04:17:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 103, 112 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 113, 129 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58715543091421184",
  "text" : "camera is all charged. final touches to the presentation being made now, practice run in the morning w @dmreagan @RumblinStumblin",
  "id" : 58715543091421184,
  "created_at" : "Fri Apr 15 02:17:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58714655115325441",
  "text" : "is a popsicle monster. om nom nom. the pizza turned out great, and this summer/next year roommates mostly worked out, it's gonna be fun!",
  "id" : 58714655115325441,
  "created_at" : "Fri Apr 15 02:13:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 34, 45 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 66, 79 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chyeah",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58667696136523777",
  "text" : "a discount impersonating success: @kreagannet's gnc gold card and @laurentappan's kroger card #chyeah",
  "id" : 58667696136523777,
  "created_at" : "Thu Apr 14 23:07:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58662293180919809",
  "text" : "did get a trim and lookin less like a bum for sure. Gettin supplies and making pizza for dinner chyeah",
  "id" : 58662293180919809,
  "created_at" : "Thu Apr 14 22:45:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58661908584202243",
  "text" : "found the only khaki 32x34 there buried in the wrong section, score! Why am I having such a hard time deciding where to get a hair cut jeez",
  "id" : 58661908584202243,
  "created_at" : "Thu Apr 14 22:44:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sucksbeingtall",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58646326665154560",
  "text" : "trying to find 32x34's...not easy. #sucksbeingtall",
  "id" : 58646326665154560,
  "created_at" : "Thu Apr 14 21:42:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 97, 113 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58635010026110976",
  "text" : "innovation space has a lot more high def vid cams, but those r out. standard def will have to do @rumblinstumblin",
  "id" : 58635010026110976,
  "created_at" : "Thu Apr 14 20:57:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58626844378931200",
  "text" : "goin to c if I can rent a camera for presentation tmrw, then hair cut (for real hopefully), shopping for new pants and grocies, then PIZZA!",
  "id" : 58626844378931200,
  "created_at" : "Thu Apr 14 20:25:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Great Minds Quotes",
      "screen_name" : "GreatestQuotes",
      "indices" : [ 3, 18 ],
      "id_str" : "22256645",
      "id" : 22256645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58622322503991296",
  "text" : "RT @GreatestQuotes: \"People are just about as happy as they make up their minds to be.\" - Abraham Lincoln",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialoomph.com\" rel=\"nofollow\">SocialOomph</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58507420426702849",
    "text" : "\"People are just about as happy as they make up their minds to be.\" - Abraham Lincoln",
    "id" : 58507420426702849,
    "created_at" : "Thu Apr 14 12:30:30 +0000 2011",
    "user" : {
      "name" : "Great Minds Quotes",
      "screen_name" : "GreatestQuotes",
      "protected" : false,
      "id_str" : "22256645",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/84526408/twitter_gm_logo_normal.PNG",
      "id" : 22256645,
      "verified" : false
    }
  },
  "id" : 58622322503991296,
  "created_at" : "Thu Apr 14 20:07:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58615653287985152",
  "geo" : {
  },
  "id_str" : "58621860950192128",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 dominate that shit",
  "id" : 58621860950192128,
  "in_reply_to_status_id" : 58615653287985152,
  "created_at" : "Thu Apr 14 20:05:15 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58611191068635136",
  "text" : "MSE 5114 Deformation and Fracture of Materials (with lab demonstrations), sounds like we would get to fatigue metal till it breaks, sweet!",
  "id" : 58611191068635136,
  "created_at" : "Thu Apr 14 19:22:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58606115549753345",
  "text" : "working on my graduate school application. I have to plan all of my courses now, before I apply, but I want to take them all!",
  "id" : 58606115549753345,
  "created_at" : "Thu Apr 14 19:02:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58515639001817089",
  "geo" : {
  },
  "id_str" : "58597598239539201",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 not even a question, PC",
  "id" : 58597598239539201,
  "in_reply_to_status_id" : 58515639001817089,
  "created_at" : "Thu Apr 14 18:28:50 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58524682621689856",
  "text" : "just put in 6 very full loads of laundry...some sorta record? gettin a hair cut",
  "id" : 58524682621689856,
  "created_at" : "Thu Apr 14 13:39:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58296100918001664",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice how close is philly to penn state?",
  "id" : 58296100918001664,
  "created_at" : "Wed Apr 13 22:30:48 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike the US for MS",
      "screen_name" : "BiketheUSforMS",
      "indices" : [ 64, 79 ],
      "id_str" : "19885009",
      "id" : 19885009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304689, -80.4151305 ]
  },
  "id_str" : "58295710407340032",
  "text" : "I'm always down to support in burrito form, tonight at moes for @biketheusforms! (@ Moe's Southwest Grill) http://4sq.com/efqonM",
  "id" : 58295710407340032,
  "created_at" : "Wed Apr 13 22:29:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58247220583084032",
  "geo" : {
  },
  "id_str" : "58291935852498944",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie rock that hardhat! happy birthday man!!",
  "id" : 58291935852498944,
  "in_reply_to_status_id" : 58247220583084032,
  "created_at" : "Wed Apr 13 22:14:15 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58262971339644928",
  "geo" : {
  },
  "id_str" : "58290151025147905",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 you follow me now, yay! haha. good luck with that, where is it?",
  "id" : 58290151025147905,
  "in_reply_to_status_id" : 58262971339644928,
  "created_at" : "Wed Apr 13 22:07:09 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 33, 43 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58289776436068353",
  "text" : "fun course preview ride with the @VTCycling C team. it's gonna be a tough freakin race, super hills",
  "id" : 58289776436068353,
  "created_at" : "Wed Apr 13 22:05:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58240368541577216",
  "text" : "open face meatball sandwhiches for lunch and a big glass of choc milk! yup. now heading out to ride",
  "id" : 58240368541577216,
  "created_at" : "Wed Apr 13 18:49:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 14, 26 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58224268911185921",
  "text" : "and thanks to @LeeRMatthis and some icing, my sore knee tendon is feeling 1000x better and I'm going to go preride the home RR course now!",
  "id" : 58224268911185921,
  "created_at" : "Wed Apr 13 17:45:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58223839846473728",
  "text" : "just bought season football tickets for 2011!!",
  "id" : 58223839846473728,
  "created_at" : "Wed Apr 13 17:43:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "58192411381350401",
  "text" : "wearin the flannel today. cmon weather! number theory hw is defeating me (@ McBryde Hall) http://4sq.com/i1wkKZ",
  "id" : 58192411381350401,
  "created_at" : "Wed Apr 13 15:38:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 28, 40 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57940653069438976",
  "text" : "swim practice now? and then @VTTriathlon or homebrew meeting?....tough tough",
  "id" : 57940653069438976,
  "created_at" : "Tue Apr 12 22:58:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57938574384963584",
  "text" : "got a flat on the way to class today. good news: i can hold 4mph walking according to my speedometer, and my chain needed tension anyway",
  "id" : 57938574384963584,
  "created_at" : "Tue Apr 12 22:50:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 25, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57938064059793408",
  "text" : "my bad, that's tomorrow! #fb",
  "id" : 57938064059793408,
  "created_at" : "Tue Apr 12 22:48:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike the US for MS",
      "screen_name" : "BiketheUSforMS",
      "indices" : [ 58, 73 ],
      "id_str" : "19885009",
      "id" : 19885009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 83, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57930925597659136",
  "text" : "who wants to go to Moes in the next hour or so to support @BiketheUSforMS with me? #fb",
  "id" : 57930925597659136,
  "created_at" : "Tue Apr 12 22:19:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57927996182511616",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet http://gr.pn/f2VmcO",
  "id" : 57927996182511616,
  "created_at" : "Tue Apr 12 22:08:05 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57913963509321729",
  "text" : "12min presentation = 50min and 3 pages of feedback...phew i'm exhausted. and the administration of my C++ class is such BS",
  "id" : 57913963509321729,
  "created_at" : "Tue Apr 12 21:12:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "57825283012702208",
  "text" : "got a flat today, found it only takes 7min longer to walk to class. 100 on both num anal hws, project handed in! http://4sq.com/fXKqz1",
  "id" : 57825283012702208,
  "created_at" : "Tue Apr 12 15:19:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 13, 23 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57651553712087040",
  "text" : "new post for @VTCycling on http://www.cycling.org.vt.edu! iced my knee, bedtime for me",
  "id" : 57651553712087040,
  "created_at" : "Tue Apr 12 03:49:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57628045124706304",
  "text" : "numerical analysis project, done! gotta try to figure out roommates for this summer...subleasing etc.",
  "id" : 57628045124706304,
  "created_at" : "Tue Apr 12 02:16:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304689, -80.4151305 ]
  },
  "id_str" : "57584959979921408",
  "text" : "Burrrrrito time (@ Moe's Southwest Grill) http://4sq.com/f8nznB",
  "id" : 57584959979921408,
  "created_at" : "Mon Apr 11 23:24:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57579728676208640",
  "text" : "headed to Moe's Monday!",
  "id" : 57579728676208640,
  "created_at" : "Mon Apr 11 23:04:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57529071881551872",
  "text" : "just rode around on Dave's bike that he installed a MOTOR on!! a little scary, but it moves",
  "id" : 57529071881551872,
  "created_at" : "Mon Apr 11 19:42:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 104, 114 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57525199909818368",
  "text" : "plan: SAYG Ride in the 80deg weather (although my legs needs a day off I can't resist) then matlab then @vtcycling meeting!",
  "id" : 57525199909818368,
  "created_at" : "Mon Apr 11 19:27:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57523070000300032",
  "geo" : {
  },
  "id_str" : "57524800129736704",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e CRC",
  "id" : 57524800129736704,
  "in_reply_to_status_id" : 57523070000300032,
  "created_at" : "Mon Apr 11 19:25:55 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57523193501589505",
  "text" : "but somehow I'm more nervous about presenting to my research group tomorrow? they're a tough crowd is why",
  "id" : 57523193501589505,
  "created_at" : "Mon Apr 11 19:19:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57522972558241792",
  "text" : "presentation schedule for this Friday: http://andyreagan.com/wp-content/uploads/2011/04/Oral-Presentation-Schedule-ROOM-D.pdf",
  "id" : 57522972558241792,
  "created_at" : "Mon Apr 11 19:18:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57522416850702336",
  "geo" : {
  },
  "id_str" : "57522895269797888",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e hahah :-P and yeah we better! It'll be the first weekend I'm here like all semester, come see me race Sunday?",
  "id" : 57522895269797888,
  "in_reply_to_status_id" : 57522416850702336,
  "created_at" : "Mon Apr 11 19:18:21 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57521658239528960",
  "geo" : {
  },
  "id_str" : "57522210633560064",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e \"We never really grow up, we only learn how to act in public.\"",
  "id" : 57522210633560064,
  "in_reply_to_status_id" : 57521658239528960,
  "created_at" : "Mon Apr 11 19:15:38 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57520538003841025",
  "text" : "the future? http://www.sunyocc.edu/index.aspx?menu=820&id=25955",
  "id" : 57520538003841025,
  "created_at" : "Mon Apr 11 19:08:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57518930020933632",
  "text" : "hey vt peeps, participate in the 2011 Commuter Challege: bus, bike, or drive! http://www.facilities.vt.edu/tcs/alternative/challenge.asp",
  "id" : 57518930020933632,
  "created_at" : "Mon Apr 11 19:02:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whuddup",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57509771594571776",
  "text" : "95 on my adv calc exam #whuddup",
  "id" : 57509771594571776,
  "created_at" : "Mon Apr 11 18:26:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "liz keegan",
      "screen_name" : "liz_keegan",
      "indices" : [ 0, 11 ],
      "id_str" : "558014770",
      "id" : 558014770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57429136637046784",
  "text" : "@liz_keegan I'm going home at the beginning of summer, let me know if you want to carpool",
  "id" : 57429136637046784,
  "created_at" : "Mon Apr 11 13:05:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57269049469579264",
  "text" : "done with numerical analysis for the night, going home!",
  "id" : 57269049469579264,
  "created_at" : "Mon Apr 11 02:29:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 51, 61 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57228991727276034",
  "text" : "awesome day of racing again today, hangin out with @VTCycling and messin with ASU. gorgeous weather...back to real life now though..hw!",
  "id" : 57228991727276034,
  "created_at" : "Sun Apr 10 23:50:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56847000796274688",
  "text" : "got 3rd in the USAC race!! Won $15, my entry fee back. And Jake won the race!!! And also won a cool tshirt, sweet socks, and a sausage ha",
  "id" : 56847000796274688,
  "created_at" : "Sat Apr 09 22:32:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56797023973810176",
  "text" : "fun mens c race and awesome atmosphere at this crit. Doublin up and racing the usac race now!",
  "id" : 56797023973810176,
  "created_at" : "Sat Apr 09 19:14:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 8, 23 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 24, 33 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 34, 45 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56602357450014720",
  "geo" : {
  },
  "id_str" : "56624710187892736",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @ryandelgiudice @DKnick88 @kreagannet I finish finals may 14, don't start REU till 30th...was gonna come home",
  "id" : 56624710187892736,
  "in_reply_to_status_id" : 56602357450014720,
  "created_at" : "Sat Apr 09 07:49:17 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56426041790562304",
  "text" : "good luck to my brewskis http://twitpic.com/4ie8tq",
  "id" : 56426041790562304,
  "created_at" : "Fri Apr 08 18:39:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "56410950756073472",
  "text" : "test down, hw handed in. Goin to get adjusted, pack, submit my homebrew 4 competition then head to WVU! http://4sq.com/eUbt2M",
  "id" : 56410950756073472,
  "created_at" : "Fri Apr 08 17:39:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrainingPeaks",
      "screen_name" : "TrainingPeaks",
      "indices" : [ 0, 14 ],
      "id_str" : "19348412",
      "id" : 19348412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56393486127202304",
  "geo" : {
  },
  "id_str" : "56410437142589440",
  "in_reply_to_user_id" : 19348412,
  "text" : "@TrainingPeaks haha that might involve actually riding my bike fast",
  "id" : 56410437142589440,
  "in_reply_to_status_id" : 56393486127202304,
  "created_at" : "Fri Apr 08 17:37:50 +0000 2011",
  "in_reply_to_screen_name" : "TrainingPeaks",
  "in_reply_to_user_id_str" : "19348412",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56340391770853376",
  "text" : "1hr till adv calc test so I need to study some... and a half done, really hard num theory problem set due...snap",
  "id" : 56340391770853376,
  "created_at" : "Fri Apr 08 12:59:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56218598628261888",
  "text" : "Droid: \"This alarm is set for 5 hours and 59 minutes from now\"",
  "id" : 56218598628261888,
  "created_at" : "Fri Apr 08 04:55:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56216383171739648",
  "text" : "just wrote all 4 pages of definitions and thms i gotta know for adv calc tmrw (today). regurgitating those=30pts, understanding them=70 more",
  "id" : 56216383171739648,
  "created_at" : "Fri Apr 08 04:46:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56206032480907264",
  "text" : "just turned off my daily training peaks email...finally! daily empty workout plans were gettin old",
  "id" : 56206032480907264,
  "created_at" : "Fri Apr 08 04:05:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56205052137844736",
  "text" : "went to PK's for tijuana toss for dinner, and had an awesome time chillin and getting a ride on the trike home. but test tmrw == no dt 4 me",
  "id" : 56205052137844736,
  "created_at" : "Fri Apr 08 04:01:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56109109879115776",
  "text" : "C++ test == dominated. 30min, first outtta there",
  "id" : 56109109879115776,
  "created_at" : "Thu Apr 07 21:40:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56095552730963968",
  "text" : "got the factorization, now just need to make iterative. (good) time to go take my exam for C++",
  "id" : 56095552730963968,
  "created_at" : "Thu Apr 07 20:46:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56088213609123841",
  "text" : "trying to write a program to determine the primality of 110870114262781 in C++ now...not going so well",
  "id" : 56088213609123841,
  "created_at" : "Thu Apr 07 20:17:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56072582482497536",
  "text" : "mathematica is useless",
  "id" : 56072582482497536,
  "created_at" : "Thu Apr 07 19:15:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56068948839501824",
  "text" : "why do there have to be so many different programming languages...ahhh",
  "id" : 56068948839501824,
  "created_at" : "Thu Apr 07 19:00:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bburg",
      "indices" : [ 13, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56011332922777600",
  "text" : "Almost 70 in #bburg, freakin awesome out! 40s in marcellus, buffalo, brockport, and philly.... :-P",
  "id" : 56011332922777600,
  "created_at" : "Thu Apr 07 15:11:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56005492618702848",
  "text" : "it is officially warmer outside my house than in it. 64 outside...56 inside!",
  "id" : 56005492618702848,
  "created_at" : "Thu Apr 07 14:48:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56004773564002304",
  "text" : "made an awesome omelette for breakfast today with fresh biscuits, and studied for C++. gonna dominate that test.",
  "id" : 56004773564002304,
  "created_at" : "Thu Apr 07 14:45:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Two Knobby Tires",
      "screen_name" : "TwoKnobbyTires",
      "indices" : [ 0, 15 ],
      "id_str" : "16188310",
      "id" : 16188310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55701465880203265",
  "geo" : {
  },
  "id_str" : "55732570821902336",
  "in_reply_to_user_id" : 16188310,
  "text" : "@TwoKnobbyTires thanks! and the trails are awesome up there, you'll love it",
  "id" : 55732570821902336,
  "in_reply_to_status_id" : 55701465880203265,
  "created_at" : "Wed Apr 06 20:44:15 +0000 2011",
  "in_reply_to_screen_name" : "TwoKnobbyTires",
  "in_reply_to_user_id_str" : "16188310",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55729140950765568",
  "geo" : {
  },
  "id_str" : "55731172591939584",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 sweet, what did you get?? i have a wrench if you want to ride it freewheel to my house",
  "id" : 55731172591939584,
  "in_reply_to_status_id" : 55729140950765568,
  "created_at" : "Wed Apr 06 20:38:41 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55699174238326784",
  "text" : "formally accepted my REU this summer! http://twitpic.com/4hob04",
  "id" : 55699174238326784,
  "created_at" : "Wed Apr 06 18:31:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55600689279270912",
  "geo" : {
  },
  "id_str" : "55689966386286592",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 I'd rather go on a rampage of contruction than desctruction!",
  "id" : 55689966386286592,
  "in_reply_to_status_id" : 55600689279270912,
  "created_at" : "Wed Apr 06 17:54:57 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55595211274981376",
  "geo" : {
  },
  "id_str" : "55689787360813056",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 go to bed on time brah!!",
  "id" : 55689787360813056,
  "in_reply_to_status_id" : 55595211274981376,
  "created_at" : "Wed Apr 06 17:54:14 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Wimmer",
      "screen_name" : "RoadID",
      "indices" : [ 14, 21 ],
      "id_str" : "36973087",
      "id" : 36973087
    }, {
      "name" : "Trek Travel",
      "screen_name" : "TrekTravel",
      "indices" : [ 40, 51 ],
      "id_str" : "21712457",
      "id" : 21712457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55689236296368129",
  "text" : "I entered the @RoadID Giveaway to win a @TrekTravel trip to the Tour de France and more. http://bit.ly/h0c5IK",
  "id" : 55689236296368129,
  "created_at" : "Wed Apr 06 17:52:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55680983558656000",
  "geo" : {
  },
  "id_str" : "55686517489807360",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e haha got my cords for graduation in the fall too :)",
  "id" : 55686517489807360,
  "in_reply_to_status_id" : 55680983558656000,
  "created_at" : "Wed Apr 06 17:41:15 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "55656067614507009",
  "text" : "is accepting an invitation to join the Pi Mu Epsilon national mathematicsal honor society after class, woop woop http://4sq.com/fmmNbu",
  "id" : 55656067614507009,
  "created_at" : "Wed Apr 06 15:40:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55103831008219136",
  "text" : "just built a bike wheel! not entirely true yet, but it was pretty easy really. it's raining now, boooo....bed",
  "id" : 55103831008219136,
  "created_at" : "Tue Apr 05 03:05:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 77, 87 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55015882388291585",
  "text" : "beautiful ride. goin to help Edoardo build a table and then Moe's before the @vtcycling meeting!",
  "id" : 55015882388291585,
  "created_at" : "Mon Apr 04 21:16:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54992591632089089",
  "text" : "numerical analysis HW done, time for a ride!",
  "id" : 54992591632089089,
  "created_at" : "Mon Apr 04 19:43:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54647958133682176",
  "geo" : {
  },
  "id_str" : "54943038123950080",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 no sir, I'm gonna be in Blacksburg this summer for an REU @vbiatvt",
  "id" : 54943038123950080,
  "in_reply_to_status_id" : 54647958133682176,
  "created_at" : "Mon Apr 04 16:26:55 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54914239013457920",
  "geo" : {
  },
  "id_str" : "54938621932871681",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 that's what she said",
  "id" : 54938621932871681,
  "in_reply_to_status_id" : 54914239013457920,
  "created_at" : "Mon Apr 04 16:09:22 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "54934202478641152",
  "text" : "sooo warm out!! stuck in class :( (@ McBryde Hall w/ 2 others) http://4sq.com/e44dv8",
  "id" : 54934202478641152,
  "created_at" : "Mon Apr 04 15:51:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 18, 27 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54834799768109056",
  "text" : "done!! yay sleep. @DKnick88 don't know how you do it",
  "id" : 54834799768109056,
  "created_at" : "Mon Apr 04 09:16:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54818634794672128",
  "text" : "wrote a program that worked perfectly...then found it had to do one little thing different. started over...now it's a mess and it's 4am",
  "id" : 54818634794672128,
  "created_at" : "Mon Apr 04 08:12:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54617911008038912",
  "text" : "awesome, though hard, ride to the river and back. high 60's out, yes! making me want to do HW now...no!",
  "id" : 54617911008038912,
  "created_at" : "Sun Apr 03 18:54:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 59, 71 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54566201904476160",
  "text" : "beautiful day today...crazy weather! goin on a bike ride w @VTTriathlon down to the river",
  "id" : 54566201904476160,
  "created_at" : "Sun Apr 03 15:29:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 35, 48 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54562628533628930",
  "text" : "congrats on the win last night! RT @williamenium I won das spandex classic",
  "id" : 54562628533628930,
  "created_at" : "Sun Apr 03 15:15:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 3, 16 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 51, 62 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spandexclassic",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54341408894623744",
  "text" : "RT @williamenium: Getting down to crunch time with @andyreagan for #spandexclassic",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 33, 44 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spandexclassic",
        "indices" : [ 49, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "54330708721799168",
    "text" : "Getting down to crunch time with @andyreagan for #spandexclassic",
    "id" : 54330708721799168,
    "created_at" : "Sat Apr 02 23:53:45 +0000 2011",
    "user" : {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "protected" : false,
      "id_str" : "25713870",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3000920642/c373789737cf47f7a99efe0a4b414eb3_normal.jpeg",
      "id" : 25713870,
      "verified" : false
    }
  },
  "id" : 54341408894623744,
  "created_at" : "Sun Apr 03 00:36:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 3, 13 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54341370390908929",
  "text" : "RT @bdoyle613: spandex classic in 30 minutes with the cycling team...should be interesting",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "54340491097018369",
    "text" : "spandex classic in 30 minutes with the cycling team...should be interesting",
    "id" : 54340491097018369,
    "created_at" : "Sun Apr 03 00:32:37 +0000 2011",
    "user" : {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "protected" : false,
      "id_str" : "45430885",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2346604224/alanc8vomddk7i369f9g_normal.jpeg",
      "id" : 45430885,
      "verified" : false
    }
  },
  "id" : 54341370390908929,
  "created_at" : "Sun Apr 03 00:36:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54333580226203648",
  "text" : "EPIC mountian bike ride today up to and across dragons back ridge through the hail and wind. 7 hrs later... gettin ready for SPANDEX CLASSIC",
  "id" : 54333580226203648,
  "created_at" : "Sun Apr 03 00:05:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54152662559637504",
  "text" : "up at 7:30am on a saturday? yup. goin to get some groceries so I can make breakfast!",
  "id" : 54152662559637504,
  "created_at" : "Sat Apr 02 12:06:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 72, 79 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54012063831429120",
  "text" : "awesome day today, got lots of things done, bottled beer, rode horses w @rkay21 and now I'm exhaustedddd. goin to bed 4 MTBing tomorrow!!",
  "id" : 54012063831429120,
  "created_at" : "Sat Apr 02 02:47:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "53843114468708352",
  "text" : "advanced calc hw was really tough, but he's giving us till Monday to hand it in now... (@ McBryde Hall) http://4sq.com/fWp6SV",
  "id" : 53843114468708352,
  "created_at" : "Fri Apr 01 15:36:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]