Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reallife",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186266875162935298",
  "text" : "sorry but if you havent roasted a marshmellow golden brown over an open fire and made that a delicious smore, you havent lived #reallife",
  "id" : 186266875162935298,
  "created_at" : "Sun Apr 01 01:40:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186193473614000128",
  "text" : "I can understand the reasons, but still it's a pain to have airports so far from the actual cities!",
  "id" : 186193473614000128,
  "created_at" : "Sat Mar 31 20:49:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/REfHi5NT",
      "expanded_url" : "http://4sq.com/H0k6iZ",
      "display_url" : "4sq.com/H0k6iZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.8766716953, -78.7930440903 ]
  },
  "id_str" : "186180775832584193",
  "text" : "73 degrees in NC? Okkkkk (@ Raleigh-Durham International Airport (RDU) w/ 25 others) http://t.co/REfHi5NT",
  "id" : 186180775832584193,
  "created_at" : "Sat Mar 31 19:58:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hopethistweetdoesntcrashtheplane",
      "indices" : [ 48, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186165438152052736",
  "geo" : {
  },
  "id_str" : "186168040583462913",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e I'll be in DCA again on Thurs from 8-10 #hopethistweetdoesntcrashtheplane",
  "id" : 186168040583462913,
  "in_reply_to_status_id" : 186165438152052736,
  "created_at" : "Sat Mar 31 19:08:14 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186165438152052736",
  "geo" : {
  },
  "id_str" : "186165613578821632",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e Raliegh NC for a nerd fest (math conference!!)",
  "id" : 186165613578821632,
  "in_reply_to_status_id" : 186165438152052736,
  "created_at" : "Sat Mar 31 18:58:35 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186163059532894209",
  "geo" : {
  },
  "id_str" : "186165326914920450",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e I had a good 20min layover on the way down, I might have an hour on the way back? I'll let you know!!",
  "id" : 186165326914920450,
  "in_reply_to_status_id" : 186163059532894209,
  "created_at" : "Sat Mar 31 18:57:27 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/AyQl8ZBx",
      "expanded_url" : "http://4sq.com/H6ghxn",
      "display_url" : "4sq.com/H6ghxn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8530437018, -77.0423126221 ]
  },
  "id_str" : "186148939588845569",
  "text" : "I'm at Ronald Reagan Washington National Airport (DCA) (Arlington, VA) w/ 38 others http://t.co/AyQl8ZBx",
  "id" : 186148939588845569,
  "created_at" : "Sat Mar 31 17:52:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley james",
      "screen_name" : "ashleyjames100",
      "indices" : [ 3, 18 ],
      "id_str" : "334513216",
      "id" : 334513216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186119667092439040",
  "text" : "RT @ashleyjames100: Didn't win the lottery last night but real life is still pretty rad.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "186102402166956033",
    "text" : "Didn't win the lottery last night but real life is still pretty rad.",
    "id" : 186102402166956033,
    "created_at" : "Sat Mar 31 14:47:24 +0000 2012",
    "user" : {
      "name" : "ashley james",
      "screen_name" : "ashleyjames100",
      "protected" : false,
      "id_str" : "334513216",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3288504479/46010fc708ff6f7905fe397077befb56_normal.jpeg",
      "id" : 334513216,
      "verified" : false
    }
  },
  "id" : 186119667092439040,
  "created_at" : "Sat Mar 31 15:56:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186117802984345600",
  "text" : "waiting for my flight now, lost my toothpaste though",
  "id" : 186117802984345600,
  "created_at" : "Sat Mar 31 15:48:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186096729479847936",
  "geo" : {
  },
  "id_str" : "186097038050590723",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 good luck!!!!!",
  "id" : 186097038050590723,
  "in_reply_to_status_id" : 186096729479847936,
  "created_at" : "Sat Mar 31 14:26:06 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 3, 13 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185870330240307202",
  "text" : "RT @NRVLiving: It's Beer 6:42.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "185859379919200256",
    "text" : "It's Beer 6:42.",
    "id" : 185859379919200256,
    "created_at" : "Fri Mar 30 22:41:43 +0000 2012",
    "user" : {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "protected" : false,
      "id_str" : "9463702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1787766827/Jeremy_normal.jpg",
      "id" : 9463702,
      "verified" : false
    }
  },
  "id" : 185870330240307202,
  "created_at" : "Fri Mar 30 23:25:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185816609162670080",
  "geo" : {
  },
  "id_str" : "185817262442287104",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 omg wow! why am I not there right now?!?!",
  "id" : 185817262442287104,
  "in_reply_to_status_id" : 185816609162670080,
  "created_at" : "Fri Mar 30 19:54:22 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 31 ],
      "url" : "https://t.co/JFUJgkhv",
      "expanded_url" : "https://twitter.com/#!/BartYasso/status/185805435276763138",
      "display_url" : "twitter.com/#!/BartYasso/s…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185807894887936000",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy https://t.co/JFUJgkhv",
  "id" : 185807894887936000,
  "created_at" : "Fri Mar 30 19:17:08 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185762491920420865",
  "geo" : {
  },
  "id_str" : "185777549564067840",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 awesomeeeee!!",
  "id" : 185777549564067840,
  "in_reply_to_status_id" : 185762491920420865,
  "created_at" : "Fri Mar 30 17:16:34 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 0, 13 ],
      "id_str" : "285218603",
      "id" : 285218603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185748828543123456",
  "geo" : {
  },
  "id_str" : "185749153404555264",
  "in_reply_to_user_id" : 285218603,
  "text" : "@EStoeckeler4 I see what you did there",
  "id" : 185749153404555264,
  "in_reply_to_status_id" : 185748828543123456,
  "created_at" : "Fri Mar 30 15:23:43 +0000 2012",
  "in_reply_to_screen_name" : "EStoeckeler4",
  "in_reply_to_user_id_str" : "285218603",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 0, 13 ],
      "id_str" : "285218603",
      "id" : 285218603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/af4ZPGnD",
      "expanded_url" : "http://www.target.com/p/Conair-Footbath-with-Bubbles-Heat/-/A-13719515?ref=tgt_adv_XSG10001&AFID=Google_PLA_df&LNM=%7C13719515&CPNG=health%20beauty&ci_sku=13719515&ci_gpa=pla&ci_kw=",
      "display_url" : "target.com/p/Conair-Footb…"
    } ]
  },
  "in_reply_to_status_id_str" : "185745916010041344",
  "geo" : {
  },
  "id_str" : "185747938994163712",
  "in_reply_to_user_id" : 285218603,
  "text" : "@EStoeckeler4 http://t.co/af4ZPGnD",
  "id" : 185747938994163712,
  "in_reply_to_status_id" : 185745916010041344,
  "created_at" : "Fri Mar 30 15:18:54 +0000 2012",
  "in_reply_to_screen_name" : "EStoeckeler4",
  "in_reply_to_user_id_str" : "285218603",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 3, 14 ],
      "id_str" : "355569678",
      "id" : 355569678
    }, {
      "name" : "UVMtv",
      "screen_name" : "UVMtv",
      "indices" : [ 41, 47 ],
      "id_str" : "14330309",
      "id" : 14330309
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 77, 89 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVM",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185742002695061504",
  "text" : "RT @erik_ryden: Be sure to follow me and @UVMtv all day as we live tweet the @BarackObama event here at #UVM!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UVMtv",
        "screen_name" : "UVMtv",
        "indices" : [ 25, 31 ],
        "id_str" : "14330309",
        "id" : 14330309
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 61, 73 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UVM",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "185710529581559808",
    "text" : "Be sure to follow me and @UVMtv all day as we live tweet the @BarackObama event here at #UVM!",
    "id" : 185710529581559808,
    "created_at" : "Fri Mar 30 12:50:15 +0000 2012",
    "user" : {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "protected" : false,
      "id_str" : "355569678",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1499094307/me_twitpic_normal.JPG",
      "id" : 355569678,
      "verified" : false
    }
  },
  "id" : 185742002695061504,
  "created_at" : "Fri Mar 30 14:55:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185741749480730625",
  "text" : "Burlington already starting to unravel",
  "id" : 185741749480730625,
  "created_at" : "Fri Mar 30 14:54:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtfUVM",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "sweating",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185729691871752192",
  "text" : "approximately 110F in my classroom this morning #wtfUVM #sweating",
  "id" : 185729691871752192,
  "created_at" : "Fri Mar 30 14:06:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ2012",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185645958741245952",
  "text" : "new record for late night math:4:30AM! ready to go #SIAMUQ2012 next week",
  "id" : 185645958741245952,
  "created_at" : "Fri Mar 30 08:33:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 0, 13 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185543029292146688",
  "geo" : {
  },
  "id_str" : "185546165499080704",
  "in_reply_to_user_id" : 328777340,
  "text" : "@DaBrownNoise LOOKING GOOD",
  "id" : 185546165499080704,
  "in_reply_to_status_id" : 185543029292146688,
  "created_at" : "Fri Mar 30 01:57:07 +0000 2012",
  "in_reply_to_screen_name" : "DaBrownNoise",
  "in_reply_to_user_id_str" : "328777340",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185533137294594050",
  "text" : "RT @ChrisDanforth: \"What would you do if you knew you could not fail?\" - Regina Dugan TED talk on Mach 20 flight & unintended consequenc ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/rBnoKua3",
        "expanded_url" : "http://www.ted.com/talks/regina_dugan_from_mach_20_glider_to_humming_bird_drone.html",
        "display_url" : "ted.com/talks/regina_d…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "185520762403295233",
    "text" : "\"What would you do if you knew you could not fail?\" - Regina Dugan TED talk on Mach 20 flight & unintended consequences http://t.co/rBnoKua3",
    "id" : 185520762403295233,
    "created_at" : "Fri Mar 30 00:16:11 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 185533137294594050,
  "created_at" : "Fri Mar 30 01:05:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185524136460820481",
  "geo" : {
  },
  "id_str" : "185528648013594624",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris video evidence required",
  "id" : 185528648013594624,
  "in_reply_to_status_id" : 185524136460820481,
  "created_at" : "Fri Mar 30 00:47:31 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/jjcnZ8w8",
      "expanded_url" : "http://www.pricepoint.com/detail/16645-220_WISSH7-3-Parts-64-Hubs/White-Industries-ENO-Eccentric-Hub.htm",
      "display_url" : "pricepoint.com/detail/16645-2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185219125705060352",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw just getting you started: http://t.co/jjcnZ8w8",
  "id" : 185219125705060352,
  "created_at" : "Thu Mar 29 04:17:35 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 31 ],
      "url" : "https://t.co/F9L143VG",
      "expanded_url" : "https://twitter.com/#!/WiMaCycling/status/185213438778294273",
      "display_url" : "twitter.com/#!/WiMaCycling…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185217061356711936",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD https://t.co/F9L143VG",
  "id" : 185217061356711936,
  "created_at" : "Thu Mar 29 04:09:23 +0000 2012",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bikeradar",
      "screen_name" : "bikeradar",
      "indices" : [ 0, 10 ],
      "id_str" : "17138369",
      "id" : 17138369
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letscleartheair",
      "indices" : [ 33, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 32 ],
      "url" : "https://t.co/F9L143VG",
      "expanded_url" : "https://twitter.com/#!/WiMaCycling/status/185213438778294273",
      "display_url" : "twitter.com/#!/WiMaCycling…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185217009422831617",
  "in_reply_to_user_id" : 17138369,
  "text" : "@bikeradar https://t.co/F9L143VG #letscleartheair",
  "id" : 185217009422831617,
  "created_at" : "Thu Mar 29 04:09:10 +0000 2012",
  "in_reply_to_screen_name" : "bikeradar",
  "in_reply_to_user_id_str" : "17138369",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tribe Cycling Team",
      "screen_name" : "WiMaCycling",
      "indices" : [ 3, 15 ],
      "id_str" : "127751624",
      "id" : 127751624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/jibeXAIE",
      "expanded_url" : "http://fb.me/1BdAavoyM",
      "display_url" : "fb.me/1BdAavoyM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185216849993138177",
  "text" : "RT @WiMaCycling: true statement. http://t.co/jibeXAIE",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http://t.co/jibeXAIE",
        "expanded_url" : "http://fb.me/1BdAavoyM",
        "display_url" : "fb.me/1BdAavoyM"
      } ]
    },
    "geo" : {
    },
    "id_str" : "185213438778294273",
    "text" : "true statement. http://t.co/jibeXAIE",
    "id" : 185213438778294273,
    "created_at" : "Thu Mar 29 03:54:59 +0000 2012",
    "user" : {
      "name" : "Tribe Cycling Team",
      "screen_name" : "WiMaCycling",
      "protected" : false,
      "id_str" : "127751624",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/784900644/websitebanner_normal.jpg",
      "id" : 127751624,
      "verified" : false
    }
  },
  "id" : 185216849993138177,
  "created_at" : "Thu Mar 29 04:08:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185212375069229057",
  "geo" : {
  },
  "id_str" : "185213300114604032",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 I wishhhh!!!! I'm flying to NC for a nerd convention on Saturday (mathematics conference) :(",
  "id" : 185213300114604032,
  "in_reply_to_status_id" : 185212375069229057,
  "created_at" : "Thu Mar 29 03:54:26 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/5nDF4g0N",
      "expanded_url" : "http://www.babyrabies.com/2009/12/how-i-gave-birth-to-my-second-marathon/",
      "display_url" : "babyrabies.com/2009/12/how-i-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185212260032057344",
  "text" : "@chaosdynamics maybe you can relate more to this: http://t.co/5nDF4g0N",
  "id" : 185212260032057344,
  "created_at" : "Thu Mar 29 03:50:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J R",
      "screen_name" : "Navre",
      "indices" : [ 15, 21 ],
      "id_str" : "28290612",
      "id" : 28290612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/liNu8Szi",
      "expanded_url" : "http://www.sciencedirect.com/science/article/pii/S030439599800089X",
      "display_url" : "sciencedirect.com/science/articl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185212147398213632",
  "text" : "@chaosdynamics @Navre during, I never thought I'd do one again, but we tend to forget the pain of those last 5k! http://t.co/liNu8Szi",
  "id" : 185212147398213632,
  "created_at" : "Thu Mar 29 03:49:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damn",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185206609092423680",
  "text" : "going to miss the year's first UVM surplus auction next week #damn",
  "id" : 185206609092423680,
  "created_at" : "Thu Mar 29 03:27:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getonthat",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185203582155493376",
  "geo" : {
  },
  "id_str" : "185206161174315008",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw a whole new level. I expect to see a picture of your slammed fischer fixie on campus before the end of the semester #getonthat",
  "id" : 185206161174315008,
  "in_reply_to_status_id" : 185203582155493376,
  "created_at" : "Thu Mar 29 03:26:04 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 33, 42 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/4jHlPBe0",
      "expanded_url" : "http://www.irunfar.com/2012/03/flow-the-path-to-optimal-experience.html",
      "display_url" : "irunfar.com/2012/03/flow-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185203898712199168",
  "text" : "Have you ever felt the flow? via @Run_Rudy: Flow: The Path to Optimal Experience http://t.co/4jHlPBe0",
  "id" : 185203898712199168,
  "created_at" : "Thu Mar 29 03:17:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/tmn1souZ",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=MrNA7RjU91I",
      "display_url" : "youtube.com/watch?feature=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185201824758898688",
  "text" : "my excitement has reached higher mountaintop highs than ever before: http://t.co/tmn1souZ",
  "id" : 185201824758898688,
  "created_at" : "Thu Mar 29 03:08:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185199805121839104",
  "geo" : {
  },
  "id_str" : "185201422042800129",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw shittt. here's what you do: take the insurance $$ and buy a sweet frame AND a eccentric rear hub + carbon tape = fischer fixie",
  "id" : 185201422042800129,
  "in_reply_to_status_id" : 185199805121839104,
  "created_at" : "Thu Mar 29 03:07:14 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185024592065208321",
  "geo" : {
  },
  "id_str" : "185199328086863873",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris sick!!!",
  "id" : 185199328086863873,
  "in_reply_to_status_id" : 185024592065208321,
  "created_at" : "Thu Mar 29 02:58:55 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185197185082720256",
  "geo" : {
  },
  "id_str" : "185198750497648640",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw whattttt??",
  "id" : 185198750497648640,
  "in_reply_to_status_id" : 185197185082720256,
  "created_at" : "Thu Mar 29 02:56:37 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweetguys",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "totallyfair",
      "indices" : [ 73, 85 ]
    }, {
      "text" : "callinginboundsplays",
      "indices" : [ 86, 107 ]
    }, {
      "text" : "whitebballteamprobz",
      "indices" : [ 108, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185188755106312192",
  "text" : "so apparently the club basketball team also plays intramurals #sweetguys #totallyfair #callinginboundsplays #whitebballteamprobz",
  "id" : 185188755106312192,
  "created_at" : "Thu Mar 29 02:16:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icracked",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185188177760370688",
  "text" : "@chaosdynamics yeah running!!! i have to disagree and say after 23 is the worst though #icracked",
  "id" : 185188177760370688,
  "created_at" : "Thu Mar 29 02:14:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "185148336402202626",
  "text" : "team No Game This Week about drop game on UVM undergrads!",
  "id" : 185148336402202626,
  "created_at" : "Wed Mar 28 23:36:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/9XiqAuHH",
      "expanded_url" : "http://andyreagan.files.wordpress.com/2012/03/hard_integral.pdf",
      "display_url" : "andyreagan.files.wordpress.com/2012/03/hard_i…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185123476976312320",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 http://t.co/9XiqAuHH",
  "id" : 185123476976312320,
  "created_at" : "Wed Mar 28 21:57:30 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185115044911132673",
  "geo" : {
  },
  "id_str" : "185123162323816448",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 safe travels brother!!",
  "id" : 185123162323816448,
  "in_reply_to_status_id" : 185115044911132673,
  "created_at" : "Wed Mar 28 21:56:15 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/aGyHs80W",
      "expanded_url" : "http://www.bakadesuyo.com/if-you-throw-a-cat-off-a-32-story-building-is",
      "display_url" : "bakadesuyo.com/if-you-throw-a…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185087132686237697",
  "text" : "should you throw you cat out the window? if it's over 7 stories, won't hurt http://t.co/aGyHs80W",
  "id" : 185087132686237697,
  "created_at" : "Wed Mar 28 19:33:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/HZNcK82V",
      "expanded_url" : "http://www.nytimes.com/2009/11/01/weekinreview/01kershaw.html?_r=1&partner=rss&emc=rss",
      "display_url" : "nytimes.com/2009/11/01/wee…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185086727742947328",
  "text" : "how smart is your dog? a bordie collie once learned 1500 words, only seeing them once, and remembered a month later http://t.co/HZNcK82V",
  "id" : 185086727742947328,
  "created_at" : "Wed Mar 28 19:31:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SLAM THAT STEM",
      "screen_name" : "SLAMTHATSTEM",
      "indices" : [ 3, 16 ],
      "id_str" : "231447953",
      "id" : 231447953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/vBQMEKZ5",
      "expanded_url" : "http://tmblr.co/ZXkVSyIiDuFb",
      "display_url" : "tmblr.co/ZXkVSyIiDuFb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185081366986244097",
  "text" : "RT @SLAMTHATSTEM: Photo: Andy got a Kazane at VT, then he went to UVM, where he slammmed it for AMERICA. http://t.co/vBQMEKZ5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/vBQMEKZ5",
        "expanded_url" : "http://tmblr.co/ZXkVSyIiDuFb",
        "display_url" : "tmblr.co/ZXkVSyIiDuFb"
      } ]
    },
    "geo" : {
    },
    "id_str" : "185063779074179072",
    "text" : "Photo: Andy got a Kazane at VT, then he went to UVM, where he slammmed it for AMERICA. http://t.co/vBQMEKZ5",
    "id" : 185063779074179072,
    "created_at" : "Wed Mar 28 18:00:17 +0000 2012",
    "user" : {
      "name" : "SLAM THAT STEM",
      "screen_name" : "SLAMTHATSTEM",
      "protected" : false,
      "id_str" : "231447953",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1214649607/slammed_normal.jpg",
      "id" : 231447953,
      "verified" : false
    }
  },
  "id" : 185081366986244097,
  "created_at" : "Wed Mar 28 19:10:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/O1w5vVbV",
      "expanded_url" : "http://slamthatstem.com/tagged/uvm",
      "display_url" : "slamthatstem.com/tagged/uvm"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/GCfrpc7z",
      "expanded_url" : "http://fb.me/1ALBO1zpH",
      "display_url" : "fb.me/1ALBO1zpH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185081086605406209",
  "text" : "RT @UVM_cycling: This is how we do it in Vermont: http://t.co/O1w5vVbV \nExcellent work Andy. http://t.co/GCfrpc7z",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http://t.co/O1w5vVbV",
        "expanded_url" : "http://slamthatstem.com/tagged/uvm",
        "display_url" : "slamthatstem.com/tagged/uvm"
      }, {
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/GCfrpc7z",
        "expanded_url" : "http://fb.me/1ALBO1zpH",
        "display_url" : "fb.me/1ALBO1zpH"
      } ]
    },
    "geo" : {
    },
    "id_str" : "185080062515740674",
    "text" : "This is how we do it in Vermont: http://t.co/O1w5vVbV \nExcellent work Andy. http://t.co/GCfrpc7z",
    "id" : 185080062515740674,
    "created_at" : "Wed Mar 28 19:05:00 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 185081086605406209,
  "created_at" : "Wed Mar 28 19:09:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185076765239148544",
  "geo" : {
  },
  "id_str" : "185077463875985408",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 I'd happily trade! I'll even tell you the answer to mine, it's pi^3/8, but you have to find out how to get that",
  "id" : 185077463875985408,
  "in_reply_to_status_id" : 185076765239148544,
  "created_at" : "Wed Mar 28 18:54:40 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/xzmjHpqR",
      "expanded_url" : "http://www.bikeradar.com/news/article/video-specialized-turbo-the-worlds-fastest-electric-bike-33568/",
      "display_url" : "bikeradar.com/news/article/v…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185077089727287296",
  "text" : "sweet bike, but it's illegal here bc it goes 28mph...but I can bike that fast w/o motor, am I illegal?! http://t.co/xzmjHpqR",
  "id" : 185077089727287296,
  "created_at" : "Wed Mar 28 18:53:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185070938738536448",
  "geo" : {
  },
  "id_str" : "185075884674383872",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 ah but one must understand a problem to tell a computer to do it for them, and just bc \"Wolfram understands\" I wont get an A",
  "id" : 185075884674383872,
  "in_reply_to_status_id" : 185070938738536448,
  "created_at" : "Wed Mar 28 18:48:24 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/hJEzsAV4",
      "expanded_url" : "http://www.bikeradar.com/beginners/news/article/boston-ma-gym-powered-by-spin-bikes-33573/",
      "display_url" : "bikeradar.com/beginners/news…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "185042792840564737",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/hJEzsAV4",
  "id" : 185042792840564737,
  "created_at" : "Wed Mar 28 16:36:54 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184893910563299328",
  "text" : "defeated by complex analysis...long night! anybody got a better idea how to integrate log^2 z / (1 + z^2) let me know!!",
  "id" : 184893910563299328,
  "created_at" : "Wed Mar 28 06:45:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM",
      "screen_name" : "uvmvermont",
      "indices" : [ 0, 11 ],
      "id_str" : "29447794",
      "id" : 29447794
    }, {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "indices" : [ 12, 19 ],
      "id_str" : "394388191",
      "id" : 394388191
    }, {
      "name" : "Kiersten Hallquist",
      "screen_name" : "KHallquist08",
      "indices" : [ 20, 33 ],
      "id_str" : "242310818",
      "id" : 242310818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184647793904857089",
  "geo" : {
  },
  "id_str" : "184667206431420416",
  "in_reply_to_user_id" : 29447794,
  "text" : "@uvmvermont @UVMBUG @KHallquist08 there is a pump in Farrell Hall, 2nd floor, right inside the grad student room. feel free to use!",
  "id" : 184667206431420416,
  "in_reply_to_status_id" : 184647793904857089,
  "created_at" : "Tue Mar 27 15:44:27 +0000 2012",
  "in_reply_to_screen_name" : "uvmvermont",
  "in_reply_to_user_id_str" : "29447794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pain",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184644459433181184",
  "text" : "cleaning your room in the internet age means organizing your downloads folder #pain",
  "id" : 184644459433181184,
  "created_at" : "Tue Mar 27 14:14:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/DVuUtef6",
      "expanded_url" : "http://shop.rogaine.com/",
      "display_url" : "shop.rogaine.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184481231637975040",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 if he's worth his salt he can photoshop some hair! and the latest infomercials tell me it's better than ever: http://t.co/DVuUtef6",
  "id" : 184481231637975040,
  "created_at" : "Tue Mar 27 03:25:27 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184477780338159617",
  "geo" : {
  },
  "id_str" : "184479452254834688",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet excellent!!",
  "id" : 184479452254834688,
  "in_reply_to_status_id" : 184477780338159617,
  "created_at" : "Tue Mar 27 03:18:23 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 1, 13 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 41, 53 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/mhEHfGUJ",
      "expanded_url" : "http://yfrog.com/kg8d8gyrj",
      "display_url" : "yfrog.com/kg8d8gyrj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184443119356489728",
  "text" : ".@bikingbiebs preparing to go to space w @UVM_cycling http://t.co/mhEHfGUJ",
  "id" : 184443119356489728,
  "created_at" : "Tue Mar 27 00:54:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "success",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/Vo2KBB7C",
      "expanded_url" : "http://yfrog.com/g017741935j",
      "display_url" : "yfrog.com/g017741935j"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184437321347772416",
  "text" : "no such thing as bad weather, just bad clothing. 30 deg and 40mph wind gusts...only one dry spot on shirt! #success http://t.co/Vo2KBB7C",
  "id" : 184437321347772416,
  "created_at" : "Tue Mar 27 00:30:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 95, 103 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/91sokSwK",
      "expanded_url" : "http://bit.ly/H9m94W",
      "display_url" : "bit.ly/H9m94W"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184414128159461377",
  "text" : "Quick yog to the north end by andyreagan at Garmin Connect - Details: http://t.co/91sokSwK via @AddThis",
  "id" : 184414128159461377,
  "created_at" : "Mon Mar 26 22:58:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184373539514748930",
  "geo" : {
  },
  "id_str" : "184381869612216320",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 you're training for a marathon! a sprint triathlon is like 1/10 the difficulty tops (I counted an olympic dist as a training run)!",
  "id" : 184381869612216320,
  "in_reply_to_status_id" : 184373539514748930,
  "created_at" : "Mon Mar 26 20:50:38 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 12, 19 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Endurance Monster",
      "screen_name" : "EnMonster",
      "indices" : [ 24, 34 ],
      "id_str" : "363191526",
      "id" : 363191526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/uUJdbG3P",
      "expanded_url" : "http://fb.me/1PWGXqELS",
      "display_url" : "fb.me/1PWGXqELS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184373373692944384",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 @sspis1 \"RT @EnMonster Gilly Girl's Sprint Triathlon http://t.co/uUJdbG3P\"",
  "id" : 184373373692944384,
  "created_at" : "Mon Mar 26 20:16:52 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184362920757575682",
  "geo" : {
  },
  "id_str" : "184364517239697409",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 I think you mean \"If only I went to bed at 8PM...\" but really, you probably only need to do it a couple times so you're good",
  "id" : 184364517239697409,
  "in_reply_to_status_id" : 184362920757575682,
  "created_at" : "Mon Mar 26 19:41:40 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184362536521564160",
  "text" : "want to go for a run...but now its 30 and suuper windy after that week of summer, making it tough!",
  "id" : 184362536521564160,
  "created_at" : "Mon Mar 26 19:33:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 29 ],
      "url" : "https://t.co/nsc6zceF",
      "expanded_url" : "https://twitter.com/#!/jhboston26/status/184293279930650625",
      "display_url" : "twitter.com/#!/jhboston26/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184362208237592576",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 https://t.co/nsc6zceF",
  "id" : 184362208237592576,
  "created_at" : "Mon Mar 26 19:32:30 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SLAM THAT STEM",
      "screen_name" : "SLAMTHATSTEM",
      "indices" : [ 19, 32 ],
      "id_str" : "231447953",
      "id" : 231447953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slam",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184296918162210816",
  "text" : "you need to follow @SLAMTHATSTEM today to see how NOT to set up your bike #slam",
  "id" : 184296918162210816,
  "created_at" : "Mon Mar 26 15:13:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "184285000487804928",
  "text" : "things I've gotten better at with age include sleeping through alarms (rather, turning them off in my sleep)",
  "id" : 184285000487804928,
  "created_at" : "Mon Mar 26 14:25:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/gMuNLOj3",
      "expanded_url" : "http://yfrog.com/kkfwfrbj",
      "display_url" : "yfrog.com/kkfwfrbj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184117772681347073",
  "text" : "nice cool night on the porch with beer in hand, beer on boil! http://t.co/gMuNLOj3",
  "id" : 184117772681347073,
  "created_at" : "Mon Mar 26 03:21:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latenightbrew",
      "indices" : [ 16, 30 ]
    }, {
      "text" : "homebrew",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/K7TeH1I8",
      "expanded_url" : "http://yfrog.com/nukgqrpj",
      "display_url" : "yfrog.com/nukgqrpj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184104927109464065",
  "text" : "all burners go! #latenightbrew #homebrew http://t.co/K7TeH1I8",
  "id" : 184104927109464065,
  "created_at" : "Mon Mar 26 02:30:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "indices" : [ 3, 16 ],
      "id_str" : "490982935",
      "id" : 490982935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/9BaxKC48",
      "expanded_url" : "http://goo.gl/TyMEz",
      "display_url" : "goo.gl/TyMEz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184077897567449088",
  "text" : "RT @AlanHungover: You'll never look at food the same way again after you read these funny autocorrects! http://t.co/9BaxKC48 LOL",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/9BaxKC48",
        "expanded_url" : "http://goo.gl/TyMEz",
        "display_url" : "goo.gl/TyMEz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "184059680513998848",
    "text" : "You'll never look at food the same way again after you read these funny autocorrects! http://t.co/9BaxKC48 LOL",
    "id" : 184059680513998848,
    "created_at" : "Sun Mar 25 23:30:22 +0000 2012",
    "user" : {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "protected" : false,
      "id_str" : "490982935",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1825288290/gifsmall_normal.gif",
      "id" : 490982935,
      "verified" : false
    }
  },
  "id" : 184077897567449088,
  "created_at" : "Mon Mar 26 00:42:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/ksWIsyrG",
      "expanded_url" : "http://yfrog.com/ntxz1ylj",
      "display_url" : "yfrog.com/ntxz1ylj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "184019073926037504",
  "text" : "attention farrell hall peeps, get ready to foose!! http://t.co/ksWIsyrG",
  "id" : 184019073926037504,
  "created_at" : "Sun Mar 25 20:49:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/qIs9vkMX",
      "expanded_url" : "http://www.ebay.com/itm/Vintage-Sony-Walkman-AM-FM-Tape-WM-FX28-Tested-and-works-/200731517769?pt=Cassette_Players&hash=item2ebc87e349",
      "display_url" : "ebay.com/itm/Vintage-So…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "183781627124662272",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 like this? http://t.co/qIs9vkMX",
  "id" : 183781627124662272,
  "created_at" : "Sun Mar 25 05:05:29 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183765397936418816",
  "text" : "\"All models are wrong, but some are useful.\" -George Box",
  "id" : 183765397936418816,
  "created_at" : "Sun Mar 25 04:00:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183691712324055040",
  "geo" : {
  },
  "id_str" : "183696549006675968",
  "in_reply_to_user_id" : 361592148,
  "text" : "@3TriDRHECK that's one hell of a year!!!",
  "id" : 183696549006675968,
  "in_reply_to_status_id" : 183691712324055040,
  "created_at" : "Sat Mar 24 23:27:24 +0000 2012",
  "in_reply_to_screen_name" : "DREK_3",
  "in_reply_to_user_id_str" : "361592148",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vermontweather",
      "indices" : [ 87, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183677498482106368",
  "text" : "every time I get it my car, I'm flipping the heat from full cold to full heat and back #vermontweather",
  "id" : 183677498482106368,
  "created_at" : "Sat Mar 24 22:11:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 31, 39 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 109, 117 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/kSk4aBeo",
      "expanded_url" : "http://bit.ly/H1OJ7l",
      "display_url" : "bit.ly/H1OJ7l"
    } ]
  },
  "geo" : {
  },
  "id_str" : "183652068525998080",
  "text" : "crazy, awesome adventure run w @Karo1yn. by andyreagan at Garmin Connect - Details: http://t.co/kSk4aBeo via @AddThis",
  "id" : 183652068525998080,
  "created_at" : "Sat Mar 24 20:30:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183580372800503808",
  "text" : "just mailed back the cycling shoes that I \"borrowed\" from my roommate freshman year",
  "id" : 183580372800503808,
  "created_at" : "Sat Mar 24 15:45:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/dbml5eWA",
      "expanded_url" : "http://twitpic.com/90cib1",
      "display_url" : "twitpic.com/90cib1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "183326193976745985",
  "text" : "and I present to you, creamy chocolate vodka http://t.co/dbml5eWA",
  "id" : 183326193976745985,
  "created_at" : "Fri Mar 23 22:55:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183283835625144320",
  "text" : "do YOU need to hear the shape of a (pinched) sphere? Dr John Voight to the rescue!",
  "id" : 183283835625144320,
  "created_at" : "Fri Mar 23 20:07:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183266419465666561",
  "text" : "\"to act on a model, you have to own it\"",
  "id" : 183266419465666561,
  "created_at" : "Fri Mar 23 18:58:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 1, 15 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complexity",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/075uP0fs",
      "expanded_url" : "http://twitpic.com/909sy3",
      "display_url" : "twitpic.com/909sy3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "183259743161294848",
  "text" : ".@uvmcomplexity SPIRE Speaker Series: Bob Glass on Complex Adaptive Systems of Systems #complexity http://t.co/075uP0fs",
  "id" : 183259743161294848,
  "created_at" : "Fri Mar 23 18:31:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 115, 127 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "183238484176289793",
  "text" : "knew it was going to happen eventually, and this is the weekend grad school wins over bike racing, best of luck to @UVM_cycling!",
  "id" : 183238484176289793,
  "created_at" : "Fri Mar 23 17:07:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.pandora.com\" rel=\"nofollow\">Pandora</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pandora",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/xT0wZG9y",
      "expanded_url" : "http://bit.ly/GOo1Bd",
      "display_url" : "bit.ly/GOo1Bd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "182994237460197377",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 diggin the harmonica, must learn http://t.co/xT0wZG9y\n #pandora",
  "id" : 182994237460197377,
  "created_at" : "Fri Mar 23 00:56:40 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182987480239321089",
  "text" : "RT @dr_pyser: over 1000 people have looked at my blog post on the happiest place in new york in the past 8 hours. thank you team! http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/5PYA6VbF",
        "expanded_url" : "http://wp.me/p1vafz-5D",
        "display_url" : "wp.me/p1vafz-5D"
      } ]
    },
    "geo" : {
    },
    "id_str" : "182983133090676738",
    "text" : "over 1000 people have looked at my blog post on the happiest place in new york in the past 8 hours. thank you team! http://t.co/5PYA6VbF",
    "id" : 182983133090676738,
    "created_at" : "Fri Mar 23 00:12:33 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 182987480239321089,
  "created_at" : "Fri Mar 23 00:29:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182983270139576321",
  "text" : "with a seatpost shim from Old Spokes, I had a lovely ride on Kazane 2.0: TT Bike Edition. felt like a missile holding 35mph with a tailwind",
  "id" : 182983270139576321,
  "created_at" : "Fri Mar 23 00:13:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triday",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182896662275039232",
  "text" : "did work on real analysis in the AM, got an hour in the pool, and then my class done. a ride and run in this steamy weather later! #triday",
  "id" : 182896662275039232,
  "created_at" : "Thu Mar 22 18:28:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182625407009427458",
  "geo" : {
  },
  "id_str" : "182632221797122048",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser if by won you mean dominated!",
  "id" : 182632221797122048,
  "in_reply_to_status_id" : 182625407009427458,
  "created_at" : "Thu Mar 22 00:58:09 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 86, 100 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182625594289295362",
  "text" : "next week, No Game This Week wears short shorts and high socks (so, normal attire for @chrisdanforth)",
  "id" : 182625594289295362,
  "created_at" : "Thu Mar 22 00:31:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182624441891692546",
  "text" : "team No Game This Week starts out 1-0",
  "id" : 182624441891692546,
  "created_at" : "Thu Mar 22 00:27:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182313961696395266",
  "text" : "and that's a night of real analysis HW.",
  "id" : 182313961696395266,
  "created_at" : "Wed Mar 21 03:53:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182265280335069185",
  "text" : "riding on a front wheel that I built up from hub, spokes, and rim felt awesome too. another level from self adjusted drivetrain",
  "id" : 182265280335069185,
  "created_at" : "Wed Mar 21 00:40:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182264932421734401",
  "text" : "good ride, felt like summer... although Burlington's TNW aren't quite up to par with Blacksburg's WW",
  "id" : 182264932421734401,
  "created_at" : "Wed Mar 21 00:38:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgradproblems",
      "indices" : [ 46, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182159224774725632",
  "text" : "running out of greek letters in our equations #mathgradproblems",
  "id" : 182159224774725632,
  "created_at" : "Tue Mar 20 17:38:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "182148824431722496",
  "text" : "it appears that I got a 0 on the Putnam exam...out of 120. Highest score at VT was a 2, only 4 ppl of the 10 taking it score points #ouch",
  "id" : 182148824431722496,
  "created_at" : "Tue Mar 20 16:57:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 31, 47 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 52, 61 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/N5KulJVF",
      "expanded_url" : "http://burlington.craigslist.org/rvs/2900551645.html",
      "display_url" : "burlington.craigslist.org/rvs/2900551645…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "181912387828457474",
  "text" : "was sort-of joking when I told @RumblinStumblin and @dmreagan abt http://t.co/N5KulJVF for living next year...they liked the idea?!",
  "id" : 181912387828457474,
  "created_at" : "Tue Mar 20 01:17:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 7, 21 ],
      "id_str" : "113114946",
      "id" : 113114946
    }, {
      "name" : "Rich Kramp",
      "screen_name" : "skirack",
      "indices" : [ 40, 48 ],
      "id_str" : "16541004",
      "id" : 16541004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181854145374990337",
  "text" : "got my @ChrisKingBuzz hub to Burlington @skirack for a warranty repair: the reason I bought wheels from a company that stands behind product",
  "id" : 181854145374990337,
  "created_at" : "Mon Mar 19 21:26:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 90, 97 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181853091711295488",
  "text" : "just got back from a quality SAYG ride and had a package at the door from brockport! from @sspis1 :)",
  "id" : 181853091711295488,
  "created_at" : "Mon Mar 19 21:22:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181599966408622080",
  "text" : "home, unpacked, and a backup of my website rolling. time for bed! swim at 7AM? unlikely",
  "id" : 181599966408622080,
  "created_at" : "Mon Mar 19 04:36:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 75, 87 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181587424676294656",
  "text" : "almost back to Burlington, such a long drive! notes: you will be judged by @UVM_cycling for inability 2 change flats, and only I patch tubes",
  "id" : 181587424676294656,
  "created_at" : "Mon Mar 19 03:46:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181533220452581376",
  "text" : "van discussion: the acceptability of racing expensive bikes in entry categories. my take: more power to ya. but dave would be very offended",
  "id" : 181533220452581376,
  "created_at" : "Mon Mar 19 00:11:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181468758789996544",
  "text" : "had a great time racing a tight, rough 4-corner crit on Temple's campus. Attacked once, and finished w the field in 12th place",
  "id" : 181468758789996544,
  "created_at" : "Sun Mar 18 19:54:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 1, 13 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/RvtP9ZYk",
      "expanded_url" : "http://twitpic.com/8y0e03",
      "display_url" : "twitpic.com/8y0e03"
    } ]
  },
  "geo" : {
  },
  "id_str" : "181368470951305217",
  "text" : ".@uvm_cycling 's Men's C team on course! http://t.co/RvtP9ZYk",
  "id" : 181368470951305217,
  "created_at" : "Sun Mar 18 13:16:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 17, 31 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/A9TZ0P6j",
      "expanded_url" : "http://twitpic.com/8xzf8k",
      "display_url" : "twitpic.com/8xzf8k"
    } ]
  },
  "geo" : {
  },
  "id_str" : "181349866885222401",
  "text" : "can't believe my @ChrisKingBuzz R45 front hub just broke while I was taking apart to adjust pre-tension... http://t.co/A9TZ0P6j",
  "id" : 181349866885222401,
  "created_at" : "Sun Mar 18 12:02:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 20, 32 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181196532664639488",
  "text" : "just watched former @UVM_cycling's Isaac Howe win the @usacrit!!",
  "id" : 181196532664639488,
  "created_at" : "Sun Mar 18 01:53:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181166220509315072",
  "text" : "checked out Riften square and walking around Philly, nice city! at least the parts we're near",
  "id" : 181166220509315072,
  "created_at" : "Sat Mar 17 23:52:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181144647073140736",
  "text" : "finished in the pack in the road race today, should've been more aggressive but that's too easy to say now. post race chillin like summer",
  "id" : 181144647073140736,
  "created_at" : "Sat Mar 17 22:27:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "181047980420382720",
  "text" : "RT @UVM_cycling: Men's B and C both 2nd in their respective TTT's this morning.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "181043891678617600",
    "text" : "Men's B and C both 2nd in their respective TTT's this morning.",
    "id" : 181043891678617600,
    "created_at" : "Sat Mar 17 15:46:42 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 181047980420382720,
  "created_at" : "Sat Mar 17 16:02:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180970734233993216",
  "text" : "collegiate bike racing!! aka up before the sun rises and getting ready to race",
  "id" : 180970734233993216,
  "created_at" : "Sat Mar 17 10:55:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/Ie2c8XKn",
      "expanded_url" : "http://twitpic.com/8xb7iq",
      "display_url" : "twitpic.com/8xb7iq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "180861964367568897",
  "text" : "sleeping on the rooftop, view of Philly skyline http://t.co/Ie2c8XKn",
  "id" : 180861964367568897,
  "created_at" : "Sat Mar 17 03:43:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180843952130375681",
  "text" : "almost to Philly! Passenger van convos w cycling folks classic as always. and reading about framebuilding, so exciting!",
  "id" : 180843952130375681,
  "created_at" : "Sat Mar 17 02:32:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 56, 71 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180700047808278528",
  "text" : "one more class then I'm packing and on my way to Philly @ryandelgiudice",
  "id" : 180700047808278528,
  "created_at" : "Fri Mar 16 17:00:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 15, 27 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/BWRyyAD2",
      "expanded_url" : "http://twitpic.com/8wt43z",
      "display_url" : "twitpic.com/8wt43z"
    } ]
  },
  "geo" : {
  },
  "id_str" : "180448089990115330",
  "text" : "awesome ride w @UVM_cycling and @UVM_triathlon!! And got my official UVM cycling kit, so official! http://t.co/BWRyyAD2",
  "id" : 180448089990115330,
  "created_at" : "Fri Mar 16 00:19:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180155671365431296",
  "text" : "homework typed up and in bed before 1AM, solid day!",
  "id" : 180155671365431296,
  "created_at" : "Thu Mar 15 04:57:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Men's Basketball",
      "screen_name" : "UVMmbb",
      "indices" : [ 3, 10 ],
      "id_str" : "48733261",
      "id" : 48733261
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVM",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180070053415362560",
  "text" : "RT @UVMmbb: #UVM builds 22-12 lead over Lamar with 7:18 remaining in the first half, we're at the 3rd media timeout.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UVM",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "180067972650500096",
    "text" : "#UVM builds 22-12 lead over Lamar with 7:18 remaining in the first half, we're at the 3rd media timeout.",
    "id" : 180067972650500096,
    "created_at" : "Wed Mar 14 23:08:44 +0000 2012",
    "user" : {
      "name" : "UVM Men's Basketball",
      "screen_name" : "UVMmbb",
      "protected" : false,
      "id_str" : "48733261",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2656154419/d1c0642db75b100620a3c093ddc37abd_normal.jpeg",
      "id" : 48733261,
      "verified" : false
    }
  },
  "id" : 180070053415362560,
  "created_at" : "Wed Mar 14 23:17:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Men's Basketball",
      "screen_name" : "UVMmbb",
      "indices" : [ 12, 19 ],
      "id_str" : "48733261",
      "id" : 48733261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180070006929883136",
  "text" : "UVM UVM UVM @uvmmbb",
  "id" : 180070006929883136,
  "created_at" : "Wed Mar 14 23:16:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graeme Street",
      "screen_name" : "CycloClub",
      "indices" : [ 76, 86 ],
      "id_str" : "40060277",
      "id" : 40060277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelinggreat",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "180017315763585024",
  "text" : "knocked out a 5mi run @ 7:15 pace, followed by Tri-Core 10 Rejuvenator from @cycloclub #feelinggreat",
  "id" : 180017315763585024,
  "created_at" : "Wed Mar 14 19:47:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179671717629804544",
  "geo" : {
  },
  "id_str" : "179696567958249472",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr done and done!!",
  "id" : 179696567958249472,
  "in_reply_to_status_id" : 179671717629804544,
  "created_at" : "Tue Mar 13 22:32:55 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 12, 22 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179696497632354305",
  "text" : "@GBurgstein @VTCycling I was hoping y'all would come to the Philly Flyer!! But alas, we will race soon. You doing tri nats garnder?",
  "id" : 179696497632354305,
  "created_at" : "Tue Mar 13 22:32:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179696314056056832",
  "text" : "time for team No Game This Week to show them who really has game!",
  "id" : 179696314056056832,
  "created_at" : "Tue Mar 13 22:31:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179655781157842944",
  "text" : "when the weather is nice, I'm confronted with tough decisions. Run at 4, race bikes at 5, or take it easy bc 2 bball games tonight?",
  "id" : 179655781157842944,
  "created_at" : "Tue Mar 13 19:50:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179412902367854592",
  "text" : "turning seatpost around didn't work, looks like I need a new bike to get that 78deg seat angle...",
  "id" : 179412902367854592,
  "created_at" : "Tue Mar 13 03:45:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/4p3reAJu",
      "expanded_url" : "http://twitpic.com/8vktnb",
      "display_url" : "twitpic.com/8vktnb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "179369510820786176",
  "text" : "the picture, i'd say there is a generous 12 inches more room than my car is long http://t.co/4p3reAJu",
  "id" : 179369510820786176,
  "created_at" : "Tue Mar 13 00:53:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179369215336263680",
  "text" : "I get the parking spots that most people can't park in!",
  "id" : 179369215336263680,
  "created_at" : "Tue Mar 13 00:52:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "totalimmersion",
      "indices" : [ 16, 31 ]
    }, {
      "text" : "motivated",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "USATCNC2012",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179360939785719808",
  "text" : "just finished a #totalimmersion pool workout #motivated #USATCNC2012",
  "id" : 179360939785719808,
  "created_at" : "Tue Mar 13 00:19:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/qzXsmuK5",
      "expanded_url" : "http://amzn.to/wg6337",
      "display_url" : "amzn.to/wg6337"
    } ]
  },
  "geo" : {
  },
  "id_str" : "179318391016927232",
  "text" : "read it already, but bought for reference frame building: 'Bicycling Science, Second Edition' by David Gordon Wilson http://t.co/qzXsmuK5",
  "id" : 179318391016927232,
  "created_at" : "Mon Mar 12 21:30:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 89, 97 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCNC2012",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/bubKLHOq",
      "expanded_url" : "http://Wheelbuilder.com",
      "display_url" : "Wheelbuilder.com"
    }, {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/cDQN99JY",
      "expanded_url" : "http://bit.ly/zIkPfA",
      "display_url" : "bit.ly/zIkPfA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "179316297174237186",
  "text" : "just ordered a disc cover #USATCNC2012 on http://t.co/bubKLHOq: http://t.co/cDQN99JY via @AddThis, 1237g total, lighter than some $2k discs",
  "id" : 179316297174237186,
  "created_at" : "Mon Mar 12 21:21:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Matt Sutkoski ",
      "screen_name" : "vermontweather",
      "indices" : [ 3, 18 ],
      "id_str" : "14603154",
      "id" : 14603154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VT",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179307885560463360",
  "text" : "RT @vermontweather: New record high temp. in Burlington #VT this p.m. 63 degrees, beats old record, 62 in 1977",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VT",
        "indices" : [ 36, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "179307505749467137",
    "text" : "New record high temp. in Burlington #VT this p.m. 63 degrees, beats old record, 62 in 1977",
    "id" : 179307505749467137,
    "created_at" : "Mon Mar 12 20:46:55 +0000 2012",
    "user" : {
      "name" : " Matt Sutkoski ",
      "screen_name" : "vermontweather",
      "protected" : false,
      "id_str" : "14603154",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1265054808/me_normal.jpg",
      "id" : 14603154,
      "verified" : false
    }
  },
  "id" : 179307885560463360,
  "created_at" : "Mon Mar 12 20:48:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "class",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "179198126689763328",
  "text" : "back on the grind #class",
  "id" : 179198126689763328,
  "created_at" : "Mon Mar 12 13:32:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859164, -73.2083139833 ]
  },
  "id_str" : "179040096614486016",
  "text" : "best part about doing laundry and hang drying all your clothes: that clean clothes smell in your room",
  "id" : 179040096614486016,
  "created_at" : "Mon Mar 12 03:04:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bum",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178925945594458112",
  "text" : "with the aid of daylight savings, I slept in until 2 today #bum",
  "id" : 178925945594458112,
  "created_at" : "Sun Mar 11 19:30:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Alain de Botton",
      "screen_name" : "alaindebotton",
      "indices" : [ 9, 23 ],
      "id_str" : "19966557",
      "id" : 19966557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178906207355027458",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@alaindebotton: True love is a lack of desire to check one's smartphone in another's presence.\"",
  "id" : 178906207355027458,
  "created_at" : "Sun Mar 11 18:12:18 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCNC12",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178658936692555777",
  "text" : "double officially registered for, and super super pumped for after an awesome training week, tri collegiate nat champs! #USATCNC12",
  "id" : 178658936692555777,
  "created_at" : "Sun Mar 11 01:49:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 78, 90 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/lKS5B5fN",
      "expanded_url" : "http://kck.st/ymLlxW",
      "display_url" : "kck.st/ymLlxW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "178653648396615680",
  "text" : "I just backed The Jiggernaut-Bringing bicycle frame building to the masses on @Kickstarter http://t.co/lKS5B5fN",
  "id" : 178653648396615680,
  "created_at" : "Sun Mar 11 01:28:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fuelly",
      "screen_name" : "fuelly",
      "indices" : [ 113, 120 ],
      "id_str" : "15686433",
      "id" : 15686433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3205451667, -72.61515825 ]
  },
  "id_str" : "178545326662234112",
  "text" : "just fueled up, got 33.3 mpg on my last tank...decent but not great. averaging 30.7 over the past 2500 miles via @fuelly",
  "id" : 178545326662234112,
  "created_at" : "Sat Mar 10 18:18:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uvmtriathlon",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.68006045, -72.6537323833 ]
  },
  "id_str" : "178530615023501312",
  "text" : "after a short trail run and some core work w Graeme from @cyclocore, headed back to burlington. an excellent training camp #uvmtriathlon",
  "id" : 178530615023501312,
  "created_at" : "Sat Mar 10 17:19:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178326548162674688",
  "geo" : {
  },
  "id_str" : "178338379837095936",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 I see what you did there, nelly",
  "id" : 178338379837095936,
  "in_reply_to_status_id" : 178326548162674688,
  "created_at" : "Sat Mar 10 04:35:57 +0000 2012",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "178289931783913472",
  "text" : "how you know you had a solid three days of training: ran down the batteries on both garmins and had to fire up Strava on the phone riding!!",
  "id" : 178289931783913472,
  "created_at" : "Sat Mar 10 01:23:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lamestate",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177951926569283585",
  "text" : "no alcohol sales past 9pm in CT #lamestate",
  "id" : 177951926569283585,
  "created_at" : "Fri Mar 09 03:00:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idontgiveaf",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177951218151333888",
  "text" : "pro tip: always travel w slippers, super comfy right after training and they give off that #idontgiveaf vibe in public",
  "id" : 177951218151333888,
  "created_at" : "Fri Mar 09 02:57:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triathlon",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177910847174217728",
  "text" : "totals for the day: 90min in the pool, 4hrs on the bike, and a quick 35min run! #triathlon",
  "id" : 177910847174217728,
  "created_at" : "Fri Mar 09 00:17:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177766083921584128",
  "text" : "headed to swim and get videotaped! I'll be able to see myself doggypaddle!",
  "id" : 177766083921584128,
  "created_at" : "Thu Mar 08 14:41:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177530351202217985",
  "text" : "solid 3.5 hours of riding in CT, what a nice day for it!",
  "id" : 177530351202217985,
  "created_at" : "Wed Mar 07 23:05:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/UdNf5KLU",
      "expanded_url" : "http://www.mixedmediaeng.com/index.php/mixed-media-engineering-partners/",
      "display_url" : "mixedmediaeng.com/index.php/mixe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "177233543792050177",
  "text" : "professional DIYers, cool http://t.co/UdNf5KLU",
  "id" : 177233543792050177,
  "created_at" : "Wed Mar 07 03:25:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 47, 56 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 57, 73 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177203625628672000",
  "text" : "excellent dinner at Kitty Hoynes in Syracuse w @dmreagan @RumblinStumblin!!",
  "id" : 177203625628672000,
  "created_at" : "Wed Mar 07 01:26:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177105851721588737",
  "geo" : {
  },
  "id_str" : "177116854232416258",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser my fame is growing!",
  "id" : 177116854232416258,
  "in_reply_to_status_id" : 177105851721588737,
  "created_at" : "Tue Mar 06 19:42:03 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 12, 28 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177116321316749312",
  "text" : "is home for @RumblinStumblin's big FIVE-ONE! Happy birthday!",
  "id" : 177116321316749312,
  "created_at" : "Tue Mar 06 19:39:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Stephanie ",
      "screen_name" : "smrave",
      "indices" : [ 16, 23 ],
      "id_str" : "225553548",
      "id" : 225553548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socute",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177105160009555968",
  "geo" : {
  },
  "id_str" : "177114101091270656",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @smrave you guys had the same tweet at the same time! #socute",
  "id" : 177114101091270656,
  "in_reply_to_status_id" : 177105160009555968,
  "created_at" : "Tue Mar 06 19:31:06 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jillian Duff",
      "screen_name" : "jillnduff",
      "indices" : [ 0, 10 ],
      "id_str" : "242396877",
      "id" : 242396877
    }, {
      "name" : "lindz",
      "screen_name" : "lindzshark",
      "indices" : [ 38, 49 ],
      "id_str" : "230893616",
      "id" : 230893616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "177113665600888832",
  "in_reply_to_user_id" : 242396877,
  "text" : "@jillnduff hey! my really good friend @lindzshark is looking for a marketing internship at OBG. could you give her more info?",
  "id" : 177113665600888832,
  "created_at" : "Tue Mar 06 19:29:23 +0000 2012",
  "in_reply_to_screen_name" : "jillnduff",
  "in_reply_to_user_id_str" : "242396877",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177045623806246912",
  "geo" : {
  },
  "id_str" : "177064005825863681",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin first, happy birthday!! I'm going to go to CT to train for triathlon tomorrow, nationals are only 7 wks away.",
  "id" : 177064005825863681,
  "in_reply_to_status_id" : 177045623806246912,
  "created_at" : "Tue Mar 06 16:12:03 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/dRowM8at",
      "expanded_url" : "http://twitpic.com/8slkj9",
      "display_url" : "twitpic.com/8slkj9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "176869932330532864",
  "text" : "homemade maple balsamic vinaigrette imitation came out perfect! http://t.co/dRowM8at",
  "id" : 176869932330532864,
  "created_at" : "Tue Mar 06 03:20:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "restday",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176840934976270337",
  "text" : "homework looked at, beer kegged and speedometer mounted on the commuter...that's a #restday",
  "id" : 176840934976270337,
  "created_at" : "Tue Mar 06 01:25:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omnomnom",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176792830449160193",
  "geo" : {
  },
  "id_str" : "176798107814731776",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e Paul: \"#omnomnom i eat everything\"",
  "id" : 176798107814731776,
  "in_reply_to_status_id" : 176792830449160193,
  "created_at" : "Mon Mar 05 22:35:28 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 8, 15 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 61, 68 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176793705330651137",
  "geo" : {
  },
  "id_str" : "176797860099141632",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @DZdan1 I'm unsure how I became involved in this.... @DZdan1!!",
  "id" : 176797860099141632,
  "in_reply_to_status_id" : 176793705330651137,
  "created_at" : "Mon Mar 05 22:34:29 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176777952116215810",
  "text" : "UPS coming through with my new bread pan",
  "id" : 176777952116215810,
  "created_at" : "Mon Mar 05 21:15:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exhausted",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176531493345177600",
  "text" : "back in snowy Burlington after a solid day of bicycle racing. #exhausted",
  "id" : 176531493345177600,
  "created_at" : "Mon Mar 05 04:56:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176093567217958913",
  "geo" : {
  },
  "id_str" : "176107021236576256",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 strange, first the weather now cell phones! i'm on skype on the phone",
  "id" : 176107021236576256,
  "in_reply_to_status_id" : 176093567217958913,
  "created_at" : "Sun Mar 04 00:49:20 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nostress",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176089881578176512",
  "geo" : {
  },
  "id_str" : "176090607717068802",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 oh okay. well we're out to get food. I can use skype from my phone to your computer, let me install it! #nostress",
  "id" : 176090607717068802,
  "in_reply_to_status_id" : 176089881578176512,
  "created_at" : "Sat Mar 03 23:44:07 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "176066209954004992",
  "text" : "race went alright for me, the 3 miles I sat on front caught up though and I cracked on 3rd climb. but avoided the crash bc of it!",
  "id" : 176066209954004992,
  "created_at" : "Sat Mar 03 22:07:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/GCLbcFFk",
      "expanded_url" : "http://twitpic.com/8riwqt",
      "display_url" : "twitpic.com/8riwqt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175990567669477376",
  "text" : "new bike! the Raleigh Furley aka suuper commuter!! http://t.co/GCLbcFFk",
  "id" : 175990567669477376,
  "created_at" : "Sat Mar 03 17:06:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/p96lowc0",
      "expanded_url" : "http://twitpic.com/8rhynd",
      "display_url" : "twitpic.com/8rhynd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175973335941922817",
  "text" : "pain face finishing the TT this AM http://t.co/p96lowc0",
  "id" : 175973335941922817,
  "created_at" : "Sat Mar 03 15:58:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175944305519755264",
  "text" : "TT went well! went out too hard but finished the 2.02 miles @ 23mph in the rain",
  "id" : 175944305519755264,
  "created_at" : "Sat Mar 03 14:02:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175887854117994496",
  "text" : "shoes? check. helmet? check. bike? check. 5am? check. ...time to race bikes!",
  "id" : 175887854117994496,
  "created_at" : "Sat Mar 03 10:18:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegiatebikeracing",
      "indices" : [ 31, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175811734806863872",
  "text" : "4.5 hours of sleep here I come #collegiatebikeracing",
  "id" : 175811734806863872,
  "created_at" : "Sat Mar 03 05:15:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 3, 16 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 27, 38 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 99, 111 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175800995757031424",
  "text" : "RT @williamenium: Have fun @andyreagan this weekend racing man! We sure miss you but go show those @UVM_cycling peps how to rock an aero ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 9, 20 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "UVM Cycling",
        "screen_name" : "UVM_cycling",
        "indices" : [ 81, 93 ],
        "id_str" : "75351547",
        "id" : 75351547
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "175796284865785856",
    "text" : "Have fun @andyreagan this weekend racing man! We sure miss you but go show those @UVM_cycling peps how to rock an aero helmet in a crit",
    "id" : 175796284865785856,
    "created_at" : "Sat Mar 03 04:14:35 +0000 2012",
    "user" : {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "protected" : false,
      "id_str" : "25713870",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3000920642/c373789737cf47f7a99efe0a4b414eb3_normal.jpeg",
      "id" : 25713870,
      "verified" : false
    }
  },
  "id" : 175800995757031424,
  "created_at" : "Sat Mar 03 04:33:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Greenlaw",
      "screen_name" : "dgreenlaw13",
      "indices" : [ 3, 15 ],
      "id_str" : "269907937",
      "id" : 269907937
    }, {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "indices" : [ 39, 46 ],
      "id_str" : "24074204",
      "id" : 24074204
    }, {
      "name" : "jake hofmeister",
      "screen_name" : "jake1124",
      "indices" : [ 47, 56 ],
      "id_str" : "211747438",
      "id" : 211747438
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 61, 72 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikegeeking",
      "indices" : [ 17, 29 ]
    }, {
      "text" : "ECCC",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175795476405305344",
  "text" : "RT @dgreenlaw13: #bikegeeking out with @BenCiv @jake1124 and @andyreagan. Cant wait for the first #ECCC race!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Civiletti",
        "screen_name" : "BenCiv",
        "indices" : [ 22, 29 ],
        "id_str" : "24074204",
        "id" : 24074204
      }, {
        "name" : "jake hofmeister",
        "screen_name" : "jake1124",
        "indices" : [ 30, 39 ],
        "id_str" : "211747438",
        "id" : 211747438
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 44, 55 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bikegeeking",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "ECCC",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "175790760350851072",
    "text" : "#bikegeeking out with @BenCiv @jake1124 and @andyreagan. Cant wait for the first #ECCC race!",
    "id" : 175790760350851072,
    "created_at" : "Sat Mar 03 03:52:37 +0000 2012",
    "user" : {
      "name" : "Dana Greenlaw",
      "screen_name" : "dgreenlaw13",
      "protected" : false,
      "id_str" : "269907937",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1296119540/image_normal.jpg",
      "id" : 269907937,
      "verified" : false
    }
  },
  "id" : 175795476405305344,
  "created_at" : "Sat Mar 03 04:11:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175790411032436736",
  "text" : "classic cycling team van discussion on the history and future of bike components (shimano, sram, campy)",
  "id" : 175790411032436736,
  "created_at" : "Sat Mar 03 03:51:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAHBS",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175770019693731843",
  "text" : "#NAHBS is making me want to build a frame even more!! burlington frameworks, coming this summer (and hopefully w better name)",
  "id" : 175770019693731843,
  "created_at" : "Sat Mar 03 02:30:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175769074087903234",
  "text" : "try to think how far you've ever been from another human.... maybe 1 mile?",
  "id" : 175769074087903234,
  "created_at" : "Sat Mar 03 02:26:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 34, 45 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/QdjzwnIo",
      "expanded_url" : "http://twitter.com/angryasian/status/175753284005543936/photo/1",
      "display_url" : "pic.twitter.com/QdjzwnIo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175765718770532354",
  "text" : "wild! cant imagine its stiff tho \"@angryasian: Here's another teaser. Insane one-sided bike from Rob English. Amazing. http://t.co/QdjzwnIo\"",
  "id" : 175765718770532354,
  "created_at" : "Sat Mar 03 02:13:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeb Vance King",
      "screen_name" : "Zeb_King",
      "indices" : [ 0, 9 ],
      "id_str" : "317552757",
      "id" : 317552757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175750204753068032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.2594317, -73.8785423333 ]
  },
  "id_str" : "175763756406685696",
  "in_reply_to_user_id" : 317552757,
  "text" : "@Zeb_King all teams should have a burrito sponsor!",
  "id" : 175763756406685696,
  "in_reply_to_status_id" : 175750204753068032,
  "created_at" : "Sat Mar 03 02:05:19 +0000 2012",
  "in_reply_to_screen_name" : "Zeb_King",
  "in_reply_to_user_id_str" : "317552757",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.2775627, -73.87338475 ]
  },
  "id_str" : "175763557386944513",
  "text" : "@chaosdynamics that sounds interesting! I'll be taking measure theory in the fall",
  "id" : 175763557386944513,
  "created_at" : "Sat Mar 03 02:04:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M&M",
      "screen_name" : "MandyMarquardt",
      "indices" : [ 0, 15 ],
      "id_str" : "191883583",
      "id" : 191883583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175758446069678080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3231375667, -73.8648402333 ]
  },
  "id_str" : "175762800700964864",
  "in_reply_to_user_id" : 191883583,
  "text" : "@MandyMarquardt same race for me!",
  "id" : 175762800700964864,
  "in_reply_to_status_id" : 175758446069678080,
  "created_at" : "Sat Mar 03 02:01:31 +0000 2012",
  "in_reply_to_screen_name" : "MandyMarquardt",
  "in_reply_to_user_id_str" : "191883583",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M&M",
      "screen_name" : "MandyMarquardt",
      "indices" : [ 3, 18 ],
      "id_str" : "191883583",
      "id" : 191883583
    }, {
      "name" : "PSU Lehigh Valley",
      "screen_name" : "PSULehighValley",
      "indices" : [ 61, 77 ],
      "id_str" : "250700374",
      "id" : 250700374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175762707302195201",
  "text" : "RT @MandyMarquardt: Gettin pumped for tomorrow! Kickoff with @psulehighvalley at Ruttgers!   First on tap: 52mile RR w/1,000ft of climbi ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.handmark.com\" rel=\"nofollow\">TweetCaster for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PSU Lehigh Valley",
        "screen_name" : "PSULehighValley",
        "indices" : [ 41, 57 ],
        "id_str" : "250700374",
        "id" : 250700374
      }, {
        "name" : "ECCC",
        "screen_name" : "ECCCNews",
        "indices" : [ 130, 139 ],
        "id_str" : "111180422",
        "id" : 111180422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "175758446069678080",
    "text" : "Gettin pumped for tomorrow! Kickoff with @psulehighvalley at Ruttgers!   First on tap: 52mile RR w/1,000ft of climbing every lap! @ECCCNews",
    "id" : 175758446069678080,
    "created_at" : "Sat Mar 03 01:44:13 +0000 2012",
    "user" : {
      "name" : "M&M",
      "screen_name" : "MandyMarquardt",
      "protected" : false,
      "id_str" : "191883583",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004695579/5070c5ca29f145dba70055f15c642a31_normal.jpeg",
      "id" : 191883583,
      "verified" : false
    }
  },
  "id" : 175762707302195201,
  "created_at" : "Sat Mar 03 02:01:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.5396460333, -73.7833228667 ]
  },
  "id_str" : "175749970094325760",
  "text" : "@chaosdynamics were we doing differentiation, which I'd already finished in my first semester at Va Tech. hoepfully as fun as writing them!",
  "id" : 175749970094325760,
  "created_at" : "Sat Mar 03 01:10:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sorry",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.5549913, -73.7848197667 ]
  },
  "id_str" : "175749474025611264",
  "text" : "only some of randomly sent old tweets have their pictures, which is the reason they didn't send originally #sorry",
  "id" : 175749474025611264,
  "created_at" : "Sat Mar 03 01:08:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.56955745, -73.7899501167 ]
  },
  "id_str" : "175749112745033728",
  "text" : "warning: my phone is launching random old tweets",
  "id" : 175749112745033728,
  "created_at" : "Sat Mar 03 01:07:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 67, 81 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/175748961959809024/photo/1",
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/vEmYzRCy",
      "media_url" : "http://pbs.twimg.com/media/AnBiv-_CEAA3bHG.jpg",
      "id_str" : "175748961968197632",
      "id" : 175748961968197632,
      "media_url_https" : "https://pbs.twimg.com/media/AnBiv-_CEAA3bHG.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/vEmYzRCy"
    } ],
    "hashtags" : [ {
      "text" : "complexsystems",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175748961959809024",
  "text" : "at Terry's Sejnowski's talk \"Suspicious Coincidences in the Brain\" @uvmcomplexity #complexsystems http://t.co/vEmYzRCy",
  "id" : 175748961959809024,
  "created_at" : "Sat Mar 03 01:06:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 0, 11 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175745802940067841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.5822024667, -73.7868057833 ]
  },
  "id_str" : "175748930653528064",
  "in_reply_to_user_id" : 16353686,
  "text" : "@angryasian sure do!! excited for the pics!",
  "id" : 175748930653528064,
  "in_reply_to_status_id" : 175745802940067841,
  "created_at" : "Sat Mar 03 01:06:24 +0000 2012",
  "in_reply_to_screen_name" : "angryasian",
  "in_reply_to_user_id_str" : "16353686",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowshoerunning",
      "indices" : [ 32, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175748798688141313",
  "text" : "currently on top of Bolton Mtn! #snowshoerunning",
  "id" : 175748798688141313,
  "created_at" : "Sat Mar 03 01:05:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bored",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "limits",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "cmon",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175748792367321088",
  "text" : "real analysis II? more like mid semester real analysis I at Va Tech #bored #limits #cmon",
  "id" : 175748792367321088,
  "created_at" : "Sat Mar 03 01:05:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 22, 34 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175748004534427649",
  "text" : "been pulled over with @UVM_cycling already!! lights on the trailer were being finicky, fixed now",
  "id" : 175748004534427649,
  "created_at" : "Sat Mar 03 01:02:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 3, 19 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 20, 31 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175734894452948992",
  "text" : "RT @RumblinStumblin @andyreagan good luck at Rutgers this weeked! Go UVM Cycling!!",
  "id" : 175734894452948992,
  "created_at" : "Sat Mar 03 00:10:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175734095651946497",
  "text" : "just told my phone to send old drafts, which never sent bc they had pictures attached. now they sent without pictures...",
  "id" : 175734095651946497,
  "created_at" : "Sat Mar 03 00:07:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175732899935563776",
  "text" : "yeah i back into 6ft wide spaces in the snow",
  "id" : 175732899935563776,
  "created_at" : "Sat Mar 03 00:02:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175732886316646400",
  "text" : "it glows!",
  "id" : 175732886316646400,
  "created_at" : "Sat Mar 03 00:02:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brooklynbrewery",
      "indices" : [ 69, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175732875273060353",
  "text" : "aged barley wine and a dark chocolate stout,  gonna be a good night! #brooklynbrewery",
  "id" : 175732875273060353,
  "created_at" : "Sat Mar 03 00:02:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175732819459440640",
  "text" : "calm down ladies (tried to send this at 6 this am)",
  "id" : 175732819459440640,
  "created_at" : "Sat Mar 03 00:02:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175713637758009344",
  "text" : "RT @UVM_cycling: Onward to Rutgers and certain glory!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "175703862244687873",
    "text" : "Onward to Rutgers and certain glory!",
    "id" : 175703862244687873,
    "created_at" : "Fri Mar 02 22:07:19 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 175713637758009344,
  "created_at" : "Fri Mar 02 22:46:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175713300934443008",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr sounds like you found your school!!",
  "id" : 175713300934443008,
  "created_at" : "Fri Mar 02 22:44:50 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoyed",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "stillwaiting",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175711908886884353",
  "text" : "twitter for droid struggles hard to send pictures...every time #annoyed #stillwaiting",
  "id" : 175711908886884353,
  "created_at" : "Fri Mar 02 22:39:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 76, 88 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 90, 102 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 103, 113 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/uvBg6iEI",
      "expanded_url" : "http://www.youtube.com/watch?v=Pn6ie1zCkZU",
      "display_url" : "youtube.com/watch?v=Pn6ie1…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175388323857182720",
  "text" : "oh no...they didn't actually make this movie did they? http://t.co/uvBg6iEI @bikingbiebs  @UVM_cycling @VTCycling",
  "id" : 175388323857182720,
  "created_at" : "Fri Mar 02 01:13:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175387962324955136",
  "text" : "@GBurgstein sounds like a bummer for you...20's and pouring snow is perfect training weather from what I can tell :P",
  "id" : 175387962324955136,
  "created_at" : "Fri Mar 02 01:12:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 73, 81 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/x3rDZTpp",
      "expanded_url" : "http://bit.ly/A7cbkr",
      "display_url" : "bit.ly/A7cbkr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "175380770033119232",
  "text" : "fun, and hard snowshoe run this afternoon followed by nothing other than @moes_hq!  Garmin Connect: http://t.co/x3rDZTpp",
  "id" : 175380770033119232,
  "created_at" : "Fri Mar 02 00:43:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175277404057632769",
  "geo" : {
  },
  "id_str" : "175303635469737985",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser leaving sat at noon to spend time w friends down there on sunday, leaving thurs 630, all w us airways",
  "id" : 175303635469737985,
  "in_reply_to_status_id" : 175277404057632769,
  "created_at" : "Thu Mar 01 19:36:58 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIAM",
      "screen_name" : "SIAMconnect",
      "indices" : [ 33, 45 ],
      "id_str" : "89036871",
      "id" : 89036871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UQ2012",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175275727434956801",
  "text" : "flight booked to Raleigh, NC for @SIAMconnect #UQ2012",
  "id" : 175275727434956801,
  "created_at" : "Thu Mar 01 17:46:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "george cummins",
      "screen_name" : "lonefalcon",
      "indices" : [ 0, 11 ],
      "id_str" : "35940635",
      "id" : 35940635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175260344686620673",
  "geo" : {
  },
  "id_str" : "175260741711048704",
  "in_reply_to_user_id" : 35940635,
  "text" : "@lonefalcon you should probably stop drinking and cycling!",
  "id" : 175260741711048704,
  "in_reply_to_status_id" : 175260344686620673,
  "created_at" : "Thu Mar 01 16:46:31 +0000 2012",
  "in_reply_to_screen_name" : "lonefalcon",
  "in_reply_to_user_id_str" : "35940635",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 13, 29 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175086574155997184",
  "geo" : {
  },
  "id_str" : "175259399131111425",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw @JacobnAndersson where to start... \"the seat doesn't even hurt anymore.\" I still don't think he bikes to work, what??",
  "id" : 175259399131111425,
  "in_reply_to_status_id" : 175086574155997184,
  "created_at" : "Thu Mar 01 16:41:11 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 10, 17 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175256282754842625",
  "geo" : {
  },
  "id_str" : "175259007907397632",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @DZdan1 burn",
  "id" : 175259007907397632,
  "in_reply_to_status_id" : 175256282754842625,
  "created_at" : "Thu Mar 01 16:39:38 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/175247499265712129/photo/1",
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/LLJH8WQ4",
      "media_url" : "http://pbs.twimg.com/media/Am6arA3CIAEGqYv.jpg",
      "id_str" : "175247499269906433",
      "id" : 175247499269906433,
      "media_url_https" : "https://pbs.twimg.com/media/Am6arA3CIAEGqYv.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LLJH8WQ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175247499265712129",
  "text" : "starting to look a lot like winter http://t.co/LLJH8WQ4",
  "id" : 175247499265712129,
  "created_at" : "Thu Mar 01 15:53:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175095668728270850",
  "text" : "mark down one more late night of complex homework! on a side not, swam at 6 and discovered my kick's flaw: i'm pedaling",
  "id" : 175095668728270850,
  "created_at" : "Thu Mar 01 05:50:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]