Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/BptM6aqy",
      "expanded_url" : "http://www.amazon.com/gp/product/B003RLHCG4/ref=ox_sc_act_title_5?ie=UTF8&m=AI815W1WMD729",
      "display_url" : "amazon.com/gp/product/B00…"
    }, {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/zr4OxWEq",
      "expanded_url" : "http://www.amazon.com/gp/product/B0029LKXM8/ref=ox_sc_act_title_4?ie=UTF8&m=A2TE9IQP68MWQU",
      "display_url" : "amazon.com/gp/product/B00…"
    } ]
  },
  "in_reply_to_status_id_str" : "164564654834712576",
  "geo" : {
  },
  "id_str" : "164565194385788928",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium no worries my man. what you think? http://t.co/BptM6aqy http://t.co/zr4OxWEq",
  "id" : 164565194385788928,
  "in_reply_to_status_id" : 164564654834712576,
  "created_at" : "Wed Feb 01 04:26:14 +0000 2012",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/eQvQgCF3",
      "expanded_url" : "http://en.wikipedia.org/wiki/Bicycle_brake#Coaster_brakes",
      "display_url" : "en.wikipedia.org/wiki/Bicycle_b…"
    } ]
  },
  "in_reply_to_status_id_str" : "164550054538002432",
  "geo" : {
  },
  "id_str" : "164563828061900800",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium i was including coasters in the statement, cuz coaster brakes are drum brakes, i thought http://t.co/eQvQgCF3",
  "id" : 164563828061900800,
  "in_reply_to_status_id" : 164550054538002432,
  "created_at" : "Wed Feb 01 04:20:48 +0000 2012",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uvm",
      "indices" : [ 71, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/lSDtC6Ju",
      "expanded_url" : "http://www.speedtest.net/result/1743476440.png",
      "display_url" : "speedtest.net/result/1743476…"
    } ]
  },
  "in_reply_to_status_id_str" : "164531509934563329",
  "geo" : {
  },
  "id_str" : "164532059149307904",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 that test hit 900, check this out, 60 is still faster than 99% #uvm http://t.co/lSDtC6Ju",
  "id" : 164532059149307904,
  "in_reply_to_status_id" : 164531509934563329,
  "created_at" : "Wed Feb 01 02:14:34 +0000 2012",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 21, 32 ],
      "id_str" : "355569678",
      "id" : 355569678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jeezum",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/ANmkK5Et",
      "expanded_url" : "http://www.speedtest.net/result/1743464925.png",
      "display_url" : "speedtest.net/result/1743464…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164529809102348288",
  "text" : "over 900?!?! #jeezum @erik_ryden http://t.co/ANmkK5Et",
  "id" : 164529809102348288,
  "created_at" : "Wed Feb 01 02:05:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/32tlSUq6",
      "expanded_url" : "http://www.speedtest.net/result/1743463098.png",
      "display_url" : "speedtest.net/result/1743463…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164529248428765184",
  "text" : "WOW 850 Mbps download speed in the office?!?! http://t.co/32tlSUq6",
  "id" : 164529248428765184,
  "created_at" : "Wed Feb 01 02:03:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164520728216084480",
  "text" : "was able to log a quick easy run, and make it to UVM Triathlon Club's meeting. in the office now for HW and internet that's Skype capable",
  "id" : 164520728216084480,
  "created_at" : "Wed Feb 01 01:29:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164489358559297536",
  "text" : "an option I didnt consider for the \"ultimate commuter\" is drum brakes... really heavy, but no maintenance, not that mechanical discs r much",
  "id" : 164489358559297536,
  "created_at" : "Tue Jan 31 23:24:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164473601360281600",
  "geo" : {
  },
  "id_str" : "164474973652652032",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw you srsly need to get faster on the bike...",
  "id" : 164474973652652032,
  "in_reply_to_status_id" : 164473601360281600,
  "created_at" : "Tue Jan 31 22:27:44 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164465253244092416",
  "geo" : {
  },
  "id_str" : "164474786943209472",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy probably need a drink...",
  "id" : 164474786943209472,
  "in_reply_to_status_id" : 164465253244092416,
  "created_at" : "Tue Jan 31 22:26:59 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohwell",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164198909156134912",
  "text" : "the biggest issue with macbook is trying to get video out of it...only reliable choice is overpriced proprietary adapter #ohwell",
  "id" : 164198909156134912,
  "created_at" : "Tue Jan 31 04:10:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 21, 35 ],
      "id_str" : "154139533",
      "id" : 154139533
    }, {
      "name" : "Ben King",
      "screen_name" : "BenKing89",
      "indices" : [ 97, 107 ],
      "id_str" : "18171525",
      "id" : 18171525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/nKzcCQLw",
      "expanded_url" : "http://twitter.com/rickygargiulo/status/164175490821787649/photo/1",
      "display_url" : "pic.twitter.com/nKzcCQLw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164185349768224768",
  "text" : "congrats Ricky!! \"RT @rickygargiulo Owen Cup Trophy. Happy to have my name on the same trophy as @benking89 http://t.co/nKzcCQLw\"",
  "id" : 164185349768224768,
  "created_at" : "Tue Jan 31 03:16:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 84, 95 ],
      "id_str" : "355569678",
      "id" : 355569678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/xflBCJ0A",
      "expanded_url" : "http://en.wikipedia.org/wiki/Power_line_communication",
      "display_url" : "en.wikipedia.org/wiki/Power_lin…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164146445971243010",
  "text" : "mind blown. using your home's power lines to connect your home network (internet)!? @erik_ryden actually has a set! http://t.co/xflBCJ0A",
  "id" : 164146445971243010,
  "created_at" : "Tue Jan 31 00:42:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/FQCMl2kC",
      "expanded_url" : "http://www.youtube.com/watch?v=zkEK2m7jOvQ&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=zkEK2m…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164126862749089793",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 i think of this song: (which I liked long before I started running) \"together its much better\" http://t.co/FQCMl2kC",
  "id" : 164126862749089793,
  "created_at" : "Mon Jan 30 23:24:28 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164120927653724162",
  "text" : "interesting attempt at mtb'ing today, the trails were solid, smooth ice. ...going 2 have my warm slippers ready after every winter ride now",
  "id" : 164120927653724162,
  "created_at" : "Mon Jan 30 23:00:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 9, 19 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164119276658229248",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@bikebuild: No, it's NOT too late to sign up for 2012! We still have a few spots left, and are still doing extended leader hiring.\"",
  "id" : 164119276658229248,
  "created_at" : "Mon Jan 30 22:54:19 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohjeez",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164014438989561856",
  "text" : "\"and with that fancy footwork I did there, pun intended...\" -dr foote #ohjeez",
  "id" : 164014438989561856,
  "created_at" : "Mon Jan 30 15:57:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163985463546363904",
  "text" : "printing homework (5 pages typed) and then complex analysis class",
  "id" : 163985463546363904,
  "created_at" : "Mon Jan 30 14:02:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square Support",
      "screen_name" : "SqSupport",
      "indices" : [ 0, 10 ],
      "id_str" : "135221095",
      "id" : 135221095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163841953715331072",
  "in_reply_to_user_id" : 135221095,
  "text" : "@SqSupport any way I can get another chance to validate? would love to be able to accept cc. my email is square@andyreagan.com",
  "id" : 163841953715331072,
  "created_at" : "Mon Jan 30 04:32:20 +0000 2012",
  "in_reply_to_screen_name" : "SqSupport",
  "in_reply_to_user_id_str" : "135221095",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 14, 21 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163833629678637056",
  "text" : "signed up for @Square tonight, looks pretty awesome",
  "id" : 163833629678637056,
  "created_at" : "Mon Jan 30 03:59:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/2et9PFwF",
      "expanded_url" : "http://www.reverbnation.com/brooklynmumbles",
      "display_url" : "reverbnation.com/brooklynmumbles"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163832469752254464",
  "text" : "Check out The Mumbles http://t.co/2et9PFwF",
  "id" : 163832469752254464,
  "created_at" : "Mon Jan 30 03:54:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livemusic",
      "indices" : [ 26, 36 ]
    }, {
      "text" : "studybreak",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163818343537721344",
  "text" : "chillin at the Radio Bean #livemusic #studybreak",
  "id" : 163818343537721344,
  "created_at" : "Mon Jan 30 02:58:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 0, 5 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163797208905420800",
  "in_reply_to_user_id" : 12,
  "text" : "@jack square looks awesome. however, it couldnt verify my identity on account set up for some reason. any other way to verify?",
  "id" : 163797208905420800,
  "created_at" : "Mon Jan 30 01:34:32 +0000 2012",
  "in_reply_to_screen_name" : "jack",
  "in_reply_to_user_id_str" : "12",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163416962645495808",
  "text" : "and now… the dreaded PC to Mac file transfer",
  "id" : 163416962645495808,
  "created_at" : "Sun Jan 29 00:23:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 62, 70 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/D4CGuay9",
      "expanded_url" : "http://bit.ly/A3VNPu",
      "display_url" : "bit.ly/A3VNPu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163412485481824257",
  "text" : "today's 53mi ride on Garmin Connect: http://t.co/D4CGuay9 via @AddThis",
  "id" : 163412485481824257,
  "created_at" : "Sun Jan 29 00:05:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 4, 15 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 16, 27 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163388959219654656",
  "text" : "RT \"@kreagannet @andyreagan schoolwork + athletics + brews = college life\"",
  "id" : 163388959219654656,
  "created_at" : "Sat Jan 28 22:32:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163384029410902017",
  "geo" : {
  },
  "id_str" : "163387532548124672",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet word. that's a long time to play bball... i'm gonna go do some work and find a brew lol",
  "id" : 163387532548124672,
  "in_reply_to_status_id" : 163384029410902017,
  "created_at" : "Sat Jan 28 22:26:38 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163382623014633472",
  "geo" : {
  },
  "id_str" : "163383273144320000",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet that's awesome!! get you some. I could def have one right now, just finished a hard ride",
  "id" : 163383273144320000,
  "in_reply_to_status_id" : 163382623014633472,
  "created_at" : "Sat Jan 28 22:09:42 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/163365540465868800/photo/1",
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/68MrLmWm",
      "media_url" : "http://pbs.twimg.com/media/AkRkF_BCAAAimCm.jpg",
      "id_str" : "163365540470063104",
      "id" : 163365540470063104,
      "media_url_https" : "https://pbs.twimg.com/media/AkRkF_BCAAAimCm.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/68MrLmWm"
    } ],
    "hashtags" : [ {
      "text" : "hellyeah",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "pandapas",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163365540465868800",
  "text" : "super awesome ride today. lots of people, awesome weather, views, even talked to a guy abt Old Farm #hellyeah #pandapas http://t.co/68MrLmWm",
  "id" : 163365540465868800,
  "created_at" : "Sat Jan 28 20:59:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 23, 35 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163302621724160001",
  "text" : "headin out on a ride w @bikingbiebs, double strength gatorade so the bottles don't freeze",
  "id" : 163302621724160001,
  "created_at" : "Sat Jan 28 16:49:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163264709259304960",
  "geo" : {
  },
  "id_str" : "163272264102576128",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 where in Vermont are you??",
  "id" : 163272264102576128,
  "in_reply_to_status_id" : 163264709259304960,
  "created_at" : "Sat Jan 28 14:48:35 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163096019716931584",
  "text" : "sorting skittles",
  "id" : 163096019716931584,
  "created_at" : "Sat Jan 28 03:08:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/xe7A0yBE",
      "expanded_url" : "http://img3.etsystatic.com/il_fullxfull.210735939.jpg",
      "display_url" : "img3.etsystatic.com/il_fullxfull.2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163088572721795072",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 I found you a knitting project, this looks awesome (macbook cover) http://t.co/xe7A0yBE",
  "id" : 163088572721795072,
  "created_at" : "Sat Jan 28 02:38:40 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sonice",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163046483560644609",
  "text" : "ahhh, having a laptop with battery life #sonice",
  "id" : 163046483560644609,
  "created_at" : "Fri Jan 27 23:51:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163016692568559617",
  "geo" : {
  },
  "id_str" : "163018900630536192",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson wait whatttt? running!?!",
  "id" : 163018900630536192,
  "in_reply_to_status_id" : 163016692568559617,
  "created_at" : "Fri Jan 27 22:01:49 +0000 2012",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/YGnbNIXG",
      "expanded_url" : "http://bit.ly/rmMKrR",
      "display_url" : "bit.ly/rmMKrR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163018824063528960",
  "text" : "RT @bakadesuyo: Why do some people get sick so often and others never do? http://t.co/YGnbNIXG",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/YGnbNIXG",
        "expanded_url" : "http://bit.ly/rmMKrR",
        "display_url" : "bit.ly/rmMKrR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "163018555036667904",
    "text" : "Why do some people get sick so often and others never do? http://t.co/YGnbNIXG",
    "id" : 163018555036667904,
    "created_at" : "Fri Jan 27 22:00:26 +0000 2012",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 163018824063528960,
  "created_at" : "Fri Jan 27 22:01:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/E6hH9FMW",
      "expanded_url" : "http://www.amazon.com/Swimmer-Remote-Control-Inflatable-Flying/dp/B005FYEAJ8",
      "display_url" : "amazon.com/Swimmer-Remote…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "163018709819064320",
  "text" : "we need 30 of these immediately http://t.co/E6hH9FMW",
  "id" : 163018709819064320,
  "created_at" : "Fri Jan 27 22:01:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163011632337915904",
  "geo" : {
  },
  "id_str" : "163014848941268992",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 school got it for me, I couldn't afford it on my salary. pretty sweet perk though",
  "id" : 163014848941268992,
  "in_reply_to_status_id" : 163011632337915904,
  "created_at" : "Fri Jan 27 21:45:43 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163009842448048128",
  "geo" : {
  },
  "id_str" : "163011124055388162",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 pretty fancy! still learning how to navigate this thing",
  "id" : 163011124055388162,
  "in_reply_to_status_id" : 163009842448048128,
  "created_at" : "Fri Jan 27 21:30:55 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "163000812988141568",
  "text" : "first tweet from my NEW MACBOOK!!",
  "id" : 163000812988141568,
  "created_at" : "Fri Jan 27 20:49:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/162980577623015424/photo/1",
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/UIUg9mOj",
      "media_url" : "http://pbs.twimg.com/media/AkMF-MrCAAIu-ZI.jpg",
      "id_str" : "162980577627209730",
      "id" : 162980577627209730,
      "media_url_https" : "https://pbs.twimg.com/media/AkMF-MrCAAIu-ZI.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/UIUg9mOj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162980577623015424",
  "text" : "week 2 of classes pwned, so treat for me! http://t.co/UIUg9mOj",
  "id" : 162980577623015424,
  "created_at" : "Fri Jan 27 19:29:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/162655377899528194/photo/1",
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/Fpe0Mhib",
      "media_url" : "http://pbs.twimg.com/media/AkHeNFTCIAEQ1XP.jpg",
      "id_str" : "162655377903722497",
      "id" : 162655377903722497,
      "media_url_https" : "https://pbs.twimg.com/media/AkHeNFTCIAEQ1XP.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Fpe0Mhib"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162655377899528194",
  "text" : "awesome views (and I didnt freeze entirely solid @ 20deg out) on a successful vermont ride! http://t.co/Fpe0Mhib",
  "id" : 162655377899528194,
  "created_at" : "Thu Jan 26 21:57:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162621243340750848",
  "geo" : {
  },
  "id_str" : "162623568054730752",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C aw yeah swipin away! it would be my turn to swipe lol! I am def enjoying burlington, actually I've been brewing a bunch too",
  "id" : 162623568054730752,
  "in_reply_to_status_id" : 162621243340750848,
  "created_at" : "Thu Jan 26 19:50:54 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162541931396739072",
  "text" : "barley spent grain bread turned out great! headed out for a 30mi ride",
  "id" : 162541931396739072,
  "created_at" : "Thu Jan 26 14:26:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/162390590129053696/photo/1",
      "indices" : [ 5, 25 ],
      "url" : "http://t.co/khTO23TR",
      "media_url" : "http://pbs.twimg.com/media/AkDtYZ-CIAEJlIK.jpg",
      "id_str" : "162390590129053697",
      "id" : 162390590129053697,
      "media_url_https" : "https://pbs.twimg.com/media/AkDtYZ-CIAEJlIK.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/khTO23TR"
    } ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162390590129053696",
  "text" : "#yum http://t.co/khTO23TR",
  "id" : 162390590129053696,
  "created_at" : "Thu Jan 26 04:25:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162366928160161792",
  "geo" : {
  },
  "id_str" : "162369264655925248",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan I would!! nice",
  "id" : 162369264655925248,
  "in_reply_to_status_id" : 162366928160161792,
  "created_at" : "Thu Jan 26 03:00:24 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162366640951001089",
  "text" : "all grain \"mild ale\" currently mashing! goal: dark but not heavy.",
  "id" : 162366640951001089,
  "created_at" : "Thu Jan 26 02:49:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complexanalysis",
      "indices" : [ 104, 120 ]
    }, {
      "text" : "mathnerd",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162191361867657217",
  "text" : "live TeX-ing complex analysis class and somehow keeping up, Dr. Foote writes fast! up now, power series #complexanalysis #mathnerd",
  "id" : 162191361867657217,
  "created_at" : "Wed Jan 25 15:13:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 22, 34 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/162181796451196929/photo/1",
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/xPLcMu3v",
      "media_url" : "http://pbs.twimg.com/media/AkAvfA7CIAAPrt2.jpg",
      "id_str" : "162181796455391232",
      "id" : 162181796455391232,
      "media_url_https" : "https://pbs.twimg.com/media/AkAvfA7CIAAPrt2.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/xPLcMu3v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162181796451196929",
  "text" : "with sample size n=2, @bikingbiebs and I have proved people grow .5in at night! http://t.co/xPLcMu3v",
  "id" : 162181796451196929,
  "created_at" : "Wed Jan 25 14:35:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161986770886594561",
  "geo" : {
  },
  "id_str" : "162022265817546754",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser then I can ingest math 24/7!!",
  "id" : 162022265817546754,
  "in_reply_to_status_id" : 161986770886594561,
  "created_at" : "Wed Jan 25 04:01:33 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162004711409582081",
  "geo" : {
  },
  "id_str" : "162022185358209025",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice sahweet!",
  "id" : 162022185358209025,
  "in_reply_to_status_id" : 162004711409582081,
  "created_at" : "Wed Jan 25 04:01:13 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162005220061233152",
  "geo" : {
  },
  "id_str" : "162022152667807744",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 okay, i'll see if I can get UVM cycling to roll by lol",
  "id" : 162022152667807744,
  "in_reply_to_status_id" : 162005220061233152,
  "created_at" : "Wed Jan 25 04:01:06 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 67, 79 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 80, 91 ],
      "id_str" : "355569678",
      "id" : 355569678
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/162008380750303233/photo/1",
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/2lBs85gc",
      "media_url" : "http://pbs.twimg.com/media/Aj-Rw5HCEAA5g7w.jpg",
      "id_str" : "162008380758691840",
      "id" : 162008380758691840,
      "media_url_https" : "https://pbs.twimg.com/media/Aj-Rw5HCEAA5g7w.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/2lBs85gc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "162008380750303233",
  "text" : "this is what we do on a tuesday night... i'm the tallest roommate! @bikingbiebs @erik_ryden http://t.co/2lBs85gc",
  "id" : 162008380750303233,
  "created_at" : "Wed Jan 25 03:06:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/fOtxSXtO",
      "expanded_url" : "http://collegiatecycling.org/eccc/wiki/index.php?n=Calendar.Current",
      "display_url" : "collegiatecycling.org/eccc/wiki/inde…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "161985475169624065",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice yo I'm coming to philly on march 17-18 to race bikes and see you http://t.co/fOtxSXtO",
  "id" : 161985475169624065,
  "created_at" : "Wed Jan 25 01:35:21 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "multitasking",
      "indices" : [ 46, 59 ]
    }, {
      "text" : "nottechnically",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161966517079117824",
  "text" : "currently reading papers while riding my bike #multitasking #nottechnically",
  "id" : 161966517079117824,
  "created_at" : "Wed Jan 25 00:20:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 3, 17 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161966274367324161",
  "text" : "RT @uvmcomplexity: Wed Jan 25, Complex Systems Reading Group, \"Uninformed Individuals Promote Democratic Consensus in Animal Groups\", ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/QfKpgqCY",
        "expanded_url" : "http://bit.ly/yAIoJj",
        "display_url" : "bit.ly/yAIoJj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "161964103039066112",
    "text" : "Wed Jan 25, Complex Systems Reading Group, \"Uninformed Individuals Promote Democratic Consensus in Animal Groups\", http://t.co/QfKpgqCY",
    "id" : 161964103039066112,
    "created_at" : "Wed Jan 25 00:10:25 +0000 2012",
    "user" : {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "protected" : false,
      "id_str" : "368379922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529859022/CSC_logo_symbol_normal.png",
      "id" : 368379922,
      "verified" : false
    }
  },
  "id" : 161966274367324161,
  "created_at" : "Wed Jan 25 00:19:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/161952546393571330/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/TTmH30zA",
      "media_url" : "http://pbs.twimg.com/media/Aj9e-56CQAABZnD.jpg",
      "id_str" : "161952546397765632",
      "id" : 161952546397765632,
      "media_url_https" : "https://pbs.twimg.com/media/Aj9e-56CQAABZnD.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/TTmH30zA"
    } ],
    "hashtags" : [ {
      "text" : "trainertime",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161952546393571330",
  "text" : "papers to read out and music cranked #trainertime http://t.co/TTmH30zA",
  "id" : 161952546393571330,
  "created_at" : "Tue Jan 24 23:24:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Zeb Vance King",
      "screen_name" : "Zeb_King",
      "indices" : [ 38, 47 ],
      "id_str" : "317552757",
      "id" : 317552757
    }, {
      "name" : "App State Cycling",
      "screen_name" : "AppStateCycling",
      "indices" : [ 51, 67 ],
      "id_str" : "343041861",
      "id" : 343041861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161945931191824384",
  "text" : "RT @VTCycling: Our thoughts go out to @Zeb_King of @AppStateCycling who was hit by a car during a ride today.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zeb Vance King",
        "screen_name" : "Zeb_King",
        "indices" : [ 23, 32 ],
        "id_str" : "317552757",
        "id" : 317552757
      }, {
        "name" : "App State Cycling",
        "screen_name" : "AppStateCycling",
        "indices" : [ 36, 52 ],
        "id_str" : "343041861",
        "id" : 343041861
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "161935132763234305",
    "text" : "Our thoughts go out to @Zeb_King of @AppStateCycling who was hit by a car during a ride today.",
    "id" : 161935132763234305,
    "created_at" : "Tue Jan 24 22:15:18 +0000 2012",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 161945931191824384,
  "created_at" : "Tue Jan 24 22:58:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 3, 16 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161871828627881985",
  "text" : "RT @HannaParsons: there is no reason why people shouldn't acknowledge the differences between there, their, and they're online...same fo ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "161849131369889793",
    "text" : "there is no reason why people shouldn't acknowledge the differences between there, their, and they're online...same for your and you're",
    "id" : 161849131369889793,
    "created_at" : "Tue Jan 24 16:33:34 +0000 2012",
    "user" : {
      "name" : "Hanna without an H ",
      "screen_name" : "HannaRuns2Live",
      "protected" : false,
      "id_str" : "368621257",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2922382677/518011409a53bbf49e32f101dfd0a4a8_normal.jpeg",
      "id" : 368621257,
      "verified" : false
    }
  },
  "id" : 161871828627881985,
  "created_at" : "Tue Jan 24 18:03:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "analysiswoes",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161871091923554304",
  "text" : "spent this morning getting angry at my new analysis textbook, making straightfoward definitions unnecessarily confusing ughhh #analysiswoes",
  "id" : 161871091923554304,
  "created_at" : "Tue Jan 24 18:00:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 29, 45 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 63, 74 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161870703115771904",
  "text" : "awww. I want ice cream now! \"@JacobnAndersson first D2 without @andyreagan. so sad\"",
  "id" : 161870703115771904,
  "created_at" : "Tue Jan 24 17:59:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161674218105344001",
  "text" : "brewing success was had, with an OG *above* the expected 1.042 (+.001). also had to turn DOWN the flow on my chiller bc it cooling too fast!",
  "id" : 161674218105344001,
  "created_at" : "Tue Jan 24 04:58:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mashing",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161594138133921792",
  "text" : "all grain brew has commenced. the grain just chills in the cooler at 153F for an hour for step one #mashing",
  "id" : 161594138133921792,
  "created_at" : "Mon Jan 23 23:40:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/161567035288059904/photo/1",
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/mX9A4WJL",
      "media_url" : "http://pbs.twimg.com/media/Aj4AXNICAAAmnMC.jpg",
      "id_str" : "161567035292254208",
      "id" : 161567035292254208,
      "media_url_https" : "https://pbs.twimg.com/media/Aj4AXNICAAAmnMC.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/mX9A4WJL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161567035288059904",
  "text" : "counterflow chiller test run successful!! http://t.co/mX9A4WJL",
  "id" : 161567035288059904,
  "created_at" : "Mon Jan 23 21:52:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161566706169421824",
  "text" : "apparently if you dont go on FB for long enough, they summarize what you've missed in an email.",
  "id" : 161566706169421824,
  "created_at" : "Mon Jan 23 21:51:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/161554007083589632/photo/1",
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/W08HR4hc",
      "media_url" : "http://pbs.twimg.com/media/Aj30g3SCIAAbpPQ.jpg",
      "id_str" : "161554007087783936",
      "id" : 161554007087783936,
      "media_url_https" : "https://pbs.twimg.com/media/Aj30g3SCIAAbpPQ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/W08HR4hc"
    } ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161554007083589632",
  "text" : "total book cost this semester: $8.35 #win http://t.co/W08HR4hc",
  "id" : 161554007083589632,
  "created_at" : "Mon Jan 23 21:00:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disneywords",
      "screen_name" : "disneywords",
      "indices" : [ 54, 66 ],
      "id_str" : "126400767",
      "id" : 126400767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161516725467217922",
  "text" : "only if you replace 'like best' with 'hate worst' ...\"@disneywords: What I like best is just doing nothing. –Christopher Robin\"",
  "id" : 161516725467217922,
  "created_at" : "Mon Jan 23 18:32:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161510315039789056",
  "geo" : {
  },
  "id_str" : "161513481823199232",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis I need some of what you're eating for lunch!",
  "id" : 161513481823199232,
  "in_reply_to_status_id" : 161510315039789056,
  "created_at" : "Mon Jan 23 18:19:49 +0000 2012",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "axiomofchoice",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161511351913680898",
  "text" : "note: a mathematician declaring he is pro-choice may not be making a political statement. #axiomofchoice",
  "id" : 161511351913680898,
  "created_at" : "Mon Jan 23 18:11:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161509927276396545",
  "text" : "the axiom of choice in 1 tweet: \"the cartesian product of any nonempty collection of nonempty sets is not empty\" -Foote",
  "id" : 161509927276396545,
  "created_at" : "Mon Jan 23 18:05:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reallyintersting",
      "indices" : [ 69, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161509710565085185",
  "text" : "already covered limits and continuity in complex, and today the AoC! #reallyintersting",
  "id" : 161509710565085185,
  "created_at" : "Mon Jan 23 18:04:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/161488761052606464/photo/1",
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/8wosVKHY",
      "media_url" : "http://pbs.twimg.com/media/Aj25LC4CMAASjEy.jpg",
      "id_str" : "161488761056800768",
      "id" : 161488761056800768,
      "media_url_https" : "https://pbs.twimg.com/media/Aj25LC4CMAASjEy.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/8wosVKHY"
    } ],
    "hashtags" : [ {
      "text" : "homebrewing",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161488761052606464",
  "text" : "all grain! #homebrewing http://t.co/8wosVKHY",
  "id" : 161488761052606464,
  "created_at" : "Mon Jan 23 16:41:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 19, 30 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161245389360607232",
  "text" : "good seeing broski @kreagannet on a quick SYR stop on the way home!! back on 90, goal is Burlington by midnight",
  "id" : 161245389360607232,
  "created_at" : "Mon Jan 23 00:34:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 98, 105 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 117, 124 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "161202779631796224",
  "text" : "leaving Brockport after a fun weekend of snowshoe running, sledding, running, and spending time w @sspis1! (and with @DZdan1 too I guess :P)",
  "id" : 161202779631796224,
  "created_at" : "Sun Jan 22 21:45:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "betterthansleeping",
      "indices" : [ 66, 85 ]
    }, {
      "text" : "maybe",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160575949614759937",
  "text" : "tweeting for entertainment when youre the only one on the highway #betterthansleeping #maybe",
  "id" : 160575949614759937,
  "created_at" : "Sat Jan 21 04:14:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160574760563126272",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice see previous tweet as well (your name was too long to tag lol)",
  "id" : 160574760563126272,
  "created_at" : "Sat Jan 21 04:09:40 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 105, 112 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 119, 128 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 129, 140 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160574553540673536",
  "text" : "checklist 2; slicked back hair? check. tucked in polos? check. premature yakking? check. must be close 2 @DZdan1's apt @DKnick88 @skholden17",
  "id" : 160574553540673536,
  "created_at" : "Sat Jan 21 04:08:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brockport",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160573707255955457",
  "text" : "middle of nowhere? check. only two bars around? check. locals havent heard of \"college\" nearby? check. i must be getting near #brockport...",
  "id" : 160573707255955457,
  "created_at" : "Sat Jan 21 04:05:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 35, 44 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 86, 93 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 94, 101 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160555779261341696",
  "text" : "successful chili pitstop at home w @dmreagan @RumblinStumblinand ...on the bport now! @sspis1 @DZdan1 be there by midnight!",
  "id" : 160555779261341696,
  "created_at" : "Sat Jan 21 02:54:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160527391561760768",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin just passed the turning stone",
  "id" : 160527391561760768,
  "created_at" : "Sat Jan 21 01:01:27 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160482523690971136",
  "text" : "back to the Empire State! Watched the sun set across the ADK's and ate an entire loaf of bread already, in one hour",
  "id" : 160482523690971136,
  "created_at" : "Fri Jan 20 22:03:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVMcomplexsystems",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160436821933834240",
  "text" : "currently attending \"Predicting the Risk for Sudden Cardiac Death\" with Leon Glass of McGill University in Montreal #UVMcomplexsystems",
  "id" : 160436821933834240,
  "created_at" : "Fri Jan 20 19:01:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "painful",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160430190151999488",
  "text" : "sitting through a lecture that you could give...kind of like finishing a hard run #painful",
  "id" : 160430190151999488,
  "created_at" : "Fri Jan 20 18:35:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bored",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "limitsreally",
      "indices" : [ 78, 91 ]
    }, {
      "text" : "VTwin",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160429175092682752",
  "text" : "real analysis II? more like mid semester real analysis I at Va Tech... #bored #limitsreally #VTwin",
  "id" : 160429175092682752,
  "created_at" : "Fri Jan 20 18:31:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "speedster",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "whatstopsigns",
      "indices" : [ 48, 62 ]
    }, {
      "text" : "ididntseethem",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160394994669195264",
  "text" : "got to class in less than 5min today #speedster #whatstopsigns #ididntseethem",
  "id" : 160394994669195264,
  "created_at" : "Fri Jan 20 16:15:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 4, 15 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 16, 27 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160230900901228544",
  "text" : "RT \"@kreagannet @andyreagan #awesome\"",
  "id" : 160230900901228544,
  "created_at" : "Fri Jan 20 05:23:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160142173566803969",
  "geo" : {
  },
  "id_str" : "160230716918075394",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e ok good thats what I thought... just using the power of twitter to dbl check, its a present for someone whose fav color is purple!",
  "id" : 160230716918075394,
  "in_reply_to_status_id" : 160142173566803969,
  "created_at" : "Fri Jan 20 05:22:34 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160178763701821442",
  "geo" : {
  },
  "id_str" : "160230385228320768",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons sometimes the andriod app is really weird, cuz you're right it still says im not following you",
  "id" : 160230385228320768,
  "in_reply_to_status_id" : 160178763701821442,
  "created_at" : "Fri Jan 20 05:21:15 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160137495089119232",
  "geo" : {
  },
  "id_str" : "160230172082176001",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser for purple...you win a free drink from the newly minted kegerator! check my last tweet to see the contraption, one for farrell?",
  "id" : 160230172082176001,
  "in_reply_to_status_id" : 160137495089119232,
  "created_at" : "Fri Jan 20 05:20:24 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160178763701821442",
  "geo" : {
  },
  "id_str" : "160229795303661569",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons I didnt unfollow you lol, it said I wasnt following you so I started again?",
  "id" : 160229795303661569,
  "in_reply_to_status_id" : 160178763701821442,
  "created_at" : "Fri Jan 20 05:18:54 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 22, 34 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "outtaform",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160229545809678336",
  "text" : "in other news, I took @bikingbiebs to his first EVER loss in foosball tonight #outtaform",
  "id" : 160229545809678336,
  "created_at" : "Fri Jan 20 05:17:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/160227317438873600/photo/1",
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/1x25wXpJ",
      "media_url" : "http://pbs.twimg.com/media/Ajk95XOCAAAUrLK.jpg",
      "id_str" : "160227317443067904",
      "id" : 160227317443067904,
      "media_url_https" : "https://pbs.twimg.com/media/Ajk95XOCAAAUrLK.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/1x25wXpJ"
    } ],
    "hashtags" : [ {
      "text" : "homebrewontap",
      "indices" : [ 30, 44 ]
    }, {
      "text" : "classy",
      "indices" : [ 45, 52 ]
    }, {
      "text" : "partyatmyhouse",
      "indices" : [ 53, 68 ]
    }, {
      "text" : "nonatty",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160227317438873600",
  "text" : "kegerator building complete!! #homebrewontap #classy #partyatmyhouse #nonatty http://t.co/1x25wXpJ",
  "id" : 160227317438873600,
  "created_at" : "Fri Jan 20 05:09:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/160166532956176385/photo/1",
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/og1rlZTI",
      "media_url" : "http://pbs.twimg.com/media/AjkGnPYCQAAg94m.jpg",
      "id_str" : "160166532960370688",
      "id" : 160166532960370688,
      "media_url_https" : "https://pbs.twimg.com/media/AjkGnPYCQAAg94m.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/og1rlZTI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160166532956176385",
  "text" : "new fridge door installed (old one next to it) http://t.co/og1rlZTI",
  "id" : 160166532956176385,
  "created_at" : "Fri Jan 20 01:07:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160124112751169537",
  "text" : "big boxes in my room?! do i smell kegerator?!",
  "id" : 160124112751169537,
  "created_at" : "Thu Jan 19 22:18:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/160120639238324224/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/jEcyslDj",
      "media_url" : "http://pbs.twimg.com/media/Ajjc339CQAAGWek.jpg",
      "id_str" : "160120639242518528",
      "id" : 160120639242518528,
      "media_url_https" : "https://pbs.twimg.com/media/Ajjc339CQAAGWek.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/jEcyslDj"
    } ],
    "hashtags" : [ {
      "text" : "deeptwitterquestions",
      "indices" : [ 15, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160120639238324224",
  "text" : "pink or purple #deeptwitterquestions http://t.co/jEcyslDj",
  "id" : 160120639238324224,
  "created_at" : "Thu Jan 19 22:05:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 57, 68 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "160120303236816898",
  "text" : "RT @DZdan1: Training is over, BSG work all day tomorrow. @andyreagan  is coming to visit this weekend!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 45, 56 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "160117413994692608",
    "text" : "Training is over, BSG work all day tomorrow. @andyreagan  is coming to visit this weekend!",
    "id" : 160117413994692608,
    "created_at" : "Thu Jan 19 21:52:20 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 160120303236816898,
  "created_at" : "Thu Jan 19 22:03:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/ymkOTb5A",
      "expanded_url" : "http://www.backcountry.com/black-diamond-contact-strap-crampon.html?CMP_SKU=BLD1066&MER=0406&CMP_ID=GAN_GPLA&003=8219600&010=BLD1066-ST-ONESIZ&mr:trackingCode=539791DA-F061-DF11-9DA0-002219319097&mr:referralID=NA&origin=pla&mr:adType=pla",
      "display_url" : "backcountry.com/black-diamond-…"
    } ]
  },
  "in_reply_to_status_id_str" : "160051538163806208",
  "geo" : {
  },
  "id_str" : "160052732642856960",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser sounds like you need these to walk to work http://t.co/ymkOTb5A",
  "id" : 160052732642856960,
  "in_reply_to_status_id" : 160051538163806208,
  "created_at" : "Thu Jan 19 17:35:19 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159988668772257794",
  "text" : "RT @sspis1 excited for life",
  "id" : 159988668772257794,
  "created_at" : "Thu Jan 19 13:20:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 3, 14 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159969603097870336",
  "text" : "RT @peterdodds: TEDxCMU -- Luis von Ahn -- Duolingo: The Next Chapter in Human Computation - YouTube: Sociotechnocene action. http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/lsluxW93",
        "expanded_url" : "http://bit.ly/qTV6JV",
        "display_url" : "bit.ly/qTV6JV"
      } ]
    },
    "geo" : {
    },
    "id_str" : "159857745540030465",
    "text" : "TEDxCMU -- Luis von Ahn -- Duolingo: The Next Chapter in Human Computation - YouTube: Sociotechnocene action. http://t.co/lsluxW93",
    "id" : 159857745540030465,
    "created_at" : "Thu Jan 19 04:40:31 +0000 2012",
    "user" : {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "protected" : false,
      "id_str" : "16174144",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/294761101/IMG_7808_small_normal.JPG",
      "id" : 16174144,
      "verified" : false
    }
  },
  "id" : 159969603097870336,
  "created_at" : "Thu Jan 19 12:05:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159824398570889216/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/e8sBYdH0",
      "media_url" : "http://pbs.twimg.com/media/AjfPcZeCIAAKy-j.jpg",
      "id_str" : "159824398575083520",
      "id" : 159824398575083520,
      "media_url_https" : "https://pbs.twimg.com/media/AjfPcZeCIAAKy-j.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/e8sBYdH0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159824398570889216",
  "text" : "ever wondered what the inside of your fridge door looks like? http://t.co/e8sBYdH0",
  "id" : 159824398570889216,
  "created_at" : "Thu Jan 19 02:28:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 16, 28 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159773188698554368/photo/1",
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/PL18hhdC",
      "media_url" : "http://pbs.twimg.com/media/Ajeg3l1CQAAu8jE.jpg",
      "id_str" : "159773188702748672",
      "id" : 159773188702748672,
      "media_url_https" : "https://pbs.twimg.com/media/Ajeg3l1CQAAu8jE.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/PL18hhdC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159773188698554368",
  "text" : "trainer time! w @bikingbiebs http://t.co/PL18hhdC",
  "id" : 159773188698554368,
  "created_at" : "Wed Jan 18 23:04:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 33, 40 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 42, 51 ],
      "id_str" : "23640974",
      "id" : 23640974
    }, {
      "name" : "Paul Beatty",
      "screen_name" : "PaulBeatty",
      "indices" : [ 56, 67 ],
      "id_str" : "30007041",
      "id" : 30007041
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159764257808977920/photo/1",
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/ubx8SG0B",
      "media_url" : "http://pbs.twimg.com/media/AjeYvvsCEAAJTKK.jpg",
      "id_str" : "159764257817366528",
      "id" : 159764257817366528,
      "media_url_https" : "https://pbs.twimg.com/media/AjeYvvsCEAAJTKK.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ubx8SG0B"
    } ],
    "hashtags" : [ {
      "text" : "thanksguys",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159764257808977920",
  "text" : "my first mail in Vermont is from @k8eb8e, @jpbeatty and @paulbeatty #thanksguys http://t.co/ubx8SG0B",
  "id" : 159764257808977920,
  "created_at" : "Wed Jan 18 22:29:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 19, 33 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159758278954450944",
  "text" : "also got to run in @brooksrunning's Pureproject PureFlow ...can I say that I can't wait for my (also Brooks) Ghost 4's to wear out?",
  "id" : 159758278954450944,
  "created_at" : "Wed Jan 18 22:05:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 67, 78 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159756800646856704/photo/1",
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/sfZTYi5z",
      "media_url" : "http://pbs.twimg.com/media/AjeR9rlCQAA_H-7.jpg",
      "id_str" : "159756800651051008",
      "id" : 159756800651051008,
      "media_url_https" : "https://pbs.twimg.com/media/AjeR9rlCQAA_H-7.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/sfZTYi5z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159756800646856704",
  "text" : "picked up a pair of running snowshoes, hopefully we get more snow. @peterdodds let me know if you go http://t.co/sfZTYi5z",
  "id" : 159756800646856704,
  "created_at" : "Wed Jan 18 21:59:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159736233373863936/photo/1",
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/UseDTFK0",
      "media_url" : "http://pbs.twimg.com/media/Ajd_QghCEAI8fYI.jpg",
      "id_str" : "159736233378058242",
      "id" : 159736233378058242,
      "media_url_https" : "https://pbs.twimg.com/media/Ajd_QghCEAI8fYI.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/UseDTFK0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159736233373863936",
  "text" : "not even close http://t.co/UseDTFK0",
  "id" : 159736233373863936,
  "created_at" : "Wed Jan 18 20:37:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159691289162551297",
  "geo" : {
  },
  "id_str" : "159731498956763136",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 new yorkers.... flannel is 100% acceptable attire in SW VA! And if it isnt already in VT, I'm making it lol",
  "id" : 159731498956763136,
  "in_reply_to_status_id" : 159691289162551297,
  "created_at" : "Wed Jan 18 20:18:51 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159700904709341184",
  "text" : "\"mature: know sets, logic, proofs etc, and question authority with a need for a convincing argument for each fact\" -Sands, real analysis",
  "id" : 159700904709341184,
  "created_at" : "Wed Jan 18 18:17:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thawplease",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159472327036379136",
  "text" : "new shifter cable installed on the mountain bike, too bad everything is ice #thawplease",
  "id" : 159472327036379136,
  "created_at" : "Wed Jan 18 03:09:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159434018465648641/photo/1",
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/724YNnWN",
      "media_url" : "http://pbs.twimg.com/media/AjZsZSQCEAA7DCJ.jpg",
      "id_str" : "159434018469842944",
      "id" : 159434018469842944,
      "media_url_https" : "https://pbs.twimg.com/media/AjZsZSQCEAA7DCJ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/724YNnWN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159434018465648641",
  "text" : "road running shoes arent made for solid ice and slush downhill trails, but ran most of the trails anyway http://t.co/724YNnWN",
  "id" : 159434018465648641,
  "created_at" : "Wed Jan 18 00:36:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 7, 19 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damn",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159433597592420352",
  "text" : "S/O to @runfasteraw for breaking 3hrs in the Charleston Marathon this past Sunday! Just barely tho (by 1sec!), and 9th overall 1st AG #damn",
  "id" : 159433597592420352,
  "created_at" : "Wed Jan 18 00:35:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159401841900257280",
  "text" : "good first day, now going to find trails to run!",
  "id" : 159401841900257280,
  "created_at" : "Tue Jan 17 22:28:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159387447623561217/photo/1",
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/SVF8LVSt",
      "media_url" : "http://pbs.twimg.com/media/AjZCCgWCMAAOeBo.jpg",
      "id_str" : "159387447627755520",
      "id" : 159387447627755520,
      "media_url_https" : "https://pbs.twimg.com/media/AjZCCgWCMAAOeBo.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/SVF8LVSt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159387447623561217",
  "text" : "stoppin at city market errday to get fresh veggies http://t.co/SVF8LVSt",
  "id" : 159387447623561217,
  "created_at" : "Tue Jan 17 21:31:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159359436606021632",
  "text" : "\"the grade percentages are loose. im also kinda like santa claus, i know whose been good or bad\" -foote",
  "id" : 159359436606021632,
  "created_at" : "Tue Jan 17 19:40:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/J0uwqoqr",
      "expanded_url" : "http://4sq.com/zWu6Rk",
      "display_url" : "4sq.com/zWu6Rk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4791461845, -73.1982564926 ]
  },
  "id_str" : "159356315859304449",
  "text" : "next up: complex analysis with Richard Foote (@ UVM Votey Hall) http://t.co/J0uwqoqr",
  "id" : 159356315859304449,
  "created_at" : "Tue Jan 17 19:28:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/b0F8hpmA",
      "expanded_url" : "http://4sq.com/Al5r3g",
      "display_url" : "4sq.com/Al5r3g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4781873009, -73.1985665569 ]
  },
  "id_str" : "159332903359234048",
  "text" : "first class: nonlinear PDE's (they werent offering regular PDE's) (@ UVM Lafayette Hall) http://t.co/b0F8hpmA",
  "id" : 159332903359234048,
  "created_at" : "Tue Jan 17 17:54:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "garminstats",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159325728712822784",
  "text" : "has averaged 8mi, over an hour of time, and 800ft of climbing in my last five months of running! #garminstats 460mi on the shoes tho...",
  "id" : 159325728712822784,
  "created_at" : "Tue Jan 17 17:26:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159262468298915840",
  "text" : "took my last night before class to sleep... 10+ hrs in the bank for this semester, here we go!",
  "id" : 159262468298915840,
  "created_at" : "Tue Jan 17 13:15:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gottarun",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159020407771512833",
  "text" : "wind whipping outside and its 20deg...but #gottarun",
  "id" : 159020407771512833,
  "created_at" : "Mon Jan 16 21:13:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/159015070062493698/photo/1",
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/y9EcTrAR",
      "media_url" : "http://pbs.twimg.com/media/AjTvXR1CQAAwL85.jpg",
      "id_str" : "159015070066688000",
      "id" : 159015070066688000,
      "media_url_https" : "https://pbs.twimg.com/media/AjTvXR1CQAAwL85.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/y9EcTrAR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "159015070062493698",
  "text" : "finished my handmade counterflow chiller (for home brewing) ...now I need to brew something! http://t.co/y9EcTrAR",
  "id" : 159015070062493698,
  "created_at" : "Mon Jan 16 20:52:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158914340949467136",
  "geo" : {
  },
  "id_str" : "158915486942371840",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin nothin, get on skype",
  "id" : 158915486942371840,
  "in_reply_to_status_id" : 158914340949467136,
  "created_at" : "Mon Jan 16 14:16:19 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158911661711953920",
  "geo" : {
  },
  "id_str" : "158914024363393024",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin you let me know when",
  "id" : 158914024363393024,
  "in_reply_to_status_id" : 158911661711953920,
  "created_at" : "Mon Jan 16 14:10:30 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158910127318122496",
  "text" : "Burlington really is going to take some getting used to....it's -9 right now",
  "id" : 158910127318122496,
  "created_at" : "Mon Jan 16 13:55:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 27, 39 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 86, 99 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Jacob Aber",
      "screen_name" : "jabervt",
      "indices" : [ 100, 108 ],
      "id_str" : "370283022",
      "id" : 370283022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/eMNGW6b7",
      "expanded_url" : "http://www.youtube.com/watch?v=qqpcBpSsj1A&feature=pyv",
      "display_url" : "youtube.com/watch?v=qqpcBp…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "158908630266167297",
  "text" : ".@vtcycling needs to adopt @UVM_cycling's newest mandatory training equipment as well @williamenium @jabervt http://t.co/eMNGW6b7",
  "id" : 158908630266167297,
  "created_at" : "Mon Jan 16 13:49:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 93, 100 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158723601468620800",
  "text" : "climbed a mountain in negative temps, quality time spent at home depot, and a great dinner w @sspis1 so far today!",
  "id" : 158723601468620800,
  "created_at" : "Mon Jan 16 01:33:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jealous",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158243448829378560",
  "geo" : {
  },
  "id_str" : "158253083275702272",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 #jealous ...it's 9 here lol",
  "id" : 158253083275702272,
  "in_reply_to_status_id" : 158243448829378560,
  "created_at" : "Sat Jan 14 18:24:09 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timetobrew",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158060986383867904",
  "text" : "meanwhile, the keg has been tapped. #timetobrew",
  "id" : 158060986383867904,
  "created_at" : "Sat Jan 14 05:40:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodwork",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/UJwYmU5D",
      "expanded_url" : "http://twitter.com/dr_pyser/status/158047306720083969/photo/1",
      "display_url" : "pic.twitter.com/UJwYmU5D"
    } ]
  },
  "geo" : {
  },
  "id_str" : "158060792007241728",
  "text" : "\"@dr_pyser: Snow angel'd! http://t.co/UJwYmU5D\" a very high quality snow angel indeed! perhaps the best ive seen? #goodwork",
  "id" : 158060792007241728,
  "created_at" : "Sat Jan 14 05:40:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "indices" : [ 44, 56 ],
      "id_str" : "19368361",
      "id" : 19368361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "158048441937825792",
  "text" : "just started tonight, and finished, reading @bikesnobnyc's book Bike Snob. really great stuff! didnt put it down once.",
  "id" : 158048441937825792,
  "created_at" : "Sat Jan 14 04:50:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157956716036751360",
  "geo" : {
  },
  "id_str" : "157958687573549057",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin yeah no newly uploaded files will open right...I made a workaround but its silly",
  "id" : 157958687573549057,
  "in_reply_to_status_id" : 157956716036751360,
  "created_at" : "Fri Jan 13 22:54:20 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/4HEHTZR9",
      "expanded_url" : "http://andyreagan.com/bike-and-build/",
      "display_url" : "andyreagan.com/bike-and-build/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157955746263343105",
  "text" : "updated the Bike and Build page on my blog with a big map and links to each day: http://t.co/4HEHTZR9",
  "id" : 157955746263343105,
  "created_at" : "Fri Jan 13 22:42:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/gVMgLHlM",
      "expanded_url" : "http://www.uvm.edu/~areagan/",
      "display_url" : "uvm.edu/~areagan/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157923828192903169",
  "text" : "got my office keys, my first paycheck, my VT classes dropped, and my CV updated on the finished UVM website: http://t.co/gVMgLHlM",
  "id" : 157923828192903169,
  "created_at" : "Fri Jan 13 20:35:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "METROFIETS",
      "screen_name" : "metrofiets",
      "indices" : [ 0, 11 ],
      "id_str" : "18385161",
      "id" : 18385161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157315688753668096",
  "geo" : {
  },
  "id_str" : "157916323073110017",
  "in_reply_to_user_id" : 18385161,
  "text" : "@metrofiets I will let you guys know! I stumbled across yours with the CK hub while looking for inspiration, the coolest one I found!",
  "id" : 157916323073110017,
  "in_reply_to_status_id" : 157315688753668096,
  "created_at" : "Fri Jan 13 20:06:00 +0000 2012",
  "in_reply_to_screen_name" : "metrofiets",
  "in_reply_to_user_id_str" : "18385161",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157844169916825600",
  "geo" : {
  },
  "id_str" : "157916179690823680",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw or, you could just stop being such a wimp and run the whole thing at 5:39",
  "id" : 157916179690823680,
  "in_reply_to_status_id" : 157844169916825600,
  "created_at" : "Fri Jan 13 20:05:25 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157886239184396288",
  "geo" : {
  },
  "id_str" : "157916015991328768",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet thanks brother! (they're all full haha)",
  "id" : 157916015991328768,
  "in_reply_to_status_id" : 157886239184396288,
  "created_at" : "Fri Jan 13 20:04:46 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "frozentoes",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157872249028886528",
  "text" : "first outdoor road ride in Burlington #fail. mid 30s, started sprinkling...then pouring #frozentoes",
  "id" : 157872249028886528,
  "created_at" : "Fri Jan 13 17:10:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/157692694477537280/photo/1",
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/PhGSJ0Ui",
      "media_url" : "http://pbs.twimg.com/media/AjA8q45CAAEhRH2.jpg",
      "id_str" : "157692694481731585",
      "id" : 157692694481731585,
      "media_url_https" : "https://pbs.twimg.com/media/AjA8q45CAAEhRH2.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/PhGSJ0Ui"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157692694477537280",
  "text" : "ill call that a successful night http://t.co/PhGSJ0Ui",
  "id" : 157692694477537280,
  "created_at" : "Fri Jan 13 05:17:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/rtzv64iq",
      "expanded_url" : "http://peakraces.com/deathrace/results/race-report/",
      "display_url" : "peakraces.com/deathrace/resu…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157561686319054849",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 I think puts tough mudder to shame! the DEATH RACE: http://t.co/rtzv64iq",
  "id" : 157561686319054849,
  "created_at" : "Thu Jan 12 20:36:48 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 30, 41 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/jtOlz64B",
      "expanded_url" : "http://bit.ly/ybUWit",
      "display_url" : "bit.ly/ybUWit"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157508050184454144",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan RT @bakadesuyo What's the best thing to have after a heart attack? http://t.co/jtOlz64B",
  "id" : 157508050184454144,
  "created_at" : "Thu Jan 12 17:03:40 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157255825272999937",
  "geo" : {
  },
  "id_str" : "157256452094967810",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin yeah i made close to a pound, whoops lol. really not that much though.",
  "id" : 157256452094967810,
  "in_reply_to_status_id" : 157255825272999937,
  "created_at" : "Thu Jan 12 00:23:54 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3days",
      "indices" : [ 130, 136 ]
    }, {
      "text" : "gl",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157256082459340800",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw dude know how u said you got twitter in the dark ages? just looked, I was 1 mon ahead! guy i wrk w was 2yr b4 me. PS #3days #gl",
  "id" : 157256082459340800,
  "created_at" : "Thu Jan 12 00:22:26 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 3, 14 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "open",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "science",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "evolve",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/OgLkK9RU",
      "expanded_url" : "http://nyti.ms/w5hrmm",
      "display_url" : "nyti.ms/w5hrmm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157254252572577794",
  "text" : "RT @peterdodds: \"Research Bought, Then Paid For\": http://t.co/OgLkK9RU #open #science #evolve",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "open",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "science",
        "indices" : [ 61, 69 ]
      }, {
        "text" : "evolve",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http://t.co/OgLkK9RU",
        "expanded_url" : "http://nyti.ms/w5hrmm",
        "display_url" : "nyti.ms/w5hrmm"
      } ]
    },
    "geo" : {
    },
    "id_str" : "157251524605652993",
    "text" : "\"Research Bought, Then Paid For\": http://t.co/OgLkK9RU #open #science #evolve",
    "id" : 157251524605652993,
    "created_at" : "Thu Jan 12 00:04:19 +0000 2012",
    "user" : {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "protected" : false,
      "id_str" : "16174144",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/294761101/IMG_7808_small_normal.JPG",
      "id" : 16174144,
      "verified" : false
    }
  },
  "id" : 157254252572577794,
  "created_at" : "Thu Jan 12 00:15:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/XcHxI4Ed",
      "expanded_url" : "http://www.youtube.com/watch?v=m9FRSghXhDM",
      "display_url" : "youtube.com/watch?v=m9FRSg…"
    } ]
  },
  "in_reply_to_status_id_str" : "157249793666727936",
  "geo" : {
  },
  "id_str" : "157253386155208704",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser ALL of them! almost as much spice in my tilapia as bacon in epic meal time's lasagna: http://t.co/XcHxI4Ed",
  "id" : 157253386155208704,
  "in_reply_to_status_id" : 157249793666727936,
  "created_at" : "Thu Jan 12 00:11:43 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157228517032075264",
  "geo" : {
  },
  "id_str" : "157252632342306817",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin and yeah I made a whole little glad container! and hope your cc is too sticky",
  "id" : 157252632342306817,
  "in_reply_to_status_id" : 157228517032075264,
  "created_at" : "Thu Jan 12 00:08:43 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 23, 39 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/157248736353980416/photo/1",
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/Bv2KwnlV",
      "media_url" : "http://pbs.twimg.com/media/Ai6o5IACEAAhi9o.jpg",
      "id_str" : "157248736358174720",
      "id" : 157248736358174720,
      "media_url_https" : "https://pbs.twimg.com/media/Ai6o5IACEAAhi9o.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Bv2KwnlV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157248736353980416",
  "text" : "mmm blackened tilapia, @RumblinStumblin jealous? http://t.co/Bv2KwnlV",
  "id" : 157248736353980416,
  "created_at" : "Wed Jan 11 23:53:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/157233767679922176/photo/1",
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/ZzdxY7lR",
      "media_url" : "http://pbs.twimg.com/media/Ai6bR1WCEAI6vgG.jpg",
      "id_str" : "157233767684116482",
      "id" : 157233767684116482,
      "media_url_https" : "https://pbs.twimg.com/media/Ai6bR1WCEAI6vgG.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ZzdxY7lR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157233767679922176",
  "text" : "woah cool!! check out this note someone left on a bike outside city market http://t.co/ZzdxY7lR",
  "id" : 157233767679922176,
  "created_at" : "Wed Jan 11 22:53:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/157221541833228288/photo/1",
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/fKHISkt3",
      "media_url" : "http://pbs.twimg.com/media/Ai6QKMgCQAMj8Py.jpg",
      "id_str" : "157221541833228291",
      "id" : 157221541833228291,
      "media_url_https" : "https://pbs.twimg.com/media/Ai6QKMgCQAMj8Py.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/fKHISkt3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157221541833228288",
  "text" : "the tap handle parts amassing! http://t.co/fKHISkt3",
  "id" : 157221541833228288,
  "created_at" : "Wed Jan 11 22:05:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "jealous",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157209453551300609",
  "geo" : {
  },
  "id_str" : "157217716917379072",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris #ouch #jealous typical edie too haha",
  "id" : 157217716917379072,
  "in_reply_to_status_id" : 157209453551300609,
  "created_at" : "Wed Jan 11 21:49:59 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 44, 60 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 65, 74 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/157217063197356032/photo/1",
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/HEHd27LZ",
      "media_url" : "http://pbs.twimg.com/media/Ai6MFgTCMAAUN9V.jpg",
      "id_str" : "157217063201550336",
      "id" : 157217063201550336,
      "media_url_https" : "https://pbs.twimg.com/media/Ai6MFgTCMAAUN9V.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/HEHd27LZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157217063197356032",
  "text" : "check out how many spices are necessary for @RumblinStumblin and @dmreagan's blackened tilapia http://t.co/HEHd27LZ",
  "id" : 157217063197356032,
  "created_at" : "Wed Jan 11 21:47:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/0xS8nxYW",
      "expanded_url" : "http://www.sciencemag.org/content/334/6062/1518",
      "display_url" : "sciencemag.org/content/334/60…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "157160825516331010",
  "text" : "paper for today's complex systems reading group presents a neat tool to look at big data: http://t.co/0xS8nxYW",
  "id" : 157160825516331010,
  "created_at" : "Wed Jan 11 18:03:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/ajPbLiuH",
      "expanded_url" : "http://www.metrofiets.com/profiles/hopworks/#photo3957329376",
      "display_url" : "metrofiets.com/profiles/hopwo…"
    } ]
  },
  "in_reply_to_status_id_str" : "157126221937913856",
  "geo" : {
  },
  "id_str" : "157131513912233984",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris spokes might flex a bit much, but that would be cool! http://t.co/ajPbLiuH",
  "id" : 157131513912233984,
  "in_reply_to_status_id" : 157126221937913856,
  "created_at" : "Wed Jan 11 16:07:26 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "earlybird",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "157091620318228480",
  "text" : "got into the office before it was even unlocked this AM #earlybird",
  "id" : 157091620318228480,
  "created_at" : "Wed Jan 11 13:28:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwonder",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156990266308427776",
  "text" : "how can you travel if you havent experienced everything that where you are has to offer #iwonder",
  "id" : 156990266308427776,
  "created_at" : "Wed Jan 11 06:46:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 80, 91 ],
      "id_str" : "15408193",
      "id" : 15408193
    }, {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "indices" : [ 92, 104 ],
      "id_str" : "19368361",
      "id" : 19368361
    }, {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 105, 121 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156989745392652288",
  "text" : "thoughts/ideas for a bicycle-inspired tap handle anyone? (shock / gear / crank) @fatcyclist @bikesnobnyc @peacelovinchris",
  "id" : 156989745392652288,
  "created_at" : "Wed Jan 11 06:44:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/Qghn54vH",
      "expanded_url" : "http://water.epa.gov/infrastructure/drinkingwater/sourcewater/protection/casestudies/upload/Source-Water-Case-Study-VT-Burlington.pdf",
      "display_url" : "water.epa.gov/infrastructure…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "156988792329342976",
  "text" : "my Burlington peeps might care to know they're drinking Lake Champlain (I was just curious) http://t.co/Qghn54vH",
  "id" : 156988792329342976,
  "created_at" : "Wed Jan 11 06:40:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156979266209320960",
  "geo" : {
  },
  "id_str" : "156988401239851008",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy tweet! nobody cares about fb anyway",
  "id" : 156988401239851008,
  "in_reply_to_status_id" : 156979266209320960,
  "created_at" : "Wed Jan 11 06:38:46 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156924776307363841",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice defend yourself?",
  "id" : 156924776307363841,
  "created_at" : "Wed Jan 11 02:25:56 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie ",
      "screen_name" : "smrave",
      "indices" : [ 0, 7 ],
      "id_str" : "225553548",
      "id" : 225553548
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 11, 26 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "confused",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "hesnotzdanowski",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156882212741062656",
  "geo" : {
  },
  "id_str" : "156899728691445761",
  "in_reply_to_user_id" : 225553548,
  "text" : "@smrave is @ryandelgiudice on girls night lol? #confused #hesnotzdanowski",
  "id" : 156899728691445761,
  "in_reply_to_status_id" : 156882212741062656,
  "created_at" : "Wed Jan 11 00:46:25 +0000 2012",
  "in_reply_to_screen_name" : "smrave",
  "in_reply_to_user_id_str" : "225553548",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156872220067631104",
  "geo" : {
  },
  "id_str" : "156899155908894720",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 congrats!",
  "id" : 156899155908894720,
  "in_reply_to_status_id" : 156872220067631104,
  "created_at" : "Wed Jan 11 00:44:08 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156764390442549248",
  "text" : "RT @MathewFox1: Its a great day to be great",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "156762760129155072",
    "text" : "Its a great day to be great",
    "id" : 156762760129155072,
    "created_at" : "Tue Jan 10 15:42:09 +0000 2012",
    "user" : {
      "name" : "Mr. Fox",
      "screen_name" : "El__Capitan1",
      "protected" : false,
      "id_str" : "91222764",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3294564583/68563b55baa3d8d0f81444b34ed58359_normal.jpeg",
      "id" : 91222764,
      "verified" : false
    }
  },
  "id" : 156764390442549248,
  "created_at" : "Tue Jan 10 15:48:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exhausted",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156601337797279744",
  "text" : "great night hike up Camel's Hump! #exhausted",
  "id" : 156601337797279744,
  "created_at" : "Tue Jan 10 05:00:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156525321850589184",
  "text" : "my new roommate just got in and is super cool, now headed out to hike Camels Hump by moonlight",
  "id" : 156525321850589184,
  "created_at" : "Mon Jan 09 23:58:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlife",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156439791263678464",
  "text" : "coming home for lunch and the apartment filled with the smell of fresh bread #goodlife",
  "id" : 156439791263678464,
  "created_at" : "Mon Jan 09 18:18:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 27, 38 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/M0MHtY1Z",
      "expanded_url" : "http://bit.ly/zILY7u",
      "display_url" : "bit.ly/zILY7u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "156418454738575360",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 just in case haha \"@bakadesuyo: Are there really devices that can increase the size of a man's penis? http://t.co/M0MHtY1Z\"",
  "id" : 156418454738575360,
  "created_at" : "Mon Jan 09 16:54:00 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156403989385187328",
  "text" : "attending Chris Jones' 'Nonlinear dynamics with applications' course online",
  "id" : 156403989385187328,
  "created_at" : "Mon Jan 09 15:56:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/156383441204674560/photo/1",
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/woZVZm80",
      "media_url" : "http://pbs.twimg.com/media/AiuV6UYCAAAB_Rf.jpg",
      "id_str" : "156383441208868864",
      "id" : 156383441208868864,
      "media_url_https" : "https://pbs.twimg.com/media/AiuV6UYCAAAB_Rf.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/woZVZm80"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156383441204674560",
  "text" : "first day in the office http://t.co/woZVZm80",
  "id" : 156383441204674560,
  "created_at" : "Mon Jan 09 14:34:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/156379531228348416/photo/1",
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/O87zll6b",
      "media_url" : "http://pbs.twimg.com/media/AiuSWulCAAEn2Bj.jpg",
      "id_str" : "156379531232542721",
      "id" : 156379531232542721,
      "media_url_https" : "https://pbs.twimg.com/media/AiuSWulCAAEn2Bj.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/O87zll6b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156379531228348416",
  "text" : "first day in the office http://t.co/O87zll6b",
  "id" : 156379531228348416,
  "created_at" : "Mon Jan 09 14:19:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156167209889169408",
  "text" : "is now a member of the Onion River Co-op, and just ate a salad so big it took nearly half a bottle of vinaigrette to cover lightly",
  "id" : 156167209889169408,
  "created_at" : "Mon Jan 09 00:15:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156119789729886208",
  "text" : "commuting bike upgraded w air horn and mounted u-lock",
  "id" : 156119789729886208,
  "created_at" : "Sun Jan 08 21:07:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156085708170342400",
  "geo" : {
  },
  "id_str" : "156110620629016577",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr yessir!!",
  "id" : 156110620629016577,
  "in_reply_to_status_id" : 156085708170342400,
  "created_at" : "Sun Jan 08 20:30:47 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156110564601499649",
  "text" : "back in Burlington! starting working tomorrow.",
  "id" : 156110564601499649,
  "created_at" : "Sun Jan 08 20:30:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shazam",
      "indices" : [ 49, 56 ]
    }, {
      "text" : "amazing",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156079401732284416",
  "text" : "downloaded, installed and identified a song with #shazam before the song ended #amazing",
  "id" : 156079401732284416,
  "created_at" : "Sun Jan 08 18:26:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156067332828053504",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr hey, im sorry that we never got to hang out while I was in Boston. Guess you'll have to come visit Burlington sometime!",
  "id" : 156067332828053504,
  "created_at" : "Sun Jan 08 17:38:46 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "156042961489100800",
  "text" : "leaving boston. its been real! mikes pastries in tow",
  "id" : 156042961489100800,
  "created_at" : "Sun Jan 08 16:01:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citylife",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155908592808103938",
  "text" : "boston is alive right now #citylife",
  "id" : 155908592808103938,
  "created_at" : "Sun Jan 08 07:07:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 12, 19 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155870178570272768",
  "geo" : {
  },
  "id_str" : "155873468703973376",
  "in_reply_to_user_id" : 91222764,
  "text" : "@MathewFox1 @DZdan1 yesss exactly!",
  "id" : 155873468703973376,
  "in_reply_to_status_id" : 155870178570272768,
  "created_at" : "Sun Jan 08 04:48:25 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 12, 19 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/155867877466050560/photo/1",
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/OuvI6BKF",
      "media_url" : "http://pbs.twimg.com/media/AinBAjyCEAAJSAW.jpg",
      "id_str" : "155867877470244864",
      "id" : 155867877470244864,
      "media_url_https" : "https://pbs.twimg.com/media/AinBAjyCEAAJSAW.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/OuvI6BKF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155867877466050560",
  "in_reply_to_user_id" : 91222764,
  "text" : "@MathewFox1 @DZdan1 remember this place right by Fenway from when we were in Boston for Bruce?? For some reason I do http://t.co/OuvI6BKF",
  "id" : 155867877466050560,
  "created_at" : "Sun Jan 08 04:26:13 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155864801854238720",
  "text" : "left my bag w laptop @ the other side cafe, and they had it behind the bar. props to those guys!!",
  "id" : 155864801854238720,
  "created_at" : "Sun Jan 08 04:13:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155846015860211712",
  "text" : "next up: nitro bcc coffeehouse porter. creamy, yummy",
  "id" : 155846015860211712,
  "created_at" : "Sun Jan 08 02:59:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155834761074581505",
  "text" : "beer review: \"slumbrew porter squared porter\" amazinggg roastedness",
  "id" : 155834761074581505,
  "created_at" : "Sun Jan 08 02:14:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155834591133966336",
  "text" : "excellent dinner and beer at \"the other side\" such a hipster place, vegan burritos and local brews. now @ the dead authors pub",
  "id" : 155834591133966336,
  "created_at" : "Sun Jan 08 02:13:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155796146961399809",
  "text" : "just registered for spring classes at UVM! looks like I'm planning on taking my first PhD prelim this May... in real and complex analysis",
  "id" : 155796146961399809,
  "created_at" : "Sat Jan 07 23:41:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155733576565014529",
  "text" : "now \"Exploring Sustainability in a Developmental-Level Mathematics Course\" with Rikki Wagstrom of Metropolitan State Univ #JMM2012",
  "id" : 155733576565014529,
  "created_at" : "Sat Jan 07 19:32:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155729038953021440",
  "text" : "currently \"A Model Heirarchy for Undergraduates Education in Radiative and Convective Heat Transfer\" with Kerry Emanuel of MIT #JMM2012",
  "id" : 155729038953021440,
  "created_at" : "Sat Jan 07 19:14:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155718815571914754",
  "text" : "now \"Teaching weather and climate using laboratory experiments\" with John Marshall of MIT #JMM2012",
  "id" : 155718815571914754,
  "created_at" : "Sat Jan 07 18:33:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 25, 39 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "justhappened",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155718551578218496",
  "text" : "\"@dr_pyser: About to see @ChrisDanforth bring the house down at #JMM2012.\" #justhappened",
  "id" : 155718551578218496,
  "created_at" : "Sat Jan 07 18:32:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 77, 91 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155708893694136324",
  "text" : "attending \"A Toy Climate Laboratory for Chaos and Differential Equations\" by @ChrisDanforth #JMM2012",
  "id" : 155708893694136324,
  "created_at" : "Sat Jan 07 17:54:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/crS0kcdy",
      "expanded_url" : "http://4sq.com/wFPDAA",
      "display_url" : "4sq.com/wFPDAA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.349222386, -71.0842051011 ]
  },
  "id_str" : "155704586072629248",
  "text" : "great lunch! (@ Cafeteria Boston) http://t.co/crS0kcdy",
  "id" : 155704586072629248,
  "created_at" : "Sat Jan 07 17:37:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155672620950503425",
  "text" : "\"Snakes and Ladders\" with Björn Sandstede",
  "id" : 155672620950503425,
  "created_at" : "Sat Jan 07 15:30:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155667734095597569",
  "text" : "at \"Lagrangian Dynamics and the incorporation of data into ocean models\" by Chris Jones #JMM2012",
  "id" : 155667734095597569,
  "created_at" : "Sat Jan 07 15:10:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmonwestin",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155663574210060288",
  "text" : "the slowest checkout of my life...and late for talks #cmonwestin",
  "id" : 155663574210060288,
  "created_at" : "Sat Jan 07 14:54:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155656424477822977",
  "text" : "math math math",
  "id" : 155656424477822977,
  "created_at" : "Sat Jan 07 14:25:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 30, 39 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155541629636317184",
  "text" : "quite a night out in Boston w @dr_pyser, Kam and friends Drew, Sean and others! more talks in the morning",
  "id" : 155541629636317184,
  "created_at" : "Sat Jan 07 06:49:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155469808941547520",
  "text" : "PERFECT city river trail bridge adventure run w Laurel, followed by some DFH and a spinach salad! Boston is sweet, this is vaca 4 sure",
  "id" : 155469808941547520,
  "created_at" : "Sat Jan 07 02:04:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155408591686340608",
  "geo" : {
  },
  "id_str" : "155428413023326208",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 congrats sir!",
  "id" : 155428413023326208,
  "in_reply_to_status_id" : 155408591686340608,
  "created_at" : "Fri Jan 06 23:19:56 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155427754337243136",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I will more than likely be late...save me a seat!",
  "id" : 155427754337243136,
  "created_at" : "Fri Jan 06 23:17:19 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155426018214150145",
  "text" : "poster session went well! headed out runnning w Laurel!",
  "id" : 155426018214150145,
  "created_at" : "Fri Jan 06 23:10:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/155382937771188224/photo/1",
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/6HETzmcH",
      "media_url" : "http://pbs.twimg.com/media/AigH9WpCIAAUgB_.jpg",
      "id_str" : "155382937775382528",
      "id" : 155382937775382528,
      "media_url_https" : "https://pbs.twimg.com/media/AigH9WpCIAAUgB_.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/6HETzmcH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155382937771188224",
  "text" : "undergrad poster session is crazy. a huuge banquet hall full, 300+ posters. we're number 183 http://t.co/6HETzmcH",
  "id" : 155382937771188224,
  "created_at" : "Fri Jan 06 20:19:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155358265167974400",
  "text" : "went up to the North End for lunch with the REU gang, was really good! Hit Mike's Pastries to go as well, mmm canoli",
  "id" : 155358265167974400,
  "created_at" : "Fri Jan 06 18:41:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155305353091891201",
  "text" : "and on another unsolved problem, \"The Birch and Swinnerton-Dyer Conjecture\" with William Stein of Univ of Washington #JMM2012",
  "id" : 155305353091891201,
  "created_at" : "Fri Jan 06 15:10:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155295578824257537",
  "text" : "at \"beyond computation, the p vs np problem\" with michael sipser from MIT #JMM2012",
  "id" : 155295578824257537,
  "created_at" : "Fri Jan 06 14:32:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155040209967398913",
  "geo" : {
  },
  "id_str" : "155047115104591873",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser apparently the thing to do wait outside for 30min, paying everyone entering $5, so that when you go in they all say LEWWISSSS",
  "id" : 155047115104591873,
  "in_reply_to_status_id" : 155040209967398913,
  "created_at" : "Thu Jan 05 22:04:47 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "155004634849738752",
  "text" : "dear unnamed presenter, you're supposed to be talking to your audience, not your powerpoint...",
  "id" : 155004634849738752,
  "created_at" : "Thu Jan 05 19:15:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/154993976599003137/photo/1",
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/0Xq6GS6q",
      "media_url" : "http://pbs.twimg.com/media/AiamM1XCQAIg4L3.jpg",
      "id_str" : "154993976603197442",
      "id" : 154993976603197442,
      "media_url_https" : "https://pbs.twimg.com/media/AiamM1XCQAIg4L3.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/0Xq6GS6q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154993976599003137",
  "text" : "lunch at the top of prudential building, view: http://t.co/0Xq6GS6q",
  "id" : 154993976599003137,
  "created_at" : "Thu Jan 05 18:33:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 48, 59 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154769773262159874",
  "text" : "RT @dr_pyser: Sif I'm not going to subscribe to @andyreagan's rss feed. Right now.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 34, 45 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "154764326220218368",
    "text" : "Sif I'm not going to subscribe to @andyreagan's rss feed. Right now.",
    "id" : 154764326220218368,
    "created_at" : "Thu Jan 05 03:21:05 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 154769773262159874,
  "created_at" : "Thu Jan 05 03:42:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loveboston",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154759828970016769",
  "text" : "dinner @ the other side, cool place, great burrito and left hand milk stout on tap #loveboston",
  "id" : 154759828970016769,
  "created_at" : "Thu Jan 05 03:03:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutuplegs",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154759552498278401",
  "text" : "had an awesome run thru Boston, 4mi in 28min. too cold 4 my knee tho #shutuplegs",
  "id" : 154759552498278401,
  "created_at" : "Thu Jan 05 03:02:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154698730895982592",
  "text" : "delicious grilled fresh salmon lunch, few great talks, and discovered a new mode of luggage and personal transport: the random shopping cart",
  "id" : 154698730895982592,
  "created_at" : "Wed Jan 04 23:00:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JMM2012",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154592814204846081",
  "text" : "at the Hynes Convention Center #JMM2012",
  "id" : 154592814204846081,
  "created_at" : "Wed Jan 04 15:59:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 51, 65 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 70, 79 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 98, 107 ],
      "id_str" : "25850390",
      "id" : 25850390
    }, {
      "name" : "Paul Vines",
      "screen_name" : "IronCyclone",
      "indices" : [ 108, 120 ],
      "id_str" : "349885460",
      "id" : 349885460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154539367162068992",
  "text" : "-2 in Burlington at 7AM and on the way to Boston w @ChrisDanforth and @dr_pyser. i got the poster @jdbrunnr @IronCyclone",
  "id" : 154539367162068992,
  "created_at" : "Wed Jan 04 12:27:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Tock",
      "screen_name" : "tick3tock3",
      "indices" : [ 0, 11 ],
      "id_str" : "223308471",
      "id" : 223308471
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154383339992793088",
  "geo" : {
  },
  "id_str" : "154385156327739395",
  "in_reply_to_user_id" : 223308471,
  "text" : "@tick3tock3 yeaahhh!! #hokies",
  "id" : 154385156327739395,
  "in_reply_to_status_id" : 154383339992793088,
  "created_at" : "Wed Jan 04 02:14:24 +0000 2012",
  "in_reply_to_screen_name" : "tick3tock3",
  "in_reply_to_user_id_str" : "223308471",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154367327662649346",
  "text" : "made dinner, built a shoe rack, made bread, and signed up for ESPN alerts for the game!",
  "id" : 154367327662649346,
  "created_at" : "Wed Jan 04 01:03:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 3, 12 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154364890180624385",
  "text" : "RT @Run_Rudy HOKIE HOKIE HOKIE HI TECH TECH VPI",
  "id" : 154364890180624385,
  "created_at" : "Wed Jan 04 00:53:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154339742165635072",
  "text" : "and another win from the day",
  "id" : 154339742165635072,
  "created_at" : "Tue Jan 03 23:13:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/154338654628745216/photo/1",
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/7CFgnSSC",
      "media_url" : "http://pbs.twimg.com/media/AiRSMEyCEAA6yE5.jpg",
      "id_str" : "154338654632939520",
      "id" : 154338654632939520,
      "media_url_https" : "https://pbs.twimg.com/media/AiRSMEyCEAA6yE5.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/7CFgnSSC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154338654628745216",
  "text" : "check out the pugsley I rode today, feels like riding on the moon http://t.co/7CFgnSSC",
  "id" : 154338654628745216,
  "created_at" : "Tue Jan 03 23:09:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154269029496926208",
  "text" : "so its official, burlington is approved by me as one cool ass town. (random bike shop with penny farthing museum, demo pugsley i rode!?)",
  "id" : 154269029496926208,
  "created_at" : "Tue Jan 03 18:32:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154262998188441600",
  "geo" : {
  },
  "id_str" : "154268375453925376",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin chili was VEGAN. that food co op is incredible!!! yeah everything successful so far",
  "id" : 154268375453925376,
  "in_reply_to_status_id" : 154262998188441600,
  "created_at" : "Tue Jan 03 18:30:21 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 11, 21 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154253767548735488",
  "text" : "wearing my @bikebuild shirt at lunch and just met a fellow bike and builder in Burlington! too cool",
  "id" : 154253767548735488,
  "created_at" : "Tue Jan 03 17:32:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 88, 104 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/154250942580142080/photo/1",
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/gYUoTUAv",
      "media_url" : "http://pbs.twimg.com/media/AiQCaj8CMAAx1H5.jpg",
      "id_str" : "154250942584336384",
      "id" : 154250942584336384,
      "media_url_https" : "https://pbs.twimg.com/media/AiQCaj8CMAAx1H5.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/gYUoTUAv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154250942580142080",
  "text" : "so many errands done, I almost forgot to eat today. lunch @ the onion river co-op. does @RumblinStumblin approve? http://t.co/gYUoTUAv",
  "id" : 154250942580142080,
  "created_at" : "Tue Jan 03 17:21:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154203722912772096",
  "text" : "off to explore Burlington and get some stuff done!",
  "id" : 154203722912772096,
  "created_at" : "Tue Jan 03 14:13:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "154019280093057025",
  "text" : "invented a fun but exhausting new game, its called \"carry everything you own up two flights of stairs\". PR of 90min",
  "id" : 154019280093057025,
  "created_at" : "Tue Jan 03 02:00:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153983971909320706",
  "text" : "at my new townhome in Burlington! made it in 5hrs in a snowstorm? idk how",
  "id" : 153983971909320706,
  "created_at" : "Mon Jan 02 23:40:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153967965837082624",
  "text" : "the champlain bridge stands! google maps, youre wrong. hello vermont!",
  "id" : 153967965837082624,
  "created_at" : "Mon Jan 02 22:36:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/153962975923945473/photo/1",
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/zaFdgp6m",
      "media_url" : "http://pbs.twimg.com/media/AiL8gsjCQAA8KnP.jpg",
      "id_str" : "153962975928139776",
      "id" : 153962975928139776,
      "media_url_https" : "https://pbs.twimg.com/media/AiL8gsjCQAA8KnP.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/zaFdgp6m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153962975923945473",
  "text" : "hit a blizzard...roads more suitable for snowmobiling. can sometimes only see the lights of plow im following http://t.co/zaFdgp6m",
  "id" : 153962975923945473,
  "created_at" : "Mon Jan 02 22:16:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/153897803490410496/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/CepNEGq3",
      "media_url" : "http://pbs.twimg.com/media/AiLBPKUCQAAT1Ni.jpg",
      "id_str" : "153897803494604800",
      "id" : 153897803494604800,
      "media_url_https" : "https://pbs.twimg.com/media/AiLBPKUCQAAT1Ni.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/CepNEGq3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153897803490410496",
  "text" : "all of my worldly possessions loaded up,  to Burlington I go! http://t.co/CepNEGq3",
  "id" : 153897803490410496,
  "created_at" : "Mon Jan 02 17:57:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 55, 69 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/gVMgLHlM",
      "expanded_url" : "http://www.uvm.edu/~areagan/",
      "display_url" : "uvm.edu/~areagan/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "153704327716941824",
  "text" : "my UVM web page nearly complete! http://t.co/gVMgLHlM (@ChrisDanforth)",
  "id" : 153704327716941824,
  "created_at" : "Mon Jan 02 05:09:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "didnthappen",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153703542249627651",
  "text" : "was going to pack tonight... #didnthappen",
  "id" : 153703542249627651,
  "created_at" : "Mon Jan 02 05:05:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 1, 17 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/153700158171910144/photo/1",
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/ZFRnGns0",
      "media_url" : "http://pbs.twimg.com/media/AiINesICEAAquxF.jpg",
      "id_str" : "153700158176104448",
      "id" : 153700158176104448,
      "media_url_https" : "https://pbs.twimg.com/media/AiINesICEAAquxF.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ZFRnGns0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153700158171910144",
  "text" : ".@rumblinstumblin cutting the siding for the carport earlier today as promised http://t.co/ZFRnGns0",
  "id" : 153700158171910144,
  "created_at" : "Mon Jan 02 04:52:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153680559820902400",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 your resolution is good, but it's also very necessary lol",
  "id" : 153680559820902400,
  "created_at" : "Mon Jan 02 03:34:35 +0000 2012",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 40, 56 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 75, 86 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/gVMgLHlM",
      "expanded_url" : "http://www.uvm.edu/~areagan/",
      "display_url" : "uvm.edu/~areagan/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "153680085063450624",
  "text" : "in addition to closing in the carport w @RumblinStumblin today (pic next), @kreagannet helped me finish my UVM webpage! http://t.co/gVMgLHlM",
  "id" : 153680085063450624,
  "created_at" : "Mon Jan 02 03:32:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stein Kåre Holden",
      "screen_name" : "SkHolden",
      "indices" : [ 50, 59 ],
      "id_str" : "753063618",
      "id" : 753063618
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 60, 69 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153679661522632705",
  "text" : "great seeing friends for the last time this break @skholden @dknick88 and Matt!!",
  "id" : 153679661522632705,
  "created_at" : "Mon Jan 02 03:31:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153677140750118912",
  "geo" : {
  },
  "id_str" : "153678315847303168",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT glad the trip was safe! hopefully this visit isn't as permanently scarring as the last lol",
  "id" : 153678315847303168,
  "in_reply_to_status_id" : 153677140750118912,
  "created_at" : "Mon Jan 02 03:25:40 +0000 2012",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153604291297427456",
  "text" : "watching the cross fit games on ESPN2...cool stuff!!",
  "id" : 153604291297427456,
  "created_at" : "Sun Jan 01 22:31:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153586918507028482",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT safe travels!!",
  "id" : 153586918507028482,
  "created_at" : "Sun Jan 01 21:22:29 +0000 2012",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 0, 10 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153367661496115200",
  "geo" : {
  },
  "id_str" : "153586850102128640",
  "in_reply_to_user_id" : 117782776,
  "text" : "@VTCycling gonna try again this year to put more miles on two wheels than four!",
  "id" : 153586850102128640,
  "in_reply_to_status_id" : 153367661496115200,
  "created_at" : "Sun Jan 01 21:22:13 +0000 2012",
  "in_reply_to_screen_name" : "VTCycling",
  "in_reply_to_user_id_str" : "117782776",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nye",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153342316260769792",
  "text" : "happy new year twitterati!! #nye",
  "id" : 153342316260769792,
  "created_at" : "Sun Jan 01 05:10:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]