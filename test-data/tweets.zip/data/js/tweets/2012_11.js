Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikes",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/P2SEF5ny",
      "expanded_url" : "http://twitpic.com/bhxcyb",
      "display_url" : "twitpic.com/bhxcyb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4824025, -73.20312445 ]
  },
  "id_str" : "274687550415831040",
  "text" : "yup, grabbed a rachet strap and pannier for the beer run...6 pack in the pannier #bikes http://t.co/P2SEF5ny",
  "id" : 274687550415831040,
  "created_at" : "Sat Dec 01 01:33:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 103, 112 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820903, -73.2030591 ]
  },
  "id_str" : "274666374314479616",
  "text" : "jalapeno maple IPA is like a chuck norris roundhouse kick to the face!!! #ouch roommate says \"YIKES!!\" @eclark66",
  "id" : 274666374314479616,
  "created_at" : "Sat Dec 01 00:09:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274620833014632450",
  "text" : "mathers have a tendency to measure things. tonight, i measure if i need new friends. method: weigh leftovers at potluck.",
  "id" : 274620833014632450,
  "created_at" : "Fri Nov 30 21:08:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4793727, -73.1974867 ]
  },
  "id_str" : "274579688091963393",
  "text" : "when asked of he'd heard a popular Mozart piece, \"neither shall I do so, lest I forfeit some of my own originality.\" -beethoven #truth",
  "id" : 274579688091963393,
  "created_at" : "Fri Nov 30 18:24:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 0, 12 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 13, 22 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274575750844272640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4793942, -73.197526 ]
  },
  "id_str" : "274578068281110528",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SumaNMNDesu @dr_pyser I WANT ONE",
  "id" : 274578068281110528,
  "in_reply_to_status_id" : 274575750844272640,
  "created_at" : "Fri Nov 30 18:18:07 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "indices" : [ 9, 22 ],
      "id_str" : "14882900",
      "id" : 14882900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/mBAeswSW",
      "expanded_url" : "http://ow.ly/fIjnw",
      "display_url" : "ow.ly/fIjnw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.479351, -73.1974903 ]
  },
  "id_str" : "274577179021549569",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@runnersworld: \"Anyone who enters, and trains for, and finishes a marathon is part of our sport’s Elite.\" http://t.co/mBAeswSW\"",
  "id" : 274577179021549569,
  "created_at" : "Fri Nov 30 18:14:35 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4793466, -73.1974685 ]
  },
  "id_str" : "274576984821100545",
  "text" : "\"the stripes were easy, it's the horse that bothers me\" -turing",
  "id" : 274576984821100545,
  "created_at" : "Fri Nov 30 18:13:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reasonstostudycomplexsystems",
      "indices" : [ 0, 29 ]
    }, {
      "text" : "food",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "storylab",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "scraps",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/YWakVsZp",
      "expanded_url" : "http://twitpic.com/bhu5j6",
      "display_url" : "twitpic.com/bhu5j6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4831969, -73.1935303 ]
  },
  "id_str" : "274560655883898880",
  "text" : "#reasonstostudycomplexsystems = #food. #storylab #scraps http://t.co/YWakVsZp",
  "id" : 274560655883898880,
  "created_at" : "Fri Nov 30 17:08:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 37, 46 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482093, -73.2030338 ]
  },
  "id_str" : "274361331270946816",
  "text" : "maple jalapeno IPA has been kegged!! @eclark66",
  "id" : 274361331270946816,
  "created_at" : "Fri Nov 30 03:56:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "274146559493537792",
  "text" : "\"Consequently, mathematicians usually have fewer and poorer figures in their papers and books than in their heads\" -Thurston",
  "id" : 274146559493537792,
  "created_at" : "Thu Nov 29 13:43:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/UnwiBWyl",
      "expanded_url" : "http://goo.gl/FPFdK",
      "display_url" : "goo.gl/FPFdK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274041055064780800",
  "text" : "RT @stevenstrogatz: To all #math teachers and fans: This article will change your thinking forever. A must read http://t.co/UnwiBWyl",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "math",
        "indices" : [ 7, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http://t.co/UnwiBWyl",
        "expanded_url" : "http://goo.gl/FPFdK",
        "display_url" : "goo.gl/FPFdK"
      } ]
    },
    "geo" : {
    },
    "id_str" : "273820172253540352",
    "text" : "To all #math teachers and fans: This article will change your thinking forever. A must read http://t.co/UnwiBWyl",
    "id" : 273820172253540352,
    "created_at" : "Wed Nov 28 16:06:31 +0000 2012",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 274041055064780800,
  "created_at" : "Thu Nov 29 06:44:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 81, 92 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "273993311205851136",
  "text" : "RT @DZdan1 Shit nobody says \"I have to figure out how to do a python integral.\" -@andyreagan",
  "id" : 273993311205851136,
  "created_at" : "Thu Nov 29 03:34:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/273630065349251072/photo/1",
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/y1UKC9jx",
      "media_url" : "http://pbs.twimg.com/media/A8whGD1CUAA5QQu.jpg",
      "id_str" : "273630065353445376",
      "id" : 273630065353445376,
      "media_url_https" : "https://pbs.twimg.com/media/A8whGD1CUAA5QQu.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com/y1UKC9jx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "273630065349251072",
  "text" : ".@sspis1 and I sandboarding in Vina del Mar during our first two days of the trip at the beach http://t.co/y1UKC9jx",
  "id" : 273630065349251072,
  "created_at" : "Wed Nov 28 03:31:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/npGICDpp",
      "expanded_url" : "http://buff.ly/WWcmJN",
      "display_url" : "buff.ly/WWcmJN"
    } ]
  },
  "geo" : {
  },
  "id_str" : "273613420220264448",
  "text" : "RT @JadAbumrad: Thought provoking piece on the dawning age of  moral machines  - http://t.co/npGICDpp",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http://t.co/npGICDpp",
        "expanded_url" : "http://buff.ly/WWcmJN",
        "display_url" : "buff.ly/WWcmJN"
      } ]
    },
    "geo" : {
    },
    "id_str" : "273593003816411139",
    "text" : "Thought provoking piece on the dawning age of  moral machines  - http://t.co/npGICDpp",
    "id" : 273593003816411139,
    "created_at" : "Wed Nov 28 01:03:49 +0000 2012",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 273613420220264448,
  "created_at" : "Wed Nov 28 02:24:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/WqusJGFK",
      "expanded_url" : "http://nyti.ms/Ss1NcH",
      "display_url" : "nyti.ms/Ss1NcH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "273613189885857792",
  "text" : "RT @nytimes: Undisclosed Finding by Mars Rover Fuels Intrigue http://t.co/WqusJGFK",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/WqusJGFK",
        "expanded_url" : "http://nyti.ms/Ss1NcH",
        "display_url" : "nyti.ms/Ss1NcH"
      } ]
    },
    "geo" : {
    },
    "id_str" : "273605510387884032",
    "text" : "Undisclosed Finding by Mars Rover Fuels Intrigue http://t.co/WqusJGFK",
    "id" : 273605510387884032,
    "created_at" : "Wed Nov 28 01:53:31 +0000 2012",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2044921128/finals_normal.png",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 273613189885857792,
  "created_at" : "Wed Nov 28 02:24:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273446117239308289",
  "geo" : {
  },
  "id_str" : "273446724121550849",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy yeah! fav, in order: 9/8cup h20, 2tbsp canola oil, 1tsp salt, 1/3cup honey, 3cup ww flour, 2tsp yeast. set to 1.5lb ww loaf",
  "id" : 273446724121550849,
  "in_reply_to_status_id" : 273446117239308289,
  "created_at" : "Tue Nov 27 15:22:34 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Elf",
      "screen_name" : "SnarkyElf",
      "indices" : [ 0, 10 ],
      "id_str" : "476060130",
      "id" : 476060130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273433260267282433",
  "geo" : {
  },
  "id_str" : "273446001208090626",
  "in_reply_to_user_id" : 476060130,
  "text" : "@SnarkyElf end-o-sperm!!",
  "id" : 273446001208090626,
  "in_reply_to_status_id" : 273433260267282433,
  "created_at" : "Tue Nov 27 15:19:41 +0000 2012",
  "in_reply_to_screen_name" : "SnarkyElf",
  "in_reply_to_user_id_str" : "476060130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "loveit",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47953477, -73.19777607 ]
  },
  "id_str" : "273419248561438720",
  "text" : "feelin good back in #btv. homemade bread, showers, it's snowing out and I'm back on two wheels #loveit",
  "id" : 273419248561438720,
  "created_at" : "Tue Nov 27 13:33:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "byehostess",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "hellothinneramerica",
      "indices" : [ 68, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/c1m8GGwO",
      "expanded_url" : "http://twitpic.com/bgu3lg",
      "display_url" : "twitpic.com/bgu3lg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7756745, -72.4540363 ]
  },
  "id_str" : "273296312932397057",
  "text" : "the status of American bake goods is looking sad indeed #byehostess #hellothinneramerica http://t.co/c1m8GGwO",
  "id" : 273296312932397057,
  "created_at" : "Tue Nov 27 05:24:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loosewheels",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7262659, -72.4247302 ]
  },
  "id_str" : "273295268345155585",
  "text" : "why are stopped at a truck stop and the driver is wandering around the bus with the tire iron... going back to sleep #loosewheels",
  "id" : 273295268345155585,
  "created_at" : "Tue Nov 27 05:20:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8062478, -72.566166 ]
  },
  "id_str" : "273277250919624704",
  "text" : "today's MegaBus ride has included a near fight with the driver, and almost running out of gas. too bad MA doesn't sell beer at gas stations",
  "id" : 273277250919624704,
  "created_at" : "Tue Nov 27 04:09:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prematuretweet",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273242302393245696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3331826, -72.6199903 ]
  },
  "id_str" : "273268625476046849",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 turns out...they found room for me on the original flight, but gave me 50 for volunteering anyway #prematuretweet",
  "id" : 273268625476046849,
  "in_reply_to_status_id" : 273242302393245696,
  "created_at" : "Tue Nov 27 03:34:52 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273143136191123457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7523553, -73.9939637 ]
  },
  "id_str" : "273144115624042498",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr I suppose I'm not driving home... so some good clean American tap water for me!",
  "id" : 273144115624042498,
  "in_reply_to_status_id" : 273143136191123457,
  "created_at" : "Mon Nov 26 19:20:06 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "predictable",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7523294, -73.9939442 ]
  },
  "id_str" : "273142932742213632",
  "text" : "first meal in the states...chipotle burrito #predictable",
  "id" : 273142932742213632,
  "created_at" : "Mon Nov 26 19:15:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Google Students",
      "screen_name" : "googlestudents",
      "indices" : [ 33, 48 ],
      "id_str" : "30315557",
      "id" : 30315557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/5pFCV50d",
      "expanded_url" : "http://goo.gl/MkCSy",
      "display_url" : "goo.gl/MkCSy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.77405, -73.87145176 ]
  },
  "id_str" : "273124717274210304",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 got any geeky students? \"@googlestudents: The Google Code-in 2012 contest has officially started! http://t.co/5pFCV50d\"",
  "id" : 273124717274210304,
  "created_at" : "Mon Nov 26 18:03:01 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 115, 124 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mylife",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7648736, -73.8628121 ]
  },
  "id_str" : "273118103825702913",
  "text" : "bumming next to a charger in LGA for 2 hours because you need your phone for directions across NYC #mylife. thx to @dmreagan 4 company tho!",
  "id" : 273118103825702913,
  "created_at" : "Mon Nov 26 17:36:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.642683, -84.443033 ]
  },
  "id_str" : "273032403306557440",
  "text" : "flight is overbooked so I'm taking the later one, first class, with a $400 voucher and still making my bus! #boom",
  "id" : 273032403306557440,
  "created_at" : "Mon Nov 26 11:56:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6377673, -84.4077777 ]
  },
  "id_str" : "273015105313181696",
  "text" : "back in los Estados Unitos! #america",
  "id" : 273015105313181696,
  "created_at" : "Mon Nov 26 10:47:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 38, 49 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takemewithyou",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "272795315290120192",
  "text" : "RT @sspis1: qetting ready to send off @andyreagan afte a week of awesomeness #takemewithyou",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 26, 37 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "takemewithyou",
        "indices" : [ 65, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "272795193919537152",
    "text" : "qetting ready to send off @andyreagan afte a week of awesomeness #takemewithyou",
    "id" : 272795193919537152,
    "created_at" : "Sun Nov 25 20:13:37 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 272795315290120192,
  "created_at" : "Sun Nov 25 20:14:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 28, 35 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "272795255621947393",
  "text" : "excellent day in Santiago w @sspis1, really like this city. besides not knowing what half them are saying. now to the aeropuerto, ciao Chile",
  "id" : 272795255621947393,
  "created_at" : "Sun Nov 25 20:13:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "272505675660292096",
  "text" : "explored the town of Puerto Natales and flew back in Santiago today, great travels so far! awesome hostel now, headed out for dinner",
  "id" : 272505675660292096,
  "created_at" : "Sun Nov 25 01:03:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bruce Van Horn",
      "screen_name" : "BruceVH",
      "indices" : [ 9, 17 ],
      "id_str" : "57497901",
      "id" : 57497901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/RlPKW939",
      "expanded_url" : "http://buff.ly/S4jvVg",
      "display_url" : "buff.ly/S4jvVg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -51.7253211, -72.5049916 ]
  },
  "id_str" : "272386436102230016",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@BruceVH: \"The purpose of the taper is rest, recover, replenish\" http://t.co/RlPKW939\"",
  "id" : 272386436102230016,
  "created_at" : "Sat Nov 24 17:09:21 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 113, 120 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atefirstthing",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -51.7253277, -72.5050527 ]
  },
  "id_str" : "272088818876821506",
  "text" : "has returned to Natales from the Patagonia wilderness, with an AWESOME experience and much hunger #atefirstthing @sspis1 pics/vids next week",
  "id" : 272088818876821506,
  "created_at" : "Fri Nov 23 21:26:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270358409713442816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -51.7253055, -72.5050104 ]
  },
  "id_str" : "272088266411495424",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia thanks Kait!! I'm going to try getting a bottle of pisco home, we'll have to drink some this winter break if I'm successful!",
  "id" : 272088266411495424,
  "in_reply_to_status_id" : 270358409713442816,
  "created_at" : "Fri Nov 23 21:24:32 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 10, 20 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/4czH4nsL",
      "expanded_url" : "http://twitpic.com/bft7qd",
      "display_url" : "twitpic.com/bft7qd"
    } ]
  },
  "in_reply_to_status_id_str" : "270624416549978112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -51.7253207, -72.505038 ]
  },
  "id_str" : "272088078418579456",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr @Crispy__C only pic on phone is from the plane, the other 1500 are stuck on the SLR until I return http://t.co/4czH4nsL",
  "id" : 272088078418579456,
  "in_reply_to_status_id" : 270624416549978112,
  "created_at" : "Fri Nov 23 21:23:47 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270626150663995393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -51.725293, -72.5050199 ]
  },
  "id_str" : "272087489836113920",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash yes!! was going to hash in Santiago but they weren't running while I'm in town",
  "id" : 272087489836113920,
  "in_reply_to_status_id" : 270626150663995393,
  "created_at" : "Fri Nov 23 21:21:27 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "270624821098995712",
  "text" : "and yes I meant to tag \"sspis1, but this keyboard is in spanish ...no hashtags either, i´ll try anyway HASHadventures",
  "id" : 270624821098995712,
  "created_at" : "Mon Nov 19 20:29:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "270624449076797441",
  "text" : "tomorrow we head into the park (parque Torres del Paine), we´ll be back to civilization on Saturday!",
  "id" : 270624449076797441,
  "created_at" : "Mon Nov 19 20:27:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "270624116690808832",
  "text" : "after some quality traveling adventures, \"sspis1 and I are in the remote mountain town of Puerto Natales!! the Andes towering above!!",
  "id" : 270624116690808832,
  "created_at" : "Mon Nov 19 20:26:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Singerhouse",
      "screen_name" : "singerhouserock",
      "indices" : [ 0, 16 ],
      "id_str" : "305221753",
      "id" : 305221753
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gringas",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/h52VyTl5",
      "expanded_url" : "http://twitpic.com/beggxe",
      "display_url" : "twitpic.com/beggxe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0128707, -71.5539448 ]
  },
  "id_str" : "270340629576421376",
  "in_reply_to_user_id" : 305221753,
  "text" : "@singerhouserock @c0rerson looking good ladies #gringas http://t.co/h52VyTl5",
  "id" : 270340629576421376,
  "created_at" : "Mon Nov 19 01:40:03 +0000 2012",
  "in_reply_to_screen_name" : "singerhouserock",
  "in_reply_to_user_id_str" : "305221753",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "picsfromtheday",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/bzvJo5xO",
      "expanded_url" : "http://twitpic.com/beggin",
      "display_url" : "twitpic.com/beggin"
    } ]
  },
  "geo" : {
  },
  "id_str" : "270340118815064065",
  "text" : "atresenal chilean helado #picsfromtheday http://t.co/bzvJo5xO",
  "id" : 270340118815064065,
  "created_at" : "Mon Nov 19 01:38:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "picsfromtheday",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/ZQI367HV",
      "expanded_url" : "http://twitpic.com/begfl3",
      "display_url" : "twitpic.com/begfl3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0127556, -71.5540257 ]
  },
  "id_str" : "270339040551792640",
  "text" : "rooftop lunch today in Valparaiso #picsfromtheday http://t.co/ZQI367HV",
  "id" : 270339040551792640,
  "created_at" : "Mon Nov 19 01:33:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/aC1mEAsM",
      "expanded_url" : "http://twitpic.com/beez6h",
      "display_url" : "twitpic.com/beez6h"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0260232, -71.554213 ]
  },
  "id_str" : "270276541336932353",
  "text" : "today we drink all the beers http://t.co/aC1mEAsM",
  "id" : 270276541336932353,
  "created_at" : "Sun Nov 18 21:25:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweet4.me\" rel=\"nofollow\">tweet4me tools</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 20, 31 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 36, 46 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phillymarathon",
      "indices" : [ 49, 64 ]
    }, {
      "text" : "philly2012",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "270073868293640192",
  "text" : "have an awesome run @skholden17 and @jcusick13!! #phillymarathon #philly2012",
  "id" : 270073868293640192,
  "created_at" : "Sun Nov 18 08:00:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brooking",
      "screen_name" : "btvjim",
      "indices" : [ 0, 7 ],
      "id_str" : "476054791",
      "id" : 476054791
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 49, 56 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269940529217826817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0128218, -71.5540976 ]
  },
  "id_str" : "270007305414774784",
  "in_reply_to_user_id" : 476054791,
  "text" : "@btvjim Solamente uno, the only I came to visit! @sspis1",
  "id" : 270007305414774784,
  "in_reply_to_status_id" : 269940529217826817,
  "created_at" : "Sun Nov 18 03:35:32 +0000 2012",
  "in_reply_to_screen_name" : "btvjim",
  "in_reply_to_user_id_str" : "476054791",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgoingglobal",
      "indices" : [ 17, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269980259288510464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0128004, -71.5541196 ]
  },
  "id_str" : "270006825049526272",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee thanks! #mathgoingglobal it would actually be cool to teach down here for a bit",
  "id" : 270006825049526272,
  "in_reply_to_status_id" : 269980259288510464,
  "created_at" : "Sun Nov 18 03:33:38 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Gardiner",
      "screen_name" : "KyleGardiner",
      "indices" : [ 0, 13 ],
      "id_str" : "17750589",
      "id" : 17750589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269981709158711299",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0128901, -71.5540187 ]
  },
  "id_str" : "270006309208875009",
  "in_reply_to_user_id" : 17750589,
  "text" : "@KyleGardiner Vina del Mar! Headed to the south, Torres del Paine, on Tuesday. 2) Idk about that...theyre pretty tasty either way",
  "id" : 270006309208875009,
  "in_reply_to_status_id" : 269981709158711299,
  "created_at" : "Sun Nov 18 03:31:35 +0000 2012",
  "in_reply_to_screen_name" : "KyleGardiner",
  "in_reply_to_user_id_str" : "17750589",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 14, 21 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 23, 34 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/FM4WY2Ws",
      "expanded_url" : "http://twitpic.com/be4vy5",
      "display_url" : "twitpic.com/be4vy5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0127524, -71.5541138 ]
  },
  "id_str" : "269981324880789505",
  "text" : "my translator @sspis1! @withane271 http://t.co/FM4WY2Ws",
  "id" : 269981324880789505,
  "created_at" : "Sun Nov 18 01:52:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/OtIdqBoQ",
      "expanded_url" : "http://twitpic.com/be4vgu",
      "display_url" : "twitpic.com/be4vgu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0127472, -71.5540971 ]
  },
  "id_str" : "269980930083528704",
  "text" : "picso sour, the official drink of Chile http://t.co/OtIdqBoQ",
  "id" : 269980930083528704,
  "created_at" : "Sun Nov 18 01:50:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/joSVM4eo",
      "expanded_url" : "http://twitpic.com/be3h9k",
      "display_url" : "twitpic.com/be3h9k"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.012812, -71.5539827 ]
  },
  "id_str" : "269929402731732992",
  "text" : "my room in Vina del Mar! Beachfront!! Already went sandboarding, ate an empanada and good helado! http://t.co/joSVM4eo",
  "id" : 269929402731732992,
  "created_at" : "Sat Nov 17 22:25:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmcdougall",
      "screen_name" : "dmcdougall_",
      "indices" : [ 0, 12 ],
      "id_str" : "884807263",
      "id" : 884807263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269617865324384256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6393136, -84.4282195 ]
  },
  "id_str" : "269631021341876224",
  "in_reply_to_user_id" : 884807263,
  "text" : "@dmcdougall_ santoago, chile!!",
  "id" : 269631021341876224,
  "in_reply_to_status_id" : 269617865324384256,
  "created_at" : "Sat Nov 17 02:40:19 +0000 2012",
  "in_reply_to_screen_name" : "dmcdougall_",
  "in_reply_to_user_id_str" : "884807263",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 52, 59 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6394052, -84.4281993 ]
  },
  "id_str" : "269630738931011584",
  "text" : "on the plane!! Chile bound w my new Chilean buddy!! @sspis1",
  "id" : 269630738931011584,
  "created_at" : "Sat Nov 17 02:39:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269581194826493953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6513153, -84.4404838 ]
  },
  "id_str" : "269609507401912320",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill sounds like some quality southern eatin', I bet kfc here has it",
  "id" : 269609507401912320,
  "in_reply_to_status_id" : 269581194826493953,
  "created_at" : "Sat Nov 17 01:14:50 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/2a0IFW6v",
      "expanded_url" : "http://4sq.com/Qjx7NO",
      "display_url" : "4sq.com/Qjx7NO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6513153, -84.4404838 ]
  },
  "id_str" : "269609321925574656",
  "text" : "landed in ATL (@ Hartsfield-Jackson Atlanta International Airport (ATL)) http://t.co/2a0IFW6v",
  "id" : 269609321925574656,
  "created_at" : "Sat Nov 17 01:14:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "indices" : [ 3, 18 ],
      "id_str" : "63491769",
      "id" : 63491769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollNats",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/q8Gj80J5",
      "expanded_url" : "http://fb.me/2fDRFWcbE",
      "display_url" : "fb.me/2fDRFWcbE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "269568290303664128",
  "text" : "RT @USACcollegiate: We'll be in Banner Elk, NC for MTB #CollNats next year!... http://t.co/q8Gj80J5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollNats",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/q8Gj80J5",
        "expanded_url" : "http://fb.me/2fDRFWcbE",
        "display_url" : "fb.me/2fDRFWcbE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269547214077050880",
    "text" : "We'll be in Banner Elk, NC for MTB #CollNats next year!... http://t.co/q8Gj80J5",
    "id" : 269547214077050880,
    "created_at" : "Fri Nov 16 21:07:18 +0000 2012",
    "user" : {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "protected" : false,
      "id_str" : "63491769",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/351269245/USACycling_Collegiate_square_normal.JPG",
      "id" : 63491769,
      "verified" : false
    }
  },
  "id" : 269568290303664128,
  "created_at" : "Fri Nov 16 22:31:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7610202, -73.8516849 ]
  },
  "id_str" : "269555774936719361",
  "text" : "through security without a bag search or not being able to bring stuff...woah I'm getting better at this",
  "id" : 269555774936719361,
  "created_at" : "Fri Nov 16 21:41:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/UTC7ktEr",
      "expanded_url" : "http://4sq.com/RZvROm",
      "display_url" : "4sq.com/RZvROm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7686956, -73.862443 ]
  },
  "id_str" : "269551968186417153",
  "text" : "made it (@ Terminal D (Delta Terminal)) http://t.co/UTC7ktEr",
  "id" : 269551968186417153,
  "created_at" : "Fri Nov 16 21:26:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countryboy",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.77011049, -73.91746118 ]
  },
  "id_str" : "269542435317751809",
  "text" : "surviving NYC #countryboy",
  "id" : 269542435317751809,
  "created_at" : "Fri Nov 16 20:48:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweet4.me\" rel=\"nofollow\">tweet4me tools</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatty",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269442849664294912",
  "text" : "this bus is hurtin bad on the uphills (15mph?), maybe I shouldn't have eaten that second burrito last night #fatty",
  "id" : 269442849664294912,
  "created_at" : "Fri Nov 16 14:12:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tweet4.me\" rel=\"nofollow\">tweet4me tools</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269439713214083073",
  "text" : "see ya later Vermont!",
  "id" : 269439713214083073,
  "created_at" : "Fri Nov 16 14:00:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.42318237, -73.01415986 ]
  },
  "id_str" : "269414198130388992",
  "text" : "on das megabus after an uphill sprint with my heavy backpack to catch it. being fit is useful for travelling after all",
  "id" : 269414198130388992,
  "created_at" : "Fri Nov 16 12:18:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 3, 12 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269247718919139329",
  "text" : "RT @vmhilljr: @andyreagan Then there is still hope.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "269247374801657856",
    "geo" : {
    },
    "id_str" : "269247491088732161",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan Then there is still hope.",
    "id" : 269247491088732161,
    "in_reply_to_status_id" : 269247374801657856,
    "created_at" : "Fri Nov 16 01:16:18 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "protected" : false,
      "id_str" : "104673361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1681278155/wally_normal.jpg",
      "id" : 104673361,
      "verified" : false
    }
  },
  "id" : 269247718919139329,
  "created_at" : "Fri Nov 16 01:17:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269247084635500545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821116, -73.2030433 ]
  },
  "id_str" : "269247374801657856",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr oh that's been on lock",
  "id" : 269247374801657856,
  "in_reply_to_status_id" : 269247084635500545,
  "created_at" : "Fri Nov 16 01:15:51 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269238909639221248",
  "geo" : {
  },
  "id_str" : "269246827080073217",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr help me",
  "id" : 269246827080073217,
  "in_reply_to_status_id" : 269238909639221248,
  "created_at" : "Fri Nov 16 01:13:40 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Elf",
      "screen_name" : "SnarkyElf",
      "indices" : [ 0, 10 ],
      "id_str" : "476060130",
      "id" : 476060130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269245514120318976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482107, -73.2030492 ]
  },
  "id_str" : "269246383972814848",
  "in_reply_to_user_id" : 476060130,
  "text" : "@SnarkyElf haha yup, only need the two prong guy on the right! thanks!",
  "id" : 269246383972814848,
  "in_reply_to_status_id" : 269245514120318976,
  "created_at" : "Fri Nov 16 01:11:54 +0000 2012",
  "in_reply_to_screen_name" : "SnarkyElf",
  "in_reply_to_user_id_str" : "476060130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821128, -73.2030385 ]
  },
  "id_str" : "269238734615085056",
  "text" : "watching bridesmaids by myself because my roommate left it on...things I should keep to myself. can't wait for Chile!",
  "id" : 269238734615085056,
  "created_at" : "Fri Nov 16 00:41:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 42, 49 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ready",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/gdLHCcS8",
      "expanded_url" : "http://twitpic.com/bdja0h",
      "display_url" : "twitpic.com/bdja0h"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208329, -73.20272375 ]
  },
  "id_str" : "269232786173472768",
  "text" : "all I need is a green man suit now #ready @sspis1 http://t.co/gdLHCcS8",
  "id" : 269232786173472768,
  "created_at" : "Fri Nov 16 00:17:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brilliant",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/nTwFXADS",
      "expanded_url" : "http://twitpic.com/bdivnr",
      "display_url" : "twitpic.com/bdivnr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821127, -73.2030367 ]
  },
  "id_str" : "269214846531297281",
  "text" : "universal power charger #brilliant http://t.co/nTwFXADS",
  "id" : 269214846531297281,
  "created_at" : "Thu Nov 15 23:06:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Strickland",
      "screen_name" : "TrueBS",
      "indices" : [ 3, 10 ],
      "id_str" : "45957932",
      "id" : 45957932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269136094476509184",
  "text" : "RT @TrueBS: \"My sadness at his ban had more to do with the fall of a tragic hero than the fact that he had broken the rules.\" http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http://t.co/uZsAjsQ1",
        "expanded_url" : "http://bit.ly/UIK7s1",
        "display_url" : "bit.ly/UIK7s1"
      } ]
    },
    "geo" : {
    },
    "id_str" : "269133291817402369",
    "text" : "\"My sadness at his ban had more to do with the fall of a tragic hero than the fact that he had broken the rules.\" http://t.co/uZsAjsQ1",
    "id" : 269133291817402369,
    "created_at" : "Thu Nov 15 17:42:31 +0000 2012",
    "user" : {
      "name" : "Bill Strickland",
      "screen_name" : "TrueBS",
      "protected" : false,
      "id_str" : "45957932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2528084928/r3dgphnf1v2lqk6fjfsu_normal.jpeg",
      "id" : 45957932,
      "verified" : false
    }
  },
  "id" : 269136094476509184,
  "created_at" : "Thu Nov 15 17:53:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Club Sports",
      "screen_name" : "UVMCLUBSPORTS",
      "indices" : [ 0, 14 ],
      "id_str" : "201323035",
      "id" : 201323035
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 43, 50 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pumped",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269123440060010496",
  "geo" : {
  },
  "id_str" : "269124210650140672",
  "in_reply_to_user_id" : 201323035,
  "text" : "@UVMCLUBSPORTS patagonia, chile!!! #pumped @sspis1",
  "id" : 269124210650140672,
  "in_reply_to_status_id" : 269123440060010496,
  "created_at" : "Thu Nov 15 17:06:26 +0000 2012",
  "in_reply_to_screen_name" : "UVMCLUBSPORTS",
  "in_reply_to_user_id_str" : "201323035",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/oWJpZD2d",
      "expanded_url" : "http://twitpic.com/bdgvhi",
      "display_url" : "twitpic.com/bdgvhi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832419, -73.1936131 ]
  },
  "id_str" : "269123374339477506",
  "text" : "my morning #storylab http://t.co/oWJpZD2d",
  "id" : 269123374339477506,
  "created_at" : "Thu Nov 15 17:03:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269053657838936064",
  "geo" : {
  },
  "id_str" : "269054976024801280",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT if I end up like the guys in 180 south, maybe! Chile for thanksgiving break for now",
  "id" : 269054976024801280,
  "in_reply_to_status_id" : 269053657838936064,
  "created_at" : "Thu Nov 15 12:31:19 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 37, 44 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "269049960333451265",
  "text" : "here's to my last day in the states! @sspis1",
  "id" : 269049960333451265,
  "created_at" : "Thu Nov 15 12:11:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/e2DgF0gG",
      "expanded_url" : "http://www.youtube.com/watch?v=dVLseWqAnpU&feature=list_other&playnext=1&list=AL94UKMTqg-9CHxkQOuBqALwdb4Sro8S6F",
      "display_url" : "youtube.com/watch?v=dVLseW…"
    } ]
  },
  "in_reply_to_status_id_str" : "268915244284387329",
  "geo" : {
  },
  "id_str" : "268920064575692800",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 sure it isn't this one http://t.co/e2DgF0gG",
  "id" : 268920064575692800,
  "in_reply_to_status_id" : 268915244284387329,
  "created_at" : "Thu Nov 15 03:35:14 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gradstatus",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268810315481886720",
  "text" : "looking like every weekend this spring will be a four day weekend! #gradstatus",
  "id" : 268810315481886720,
  "created_at" : "Wed Nov 14 20:19:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/3HQOm65S",
      "expanded_url" : "http://www.nature.com/news/why-math-is-like-the-honey-badger-1.11783",
      "display_url" : "nature.com/news/why-math-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "268565072140455937",
  "text" : "RT @ChrisDanforth: Why math is like the honey badger, courtesy of Nature magazine, which is growing on me. http://t.co/3HQOm65S",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http://t.co/3HQOm65S",
        "expanded_url" : "http://www.nature.com/news/why-math-is-like-the-honey-badger-1.11783",
        "display_url" : "nature.com/news/why-math-…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "268518770702692352",
    "text" : "Why math is like the honey badger, courtesy of Nature magazine, which is growing on me. http://t.co/3HQOm65S",
    "id" : 268518770702692352,
    "created_at" : "Wed Nov 14 01:00:38 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 268565072140455937,
  "created_at" : "Wed Nov 14 04:04:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268559194511257600",
  "text" : "my broomball debut season ends in the elite eight, with a hard fought 3-2 loss and a bruised shin to show. we'll be back in the spring!!",
  "id" : 268559194511257600,
  "created_at" : "Wed Nov 14 03:41:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 63, 70 ]
    }, {
      "text" : "heavy",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "superexcited",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/wWeBSn1k",
      "expanded_url" : "http://twitpic.com/bczyin",
      "display_url" : "twitpic.com/bczyin"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821714, -73.2030685 ]
  },
  "id_str" : "268500991698141185",
  "text" : "got a package today it appears, with enough brass for 20 bikes #whoops #heavy #superexcited http://t.co/wWeBSn1k",
  "id" : 268500991698141185,
  "created_at" : "Tue Nov 13 23:49:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homebrew",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48232952, -73.20351056 ]
  },
  "id_str" : "268500079244091393",
  "text" : "finished my work right about when my bad eye was barely open from too much computer screen, home to make a burrito and drink a #homebrew",
  "id" : 268500079244091393,
  "created_at" : "Tue Nov 13 23:46:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "21stcentury",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821216, -73.2030348 ]
  },
  "id_str" : "268245799958351873",
  "text" : "mirrors are on the way out, we have giant screen phones with front cameras #21stcentury",
  "id" : 268245799958351873,
  "created_at" : "Tue Nov 13 06:55:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Tokyo Reporter",
      "screen_name" : "tokyoreporter",
      "indices" : [ 11, 25 ],
      "id_str" : "19386949",
      "id" : 19386949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/rBKivZAV",
      "expanded_url" : "http://f24.my/VYs1HY",
      "display_url" : "f24.my/VYs1HY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821214, -73.2030613 ]
  },
  "id_str" : "268243953776721922",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 MT @tokyoreporter Underpants to neutralise smell of flatulence proving a hit in Japan http://t.co/rBKivZAV",
  "id" : 268243953776721922,
  "created_at" : "Tue Nov 13 06:48:36 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youshouldseetheotherguy",
      "indices" : [ 29, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/T5P0Nt2x",
      "expanded_url" : "http://twitpic.com/bcsous",
      "display_url" : "twitpic.com/bcsous"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4809169, -73.1989435 ]
  },
  "id_str" : "268234755236057088",
  "text" : "that broomball can get rough #youshouldseetheotherguy http://t.co/T5P0Nt2x",
  "id" : 268234755236057088,
  "created_at" : "Tue Nov 13 06:12:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "268013204322545664",
  "text" : "goodbye internet. three days to finish up work, then headed to Chile",
  "id" : 268013204322545664,
  "created_at" : "Mon Nov 12 15:31:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 20, 36 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821263, -73.2030499 ]
  },
  "id_str" : "267724562098163712",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet old guy @RumblinStumblin is much obliged",
  "id" : 267724562098163712,
  "created_at" : "Sun Nov 11 20:24:44 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 28, 44 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 76, 85 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/BfDd3ajx",
      "expanded_url" : "http://twitpic.com/bcfon6",
      "display_url" : "twitpic.com/bcfon6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821459, -73.203067 ]
  },
  "id_str" : "267724318962769920",
  "text" : "didn't send from up there: .@RumblinStumblin  and I at the top of Mt Philo! @dmreagan http://t.co/BfDd3ajx",
  "id" : 267724318962769920,
  "created_at" : "Sun Nov 11 20:23:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 53, 62 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allset",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/pAie8OIE",
      "expanded_url" : "http://twitpic.com/bcfoa4",
      "display_url" : "twitpic.com/bcfoa4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821263, -73.2030294 ]
  },
  "id_str" : "267723849569812480",
  "text" : "got the old man a football game and a porter #allset @dmreagan http://t.co/pAie8OIE",
  "id" : 267723849569812480,
  "created_at" : "Sun Nov 11 20:21:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/RprMjItZ",
      "expanded_url" : "http://gmail.com",
      "display_url" : "gmail.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "267717907159580672",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet check your kyle.reagan at http://t.co/RprMjItZ",
  "id" : 267717907159580672,
  "created_at" : "Sun Nov 11 19:58:17 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/sxWHiMbY",
      "expanded_url" : "http://twitpic.com/bc7mpr",
      "display_url" : "twitpic.com/bc7mpr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48202376, -73.20326977 ]
  },
  "id_str" : "267493304369836033",
  "text" : "jalapeno maple ipa is in secondary w nothing other than vermont grade b (and more hops) #yum http://t.co/sxWHiMbY",
  "id" : 267493304369836033,
  "created_at" : "Sun Nov 11 05:05:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/UdY2qRiH",
      "expanded_url" : "http://twitpic.com/bc6bav",
      "display_url" : "twitpic.com/bc6bav"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821262, -73.203036 ]
  },
  "id_str" : "267456163342348288",
  "text" : "organizing the brewing box, found a shredded bike crank, tie down straps, angle grinder manual... typical http://t.co/UdY2qRiH",
  "id" : 267456163342348288,
  "created_at" : "Sun Nov 11 02:38:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/us55WVIr",
      "expanded_url" : "http://twitpic.com/bc615z",
      "display_url" : "twitpic.com/bc615z"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821277, -73.2030359 ]
  },
  "id_str" : "267448053802336257",
  "text" : "kegerator ready for commercial pony kegs! operation sankey tap complete http://t.co/us55WVIr",
  "id" : 267448053802336257,
  "created_at" : "Sun Nov 11 02:05:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 3, 10 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 61, 74 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lumberjackin",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/ROfjdw82",
      "expanded_url" : "http://twitter.com/ttmill/status/267382168475537408/photo/1",
      "display_url" : "pic.twitter.com/ROfjdw82"
    } ]
  },
  "geo" : {
  },
  "id_str" : "267420763936669697",
  "text" : "RT @ttmill: 2-in-1. Strength work. Fuel for the cold months. @UVMTriathlon #lumberjackin http://t.co/ROfjdw82",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UVM Triathlon",
        "screen_name" : "UVMTriathlon",
        "indices" : [ 49, 62 ],
        "id_str" : "546451472",
        "id" : 546451472
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ttmill/status/267382168475537408/photo/1",
        "indices" : [ 77, 97 ],
        "url" : "http://t.co/ROfjdw82",
        "media_url" : "http://pbs.twimg.com/media/A7XuqmOCEAQne1p.jpg",
        "id_str" : "267382168479731716",
        "id" : 267382168479731716,
        "media_url_https" : "https://pbs.twimg.com/media/A7XuqmOCEAQne1p.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com/ROfjdw82"
      } ],
      "hashtags" : [ {
        "text" : "lumberjackin",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "267382168475537408",
    "text" : "2-in-1. Strength work. Fuel for the cold months. @UVMTriathlon #lumberjackin http://t.co/ROfjdw82",
    "id" : 267382168475537408,
    "created_at" : "Sat Nov 10 21:44:12 +0000 2012",
    "user" : {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "protected" : false,
      "id_str" : "549461514",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2249653724/BIKE3_normal.jpg",
      "id" : 549461514,
      "verified" : false
    }
  },
  "id" : 267420763936669697,
  "created_at" : "Sun Nov 11 00:17:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 61, 77 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821271, -73.2030532 ]
  },
  "id_str" : "267417562386685952",
  "text" : "a walking tour of the #btv and a win in pool so far for pops @RumblinStumblin",
  "id" : 267417562386685952,
  "created_at" : "Sun Nov 11 00:04:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267280241528012801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48223983, -73.20306518 ]
  },
  "id_str" : "267309695994306560",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee save up for the bike!",
  "id" : 267309695994306560,
  "in_reply_to_status_id" : 267280241528012801,
  "created_at" : "Sat Nov 10 16:56:12 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burritos",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4805063, -73.2072345 ]
  },
  "id_str" : "267098932486733824",
  "text" : "Man, I can rip a good one. #burritos",
  "id" : 267098932486733824,
  "created_at" : "Sat Nov 10 02:58:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homebrewjam",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/KiM4rwav",
      "expanded_url" : "http://twitpic.com/bbtnq1",
      "display_url" : "twitpic.com/bbtnq1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821344, -73.2030556 ]
  },
  "id_str" : "267057200860647424",
  "text" : "whether or not we like to admit it, homebrewing is a lot about cleaning. i.e. soaking carboys in starsan #homebrewjam http://t.co/KiM4rwav",
  "id" : 267057200860647424,
  "created_at" : "Sat Nov 10 00:12:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yummm",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "potluckjam",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/7FrW8Hce",
      "expanded_url" : "http://instagr.am/p/R1AzZKuS-c/",
      "display_url" : "instagr.am/p/R1AzZKuS-c/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "267056063000489985",
  "text" : "cinnamon sugar bubbling out #yummm #potluckjam http://t.co/7FrW8Hce",
  "id" : 267056063000489985,
  "created_at" : "Sat Nov 10 00:08:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 99, 106 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patagonia",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821344, -73.2030703 ]
  },
  "id_str" : "267054873130971136",
  "text" : "this time next week, I'll be hiking on a glacier near the southern tip of south america #patagonia @sspis1",
  "id" : 267054873130971136,
  "created_at" : "Sat Nov 10 00:03:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 57, 66 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homebrewing",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/4TM7rABP",
      "expanded_url" : "http://twitpic.com/bbsv40",
      "display_url" : "twitpic.com/bbsv40"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821321, -73.2030604 ]
  },
  "id_str" : "267024170502717440",
  "text" : "some mad scientist stuff going on over here #homebrewing @eclark66 http://t.co/4TM7rABP",
  "id" : 267024170502717440,
  "created_at" : "Fri Nov 09 22:01:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266966311458988032",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill happy birthday man!!",
  "id" : 266966311458988032,
  "created_at" : "Fri Nov 09 18:11:43 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikes",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "zoom",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821314, -73.2030768 ]
  },
  "id_str" : "266701995413487616",
  "text" : "15 minutes round trip to the grocery store for some local burrito makin #bikes #zoom",
  "id" : 266701995413487616,
  "created_at" : "Fri Nov 09 00:41:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266681495085797376",
  "geo" : {
  },
  "id_str" : "266685820633767937",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 good work!",
  "id" : 266685820633767937,
  "in_reply_to_status_id" : 266681495085797376,
  "created_at" : "Thu Nov 08 23:37:09 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "266624131238334464",
  "text" : "would like to point out I'm dominating the Points Against category in my FF league, landing my 3rd best scoring team at tied for 10th/12",
  "id" : 266624131238334464,
  "created_at" : "Thu Nov 08 19:32:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Elf",
      "screen_name" : "SnarkyElf",
      "indices" : [ 0, 10 ],
      "id_str" : "476060130",
      "id" : 476060130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http://t.co/HlBbxHnn",
      "expanded_url" : "http://www.psfk.com/2012/01/lost-keys-iphone-rfid.html",
      "display_url" : "psfk.com/2012/01/lost-k…"
    } ]
  },
  "in_reply_to_status_id_str" : "266571358379601920",
  "geo" : {
  },
  "id_str" : "266574068701073408",
  "in_reply_to_user_id" : 476060130,
  "text" : "@SnarkyElf http://t.co/HlBbxHnn",
  "id" : 266574068701073408,
  "in_reply_to_status_id" : 266571358379601920,
  "created_at" : "Thu Nov 08 16:13:05 +0000 2012",
  "in_reply_to_screen_name" : "SnarkyElf",
  "in_reply_to_user_id_str" : "476060130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alwayssunny",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4797469, -73.1976801 ]
  },
  "id_str" : "266546371262312449",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet  professor just said something about trolls and now I've got frank's \"troll toll\" song stuck in my head... #alwayssunny",
  "id" : 266546371262312449,
  "created_at" : "Thu Nov 08 14:23:01 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/jNWC9iiB",
      "expanded_url" : "http://en.wikipedia.org/wiki/Metamathematics",
      "display_url" : "en.wikipedia.org/wiki/Metamathe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "266321003783811072",
  "text" : "http://t.co/jNWC9iiB",
  "id" : 266321003783811072,
  "created_at" : "Wed Nov 07 23:27:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/omnUDpwn",
      "expanded_url" : "http://bit.ly/Ui6Xfy",
      "display_url" : "bit.ly/Ui6Xfy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3582135, -73.2249079 ]
  },
  "id_str" : "265996717231579136",
  "text" : "want to watch the election happening real time?!?! go to http://t.co/omnUDpwn !! #storylab",
  "id" : 265996717231579136,
  "created_at" : "Wed Nov 07 01:58:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265957653023449090",
  "text" : "on expresso, I'm typing a page of HW in TeX every 10 minutes #boom",
  "id" : 265957653023449090,
  "created_at" : "Tue Nov 06 23:23:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/265950205533356033/photo/1",
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/BGqG8qKE",
      "media_url" : "http://pbs.twimg.com/media/A7DYTYkCAAIqN4J.png",
      "id_str" : "265950205537550338",
      "id" : 265950205537550338,
      "media_url_https" : "https://pbs.twimg.com/media/A7DYTYkCAAIqN4J.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/BGqG8qKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265950205533356033",
  "text" : "http://t.co/BGqG8qKE",
  "id" : 265950205533356033,
  "created_at" : "Tue Nov 06 22:54:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "electionday",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265907193998614528",
  "text" : "to the polls #electionday",
  "id" : 265907193998614528,
  "created_at" : "Tue Nov 06 20:03:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 69, 80 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 81, 88 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 89, 102 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/j9c9I9Tg",
      "expanded_url" : "http://www.ironman.com/triathlon/events/ironman-70.3/timberman.aspx#axzz2BTOi5VJ9",
      "display_url" : "ironman.com/triathlon/even…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265906553247375360",
  "text" : "Just registered for 2013 IRONMAN 70.3 Timberman http://t.co/j9c9I9Tg @skholden17 @sspis1 @UVMTriathlon",
  "id" : 265906553247375360,
  "created_at" : "Tue Nov 06 20:00:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 3, 15 ],
      "id_str" : "219863324",
      "id" : 219863324
    }, {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 46, 52 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265886198281678849",
  "text" : "RT @MechE_Hokie: Holy sample bias, Batman! MT @wired Facebook's keeping tabs on how many people have voted—in real time. http://t.co/CUA ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wired",
        "screen_name" : "wired",
        "indices" : [ 29, 35 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/CUAnwr7u",
        "expanded_url" : "http://bit.ly/SKXVoq",
        "display_url" : "bit.ly/SKXVoq"
      } ]
    },
    "geo" : {
    },
    "id_str" : "265885371726983169",
    "text" : "Holy sample bias, Batman! MT @wired Facebook's keeping tabs on how many people have voted—in real time. http://t.co/CUAnwr7u",
    "id" : 265885371726983169,
    "created_at" : "Tue Nov 06 18:36:27 +0000 2012",
    "user" : {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "protected" : false,
      "id_str" : "219863324",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1175821783/me_at_move_inGIF_normal.gif",
      "id" : 219863324,
      "verified" : false
    }
  },
  "id" : 265886198281678849,
  "created_at" : "Tue Nov 06 18:39:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265851780171194368",
  "geo" : {
  },
  "id_str" : "265876667086540803",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 I wishhhh",
  "id" : 265876667086540803,
  "in_reply_to_status_id" : 265851780171194368,
  "created_at" : "Tue Nov 06 18:01:51 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 24, 37 ],
      "id_str" : "17900130",
      "id" : 17900130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/VslscVDd",
      "expanded_url" : "http://ow.ly/f288R",
      "display_url" : "ow.ly/f288R"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821262, -73.2030437 ]
  },
  "id_str" : "265804808710139905",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 just the title \"@BicyclingMag: MTB Video: The search for wild singletrack in the remote mountains of Argentina http://t.co/VslscVDd\"",
  "id" : 265804808710139905,
  "created_at" : "Tue Nov 06 13:16:19 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "framebuilding",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/cVQuUfnV",
      "expanded_url" : "http://www.cycledesignusa.com/brazage_lfb.htm",
      "display_url" : "cycledesignusa.com/brazage_lfb.htm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "265622663635030017",
  "text" : "get your low fuming brazing rods here: http://t.co/cVQuUfnV #framebuilding",
  "id" : 265622663635030017,
  "created_at" : "Tue Nov 06 01:12:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 8, 20 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265573596750024704",
  "geo" : {
  },
  "id_str" : "265603185236901888",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 @runfasteraw guys, let's focus on the bright side: I found it. and it snowed today in Burlington",
  "id" : 265603185236901888,
  "in_reply_to_status_id" : 265573596750024704,
  "created_at" : "Mon Nov 05 23:55:08 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wagner",
      "screen_name" : "ewags71",
      "indices" : [ 0, 8 ],
      "id_str" : "29055432",
      "id" : 29055432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265572897811230720",
  "geo" : {
  },
  "id_str" : "265603013429833730",
  "in_reply_to_user_id" : 29055432,
  "text" : "@ewags71 let's hope not",
  "id" : 265603013429833730,
  "in_reply_to_status_id" : 265572897811230720,
  "created_at" : "Mon Nov 05 23:54:27 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Elf",
      "screen_name" : "SnarkyElf",
      "indices" : [ 0, 10 ],
      "id_str" : "476060130",
      "id" : 476060130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265588298754441216",
  "geo" : {
  },
  "id_str" : "265602977576923136",
  "in_reply_to_user_id" : 476060130,
  "text" : "@SnarkyElf I have been known to prepare a salad with a dull machete lol",
  "id" : 265602977576923136,
  "in_reply_to_status_id" : 265588298754441216,
  "created_at" : "Mon Nov 05 23:54:19 +0000 2012",
  "in_reply_to_screen_name" : "SnarkyElf",
  "in_reply_to_user_id_str" : "476060130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/2mFZJ9jI",
      "expanded_url" : "http://twitpic.com/bao68w",
      "display_url" : "twitpic.com/bao68w"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821309, -73.2030815 ]
  },
  "id_str" : "265580658091507712",
  "text" : "I should stay away from the weight room... http://t.co/2mFZJ9jI",
  "id" : 265580658091507712,
  "created_at" : "Mon Nov 05 22:25:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "whatelsecangowrong",
      "indices" : [ 65, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821551, -73.2030865 ]
  },
  "id_str" : "265568035476213762",
  "text" : "pre-trip lost passport freakout has been calmed, I got it. #phew #whatelsecangowrong",
  "id" : 265568035476213762,
  "created_at" : "Mon Nov 05 21:35:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "265542842557030400",
  "text" : "got in some solid pick-up basketball today, that's gonna happen more often.",
  "id" : 265542842557030400,
  "created_at" : "Mon Nov 05 19:55:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4796989, -73.1982515 ]
  },
  "id_str" : "265480426754293761",
  "text" : "okay I've seen some snow flurries, we can go back to summer now",
  "id" : 265480426754293761,
  "created_at" : "Mon Nov 05 15:47:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832457, -73.1936234 ]
  },
  "id_str" : "265209591208476673",
  "text" : "solid mountain bike action was had today!! inspiration to keep building. even got some small hail/sleet flurries",
  "id" : 265209591208476673,
  "created_at" : "Sun Nov 04 21:51:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 9, 23 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265127791685677056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822339, -73.2030448 ]
  },
  "id_str" : "265155472053637121",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee @ChrisDanforth congrats to you both!!",
  "id" : 265155472053637121,
  "in_reply_to_status_id" : 265127791685677056,
  "created_at" : "Sun Nov 04 18:16:05 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wellneverknow",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264971267789180928",
  "text" : "diggin that it's only 1AM now...I wonder if the bars are open that extra hours #wellneverknow",
  "id" : 264971267789180928,
  "created_at" : "Sun Nov 04 06:04:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 0, 8 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264923257059282944",
  "geo" : {
  },
  "id_str" : "264969190606258176",
  "in_reply_to_user_id" : 103102170,
  "text" : "@pkemp33 yeah I was having hallucinations that he was chasing us later! poor fella",
  "id" : 264969190606258176,
  "in_reply_to_status_id" : 264923257059282944,
  "created_at" : "Sun Nov 04 05:55:52 +0000 2012",
  "in_reply_to_screen_name" : "pkemp33",
  "in_reply_to_user_id_str" : "103102170",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822362, -73.2030646 ]
  },
  "id_str" : "264916646903308289",
  "text" : "next door potluck? yup",
  "id" : 264916646903308289,
  "created_at" : "Sun Nov 04 02:27:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 87, 95 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48226, -73.203105 ]
  },
  "id_str" : "264846100748460033",
  "text" : "saran wrapped feet stay warm for a 40 mile, 40deg and misting Vermont dirt road ride w @pkemp33? ...not really, but it was fun",
  "id" : 264846100748460033,
  "created_at" : "Sat Nov 03 21:46:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/rmETnSd0",
      "expanded_url" : "http://twitpic.com/ba1atc",
      "display_url" : "twitpic.com/ba1atc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822309, -73.2030219 ]
  },
  "id_str" : "264790672345821184",
  "text" : "today's goal of building something with my hands, complete http://t.co/rmETnSd0",
  "id" : 264790672345821184,
  "created_at" : "Sat Nov 03 18:06:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 0, 11 ],
      "id_str" : "23695888",
      "id" : 23695888
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 47, 61 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maths",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264772400372150272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48232696, -73.20319966 ]
  },
  "id_str" : "264789483600375808",
  "in_reply_to_user_id" : 23695888,
  "text" : "@iamtedking what an off season! but apparently @ChrisDanforth didn't proof read this one, I thought a third of a dozen was four... :P #maths",
  "id" : 264789483600375808,
  "in_reply_to_status_id" : 264772400372150272,
  "created_at" : "Sat Nov 03 18:01:47 +0000 2012",
  "in_reply_to_screen_name" : "iamtedking",
  "in_reply_to_user_id_str" : "23695888",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Johnson",
      "screen_name" : "iamscratchbob",
      "indices" : [ 0, 14 ],
      "id_str" : "298873947",
      "id" : 298873947
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beerseason",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264545112384753665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4803953, -73.21163092 ]
  },
  "id_str" : "264568683857338368",
  "in_reply_to_user_id" : 298873947,
  "text" : "@iamscratchbob I'd love to!! I bet it's worth the ride! #beerseason",
  "id" : 264568683857338368,
  "in_reply_to_status_id" : 264545112384753665,
  "created_at" : "Sat Nov 03 03:24:24 +0000 2012",
  "in_reply_to_screen_name" : "iamscratchbob",
  "in_reply_to_user_id_str" : "298873947",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Johnson",
      "screen_name" : "iamscratchbob",
      "indices" : [ 3, 17 ],
      "id_str" : "298873947",
      "id" : 298873947
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 19, 30 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264568073787432960",
  "text" : "RT @iamscratchbob: @andyreagan inspired, Son. I like.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "264536731632693248",
    "geo" : {
    },
    "id_str" : "264544013124763648",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan inspired, Son. I like.",
    "id" : 264544013124763648,
    "in_reply_to_status_id" : 264536731632693248,
    "created_at" : "Sat Nov 03 01:46:22 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Bob Johnson",
      "screen_name" : "iamscratchbob",
      "protected" : false,
      "id_str" : "298873947",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2131726761/image_normal.jpg",
      "id" : 298873947,
      "verified" : false
    }
  },
  "id" : 264568073787432960,
  "created_at" : "Sat Nov 03 03:21:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/1HOxkE3z",
      "expanded_url" : "http://twitpic.com/b9s7f9",
      "display_url" : "twitpic.com/b9s7f9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822357, -73.2030584 ]
  },
  "id_str" : "264536731632693248",
  "text" : "I bring to you BurlingTRON Brews!! http://t.co/1HOxkE3z",
  "id" : 264536731632693248,
  "created_at" : "Sat Nov 03 01:17:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keeper",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "lovehim",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264400815643578368",
  "text" : "RT @sspis1: Only @andyreagan would narrate a documentary for me #keeper #lovehim",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 5, 16 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "keeper",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "lovehim",
        "indices" : [ 60, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "264238650714374144",
    "text" : "Only @andyreagan would narrate a documentary for me #keeper #lovehim",
    "id" : 264238650714374144,
    "created_at" : "Fri Nov 02 05:32:58 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 264400815643578368,
  "created_at" : "Fri Nov 02 16:17:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264254609160282112",
  "geo" : {
  },
  "id_str" : "264400763344797696",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 haha good stat (not $200 tho)...I'm at $45 for some Rudy's which I've already lost and $15 for a pair of lenses (have), this year!",
  "id" : 264400763344797696,
  "in_reply_to_status_id" : 264254609160282112,
  "created_at" : "Fri Nov 02 16:17:08 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmcdougall",
      "screen_name" : "dmcdougall_",
      "indices" : [ 0, 12 ],
      "id_str" : "884807263",
      "id" : 884807263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264143368639098881",
  "geo" : {
  },
  "id_str" : "264400321512603649",
  "in_reply_to_user_id" : 884807263,
  "text" : "@dmcdougall_ yeah that was right. not sure what I changed, but it works now!",
  "id" : 264400321512603649,
  "in_reply_to_status_id" : 264143368639098881,
  "created_at" : "Fri Nov 02 16:15:23 +0000 2012",
  "in_reply_to_screen_name" : "dmcdougall_",
  "in_reply_to_user_id_str" : "884807263",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "taperJAM",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "crushPhilly",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264204642097975296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822384, -73.2030638 ]
  },
  "id_str" : "264207731978809346",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 woop woop! #taperJAM #crushPhilly",
  "id" : 264207731978809346,
  "in_reply_to_status_id" : 264204642097975296,
  "created_at" : "Fri Nov 02 03:30:06 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3579349, -73.2247193 ]
  },
  "id_str" : "264195108822478849",
  "text" : "the only thing keeping my frustration w the #hokies in check is the pair of lost sunglasses I found in my jacket",
  "id" : 264195108822478849,
  "created_at" : "Fri Nov 02 02:39:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 3, 14 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264190795739955200",
  "text" : "RT @angryasian: New life goal: design and build a winning Punkin' Chunkin' machine.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "264189704184942592",
    "text" : "New life goal: design and build a winning Punkin' Chunkin' machine.",
    "id" : 264189704184942592,
    "created_at" : "Fri Nov 02 02:18:28 +0000 2012",
    "user" : {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "protected" : false,
      "id_str" : "16353686",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/904017577/105073547_normal.jpg",
      "id" : 16353686,
      "verified" : false
    }
  },
  "id" : 264190795739955200,
  "created_at" : "Fri Nov 02 02:22:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.35840213, -73.22494599 ]
  },
  "id_str" : "264186258933284865",
  "text" : "\"well we can all agree there is a lot of sucking going on in this game\"",
  "id" : 264186258933284865,
  "created_at" : "Fri Nov 02 02:04:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "handingawaythegame",
      "indices" : [ 68, 87 ]
    }, {
      "text" : "hokies",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3581845, -73.22491544 ]
  },
  "id_str" : "264183514176552962",
  "text" : "if we can win with this many mistakes...Miami should be embarrassed #handingawaythegame #hokies",
  "id" : 264183514176552962,
  "created_at" : "Fri Nov 02 01:53:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmcdougall",
      "screen_name" : "dmcdougall_",
      "indices" : [ 0, 12 ],
      "id_str" : "884807263",
      "id" : 884807263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264125179901407232",
  "geo" : {
  },
  "id_str" : "264132955075661824",
  "in_reply_to_user_id" : 884807263,
  "text" : "@dmcdougall_ yeah I was little confused about that. I'm on OSX 10.7, everything works but the font",
  "id" : 264132955075661824,
  "in_reply_to_status_id" : 264125179901407232,
  "created_at" : "Thu Nov 01 22:32:58 +0000 2012",
  "in_reply_to_screen_name" : "dmcdougall_",
  "in_reply_to_user_id_str" : "884807263",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "264082559749722112",
  "text" : "@axetickle running your XKCD matplotlib script. very cool. text isn't working tho, is there a trick? i have ttf downloaded, pointed like urs",
  "id" : 264082559749722112,
  "created_at" : "Thu Nov 01 19:12:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 5, 17 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/Q5gUcecU",
      "expanded_url" : "http://instagr.am/p/Rf07rKOS3J/",
      "display_url" : "instagr.am/p/Rf07rKOS3J/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264074869929545728",
  "text" : "the \"@mrfrank5790 productivity corner\" complete with espresso machine #storylab http://t.co/Q5gUcecU",
  "id" : 264074869929545728,
  "created_at" : "Thu Nov 01 18:42:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/QjsZUdvg",
      "expanded_url" : "http://buff.ly/Sapl53",
      "display_url" : "buff.ly/Sapl53"
    } ]
  },
  "geo" : {
  },
  "id_str" : "264019889860251648",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"How do frequent emails and texts affect productivity? http://t.co/QjsZUdvg\"",
  "id" : 264019889860251648,
  "created_at" : "Thu Nov 01 15:03:41 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264011511763202049",
  "geo" : {
  },
  "id_str" : "264014229936422912",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr haha good guess! had HW to hand in, so opted for the third option \"go but use twitter for the remaining 15 minutes\"",
  "id" : 264014229936422912,
  "in_reply_to_status_id" : 264011511763202049,
  "created_at" : "Thu Nov 01 14:41:12 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264010628266614785",
  "geo" : {
  },
  "id_str" : "264014048155299840",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser would've if I didn't have HW to hand in...",
  "id" : 264014048155299840,
  "in_reply_to_status_id" : 264010628266614785,
  "created_at" : "Thu Nov 01 14:40:28 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47984692, -73.19764521 ]
  },
  "id_str" : "263993746423693316",
  "text" : "when your alarm doesn't do the job...always tough deciding whether to show up to class halfway though or can it",
  "id" : 263993746423693316,
  "created_at" : "Thu Nov 01 13:19:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]