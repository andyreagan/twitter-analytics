Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http://t.co/kYNMLnr",
      "expanded_url" : "http://connect.garmin.com/activity/89315202?sms_ss=twitter&at_xt=4de562377bb40e3b,0",
      "display_url" : "connect.garmin.com/activity/89315…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "75680384939077632",
  "text" : "today's run: http://t.co/kYNMLnr",
  "id" : 75680384939077632,
  "created_at" : "Tue May 31 21:49:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75677439778500609",
  "text" : "Been helping the other REU'ers move in, took them to Moes for lunch, on a run up Old Farm, now a quick shower and dinner @ macados",
  "id" : 75677439778500609,
  "created_at" : "Tue May 31 21:38:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75573433831915522",
  "text" : "just got my meal card, schweet!",
  "id" : 75573433831915522,
  "created_at" : "Tue May 31 14:44:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "75571664213114880",
  "text" : "still got my desk! heading to Roanoke soon to get other REU students from airport http://4sq.com/iIjX9W",
  "id" : 75571664213114880,
  "created_at" : "Tue May 31 14:37:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http://t.co/ykAtSeA",
      "expanded_url" : "http://connect.garmin.com/activity/89110266?sms_ss=twitter&at_xt=4de415b47fe0eed0,0",
      "display_url" : "connect.garmin.com/activity/89110…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "75323933477453824",
  "text" : "Short hilly ride by andyreagan at Garmin Connect - Details: http://t.co/ykAtSeA",
  "id" : 75323933477453824,
  "created_at" : "Mon May 30 22:13:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75304373110063104",
  "text" : "goin for a short ride, then cookout! Long day of cleaning and moving",
  "id" : 75304373110063104,
  "created_at" : "Mon May 30 20:55:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http://t.co/iBLGE51",
      "expanded_url" : "http://twitpic.com/54qmh3",
      "display_url" : "twitpic.com/54qmh3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "75284217692569600",
  "text" : "Perfection http://t.co/iBLGE51",
  "id" : 75284217692569600,
  "created_at" : "Mon May 30 19:35:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75248089191034881",
  "geo" : {
  },
  "id_str" : "75249392419995648",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium schweet!",
  "id" : 75249392419995648,
  "in_reply_to_status_id" : 75248089191034881,
  "created_at" : "Mon May 30 17:17:07 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 87, 100 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75196353600421888",
  "text" : "spent the first half of \"moving in\" packing up Dave's stuff... slowly getting settled. @williamenium have you seen the blue single speed?",
  "id" : 75196353600421888,
  "created_at" : "Mon May 30 13:46:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75043663654301696",
  "text" : "Unpacked, grabbed a pb sandwich, then ran to the top of brush mtn w just my hammock to camp for the night!",
  "id" : 75043663654301696,
  "created_at" : "Mon May 30 03:39:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bestdriveyet",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75010844571877377",
  "text" : "5 miles away! 9.5 hrs w a subway stop, not bad. Literally didn't touch my brakes on 81, had the interstate to myself today #bestdriveyet",
  "id" : 75010844571877377,
  "created_at" : "Mon May 30 01:29:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obnoxious",
      "indices" : [ 110, 120 ]
    }, {
      "text" : "unnecessary",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74966869743906816",
  "text" : "they didn't even notice, score! Motorcycle passing is so loud that the girl on the back was plugging her ears #obnoxious #unnecessary",
  "id" : 74966869743906816,
  "created_at" : "Sun May 29 22:34:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74963633125343232",
  "text" : "oh why hello VA, signs for Roanoke! Would it be cool to stop at a different subway for a free refill?",
  "id" : 74963633125343232,
  "created_at" : "Sun May 29 22:21:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 0, 8 ],
      "id_str" : "86132431",
      "id" : 86132431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74955595261804544",
  "geo" : {
  },
  "id_str" : "74961258763395072",
  "in_reply_to_user_id" : 86132431,
  "text" : "@bricec5 yessir, I think a couple purist 22s and a bunch of 20oz with the orange caps",
  "id" : 74961258763395072,
  "in_reply_to_status_id" : 74955595261804544,
  "created_at" : "Sun May 29 22:12:11 +0000 2011",
  "in_reply_to_screen_name" : "bricec5",
  "in_reply_to_user_id_str" : "86132431",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74918976756518912",
  "text" : "Successful gas stop and subway",
  "id" : 74918976756518912,
  "created_at" : "Sun May 29 19:24:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74890376745459712",
  "text" : "peace NY",
  "id" : 74890376745459712,
  "created_at" : "Sun May 29 17:30:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74848997176647680",
  "text" : "gorgeous NY day...want to ride my bike instead of pack it into the car for the drive back to #blacksburg",
  "id" : 74848997176647680,
  "created_at" : "Sun May 29 14:46:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 21, 32 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 37, 46 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "74668769015898112",
  "text" : "RT @DZdan1: Out with @andyreagan and @dknick88 its andy last night in cuse :(.... id also like to wish a happy early bday to my wonderfu ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.motorola.com\" rel=\"nofollow\">DROID</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 9, 20 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 25, 34 ],
        "id_str" : "204631321",
        "id" : 204631321
      }, {
        "name" : "Hannah Weeks",
        "screen_name" : "anasemanas",
        "indices" : [ 129, 140 ],
        "id_str" : "40995810",
        "id" : 40995810
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "74667505792204801",
    "text" : "Out with @andyreagan and @dknick88 its andy last night in cuse :(.... id also like to wish a happy early bday to my wonderful gf @anasemanas",
    "id" : 74667505792204801,
    "created_at" : "Sun May 29 02:44:55 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 74668769015898112,
  "created_at" : "Sun May 29 02:49:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/iVAaFj5",
      "expanded_url" : "http://connect.garmin.com/activity/88329487?sms_ss=twitter&at_xt=4ddfdf5e37539f4c,0",
      "display_url" : "connect.garmin.com/activity/88329…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "74165978501611520",
  "text" : "Short ride by andyreagan on Garmin Connect - Details http://t.co/iVAaFj5",
  "id" : 74165978501611520,
  "created_at" : "Fri May 27 17:32:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http://t.co/VDaWgTk",
      "expanded_url" : "http://twitpic.com/537vek",
      "display_url" : "twitpic.com/537vek"
    } ]
  },
  "geo" : {
  },
  "id_str" : "74137701074481152",
  "text" : "a perfect loaf from the new bread machine! Headed out for a road ride now http://t.co/VDaWgTk",
  "id" : 74137701074481152,
  "created_at" : "Fri May 27 15:39:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 12, 21 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74116758109298689",
  "geo" : {
  },
  "id_str" : "74119773587382272",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 @DKnick88 buy 10 deluxe grilled cheese, get one free?",
  "id" : 74119773587382272,
  "in_reply_to_status_id" : 74116758109298689,
  "created_at" : "Fri May 27 14:28:25 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/QlQK19r",
      "expanded_url" : "http://twitpic.com/52r6ce",
      "display_url" : "twitpic.com/52r6ce"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73751027962220544",
  "text" : "and the rafting adventure begins! Im outta breath from blowing this thing up: http://t.co/QlQK19r",
  "id" : 73751027962220544,
  "created_at" : "Thu May 26 14:03:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 102, 110 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/iBsjk3J",
      "expanded_url" : "http://connect.garmin.com/activity/88038557?sms_ss=twitter&at_xt=4ddd99b335721416,0",
      "display_url" : "connect.garmin.com/activity/88038…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73541196512890880",
  "text" : "my mapped run w/ @dmreagan at the park on my new Garmin 310XT!! check it out: http://t.co/iBsjk3J via @AddThis",
  "id" : 73541196512890880,
  "created_at" : "Thu May 26 00:09:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 129, 138 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73508592287879169",
  "text" : "and split the pizza with the fam on the way back from picking up a breadmaker. Test loaf in the bread machine now, goin runnin w @dmreagan",
  "id" : 73508592287879169,
  "created_at" : "Wed May 25 21:59:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73487056478814208",
  "text" : "got it in the nose on the 19th hole for a free game, free ice cream cone, bowling game, 10 wings, and pizza hut pizza! Cone was delic",
  "id" : 73487056478814208,
  "created_at" : "Wed May 25 20:34:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 58, 69 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 74, 83 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73481333594259456",
  "text" : "Beautiful day outside! Good for an 11 stroke victory over @kreagannet and @dmreagan, at 2 under par :-P",
  "id" : 73481333594259456,
  "created_at" : "Wed May 25 20:11:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 12, 23 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 28, 37 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73461129103413248",
  "text" : "Putt putt w @kreagannet and @dmreagan!",
  "id" : 73461129103413248,
  "created_at" : "Wed May 25 18:51:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Li",
      "screen_name" : "jacquesli",
      "indices" : [ 0, 10 ],
      "id_str" : "30700815",
      "id" : 30700815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73417221552078849",
  "geo" : {
  },
  "id_str" : "73428408658444288",
  "in_reply_to_user_id" : 30700815,
  "text" : "@jacquesli not bad at all!!",
  "id" : 73428408658444288,
  "in_reply_to_status_id" : 73417221552078849,
  "created_at" : "Wed May 25 16:41:11 +0000 2011",
  "in_reply_to_screen_name" : "jacquesli",
  "in_reply_to_user_id_str" : "30700815",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http://t.co/IRug9F8",
      "expanded_url" : "http://twitpic.com/524vl2",
      "display_url" : "twitpic.com/524vl2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73198154358591489",
  "text" : ".@ryandelguidice signing to eat the atomic wings, 150,000 SHU! http://t.co/IRug9F8",
  "id" : 73198154358591489,
  "created_at" : "Wed May 25 01:26:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 39, 54 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 55, 64 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Matt McKenney",
      "screen_name" : "mattmckenney",
      "indices" : [ 65, 78 ],
      "id_str" : "244222514",
      "id" : 244222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73189468269580289",
  "text" : "Quaker steak and lube for wing night w @ryandelgiudice @DKnick88 @mattmckenney p, slade, blackmer, choroser aand mosher!",
  "id" : 73189468269580289,
  "created_at" : "Wed May 25 00:51:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 1, 17 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http://t.co/OBlLNib",
      "expanded_url" : "http://twitpic.com/5235j7",
      "display_url" : "twitpic.com/5235j7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73158175825735681",
  "text" : ".@rumblinstumblin's a chef! Blackened tilapia, yellow squash, and homemade sweet potatoe fries http://t.co/OBlLNib",
  "id" : 73158175825735681,
  "created_at" : "Tue May 24 22:47:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "John Schlegel",
      "screen_name" : "jschlegs31",
      "indices" : [ 8, 19 ],
      "id_str" : "248895700",
      "id" : 248895700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http://t.co/5oibeph",
      "expanded_url" : "http://www.urbandictionary.com/iphone/#define?term=smug",
      "display_url" : "urbandictionary.com/iphone/#define…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "73156805693411328",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @jschlegs31 http://t.co/5oibeph",
  "id" : 73156805693411328,
  "created_at" : "Tue May 24 22:41:56 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 26, 37 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 43, 50 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "John Schlegel",
      "screen_name" : "jschlegs31",
      "indices" : [ 56, 67 ],
      "id_str" : "248895700",
      "id" : 248895700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73150084551942144",
  "text" : "disc golfing was awesome, @andyreagan 1st, @DZdan1 2nd, @jschlegs31 3rd",
  "id" : 73150084551942144,
  "created_at" : "Tue May 24 22:15:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 4, 11 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73117755590713344",
  "text" : "got @DZdan1 all set up on his droid lol, now goin disc golfing once he can find his discs!",
  "id" : 73117755590713344,
  "created_at" : "Tue May 24 20:06:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 67, 74 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 75, 82 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73106752782073856",
  "text" : "Just got the Droid PRO! Its sick! Thanks for the other suggestions @k8eb8e @jbice0",
  "id" : 73106752782073856,
  "created_at" : "Tue May 24 19:23:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Quick",
      "screen_name" : "BQueezy",
      "indices" : [ 0, 8 ],
      "id_str" : "19423209",
      "id" : 19423209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73077885463834624",
  "geo" : {
  },
  "id_str" : "73078068075438080",
  "in_reply_to_user_id" : 19423209,
  "text" : "@BQueezy it finally kicked the bucket?!?!!",
  "id" : 73078068075438080,
  "in_reply_to_status_id" : 73077885463834624,
  "created_at" : "Tue May 24 17:29:03 +0000 2011",
  "in_reply_to_screen_name" : "BQueezy",
  "in_reply_to_user_id_str" : "19423209",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73077774755168257",
  "text" : "purtyy http://yfrog.com/gyfm0ncj",
  "id" : 73077774755168257,
  "created_at" : "Tue May 24 17:27:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 65, 74 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "73056958017576960",
  "text" : "blog updated and research summary written! now givin the lawn an @DKnick88 style mowjob",
  "id" : 73056958017576960,
  "created_at" : "Tue May 24 16:05:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 58, 65 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 129, 138 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peacetwitterati",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72871363173560320",
  "text" : "gonna be gettin up early-ish tmrw to get the droid pro so @dzdan1 and I can be twins! #peacetwitterati @ryandelguidice where was @dknick88",
  "id" : 72871363173560320,
  "created_at" : "Tue May 24 03:47:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 67, 76 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72867119678763008",
  "text" : "has been loving the fresh homemade bread while I've been home from @dmreagan. I'm excited at the idea of gettin a bread machine myself!",
  "id" : 72867119678763008,
  "created_at" : "Tue May 24 03:30:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72855996925620224",
  "text" : "drinkin a growler of my very first beer! Aged for a year and half...not bad.",
  "id" : 72855996925620224,
  "created_at" : "Tue May 24 02:46:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 119, 126 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 127, 134 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72854213448826880",
  "text" : "found out today what Im goin to be researching @vbiatvt this summer: iron metabolism! And also got a wicked burn today @DZdan1 @sspis1 #ouch",
  "id" : 72854213448826880,
  "created_at" : "Tue May 24 02:39:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72785768682233856",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 it was really nice meeting you, hope you're having a safe trip home!! come back before this weekend??",
  "id" : 72785768682233856,
  "created_at" : "Mon May 23 22:07:34 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 60, 67 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 72, 79 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72785581293322240",
  "text" : "had an awesome, perhaps epic, kayaking adventure today with @DZdan1 and @sspis1!! w/ Subway chicken terriyaki to top it off.",
  "id" : 72785581293322240,
  "created_at" : "Mon May 23 22:06:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 58, 65 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 70, 81 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72665074006884354",
  "text" : "RT @DZdan1: Getting ready to go kayaking on Otisco Lake w @sspis1 and @andyreagan for the day!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.motorola.com\" rel=\"nofollow\">DROID</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 46, 53 ],
        "id_str" : "282847130",
        "id" : 282847130
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 58, 69 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "72664967962308609",
    "text" : "Getting ready to go kayaking on Otisco Lake w @sspis1 and @andyreagan for the day!",
    "id" : 72664967962308609,
    "created_at" : "Mon May 23 14:07:33 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 72665074006884354,
  "created_at" : "Mon May 23 14:07:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughlifedecisions",
      "indices" : [ 88, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72423455999533056",
  "text" : "should I get the iPhone 4, Droid Pro, or Droid Charge, or HTC Thunderbolt? Let me know! #toughlifedecisions",
  "id" : 72423455999533056,
  "created_at" : "Sun May 22 22:07:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72341714983071744",
  "geo" : {
  },
  "id_str" : "72422485928316928",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 that's strange...I can't imagine why",
  "id" : 72422485928316928,
  "in_reply_to_status_id" : 72341714983071744,
  "created_at" : "Sun May 22 22:04:00 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "72069904429355008",
  "text" : "race was fun! more like a circuit race, it was 22 1-mile laps. was way OTF for first 3, went 4 couple primes, and attacked last lap!",
  "id" : 72069904429355008,
  "created_at" : "Sat May 21 22:42:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 71, 87 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71996210977849344",
  "text" : "most expensive race ever, 45 for the crit, good thing I'm sponsored by @rumblinstumblin. Going to be interesting, big field but no teammates",
  "id" : 71996210977849344,
  "created_at" : "Sat May 21 17:50:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71995648924336128",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan can you bring the spray adhesive in the box on the hot tub, and sunscreen? Should be at 4",
  "id" : 71995648924336128,
  "created_at" : "Sat May 21 17:47:54 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71984575089360897",
  "text" : "headed downtown for the Tour de Syracuse crit racing. Still haven't decided whether or not I'm entering the omnium (RR + TT tmrw) yet",
  "id" : 71984575089360897,
  "created_at" : "Sat May 21 17:03:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71934913045200896",
  "geo" : {
  },
  "id_str" : "71937948077129728",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson chyeah! sounds like a plan",
  "id" : 71937948077129728,
  "in_reply_to_status_id" : 71934913045200896,
  "created_at" : "Sat May 21 13:58:38 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 95, 105 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71937057546698752",
  "text" : "I'm riding from Lexington, VA to Charlottesville, VA on Sat, June 4 and back to Lexington with @bikebuild on Sun, June 5. Who wants to join?",
  "id" : 71937057546698752,
  "created_at" : "Sat May 21 13:55:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71930661950341120",
  "geo" : {
  },
  "id_str" : "71931236423184385",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson bummer. now you should come to my crit in Syracuse and lead out!",
  "id" : 71931236423184385,
  "in_reply_to_status_id" : 71930661950341120,
  "created_at" : "Sat May 21 13:31:57 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ghincapie",
      "screen_name" : "ghincapie",
      "indices" : [ 3, 13 ],
      "id_str" : "18077270",
      "id" : 18077270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71734884292493312",
  "text" : "RT @ghincapie: As I've said in the past, I continue to be disappointed that people are talking about the past in cycling instead of the  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://ubersocial.com\" rel=\"nofollow\">UberSocial Pro for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "71734564690726912",
    "text" : "As I've said in the past, I continue to be disappointed that people are talking about the past in cycling instead of the future.",
    "id" : 71734564690726912,
    "created_at" : "Sat May 21 00:30:27 +0000 2011",
    "user" : {
      "name" : "ghincapie",
      "screen_name" : "ghincapie",
      "protected" : false,
      "id_str" : "18077270",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3002944813/75e595b40d07d33e2bfdf990239fad75_normal.jpeg",
      "id" : 18077270,
      "verified" : true
    }
  },
  "id" : 71734884292493312,
  "created_at" : "Sat May 21 00:31:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71696440417722368",
  "geo" : {
  },
  "id_str" : "71709201377923073",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet watch out for slipping foot rests!",
  "id" : 71709201377923073,
  "in_reply_to_status_id" : 71696440417722368,
  "created_at" : "Fri May 20 22:49:40 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71623614876753922",
  "text" : "headed out for an opener ride, new post on http://andyreagan.com",
  "id" : 71623614876753922,
  "created_at" : "Fri May 20 17:09:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71610943502684160",
  "geo" : {
  },
  "id_str" : "71623500779094016",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson congrats on the upgrade (we'll be together again) and the anniversary! I'm also doing a cat 4 crit tmrw, good luck!",
  "id" : 71623500779094016,
  "in_reply_to_status_id" : 71610943502684160,
  "created_at" : "Fri May 20 17:09:07 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71375151027073024",
  "text" : "Just finished reading \"Born to Run\" by Christopher McDougall, great read. Highly recommend",
  "id" : 71375151027073024,
  "created_at" : "Fri May 20 00:42:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71361179431346176",
  "geo" : {
  },
  "id_str" : "71373222221852672",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 you better be getting triple time if that means you wont be back tmrw night!",
  "id" : 71373222221852672,
  "in_reply_to_status_id" : 71361179431346176,
  "created_at" : "Fri May 20 00:34:36 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71331210315571200",
  "geo" : {
  },
  "id_str" : "71333548832993280",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 woot woot! keep travelling safe!",
  "id" : 71333548832993280,
  "in_reply_to_status_id" : 71331210315571200,
  "created_at" : "Thu May 19 21:56:58 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71310669860978688",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan 10-4",
  "id" : 71310669860978688,
  "created_at" : "Thu May 19 20:26:03 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "71308569156390912",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan where ya at?",
  "id" : 71308569156390912,
  "created_at" : "Thu May 19 20:17:42 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http://t.co/J5zme9O",
      "expanded_url" : "http://twitpic.com/4zfi6q",
      "display_url" : "twitpic.com/4zfi6q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70990306018983936",
  "text" : ".@ryandelguidice's makin the spread http://t.co/J5zme9O",
  "id" : 70990306018983936,
  "created_at" : "Wed May 18 23:13:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 3, 12 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 30, 45 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70986703300599809",
  "text" : "RT @DKnick88: heading over to @ryandelgiudice 's for a while",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan DelGiudice",
        "screen_name" : "ryandelgiudice",
        "indices" : [ 16, 31 ],
        "id_str" : "44471444",
        "id" : 44471444
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "70980573451124736",
    "text" : "heading over to @ryandelgiudice 's for a while",
    "id" : 70980573451124736,
    "created_at" : "Wed May 18 22:34:22 +0000 2011",
    "user" : {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "protected" : false,
      "id_str" : "204631321",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3194859210/2cfdf039ddb963cafa9970cf96a5b8d2_normal.jpeg",
      "id" : 204631321,
      "verified" : false
    }
  },
  "id" : 70986703300599809,
  "created_at" : "Wed May 18 22:58:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70965122729906176",
  "geo" : {
  },
  "id_str" : "70966246706917376",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 i'd say that's fitting",
  "id" : 70966246706917376,
  "in_reply_to_status_id" : 70965122729906176,
  "created_at" : "Wed May 18 21:37:26 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://MapMyRun.com\" rel=\"nofollow\">MapMyRun</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70961614261727232",
  "text" : ".@ryandelguidice and I's run today: . run with Del in Marcellus, NY | Running Map | MapMyRUN: http://soc.li/w4qidrK",
  "id" : 70961614261727232,
  "created_at" : "Wed May 18 21:19:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://MapMyRun.com\" rel=\"nofollow\">MapMyRun</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70960367559385089",
  "text" : "map of my ride, 57mi! A bike mapped on 05/18/2011 in Marcellus, NY | Running Map | MapMyRUN: http://soc.li/iJEk3qV",
  "id" : 70960367559385089,
  "created_at" : "Wed May 18 21:14:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/SC88plf",
      "expanded_url" : "http://twitpic.com/4zdmdw",
      "display_url" : "twitpic.com/4zdmdw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70942217983897600",
  "text" : "Now that's a pbj (big jif jar for perspective) http://t.co/SC88plf",
  "id" : 70942217983897600,
  "created_at" : "Wed May 18 20:01:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 59, 74 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imcrazy",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70939978103918593",
  "text" : "sweet 4hr ride! rode all over SYR... now going for a run w @ryandelgiudice #imcrazy",
  "id" : 70939978103918593,
  "created_at" : "Wed May 18 19:53:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 35, 45 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70878369306255360",
  "text" : "goin for a ride...miss riding with @vtcycling in BBurg",
  "id" : 70878369306255360,
  "created_at" : "Wed May 18 15:48:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 69, 85 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70620139690790912",
  "text" : "beautiful 1hr 5min run, even saved a turtle! home to choc milk, then @RumblinStumblin's blackened fish w pasta and a brooklyn pils #winning",
  "id" : 70620139690790912,
  "created_at" : "Tue May 17 22:42:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70593982165553152",
  "text" : "goin for a run at the park!",
  "id" : 70593982165553152,
  "created_at" : "Tue May 17 20:58:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70563384386531328",
  "geo" : {
  },
  "id_str" : "70563944720379904",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 after three weeks it isn't done actively fermenting? ideally you would move it into a secondary fermenter for another month",
  "id" : 70563944720379904,
  "in_reply_to_status_id" : 70563384386531328,
  "created_at" : "Tue May 17 18:58:50 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70561753188143105",
  "geo" : {
  },
  "id_str" : "70562534788300800",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 thanks! and you're bottling in two days that's awesome!!",
  "id" : 70562534788300800,
  "in_reply_to_status_id" : 70561753188143105,
  "created_at" : "Tue May 17 18:53:13 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 41, 50 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70324729478787073",
  "text" : "downtownnnn here we come @ryandelguidice @dknick88",
  "id" : 70324729478787073,
  "created_at" : "Tue May 17 03:08:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http://t.co/4ymWYKP",
      "expanded_url" : "http://twitpic.com/4ynwy4",
      "display_url" : "twitpic.com/4ynwy4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "70298843341787136",
  "text" : "just check my grades, 3.60 on the semester!! deserved: http://t.co/4ymWYKP",
  "id" : 70298843341787136,
  "created_at" : "Tue May 17 01:25:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ispendwaytomuchmoneyon",
      "indices" : [ 68, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70181723161366528",
  "text" : "is seriously disappointed with our grammar... how is this trending: #ispendwaytomuchmoneyon",
  "id" : 70181723161366528,
  "created_at" : "Mon May 16 17:40:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 4, 15 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icouldgetusedtothis",
      "indices" : [ 101, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70181072092135424",
  "text" : "cut @kreagannet's hair and chopped wood while he made me lunch. whole wheat pasta, 5 veggie salad... #icouldgetusedtothis",
  "id" : 70181072092135424,
  "created_at" : "Mon May 16 17:37:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Young",
      "screen_name" : "annaeyoung",
      "indices" : [ 103, 114 ],
      "id_str" : "32577122",
      "id" : 32577122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70161831242633216",
  "text" : "35mi, 2hrs, rain, cold, getting lost, bunny hopping a deer, and lots of  short climbs... good ride! (w @annaeyoung)",
  "id" : 70161831242633216,
  "created_at" : "Mon May 16 16:20:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "70095684543586304",
  "text" : "48deg and raining...goin for a road bike ride! def wouldn't be ridin by myself tho",
  "id" : 70095684543586304,
  "created_at" : "Mon May 16 11:58:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Young",
      "screen_name" : "annaeyoung",
      "indices" : [ 54, 65 ],
      "id_str" : "32577122",
      "id" : 32577122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69957410915221504",
  "text" : "gettin up early to ride the Tour de Syracuse course w @annaeyoung, maybe this time getting a night's sleep...woah.",
  "id" : 69957410915221504,
  "created_at" : "Mon May 16 02:48:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69941048666886144",
  "text" : "and side note before i forget, calculated my mileage for the trip from BBurg -&gt; SYR .... 40.3MPG!!! ('99 honda accord)",
  "id" : 69941048666886144,
  "created_at" : "Mon May 16 01:43:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69937725716971520",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 hope the trip back to school went well my man! see you next week. camping part dos in the adks 4 sure.",
  "id" : 69937725716971520,
  "created_at" : "Mon May 16 01:30:27 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69891872138596352",
  "geo" : {
  },
  "id_str" : "69929197862268928",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy thanks man, I wanna read about your trip! and congrats on the socks haha",
  "id" : 69929197862268928,
  "in_reply_to_status_id" : 69891872138596352,
  "created_at" : "Mon May 16 00:56:34 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69924577702199298",
  "geo" : {
  },
  "id_str" : "69928085461536770",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan has it ever gone longer than one round?",
  "id" : 69928085461536770,
  "in_reply_to_status_id" : 69924577702199298,
  "created_at" : "Mon May 16 00:52:09 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69850170489176064",
  "text" : "won the race this morning! http://yfrog.com/h7otzxfj",
  "id" : 69850170489176064,
  "created_at" : "Sun May 15 19:42:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69660688334852096",
  "text" : "fun bbq and night out in downtown SYR! Four hours sleep and then up to race bikes....sounds like a collegiate weekend",
  "id" : 69660688334852096,
  "created_at" : "Sun May 15 07:09:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 76, 91 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69537699572367360",
  "text" : "new post on http://andyreagan.com abt the race today, and waitin to bbq for @ryandelgiudice's big TWO ONE before we go dt tonight!",
  "id" : 69537699572367360,
  "created_at" : "Sat May 14 23:00:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 39, 48 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 90, 106 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69420167196721152",
  "text" : "just ran the Race for the Cure 5K with @dmreagan! We were cruisin at 7min pace 4 a while. @rumblinstumblin we're going to the bike shop now",
  "id" : 69420167196721152,
  "created_at" : "Sat May 14 15:13:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "del",
      "screen_name" : "del",
      "indices" : [ 41, 45 ],
      "id_str" : "18956852",
      "id" : 18956852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moregreatquotes",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69231324141076480",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 \"thanks for coming out tonight\" -@del #moregreatquotes",
  "id" : 69231324141076480,
  "created_at" : "Sat May 14 02:43:28 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan dz",
      "screen_name" : "DzDan",
      "indices" : [ 0, 6 ],
      "id_str" : "309002970",
      "id" : 309002970
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 42, 51 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatquotes",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69231185783554048",
  "text" : "@dzdan \"we've confirmed that you're gay\" -@dknick88 #greatquotes",
  "id" : 69231185783554048,
  "created_at" : "Sat May 14 02:42:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69173304258347008",
  "text" : "yard mowed and lookin purty!",
  "id" : 69173304258347008,
  "created_at" : "Fri May 13 22:52:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69131669931687936",
  "text" : "just went up to the bike shop, didn't get my powertap fixed but got a number...",
  "id" : 69131669931687936,
  "created_at" : "Fri May 13 20:07:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 48, 55 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 56, 65 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 66, 81 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69065931317452801",
  "text" : "my workout yesterday: http://twitpic.com/4x37kg @DZdan1 @DKnick88 @ryandelgiudice bonfire tonight at my place?",
  "id" : 69065931317452801,
  "created_at" : "Fri May 13 15:46:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "69056072073220096",
  "text" : "has too many tshirts. just counted, 183 of them!",
  "id" : 69056072073220096,
  "created_at" : "Fri May 13 15:07:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68840123235696640",
  "geo" : {
  },
  "id_str" : "68860749191184384",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 on 9 holes I assume",
  "id" : 68860749191184384,
  "in_reply_to_status_id" : 68840123235696640,
  "created_at" : "Fri May 13 02:10:56 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68821771033391104",
  "geo" : {
  },
  "id_str" : "68833769947283456",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel question, is high school track still going on lol? i wanna come pole vault while I'm home!",
  "id" : 68833769947283456,
  "in_reply_to_status_id" : 68821771033391104,
  "created_at" : "Fri May 13 00:23:44 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carmichael Training",
      "screen_name" : "trainright",
      "indices" : [ 22, 33 ],
      "id_str" : "16881163",
      "id" : 16881163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68833250579185664",
  "text" : "just finished reading @trainright's Food for Fitness, lots of great advice. agrees well with how my Dad is eating for heart health",
  "id" : 68833250579185664,
  "created_at" : "Fri May 13 00:21:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 12, 28 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68799606359732224",
  "text" : "the old man @RumblinStumblin can still shoot the rock...got me in free throws, horse, and he didn't miss a shot in around the world!",
  "id" : 68799606359732224,
  "created_at" : "Thu May 12 22:07:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68405444162494464",
  "text" : "nice 43mi ride today around Otisco http://www.mapmyrun.com/routes/view/34061572/",
  "id" : 68405444162494464,
  "created_at" : "Wed May 11 20:01:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.980236, -76.305137 ]
  },
  "id_str" : "68067314356072448",
  "text" : "Back after a good run at Baltimore Woods (@ Reagan Stronghold) http://4sq.com/kksMMI",
  "id" : 68067314356072448,
  "created_at" : "Tue May 10 21:38:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 23, 32 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "activeday",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68044996951031808",
  "text" : "goin for a trail run w @dmreagan! after tilling the garden and planting potatoes, after 2.5hr ride. #activeday",
  "id" : 68044996951031808,
  "created_at" : "Tue May 10 20:09:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68017434463977472",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia the spot http://twitpic.com/4vyu0u",
  "id" : 68017434463977472,
  "created_at" : "Tue May 10 18:19:54 +0000 2011",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "68014090123087872",
  "text" : "WOW check out pleasant valley rdd http://twitpic.com/4vype1",
  "id" : 68014090123087872,
  "created_at" : "Tue May 10 18:06:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67971948709281792",
  "text" : "my parents signed me up for a 5k and a bike race this weekend! guess that means I need to train... headin out for a ride!",
  "id" : 67971948709281792,
  "created_at" : "Tue May 10 15:19:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67965204377505792",
  "geo" : {
  },
  "id_str" : "67971721747120130",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 alright, well hang in there man. Let me know if you need anything at all",
  "id" : 67971721747120130,
  "in_reply_to_status_id" : 67965204377505792,
  "created_at" : "Tue May 10 15:18:15 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67964842862059521",
  "geo" : {
  },
  "id_str" : "67971612997193728",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 because she's excited to get sunburned! (Skin cancer....) and home is home, can't wait",
  "id" : 67971612997193728,
  "in_reply_to_status_id" : 67964842862059521,
  "created_at" : "Tue May 10 15:17:50 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67825230030176256",
  "geo" : {
  },
  "id_str" : "67955394055643137",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 what happened man? You're not going to be in bburg this fall?",
  "id" : 67955394055643137,
  "in_reply_to_status_id" : 67825230030176256,
  "created_at" : "Tue May 10 14:13:23 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67808143396192256",
  "geo" : {
  },
  "id_str" : "67955211674718208",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 hopefully the ACS doesn't follow your friends tweets",
  "id" : 67955211674718208,
  "in_reply_to_status_id" : 67808143396192256,
  "created_at" : "Tue May 10 14:12:39 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67724102496043008",
  "geo" : {
  },
  "id_str" : "67791965441368064",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 3 weeks brotha",
  "id" : 67791965441368064,
  "in_reply_to_status_id" : 67724102496043008,
  "created_at" : "Tue May 10 03:23:58 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 72, 83 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.980236, -76.305137 ]
  },
  "id_str" : "67791422790713344",
  "text" : "just to make it official, tho I won't even be here long enough to steal @kreagannet's mayorship: (@ Reagan Stronghold) http://4sq.com/kheK1E",
  "id" : 67791422790713344,
  "created_at" : "Tue May 10 03:21:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67718273965371392",
  "text" : "Home!!!",
  "id" : 67718273965371392,
  "created_at" : "Mon May 09 22:31:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67683298587058177",
  "text" : "our inability to merge on the highway is astounding (and frustrating) ...loss of one lane = 5mi backup",
  "id" : 67683298587058177,
  "created_at" : "Mon May 09 20:12:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67613547651272704",
  "text" : "was fighting the eyelids, but a 20min nap at a rest stop and I'm rollin",
  "id" : 67613547651272704,
  "created_at" : "Mon May 09 15:35:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67584136545714176",
  "text" : "actually got goin at 8:30 but after four failed attempts by yfrog and twitpic gave up on the pic. Just filled up, $50.77 #ouch",
  "id" : 67584136545714176,
  "created_at" : "Mon May 09 13:38:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67582001057771521",
  "text" : "pancakes w vermont maple syrup, num theory book sold, masters PoS turned in, on the road! Check the new stickers",
  "id" : 67582001057771521,
  "created_at" : "Mon May 09 13:29:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67407441133977600",
  "geo" : {
  },
  "id_str" : "67407638991867904",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice 65MPH cruise control! ha",
  "id" : 67407638991867904,
  "in_reply_to_status_id" : 67407441133977600,
  "created_at" : "Mon May 09 01:56:48 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67407537447763969",
  "text" : "then grilled filet mignon, corn, sweet potatoes 4 dinner...delic. packing up now...",
  "id" : 67407537447763969,
  "created_at" : "Mon May 09 01:56:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67407354848739328",
  "text" : "bike ride w Dave and Danny to the New River today was incredible. double rope swing action! and drilling it downhill, couldn't drop Dave!",
  "id" : 67407354848739328,
  "created_at" : "Mon May 09 01:55:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67288885872431104",
  "geo" : {
  },
  "id_str" : "67405866290262016",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice have a good first day at work tmrw, i'll cya tmrw night!!",
  "id" : 67405866290262016,
  "in_reply_to_status_id" : 67288885872431104,
  "created_at" : "Mon May 09 01:49:45 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Li",
      "screen_name" : "jacquesli",
      "indices" : [ 0, 10 ],
      "id_str" : "30700815",
      "id" : 30700815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67342334534234112",
  "geo" : {
  },
  "id_str" : "67399336442605568",
  "in_reply_to_user_id" : 30700815,
  "text" : "@jacquesli that sounds like a terrible combination lol",
  "id" : 67399336442605568,
  "in_reply_to_status_id" : 67342334534234112,
  "created_at" : "Mon May 09 01:23:48 +0000 2011",
  "in_reply_to_screen_name" : "jacquesli",
  "in_reply_to_user_id_str" : "30700815",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67343215396786177",
  "geo" : {
  },
  "id_str" : "67399232130260992",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 nice!!",
  "id" : 67399232130260992,
  "in_reply_to_status_id" : 67343215396786177,
  "created_at" : "Mon May 09 01:23:23 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlia",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "67289644462641152",
  "text" : "good run this AM, noon mass, last d2 now, then ridin to the river w Dave and ppl before dinner! #mlia http://4sq.com/jX5zTX",
  "id" : 67289644462641152,
  "created_at" : "Sun May 08 18:07:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Dogfish Head Brewery",
      "screen_name" : "dogfishbeer",
      "indices" : [ 56, 68 ],
      "id_str" : "16721886",
      "id" : 16721886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67032806399815680",
  "geo" : {
  },
  "id_str" : "67033270948343808",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis celebrations are in order! breakin out the @dogfishbeer Olde School barleywine from Sam that I won in our competition",
  "id" : 67033270948343808,
  "in_reply_to_status_id" : 67032806399815680,
  "created_at" : "Sun May 08 01:09:11 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67031156897497088",
  "geo" : {
  },
  "id_str" : "67031648998408193",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 yup. how was your final? mine sucked..but whatever, i'm done :-P",
  "id" : 67031648998408193,
  "in_reply_to_status_id" : 67031156897497088,
  "created_at" : "Sun May 08 01:02:45 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67027304139853824",
  "text" : "Done!!!",
  "id" : 67027304139853824,
  "created_at" : "Sun May 08 00:45:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2303027604, -80.4244172573 ]
  },
  "id_str" : "66997422987018241",
  "text" : "Last final.... (@ Hancock Hall) http://4sq.com/ijA698",
  "id" : 66997422987018241,
  "created_at" : "Sat May 07 22:46:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2266550644, -80.4188597202 ]
  },
  "id_str" : "66991997101158400",
  "text" : "fantastic frank sandwhich and berry breeze smoothie w cheesecake 4 dessert to ease my woes from that last exam... http://4sq.com/l8LDkE",
  "id" : 66991997101158400,
  "created_at" : "Sat May 07 22:25:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2287394837, -80.4193210602 ]
  },
  "id_str" : "66983326220689408",
  "text" : "studying for C++ ughhh (@ Newman Library) http://4sq.com/kbbHfa",
  "id" : 66983326220689408,
  "created_at" : "Sat May 07 21:50:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "66982287270617088",
  "text" : "just got rocked hard by number theory...so much for studying more (@ McBryde Hall) http://4sq.com/iEjxSO",
  "id" : 66982287270617088,
  "created_at" : "Sat May 07 21:46:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66938734565793792",
  "text" : "been through all the HW, all the tests..here we go number theory!",
  "id" : 66938734565793792,
  "created_at" : "Sat May 07 18:53:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66882571568562178",
  "geo" : {
  },
  "id_str" : "66888623517208576",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet take exams for me?",
  "id" : 66888623517208576,
  "in_reply_to_status_id" : 66882571568562178,
  "created_at" : "Sat May 07 15:34:25 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66869291298996226",
  "text" : "What's fresh, pasture raised and over easy on rice? http://twitpic.com/4ul4fy Chris and I really thinking abt getting some chickens",
  "id" : 66869291298996226,
  "created_at" : "Sat May 07 14:17:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66860694351527936",
  "geo" : {
  },
  "id_str" : "66863720470560769",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson watch out more closely for the biro de italia in the fall",
  "id" : 66863720470560769,
  "in_reply_to_status_id" : 66860694351527936,
  "created_at" : "Sat May 07 13:55:27 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66848781727043584",
  "text" : "headed down to the farmers market",
  "id" : 66848781727043584,
  "created_at" : "Sat May 07 12:56:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 9, 21 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2233062045, -80.4220461845 ]
  },
  "id_str" : "66642830352850944",
  "text" : "Dinner w @runfasteraw (@ West End Market w/ 2 others) http://4sq.com/itRTun",
  "id" : 66642830352850944,
  "created_at" : "Fri May 06 23:17:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exhausted",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66625649237958656",
  "text" : "got in a couple hours of good studying with Jessey, now I'm #exhausted",
  "id" : 66625649237958656,
  "created_at" : "Fri May 06 22:09:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 32, 40 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66625423013969920",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy blasphemy! Must be no @moes_hq within 100 miles haha",
  "id" : 66625423013969920,
  "created_at" : "Fri May 06 22:08:33 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "66564582889627649",
  "text" : "last d2 lunch of the semester! (@ Dietrick Dining Center) http://4sq.com/j9MmXA",
  "id" : 66564582889627649,
  "created_at" : "Fri May 06 18:06:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.230039, -80.415711 ]
  },
  "id_str" : "66530876393136128",
  "text" : "returned my two books I rented, only two finals between me and summer! (@ Bookholders) http://4sq.com/k5aAG8",
  "id" : 66530876393136128,
  "created_at" : "Fri May 06 15:52:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66503535306612736",
  "geo" : {
  },
  "id_str" : "66524103548485632",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice sweet! I'm drivin up to Syr on Monday, is a detour to philly in order?",
  "id" : 66524103548485632,
  "in_reply_to_status_id" : 66503535306612736,
  "created_at" : "Fri May 06 15:25:56 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "66503528276951040",
  "text" : "adv calc final was tough... hopin for an b, which would maybe be an a- in the course? We'll see. (@ McBryde Hall) http://4sq.com/mOONcJ",
  "id" : 66503528276951040,
  "created_at" : "Fri May 06 14:04:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66215640825991168",
  "geo" : {
  },
  "id_str" : "66294496186466304",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo hey, you need help with math man? i'm a math major",
  "id" : 66294496186466304,
  "in_reply_to_status_id" : 66215640825991168,
  "created_at" : "Fri May 06 00:13:34 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "66262221470187520",
  "text" : "picnic was awesome, beautiful weather and friends. Dinner now, though I'm not really hungry hah http://4sq.com/kemMvU",
  "id" : 66262221470187520,
  "created_at" : "Thu May 05 22:05:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 11, 23 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66199321502154753",
  "text" : "goin to an @VTTriathlon picnic for a break, then back to the books!",
  "id" : 66199321502154753,
  "created_at" : "Thu May 05 17:55:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66199176127594497",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan http://blog.twitter.com/2011/05/your-momon-twitter.html",
  "id" : 66199176127594497,
  "created_at" : "Thu May 05 17:54:48 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "66189918078119936",
  "text" : "really hard exam, but I think I did okay. Bad news is dr adjerid says that i have to redo my masters plan of study... http://4sq.com/mESsHs",
  "id" : 66189918078119936,
  "created_at" : "Thu May 05 17:18:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66151843427926016",
  "text" : "woke up at 8am and i've been filling my brain with numerical analysis formulas for 3 hours... here we go for final #1",
  "id" : 66151843427926016,
  "created_at" : "Thu May 05 14:46:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "66020023503831040",
  "text" : "the tour lives on",
  "id" : 66020023503831040,
  "created_at" : "Thu May 05 06:02:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65886990616371200",
  "text" : "rent paid, gettin ready to disco",
  "id" : 65886990616371200,
  "created_at" : "Wed May 04 21:14:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 13, 20 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2266550644, -80.4188597202 ]
  },
  "id_str" : "65839430598000640",
  "text" : "free lunch w @rkay21's extra meal plan, chyeah (@ Owens Dining Center w/ 2 others) http://4sq.com/mOvCBJ",
  "id" : 65839430598000640,
  "created_at" : "Wed May 04 18:05:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "65837844480012288",
  "text" : "went home to grab a jacket...what's this cold stuff, and came in to give Shernita her awesome present! [pic]: http://4sq.com/l8yYvO",
  "id" : 65837844480012288,
  "created_at" : "Wed May 04 17:58:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 4, 17 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tourdefranzia",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65831221241974784",
  "text" : "via @williamenium the trike is fully operational w new brakes, cables and pads! #tourdefranzia",
  "id" : 65831221241974784,
  "created_at" : "Wed May 04 17:32:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "65797278782324736",
  "text" : "caught another hipster on a fixie w chrome bag and he wanted to race to class. I toasted him haha (@ McBryde Hall) http://4sq.com/mIjxVf",
  "id" : 65797278782324736,
  "created_at" : "Wed May 04 15:17:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2207517445, -80.4220998287 ]
  },
  "id_str" : "65611889123659777",
  "text" : "And last check-in spree, I almost got the flip turn down at swim practice today (@ McComas Hall) http://4sq.com/j1IwdY",
  "id" : 65611889123659777,
  "created_at" : "Wed May 04 03:01:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.228671143, -80.4246425629 ]
  },
  "id_str" : "65611549611524096",
  "text" : "but our last C++ class was worthless, although the class did support my suggestion of moving quiz deadlines http://4sq.com/jF4n4u",
  "id" : 65611549611524096,
  "created_at" : "Wed May 04 02:59:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "65611258031910912",
  "text" : "and our last @vbiatvt group meeting today was excellent (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/mPnCKy",
  "id" : 65611258031910912,
  "created_at" : "Wed May 04 02:58:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "65611051311435776",
  "text" : "it was anti-earth day today (dishwasher down = styofoam plates and cups) (@ Dietrick Dining Center) http://4sq.com/meltkV",
  "id" : 65611051311435776,
  "created_at" : "Wed May 04 02:57:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "65443304250163200",
  "text" : "last numerical analysis class...but I'm going to have to redo my project (@ McBryde Hall) http://4sq.com/mUsE6j",
  "id" : 65443304250163200,
  "created_at" : "Tue May 03 15:51:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304689, -80.4151305 ]
  },
  "id_str" : "65193715177750529",
  "text" : "put clips and road tires on my fixed gear, just went for a sayg ride on it, awesome. Burrito time http://4sq.com/iqef4N",
  "id" : 65193715177750529,
  "created_at" : "Mon May 02 23:19:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "65146018597056512",
  "text" : "I was the only one who came 2 the review session, awesome. Didnt have any specific q's so no review... shouldnt I get a bonus point @ least",
  "id" : 65146018597056512,
  "created_at" : "Mon May 02 20:09:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "65141902571356160",
  "text" : "numerical analysis review session",
  "id" : 65141902571356160,
  "created_at" : "Mon May 02 19:53:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "65070697919156225",
  "text" : "officially bought Dave's mountain bike from him this morning! In class now (@ McBryde Hall) http://4sq.com/juLZWL",
  "id" : 65070697919156225,
  "created_at" : "Mon May 02 15:10:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64881100236918784",
  "geo" : {
  },
  "id_str" : "65064450801143809",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 nice work! no mtb'ing today, its impossible to recover on a mtb lol. sayg at 6pm tho",
  "id" : 65064450801143809,
  "in_reply_to_status_id" : 64881100236918784,
  "created_at" : "Mon May 02 14:45:48 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 46, 60 ],
      "id_str" : "154139533",
      "id" : 154139533
    }, {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 118, 125 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "64743047157657600",
  "text" : "good 3hr ride in the rain w Edo, Mike, Tyler, @rickygargiulo. not sure what i'm training for... now its brewin time w @jbice0",
  "id" : 64743047157657600,
  "created_at" : "Sun May 01 17:28:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]