Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http://t.co/jHtFd4eC",
      "expanded_url" : "http://twitpic.com/brbtn2",
      "display_url" : "twitpic.com/brbtn2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93321768, -76.554408 ]
  },
  "id_str" : "285922163553357825",
  "text" : "art! http://t.co/jHtFd4eC",
  "id" : 285922163553357825,
  "created_at" : "Tue Jan 01 01:35:30 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 13, 20 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newyearscrafts",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/KXpguTt4",
      "expanded_url" : "http://twitpic.com/brbgpy",
      "display_url" : "twitpic.com/brbgpy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93315857, -76.55460592 ]
  },
  "id_str" : "285912439910961152",
  "text" : "we're crafty @sspis1 #newyearscrafts http://t.co/KXpguTt4",
  "id" : 285912439910961152,
  "created_at" : "Tue Jan 01 00:56:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/9KvTqdyX",
      "expanded_url" : "http://nyti.ms/S20ipD",
      "display_url" : "nyti.ms/S20ipD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "285851139323330562",
  "text" : "RT @nytimes: The changes that will occur if Congress takes no action: http://t.co/9KvTqdyX",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/9KvTqdyX",
        "expanded_url" : "http://nyti.ms/S20ipD",
        "display_url" : "nyti.ms/S20ipD"
      } ]
    },
    "geo" : {
    },
    "id_str" : "285837966868373504",
    "text" : "The changes that will occur if Congress takes no action: http://t.co/9KvTqdyX",
    "id" : 285837966868373504,
    "created_at" : "Mon Dec 31 20:00:56 +0000 2012",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2044921128/finals_normal.png",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 285851139323330562,
  "created_at" : "Mon Dec 31 20:53:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scot Nicol",
      "screen_name" : "chuck_i",
      "indices" : [ 3, 11 ],
      "id_str" : "17170198",
      "id" : 17170198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "intothemind",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/MFDOsTDC",
      "expanded_url" : "http://vimeo.com/54348266",
      "display_url" : "vimeo.com/54348266"
    } ]
  },
  "geo" : {
  },
  "id_str" : "285551616717901824",
  "text" : "RT @chuck_i: Mandatory full screen: http://t.co/MFDOsTDC #intothemind",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "intothemind",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http://t.co/MFDOsTDC",
        "expanded_url" : "http://vimeo.com/54348266",
        "display_url" : "vimeo.com/54348266"
      } ]
    },
    "geo" : {
    },
    "id_str" : "283970953136963585",
    "text" : "Mandatory full screen: http://t.co/MFDOsTDC #intothemind",
    "id" : 283970953136963585,
    "created_at" : "Wed Dec 26 16:22:05 +0000 2012",
    "user" : {
      "name" : "Scot Nicol",
      "screen_name" : "chuck_i",
      "protected" : false,
      "id_str" : "17170198",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1168161620/2AMtaqueria_normal.jpg",
      "id" : 17170198,
      "verified" : false
    }
  },
  "id" : 285551616717901824,
  "created_at" : "Mon Dec 31 01:03:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/iuuvgbtM",
      "expanded_url" : "http://uvm.edu/~areagan/IMG_7576.JPG",
      "display_url" : "uvm.edu/~areagan/IMG_7…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "285521293808381952",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin http://t.co/iuuvgbtM",
  "id" : 285521293808381952,
  "created_at" : "Sun Dec 30 23:02:35 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 79, 88 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 89, 96 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 97, 104 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Nathan Scharf",
      "screen_name" : "natescharf",
      "indices" : [ 105, 116 ],
      "id_str" : "64093685",
      "id" : 64093685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/28PC9uTH",
      "expanded_url" : "http://twitpic.com/bqvqer",
      "display_url" : "twitpic.com/bqvqer"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98051915, -76.3049921 ]
  },
  "id_str" : "285493366475616256",
  "text" : "the Marcellus Cowtippers Chocolate Milk Stout, first try! On tap for new years @DKnick88 @DZdan1 @sspis1 @natescharf http://t.co/28PC9uTH",
  "id" : 285493366475616256,
  "created_at" : "Sun Dec 30 21:11:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Christakis",
      "screen_name" : "NAChristakis",
      "indices" : [ 3, 16 ],
      "id_str" : "788363167",
      "id" : 788363167
    }, {
      "name" : "Mike Andrews",
      "screen_name" : "ma",
      "indices" : [ 133, 136 ],
      "id_str" : "47477101",
      "id" : 47477101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/wd7vA1lL",
      "expanded_url" : "http://twitpic.com/aw86qy",
      "display_url" : "twitpic.com/aw86qy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "285229004636692481",
  "text" : "RT @NAChristakis: Most distant image of Earth, taken by Voyager 1: http://t.co/wd7vA1lL  and still space is unfathomably vaster h/t: @ma ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus Chown",
        "screen_name" : "marcuschown",
        "indices" : [ 115, 127 ],
        "id_str" : "38205414",
        "id" : 38205414
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/wd7vA1lL",
        "expanded_url" : "http://twitpic.com/aw86qy",
        "display_url" : "twitpic.com/aw86qy"
      } ]
    },
    "geo" : {
    },
    "id_str" : "285225085525172224",
    "text" : "Most distant image of Earth, taken by Voyager 1: http://t.co/wd7vA1lL  and still space is unfathomably vaster h/t: @marcuschown",
    "id" : 285225085525172224,
    "created_at" : "Sun Dec 30 03:25:34 +0000 2012",
    "user" : {
      "name" : "Nicholas Christakis",
      "screen_name" : "NAChristakis",
      "protected" : false,
      "id_str" : "788363167",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2554415250/portrait2_normal.jpg",
      "id" : 788363167,
      "verified" : false
    }
  },
  "id" : 285229004636692481,
  "created_at" : "Sun Dec 30 03:41:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.10991122, -77.22896752 ]
  },
  "id_str" : "285213761982308353",
  "text" : "next level reading experiment: listen to audiobook and doodle (experiment underway with Nate Silver's Signal and the Noise)",
  "id" : 285213761982308353,
  "created_at" : "Sun Dec 30 02:40:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/sBrNrQb6",
      "expanded_url" : "http://twitpic.com/bqmmlk",
      "display_url" : "twitpic.com/bqmmlk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.10992313, -77.22902153 ]
  },
  "id_str" : "285213221923737600",
  "text" : "the Reagan family tree, in list form http://t.co/sBrNrQb6",
  "id" : 285213221923737600,
  "created_at" : "Sun Dec 30 02:38:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.11015846, -77.22904827 ]
  },
  "id_str" : "285170163039490048",
  "text" : "excellent run in the winter wonderland of Addison NY (running away from the family Christmas party?). snowy grip maximum speed at 8:15/mi",
  "id" : 285170163039490048,
  "created_at" : "Sat Dec 29 23:47:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/MDUJcU6q",
      "expanded_url" : "http://twitpic.com/bq9ieb",
      "display_url" : "twitpic.com/bq9ieb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799338, -76.3053954 ]
  },
  "id_str" : "284788687785586689",
  "text" : "unacceptable bearing seal seat. taking out those snap rings again is a pain,  but smooth spinning is worth it http://t.co/MDUJcU6q",
  "id" : 284788687785586689,
  "created_at" : "Fri Dec 28 22:31:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 31, 40 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/evwzX86I",
      "expanded_url" : "http://twitpic.com/bq8rnp",
      "display_url" : "twitpic.com/bq8rnp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.04954201, -76.22550063 ]
  },
  "id_str" : "284746924400205824",
  "text" : "a very unlikely shopping team, @dmreagan and I, did work at the mall. The new part of the mall is impressive: http://t.co/evwzX86I",
  "id" : 284746924400205824,
  "created_at" : "Fri Dec 28 19:45:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/wBfmcFxH",
      "expanded_url" : "http://andrewsullivan.thedailybeast.com/2012/12/the-bilingual-brain.html",
      "display_url" : "andrewsullivan.thedailybeast.com/2012/12/the-bi…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799339, -76.3053949 ]
  },
  "id_str" : "284519825848532992",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 all the more reason to learn a new language http://t.co/wBfmcFxH",
  "id" : 284519825848532992,
  "created_at" : "Fri Dec 28 04:43:07 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284393783628537856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98034125, -76.30525306 ]
  },
  "id_str" : "284517926646722561",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill I should get one...I just cant bring myself to commit to that much trainer time",
  "id" : 284517926646722561,
  "in_reply_to_status_id" : 284393783628537856,
  "created_at" : "Fri Dec 28 04:35:34 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98010634, -76.30510554 ]
  },
  "id_str" : "284479608097734656",
  "text" : "disregard previous concerns. I can now open more than 8 internet tabs",
  "id" : 284479608097734656,
  "created_at" : "Fri Dec 28 02:03:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98047086, -76.30535433 ]
  },
  "id_str" : "284476720675946497",
  "text" : "twitter: my galaxy s3 just rebooted and something strange happened. virus or update?",
  "id" : 284476720675946497,
  "created_at" : "Fri Dec 28 01:51:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 55, 64 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vermontcheese",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/oknPArpq",
      "expanded_url" : "http://twitpic.com/bpzedn",
      "display_url" : "twitpic.com/bpzedn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799354, -76.3053923 ]
  },
  "id_str" : "284454943740551168",
  "text" : "cabot hand select habanero cheddar mac and cheese from @dmreagan #vermontcheese http://t.co/oknPArpq",
  "id" : 284454943740551168,
  "created_at" : "Fri Dec 28 00:25:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 52, 63 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/LysHIVHs",
      "expanded_url" : "http://twitpic.com/bpz9ue",
      "display_url" : "twitpic.com/bpz9ue"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799329, -76.3053938 ]
  },
  "id_str" : "284450068499664898",
  "text" : "pops frying up some perogie, a new irish tradition? @withane271 http://t.co/LysHIVHs",
  "id" : 284450068499664898,
  "created_at" : "Fri Dec 28 00:05:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "precisionmachining",
      "indices" : [ 22, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/eqZ6ftgj",
      "expanded_url" : "http://twitpic.com/bpy5wb",
      "display_url" : "twitpic.com/bpy5wb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98035691, -76.30517664 ]
  },
  "id_str" : "284403445685956609",
  "text" : "Chris King driveshell #precisionmachining http://t.co/eqZ6ftgj",
  "id" : 284403445685956609,
  "created_at" : "Thu Dec 27 21:00:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284353207935848450",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799343, -76.3053945 ]
  },
  "id_str" : "284357519177035776",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 you got back in bed?",
  "id" : 284357519177035776,
  "in_reply_to_status_id" : 284353207935848450,
  "created_at" : "Thu Dec 27 17:58:10 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 0, 11 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98035813, -76.30525907 ]
  },
  "id_str" : "284355931163213824",
  "in_reply_to_user_id" : 606793907,
  "text" : "@withane271 Sam wanted me to let you know that her phone is out of batteries today",
  "id" : 284355931163213824,
  "created_at" : "Thu Dec 27 17:51:51 +0000 2012",
  "in_reply_to_screen_name" : "withane271",
  "in_reply_to_user_id_str" : "606793907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 45, 52 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 84, 100 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 105, 112 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/PgaJaqeh",
      "expanded_url" : "http://twitpic.com/bpwy9g",
      "display_url" : "twitpic.com/bpwy9g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98045489, -76.30523515 ]
  },
  "id_str" : "284354992536682497",
  "text" : "the UVM pint glass has been stolen back from @DZdan1 and returned to rightful owner @RumblinStumblin! cc @sspis1 http://t.co/PgaJaqeh",
  "id" : 284354992536682497,
  "created_at" : "Thu Dec 27 17:48:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 65, 76 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 77, 86 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blizzard",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "frontwheeldrive",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93315183, -76.55457293 ]
  },
  "id_str" : "284131552970022913",
  "text" : "driving through a snowstorm with just the plows out: successful! @skholden17 @DKnick88 #blizzard #frontwheeldrive",
  "id" : 284131552970022913,
  "created_at" : "Thu Dec 27 03:00:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98028845, -76.30521758 ]
  },
  "id_str" : "284073013262024704",
  "text" : "\"we can budget only so much time to each decision. nevertheless we are making many predictions every day\"",
  "id" : 284073013262024704,
  "created_at" : "Wed Dec 26 23:07:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98021405, -76.30506889 ]
  },
  "id_str" : "284067301010063361",
  "text" : "\"the story the data tells us is the one want to hear\"",
  "id" : 284067301010063361,
  "created_at" : "Wed Dec 26 22:44:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/UdynDhSo",
      "expanded_url" : "http://xkcd.com/627/",
      "display_url" : "xkcd.com/627/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "283787087252164608",
  "text" : "got a new electronic device for Christmas that you just can't figure out? I'm here to help: http://t.co/UdynDhSo",
  "id" : 283787087252164608,
  "created_at" : "Wed Dec 26 04:11:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 101, 110 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/h3z3Ig2S",
      "expanded_url" : "http://androidcowboy.com/2012/01/how-to-sideload-apps-on-kindle-fire/",
      "display_url" : "androidcowboy.com/2012/01/how-to…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "283740464585256962",
  "text" : "get a Kindle Fire HD for Christmas and want to install apps outside of Amazon app store? This works: @dmreagan http://t.co/h3z3Ig2S",
  "id" : 283740464585256962,
  "created_at" : "Wed Dec 26 01:06:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/otHb5APM",
      "expanded_url" : "http://lmgtfy.com/?q=online+cricket+darts+scoreboard&l=1",
      "display_url" : "lmgtfy.com/?q=online+cric…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "283731195408302080",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan http://t.co/otHb5APM",
  "id" : 283731195408302080,
  "created_at" : "Wed Dec 26 00:29:23 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 18, 25 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 29, 39 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodaysoff",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/Ol5M9ISd",
      "expanded_url" : "http://twitpic.com/bpdq8r",
      "display_url" : "twitpic.com/bpdq8r"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98041887, -76.30543792 ]
  },
  "id_str" : "283724301667008513",
  "text" : "\"typical reagan\" -@sspis1 cc @conneryVT #nodaysoff http://t.co/Ol5M9ISd",
  "id" : 283724301667008513,
  "created_at" : "Wed Dec 26 00:01:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "christmas",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "reaganchristmas",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/aVycRJOR",
      "expanded_url" : "http://instagr.am/p/TrHt7SuS4U/",
      "display_url" : "instagr.am/p/TrHt7SuS4U/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "283678249668718592",
  "text" : "salud! #christmas #reaganchristmas http://t.co/aVycRJOR",
  "id" : 283678249668718592,
  "created_at" : "Tue Dec 25 20:58:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 1, 12 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 61, 68 ],
      "id_str" : "31015715",
      "id" : 31015715
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 69, 76 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/BLh1EboO",
      "expanded_url" : "http://twitpic.com/bpbvnc",
      "display_url" : "twitpic.com/bpbvnc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98013564, -76.3052309 ]
  },
  "id_str" : "283657117842407424",
  "text" : ".@kreagannet with the official drink of Chile, a pisco sour! @Kaitia @sspis1 http://t.co/BLh1EboO",
  "id" : 283657117842407424,
  "created_at" : "Tue Dec 25 19:35:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283615402792206336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9799339, -76.3053944 ]
  },
  "id_str" : "283656723456208896",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill a trainer tire...it's like getting excited for a noose",
  "id" : 283656723456208896,
  "in_reply_to_status_id" : 283615402792206336,
  "created_at" : "Tue Dec 25 19:33:27 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/dJKvUZ6a",
      "expanded_url" : "http://twitpic.com/bpbv6v",
      "display_url" : "twitpic.com/bpbv6v"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98021263, -76.30524786 ]
  },
  "id_str" : "283656645228261377",
  "text" : "tool set is missing a piece #fail http://t.co/dJKvUZ6a",
  "id" : 283656645228261377,
  "created_at" : "Tue Dec 25 19:33:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 3, 12 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "283568859728973824",
  "text" : "RT @DKnick88: Merry Christmas!! Hope y'all have an awesome day",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "283442557323718656",
    "text" : "Merry Christmas!! Hope y'all have an awesome day",
    "id" : 283442557323718656,
    "created_at" : "Tue Dec 25 05:22:26 +0000 2012",
    "user" : {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "protected" : false,
      "id_str" : "204631321",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3194859210/2cfdf039ddb963cafa9970cf96a5b8d2_normal.jpeg",
      "id" : 204631321,
      "verified" : false
    }
  },
  "id" : 283568859728973824,
  "created_at" : "Tue Dec 25 13:44:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.86266657, -78.74718491 ]
  },
  "id_str" : "283384995064737793",
  "text" : "the \"logo board game\": test corporate america's penetration into your psyche",
  "id" : 283384995064737793,
  "created_at" : "Tue Dec 25 01:33:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.86243588, -78.74719292 ]
  },
  "id_str" : "283353681980710912",
  "text" : "mushroom soup: the polish kool aid",
  "id" : 283353681980710912,
  "created_at" : "Mon Dec 24 23:29:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "282959071626280962",
  "text" : "the first festivus tradition begins: \"I got a lot of problems with you people, and now you're going to hear about it!\"",
  "id" : 282959071626280962,
  "created_at" : "Sun Dec 23 21:21:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 49, 56 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 59, 70 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/F8y57b1Z",
      "expanded_url" : "http://yfrog.com/ob81373425j",
      "display_url" : "yfrog.com/ob81373425j"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8436459, -78.6764287 ]
  },
  "id_str" : "282566696865259520",
  "text" : "first hour dedicated to the deep fried cookie RT @sspis1: .@andyreagan on a ride througha winter wonderland http://t.co/F8y57b1Z",
  "id" : 282566696865259520,
  "created_at" : "Sat Dec 22 19:22:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotasty",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/gyqZOxWI",
      "expanded_url" : "http://twitpic.com/boa4wk",
      "display_url" : "twitpic.com/boa4wk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.84359173, -78.676352 ]
  },
  "id_str" : "282540464358436866",
  "text" : "it's a deep fried Christmas (cookie) this year #sotasty http://t.co/gyqZOxWI",
  "id" : 282540464358436866,
  "created_at" : "Sat Dec 22 17:37:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/WVPfP2j9",
      "expanded_url" : "http://twitpic.com/boa11l",
      "display_url" : "twitpic.com/boa11l"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8436432, -78.6764141 ]
  },
  "id_str" : "282536823165706240",
  "text" : "making my first perogie! http://t.co/WVPfP2j9",
  "id" : 282536823165706240,
  "created_at" : "Sat Dec 22 17:23:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pollocks",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/85yXFeBY",
      "expanded_url" : "http://twitpic.com/bo95u4",
      "display_url" : "twitpic.com/bo95u4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.84359751, -78.67614094 ]
  },
  "id_str" : "282512632785817602",
  "text" : ".@sspis1 on the floor of the Spisiak perogie factory #pollocks http://t.co/85yXFeBY",
  "id" : 282512632785817602,
  "created_at" : "Sat Dec 22 15:47:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 12, 19 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 63, 79 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282355295638913024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.84370181, -78.67643331 ]
  },
  "id_str" : "282379604398833664",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet @sspis1 apparently lol, but you can blame director @RumblinStumblin for the screenplay",
  "id" : 282379604398833664,
  "in_reply_to_status_id" : 282355295638913024,
  "created_at" : "Sat Dec 22 06:58:38 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "data",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/55P5DFzs",
      "expanded_url" : "http://www.bakadesuyo.com/2012/03/are-couples-that-commute-in-the-same-directio/",
      "display_url" : "bakadesuyo.com/2012/03/are-co…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "282336367109873664",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 you could answer this with #data http://t.co/55P5DFzs",
  "id" : 282336367109873664,
  "created_at" : "Sat Dec 22 04:06:50 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 15, 22 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/gzQO9mn5",
      "expanded_url" : "http://bit.ly/R9P5RX",
      "display_url" : "bit.ly/R9P5RX"
    } ]
  },
  "geo" : {
  },
  "id_str" : "282335563477032960",
  "text" : "check out what @sspis1 and I did in Chile!! http://t.co/gzQO9mn5",
  "id" : 282335563477032960,
  "created_at" : "Sat Dec 22 04:03:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281854075618873344",
  "text" : "RT @dr_pyser: @andyreagan fact. protip: you can use the leftover stem as a toothpick.",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "281840260806213632",
    "geo" : {
    },
    "id_str" : "281844085059366913",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan fact. protip: you can use the leftover stem as a toothpick.",
    "id" : 281844085059366913,
    "in_reply_to_status_id" : 281840260806213632,
    "created_at" : "Thu Dec 20 19:30:40 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 281854075618873344,
  "created_at" : "Thu Dec 20 20:10:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.02055942, -77.49292017 ]
  },
  "id_str" : "281840260806213632",
  "text" : "real men eat the whole apple",
  "id" : 281840260806213632,
  "created_at" : "Thu Dec 20 19:15:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 53, 62 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/Dh6aqtfE",
      "expanded_url" : "http://twitpic.com/bni1h3",
      "display_url" : "twitpic.com/bni1h3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98026717, -76.30522675 ]
  },
  "id_str" : "281604700799922176",
  "text" : "the Reagan cookie factory is a one (wo)man operation @dmreagan http://t.co/Dh6aqtfE",
  "id" : 281604700799922176,
  "created_at" : "Thu Dec 20 03:39:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 78, 87 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/mGI03NOF",
      "expanded_url" : "http://connect.garmin.com/activity/252948076",
      "display_url" : "connect.garmin.com/activity/25294…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281492784580542466",
  "text" : "taking advantage of any sunlight we can get in CNY in December, a run w madre @dmreagan on the Erie Canal http://t.co/mGI03NOF",
  "id" : 281492784580542466,
  "created_at" : "Wed Dec 19 20:14:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 14, 22 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "randomfacts",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/xI0Jyeo4",
      "expanded_url" : "http://nyti.ms/UEnRRh",
      "display_url" : "nyti.ms/UEnRRh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98006044, -76.3053464 ]
  },
  "id_str" : "281466723364917248",
  "text" : "#randomfacts \"@nytimes: Liquor stores outnumber bookstores by 3 to 1, and other facts from 2013's Statistical Abstract http://t.co/xI0Jyeo4\"",
  "id" : 281466723364917248,
  "created_at" : "Wed Dec 19 18:31:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 30, 37 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 42, 51 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reagangameroom",
      "indices" : [ 52, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/bUUahT4b",
      "expanded_url" : "http://twitpic.com/bn8lj8",
      "display_url" : "twitpic.com/bn8lj8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9800232, -76.3054396 ]
  },
  "id_str" : "281261620389355520",
  "text" : "fun night of darts w the boys @DZdan1 and @DKnick88 #reagangameroom http://t.co/bUUahT4b",
  "id" : 281261620389355520,
  "created_at" : "Wed Dec 19 04:56:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 29, 40 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 45, 54 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tenders",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.01588574, -76.28479338 ]
  },
  "id_str" : "281199284949491713",
  "text" : "RT @DZdan1 tullys bound with @andyreagan and @DKnick88 #tenders",
  "id" : 281199284949491713,
  "created_at" : "Wed Dec 19 00:48:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 73, 82 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9800222, -76.3054387 ]
  },
  "id_str" : "281096761395773440",
  "text" : "\"really good games are story making machines ...fantastic human dramas\" -@Radiolab on games",
  "id" : 281096761395773440,
  "created_at" : "Tue Dec 18 18:01:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Wolfers",
      "screen_name" : "justinwolfers",
      "indices" : [ 3, 17 ],
      "id_str" : "327577091",
      "id" : 327577091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/Nn1m6ZOd",
      "expanded_url" : "http://edge.org/conversation/win-at-forecasting",
      "display_url" : "edge.org/conversation/w…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281068820276338688",
  "text" : "RT @justinwolfers: How to Win at Forecasting.\nPhil Tetlock + Danny Kahneman = Insight-a-palooza. \nhttp://t.co/Nn1m6ZOd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/Nn1m6ZOd",
        "expanded_url" : "http://edge.org/conversation/win-at-forecasting",
        "display_url" : "edge.org/conversation/w…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281052696042168320",
    "text" : "How to Win at Forecasting.\nPhil Tetlock + Danny Kahneman = Insight-a-palooza. \nhttp://t.co/Nn1m6ZOd",
    "id" : 281052696042168320,
    "created_at" : "Tue Dec 18 15:05:59 +0000 2012",
    "user" : {
      "name" : "Justin Wolfers",
      "screen_name" : "justinwolfers",
      "protected" : false,
      "id_str" : "327577091",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1427549764/105629_MB3_1893_normal.jpg",
      "id" : 327577091,
      "verified" : false
    }
  },
  "id" : 281068820276338688,
  "created_at" : "Tue Dec 18 16:10:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 98, 107 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/m23IxY8R",
      "expanded_url" : "http://twitpic.com/bmxe8f",
      "display_url" : "twitpic.com/bmxe8f"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98008766, -76.3054694 ]
  },
  "id_str" : "280857571882057728",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 you're on ESPN, again! how could you not tell us about your poker career taking off?! @DKnick88 http://t.co/m23IxY8R",
  "id" : 280857571882057728,
  "created_at" : "Tue Dec 18 02:10:37 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 33, 47 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "precisionmanufacturing",
      "indices" : [ 48, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/qYRA6gQ1",
      "expanded_url" : "http://twitpic.com/bmvoq4",
      "display_url" : "twitpic.com/bmvoq4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9800244, -76.3054374 ]
  },
  "id_str" : "280782827690287104",
  "text" : "a close up of real fast bearings @ChrisKingBuzz #precisionmanufacturing http://t.co/qYRA6gQ1",
  "id" : 280782827690287104,
  "created_at" : "Mon Dec 17 21:13:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 77, 84 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/IVrnoLzQ",
      "expanded_url" : "http://bit.ly/ZaY0HB",
      "display_url" : "bit.ly/ZaY0HB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93313561, -76.55456842 ]
  },
  "id_str" : "280395454213140481",
  "text" : "with the final mustachananigans, I become Ron Burgundy: http://t.co/IVrnoLzQ @DZdan1 with the vocal accompaniment",
  "id" : 280395454213140481,
  "created_at" : "Sun Dec 16 19:34:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 50, 66 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 80, 87 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 119, 126 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93324469, -76.56317572 ]
  },
  "id_str" : "280098661151670272",
  "text" : "after probably the smoothest brew I've done, with @RumblinStumblin at the helm, @DZdan1 and I are headed to brockport! @sspis1 here we come",
  "id" : 280098661151670272,
  "created_at" : "Sat Dec 15 23:54:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 5, 21 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/UvGtB3Vg",
      "expanded_url" : "http://twitpic.com/bm8q3y",
      "display_url" : "twitpic.com/bm8q3y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280001034905075712",
  "text" : "pops @RumblinStumblin stirring up the mash! http://t.co/UvGtB3Vg",
  "id" : 280001034905075712,
  "created_at" : "Sat Dec 15 17:27:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "happyyeast",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/Wnhcfrxg",
      "expanded_url" : "http://twitpic.com/bm862r",
      "display_url" : "twitpic.com/bm862r"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279985296555245568",
  "text" : "the reagan brewery firing up! #science #happyyeast http://t.co/Wnhcfrxg",
  "id" : 279985296555245568,
  "created_at" : "Sat Dec 15 16:24:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "focus",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "sneaky",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.07433062, -76.05370662 ]
  },
  "id_str" : "279749557481512961",
  "text" : "missed my exit (by 3) on the thruway #focus, didnt have enough change for that exit so I turned around and went back #sneaky",
  "id" : 279749557481512961,
  "created_at" : "Sat Dec 15 00:47:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.35303332, -73.23877134 ]
  },
  "id_str" : "279683106540236801",
  "text" : "cya in a month #btv! I'm grateful to be able to spend Christmas at home still",
  "id" : 279683106540236801,
  "created_at" : "Fri Dec 14 20:23:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48219877, -73.20311513 ]
  },
  "id_str" : "279636939869650944",
  "text" : "finals complete, another great semester in Burlington! spinning for an hour before hitting the road",
  "id" : 279636939869650944,
  "created_at" : "Fri Dec 14 17:20:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "indices" : [ 0, 13 ],
      "id_str" : "19867945",
      "id" : 19867945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279388551903330304",
  "geo" : {
  },
  "id_str" : "279396049133633538",
  "in_reply_to_user_id" : 19867945,
  "text" : "@closethedoor that is fantastic!",
  "id" : 279396049133633538,
  "in_reply_to_status_id" : 279388551903330304,
  "created_at" : "Fri Dec 14 01:23:03 +0000 2012",
  "in_reply_to_screen_name" : "closethedoor",
  "in_reply_to_user_id_str" : "19867945",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 35, 51 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 82, 98 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279365567243235329",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet good work, and I think @RumblinStumblin meant to send this to you: RT @RumblinStumblin 7 down 1 to go!",
  "id" : 279365567243235329,
  "created_at" : "Thu Dec 13 23:21:56 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 25, 38 ],
      "id_str" : "14193991",
      "id" : 14193991
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 77, 84 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/e0dEXQfe",
      "expanded_url" : "http://www.youtube.com/watch?v=QyT2yqtuqS4",
      "display_url" : "youtube.com/watch?v=QyT2yq…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279043919583510529",
  "text" : "hey teacher's, check out @plaidavenger inspiring TEDxVT http://t.co/e0dEXQfe @DZdan1",
  "id" : 279043919583510529,
  "created_at" : "Thu Dec 13 02:03:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 73, 85 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/DNfDYz0l",
      "expanded_url" : "http://www.youtube.com/watch?v=3lqMRHwGsRA&feature=youtu.be",
      "display_url" : "youtube.com/watch?v=3lqMRH…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279038612295806976",
  "text" : "YES: why drones were built, to deliver burritos http://t.co/DNfDYz0l via @MechE_Hokie",
  "id" : 279038612295806976,
  "created_at" : "Thu Dec 13 01:42:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 0, 10 ],
      "id_str" : "74822774",
      "id" : 74822774
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 11, 21 ],
      "id_str" : "528928681",
      "id" : 528928681
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 22, 30 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278984441525841920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48207533, -73.20311542 ]
  },
  "id_str" : "278984612791861248",
  "in_reply_to_user_id" : 74822774,
  "text" : "@b_devaney @jcusick13 @Karo1yn twitter partyyyy",
  "id" : 278984612791861248,
  "in_reply_to_status_id" : 278984441525841920,
  "created_at" : "Wed Dec 12 22:08:09 +0000 2012",
  "in_reply_to_screen_name" : "b_devaney",
  "in_reply_to_user_id_str" : "74822774",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 0, 10 ],
      "id_str" : "74822774",
      "id" : 74822774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278964143392952321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48201216, -73.20304296 ]
  },
  "id_str" : "278983678162530307",
  "in_reply_to_user_id" : 74822774,
  "text" : "@b_devaney not at all, lets do it",
  "id" : 278983678162530307,
  "in_reply_to_status_id" : 278964143392952321,
  "created_at" : "Wed Dec 12 22:04:26 +0000 2012",
  "in_reply_to_screen_name" : "b_devaney",
  "in_reply_to_user_id_str" : "74822774",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/7XfqHepX",
      "expanded_url" : "http://twitpic.com/bldfp5",
      "display_url" : "twitpic.com/bldfp5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832302, -73.1935825 ]
  },
  "id_str" : "278898207050833920",
  "text" : "#storylab takes over http://t.co/7XfqHepX",
  "id" : 278898207050833920,
  "created_at" : "Wed Dec 12 16:24:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 63, 75 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdpoints",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "storylab",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/ifJFV2GE",
      "expanded_url" : "http://twitpic.com/bldfec",
      "display_url" : "twitpic.com/bldfec"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4833518, -73.19367158 ]
  },
  "id_str" : "278897933125042176",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash unicode for dodecahardon #nerdpoints #storylab @mrfrank5790 http://t.co/ifJFV2GE",
  "id" : 278897933125042176,
  "created_at" : "Wed Dec 12 16:23:43 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 23, 32 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278698045913309184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208716, -73.20329184 ]
  },
  "id_str" : "278704720481226752",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 kickerbocker? @DKnick88",
  "id" : 278704720481226752,
  "in_reply_to_status_id" : 278698045913309184,
  "created_at" : "Wed Dec 12 03:35:58 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821686, -73.2030397 ]
  },
  "id_str" : "278702590072590336",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee we used to do this called \"tray-lo\" which meant riding trainers and pwning 10 year olds in halo at the same time...you'd like this",
  "id" : 278702590072590336,
  "created_at" : "Wed Dec 12 03:27:30 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nextleveltraining",
      "indices" : [ 87, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482127, -73.2030765 ]
  },
  "id_str" : "278646940391047168",
  "text" : "read 40 pages, sent some emails, listened to jams, AND did my workout at the same time #nextleveltraining",
  "id" : 278646940391047168,
  "created_at" : "Tue Dec 11 23:46:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 0, 12 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278622127593250817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821562, -73.2030204 ]
  },
  "id_str" : "278628543360020480",
  "in_reply_to_user_id" : 276236513,
  "text" : "@bikingbiebs goldsprints?",
  "id" : 278628543360020480,
  "in_reply_to_status_id" : 278622127593250817,
  "created_at" : "Tue Dec 11 22:33:16 +0000 2012",
  "in_reply_to_screen_name" : "bikingbiebs",
  "in_reply_to_user_id_str" : "276236513",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 43, 53 ],
      "id_str" : "363086298",
      "id" : 363086298
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 54, 65 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "multitasking",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/PstjRom4",
      "expanded_url" : "http://twitpic.com/bl5nfq",
      "display_url" : "twitpic.com/bl5nfq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48223492, -73.20289459 ]
  },
  "id_str" : "278628385566126081",
  "text" : "the pain cave got an upgrade #multitasking @conneryVT @peterdodds http://t.co/PstjRom4",
  "id" : 278628385566126081,
  "created_at" : "Tue Dec 11 22:32:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen B. MacKenzie",
      "screen_name" : "mackenab",
      "indices" : [ 3, 12 ],
      "id_str" : "4889441",
      "id" : 4889441
    }, {
      "name" : "Rich Siegel",
      "screen_name" : "siegel",
      "indices" : [ 91, 98 ],
      "id_str" : "8021722",
      "id" : 8021722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/POzwW30Q",
      "expanded_url" : "http://jalopnik.com/5967574/an-incredibly-massive-explosion-has-set-the-highway-on-fire-in-west-virginia",
      "display_url" : "jalopnik.com/5967574/an-inc…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278616799719866369",
  "text" : "RT @mackenab: Crazy photos of the gas explosion along I-77 in WV. http://t.co/POzwW30Q Via @siegel",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich Siegel",
        "screen_name" : "siegel",
        "indices" : [ 77, 84 ],
        "id_str" : "8021722",
        "id" : 8021722
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/POzwW30Q",
        "expanded_url" : "http://jalopnik.com/5967574/an-incredibly-massive-explosion-has-set-the-highway-on-fire-in-west-virginia",
        "display_url" : "jalopnik.com/5967574/an-inc…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278613074892701696",
    "text" : "Crazy photos of the gas explosion along I-77 in WV. http://t.co/POzwW30Q Via @siegel",
    "id" : 278613074892701696,
    "created_at" : "Tue Dec 11 21:31:48 +0000 2012",
    "user" : {
      "name" : "Allen B. MacKenzie",
      "screen_name" : "mackenab",
      "protected" : false,
      "id_str" : "4889441",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/376674123/ProfileNewCrop_normal.jpg",
      "id" : 4889441,
      "verified" : false
    }
  },
  "id" : 278616799719866369,
  "created_at" : "Tue Dec 11 21:46:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278232781279084544",
  "geo" : {
  },
  "id_str" : "278250240929300480",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth so this means I'll have to to wait until tomorrow to hear back, good to know.",
  "id" : 278250240929300480,
  "in_reply_to_status_id" : 278232781279084544,
  "created_at" : "Mon Dec 10 21:30:01 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 9, 21 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/bj57siYO",
      "expanded_url" : "http://tmblr.co/ZlFOTvSOtFXL",
      "display_url" : "tmblr.co/ZlFOTvSOtFXL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48103767, -73.19915833 ]
  },
  "id_str" : "278187218902859777",
  "text" : "my life \"@mrfrank5790: JUST WHEN I THINK IM GETTING THE HANG OF SCIENCE | http://t.co/bj57siYO\"",
  "id" : 278187218902859777,
  "created_at" : "Mon Dec 10 17:19:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/2WJm1xma",
      "expanded_url" : "http://www.brooksrunning.com/Utopia-Thermal-Pant/210240001%2e020,default,pd.html?start=1&cgid=mens-apparel-tights-pants",
      "display_url" : "brooksrunning.com/Utopia-Thermal…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277892584888729600",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan add these to the list: http://t.co/2WJm1xma",
  "id" : 277892584888729600,
  "created_at" : "Sun Dec 09 21:48:49 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 33, 46 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 51, 66 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277649555405811712",
  "text" : "solid double yankee swap night w @UVMTriathlon and @BurlingtonHash",
  "id" : 277649555405811712,
  "created_at" : "Sun Dec 09 05:43:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277646383345975296",
  "geo" : {
  },
  "id_str" : "277646483166224384",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 get off twitter and answer my call! JK",
  "id" : 277646483166224384,
  "in_reply_to_status_id" : 277646383345975296,
  "created_at" : "Sun Dec 09 05:30:54 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 36, 43 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tendersontenders",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277280660429869056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48222953, -73.2033055 ]
  },
  "id_str" : "277296132546244609",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 yessir. #tendersontenders @DZdan1",
  "id" : 277296132546244609,
  "in_reply_to_status_id" : 277280660429869056,
  "created_at" : "Sat Dec 08 06:18:44 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277278653421846528",
  "geo" : {
  },
  "id_str" : "277278737161134080",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 Dec 14!",
  "id" : 277278737161134080,
  "in_reply_to_status_id" : 277278653421846528,
  "created_at" : "Sat Dec 08 05:09:37 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277276540658655232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48213197, -73.20310909 ]
  },
  "id_str" : "277278036410380288",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 if by dominated, you mean sandbagged",
  "id" : 277278036410380288,
  "in_reply_to_status_id" : 277276540658655232,
  "created_at" : "Sat Dec 08 05:06:50 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277276301897895937",
  "geo" : {
  },
  "id_str" : "277277749603872768",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud get itttt",
  "id" : 277277749603872768,
  "in_reply_to_status_id" : 277276301897895937,
  "created_at" : "Sat Dec 08 05:05:41 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277131572824657920",
  "geo" : {
  },
  "id_str" : "277132649112403968",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill well I'll be home for Christmas break, we're not too far away!",
  "id" : 277132649112403968,
  "in_reply_to_status_id" : 277131572824657920,
  "created_at" : "Fri Dec 07 19:29:07 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getonmylevel",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276885218969935874",
  "geo" : {
  },
  "id_str" : "276885423819726848",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill that's it?? #getonmylevel",
  "id" : 276885423819726848,
  "in_reply_to_status_id" : 276885218969935874,
  "created_at" : "Fri Dec 07 03:06:43 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276885289971089408",
  "text" : "why did I look at the Blacksburg forecast. 70 and sunny there this weekend! curiosity makes for a sad andy",
  "id" : 276885289971089408,
  "created_at" : "Fri Dec 07 03:06:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 0, 12 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/8rLPqoiz",
      "expanded_url" : "http://onehappybird.com/",
      "display_url" : "onehappybird.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276881853485576192",
  "in_reply_to_user_id" : 14109167,
  "text" : "@flowingdata speaking of visualizations, take a look at the structure of mathematics these guys made: http://t.co/8rLPqoiz",
  "id" : 276881853485576192,
  "created_at" : "Fri Dec 07 02:52:32 +0000 2012",
  "in_reply_to_screen_name" : "flowingdata",
  "in_reply_to_user_id_str" : "14109167",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/ItdWaEWr",
      "expanded_url" : "http://www.inquisitr.com/wp-content/2012/09/Grumpy-Cat-Tadar-Sauce.jpg",
      "display_url" : "inquisitr.com/wp-content/201…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276811990456991744",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn http://t.co/ItdWaEWr",
  "id" : 276811990456991744,
  "created_at" : "Thu Dec 06 22:14:56 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/4Cruq74a",
      "expanded_url" : "http://www.maratonbbva.cl/resultados42K_mcp2012.html",
      "display_url" : "maratonbbva.cl/resultados42K_…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276715156602486784",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/4Cruq74a",
  "id" : 276715156602486784,
  "created_at" : "Thu Dec 06 15:50:09 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 12, 20 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 25, 33 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yes",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "doingitright",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/A2MW9nBE",
      "expanded_url" : "http://connect.garmin.com/activity/249704592",
      "display_url" : "connect.garmin.com/activity/24970…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276710252886491136",
  "text" : "pumped that @Karo1yn and @pkemp33 got me out to run this morning! fitness by association #yes #doingitright http://t.co/A2MW9nBE",
  "id" : 276710252886491136,
  "created_at" : "Thu Dec 06 15:30:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yes",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48221754, -73.20293748 ]
  },
  "id_str" : "276550787927261184",
  "text" : "has stumbled onto the greatest beer ever. black + tan with Maple Street Nerdfire and Pomeroy Porter, my porter and very spicy maple IPA #yes",
  "id" : 276550787927261184,
  "created_at" : "Thu Dec 06 04:57:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 51, 61 ],
      "id_str" : "74822774",
      "id" : 74822774
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 63, 74 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hotstuff",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48204807, -73.20318119 ]
  },
  "id_str" : "276482985941946370",
  "text" : "or perhaps just a punch in the face?  #hotstuff RT @b_devaney: @andyreagan I'm seriously jonesing from an habanero IPA",
  "id" : 276482985941946370,
  "created_at" : "Thu Dec 06 00:27:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 0, 10 ],
      "id_str" : "74822774",
      "id" : 74822774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276481611229442048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48213942, -73.20322337 ]
  },
  "id_str" : "276482304883449856",
  "in_reply_to_user_id" : 74822774,
  "text" : "@b_devaney dude get over here!!",
  "id" : 276482304883449856,
  "in_reply_to_status_id" : 276481611229442048,
  "created_at" : "Thu Dec 06 00:24:52 +0000 2012",
  "in_reply_to_screen_name" : "b_devaney",
  "in_reply_to_user_id_str" : "74822774",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/KSUMlgEQ",
      "expanded_url" : "http://twitpic.com/bjeojf",
      "display_url" : "twitpic.com/bjeojf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276478605230497793",
  "text" : "dinner. I need to lend out bike tools for more often http://t.co/KSUMlgEQ",
  "id" : 276478605230497793,
  "created_at" : "Thu Dec 06 00:10:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samir Mezrahi",
      "screen_name" : "samir",
      "indices" : [ 3, 9 ],
      "id_str" : "115396965",
      "id" : 115396965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/rTqM6yJz",
      "expanded_url" : "http://bzfd.it/YOzXwM",
      "display_url" : "bzfd.it/YOzXwM"
    }, {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/VbOdRHxQ",
      "expanded_url" : "http://twitter.com/samir/status/276400684570664960/photo/1",
      "display_url" : "pic.twitter.com/VbOdRHxQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276470675827486720",
  "text" : "RT @samir: this whale shark pic from the 50 best animal photos of 2012 is ridic http://t.co/rTqM6yJz http://t.co/VbOdRHxQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/samir/status/276400684570664960/photo/1",
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/VbOdRHxQ",
        "media_url" : "http://pbs.twimg.com/media/A9X49UvCYAAbKs_.jpg",
        "id_str" : "276400684574859264",
        "id" : 276400684574859264,
        "media_url_https" : "https://pbs.twimg.com/media/A9X49UvCYAAbKs_.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/VbOdRHxQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http://t.co/rTqM6yJz",
        "expanded_url" : "http://bzfd.it/YOzXwM",
        "display_url" : "bzfd.it/YOzXwM"
      } ]
    },
    "geo" : {
    },
    "id_str" : "276400684570664960",
    "text" : "this whale shark pic from the 50 best animal photos of 2012 is ridic http://t.co/rTqM6yJz http://t.co/VbOdRHxQ",
    "id" : 276400684570664960,
    "created_at" : "Wed Dec 05 19:00:33 +0000 2012",
    "user" : {
      "name" : "Samir Mezrahi",
      "screen_name" : "samir",
      "protected" : false,
      "id_str" : "115396965",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3080861219/f750586690f11c65c36397023e67f116_normal.png",
      "id" : 115396965,
      "verified" : true
    }
  },
  "id" : 276470675827486720,
  "created_at" : "Wed Dec 05 23:38:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/276467730830471169/photo/1",
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/yDMWg9DY",
      "media_url" : "http://pbs.twimg.com/media/A9Y177hCMAEk37f.png",
      "id_str" : "276467730834665473",
      "id" : 276467730834665473,
      "media_url_https" : "https://pbs.twimg.com/media/A9Y177hCMAEk37f.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 68,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/yDMWg9DY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276467730830471169",
  "text" : "rise and fall of a blog post: (48h of hits per hour) http://t.co/yDMWg9DY",
  "id" : 276467730830471169,
  "created_at" : "Wed Dec 05 23:26:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276459914749161472",
  "text" : "hey #btv, i'm looking to use an inkjet printer. 10 pages, black and white. pretty please :)",
  "id" : 276459914749161472,
  "created_at" : "Wed Dec 05 22:55:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276398381960675328",
  "geo" : {
  },
  "id_str" : "276403880793878528",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn you know him!?!? LOL",
  "id" : 276403880793878528,
  "in_reply_to_status_id" : 276398381960675328,
  "created_at" : "Wed Dec 05 19:13:15 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276403760329277440",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan fuse was blown in the car. having oil changed, fuse changed, new battery and terminals done for 250",
  "id" : 276403760329277440,
  "created_at" : "Wed Dec 05 19:12:46 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 12, 26 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 56, 68 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/f6N4Xw32",
      "expanded_url" : "http://twitpic.com/bj3hi4",
      "display_url" : "twitpic.com/bj3hi4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48073264, -73.19568764 ]
  },
  "id_str" : "276063414118395904",
  "in_reply_to_user_id" : 16174144,
  "text" : "@peterdodds @ChrisDanforth more from the Farrell artist @SumaNMNDesu http://t.co/f6N4Xw32",
  "id" : 276063414118395904,
  "created_at" : "Tue Dec 04 20:40:21 +0000 2012",
  "in_reply_to_screen_name" : "peterdodds",
  "in_reply_to_user_id_str" : "16174144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo",
      "screen_name" : "bollive",
      "indices" : [ 0, 8 ],
      "id_str" : "607367268",
      "id" : 607367268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275979155705835520",
  "in_reply_to_user_id" : 607367268,
  "text" : "@bollive happy birthday!!",
  "id" : 275979155705835520,
  "created_at" : "Tue Dec 04 15:05:32 +0000 2012",
  "in_reply_to_screen_name" : "bollive",
  "in_reply_to_user_id_str" : "607367268",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 0, 8 ],
      "id_str" : "300735398",
      "id" : 300735398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275958478114283520",
  "in_reply_to_user_id" : 300735398,
  "text" : "@aatishb thanks for the mention :)",
  "id" : 275958478114283520,
  "created_at" : "Tue Dec 04 13:43:22 +0000 2012",
  "in_reply_to_screen_name" : "aatishb",
  "in_reply_to_user_id_str" : "300735398",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "reddit",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275953457645641729",
  "text" : "RT @dr_pyser: @andyreagan's post on the most important theorem in math hits no. 1 on /r/math! congrats! #storylab #reddit http://t.co/Vx ...",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storylab",
        "indices" : [ 90, 99 ]
      }, {
        "text" : "reddit",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/VxfEmqv7",
        "expanded_url" : "http://bit.ly/TzDOXY",
        "display_url" : "bit.ly/TzDOXY"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275947762426728449",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan's post on the most important theorem in math hits no. 1 on /r/math! congrats! #storylab #reddit http://t.co/VxfEmqv7",
    "id" : 275947762426728449,
    "created_at" : "Tue Dec 04 13:00:48 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 275953457645641729,
  "created_at" : "Tue Dec 04 13:23:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Luis Mateos",
      "screen_name" : "jlmateos",
      "indices" : [ 0, 9 ],
      "id_str" : "24669093",
      "id" : 24669093
    }, {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 10, 25 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275819333928771584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208831, -73.20310292 ]
  },
  "id_str" : "275838326760681472",
  "in_reply_to_user_id" : 24669093,
  "text" : "@jlmateos @stevenstrogatz good luck! feel free to shoot me questions. I'd start w a csv of the edges, download gephi, and go",
  "id" : 275838326760681472,
  "in_reply_to_status_id" : 275819333928771584,
  "created_at" : "Tue Dec 04 05:45:56 +0000 2012",
  "in_reply_to_screen_name" : "jlmateos",
  "in_reply_to_user_id_str" : "24669093",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vi Hart",
      "screen_name" : "vihartvihart",
      "indices" : [ 0, 13 ],
      "id_str" : "277071665",
      "id" : 277071665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/YW5CvZHC",
      "expanded_url" : "http://bit.ly/VgumbF",
      "display_url" : "bit.ly/VgumbF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275819404653125633",
  "in_reply_to_user_id" : 277071665,
  "text" : "@vihartvihart what do think is the most important theorem in math? i tried to answer this with network, you might like: http://t.co/YW5CvZHC",
  "id" : 275819404653125633,
  "created_at" : "Tue Dec 04 04:30:45 +0000 2012",
  "in_reply_to_screen_name" : "vihartvihart",
  "in_reply_to_user_id_str" : "277071665",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/UGdVlsCi",
      "expanded_url" : "http://proofwiki.org",
      "display_url" : "proofwiki.org"
    } ]
  },
  "in_reply_to_status_id_str" : "275810438418157568",
  "geo" : {
  },
  "id_str" : "275811696688377856",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr that would be cool to do. try it! lol. next i'm going to try doing the proof wiki (http://t.co/UGdVlsCi), gotta go data driven",
  "id" : 275811696688377856,
  "in_reply_to_status_id" : 275810438418157568,
  "created_at" : "Tue Dec 04 04:00:07 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 0, 15 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/Y68KSlty",
      "expanded_url" : "http://www.proofwiki.org/wiki/Main_Page",
      "display_url" : "proofwiki.org/wiki/Main_Page"
    } ]
  },
  "in_reply_to_status_id_str" : "275790443969646593",
  "geo" : {
  },
  "id_str" : "275793695360573440",
  "in_reply_to_user_id" : 579299426,
  "text" : "@stevenstrogatz I'm glad you like it! thx for the mention. shooting for the http://t.co/Y68KSlty next, any suggestions?",
  "id" : 275793695360573440,
  "in_reply_to_status_id" : 275790443969646593,
  "created_at" : "Tue Dec 04 02:48:35 +0000 2012",
  "in_reply_to_screen_name" : "stevenstrogatz",
  "in_reply_to_user_id_str" : "579299426",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 65, 76 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/RDA92aVQ",
      "expanded_url" : "http://goo.gl/tZspH",
      "display_url" : "goo.gl/tZspH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275792967082586112",
  "text" : "RT @stevenstrogatz: What's the central theorem in real analysis? @andyreagan used network theory on Rudin to find out http://t.co/RDA92aVQ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 45, 56 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/RDA92aVQ",
        "expanded_url" : "http://goo.gl/tZspH",
        "display_url" : "goo.gl/tZspH"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275792261185417216",
    "text" : "What's the central theorem in real analysis? @andyreagan used network theory on Rudin to find out http://t.co/RDA92aVQ",
    "id" : 275792261185417216,
    "created_at" : "Tue Dec 04 02:42:53 +0000 2012",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 275792967082586112,
  "created_at" : "Tue Dec 04 02:45:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sogood",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "brownrice",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "unclebenwherehaveyoubeenallmylife",
      "indices" : [ 66, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/0FWX8j65",
      "expanded_url" : "http://twitpic.com/bivnbt",
      "display_url" : "twitpic.com/bivnbt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48216509, -73.2031254 ]
  },
  "id_str" : "275789052236681216",
  "text" : "went brown and I'm definitely never going back #sogood #brownrice #unclebenwherehaveyoubeenallmylife http://t.co/0FWX8j65",
  "id" : 275789052236681216,
  "created_at" : "Tue Dec 04 02:30:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275746370206453762",
  "geo" : {
  },
  "id_str" : "275749768490254338",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn best roommie ever!! :)",
  "id" : 275749768490254338,
  "in_reply_to_status_id" : 275746370206453762,
  "created_at" : "Mon Dec 03 23:54:02 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 8, 15 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275702110220328960",
  "geo" : {
  },
  "id_str" : "275705919478841344",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill @sspis1 oh would you now?",
  "id" : 275705919478841344,
  "in_reply_to_status_id" : 275702110220328960,
  "created_at" : "Mon Dec 03 20:59:48 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poorlegs",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275701354213826560",
  "text" : "need some exercise? try pushing a car 200m up a slight incline. my pace went from running, to fast walking, to crawling. #poorlegs",
  "id" : 275701354213826560,
  "created_at" : "Mon Dec 03 20:41:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 107, 118 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275701034024841216",
  "text" : "RT @ChrisDanforth: Overheard on the second floor of Farrell Hall: \"so what is the most important theorem?\" @andyreagan has the answer: h ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 88, 99 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/a0FWreV1",
        "expanded_url" : "http://onehappybird.com/2012/12/03/whats-the-most-important-theorem/",
        "display_url" : "onehappybird.com/2012/12/03/wha…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275678050371371008",
    "text" : "Overheard on the second floor of Farrell Hall: \"so what is the most important theorem?\" @andyreagan has the answer: http://t.co/a0FWreV1",
    "id" : 275678050371371008,
    "created_at" : "Mon Dec 03 19:09:03 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 275701034024841216,
  "created_at" : "Mon Dec 03 20:40:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Celis",
      "screen_name" : "shanecelis",
      "indices" : [ 3, 14 ],
      "id_str" : "25248496",
      "id" : 25248496
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 65, 76 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/zguIOufY",
      "expanded_url" : "http://bit.ly/VgumbF",
      "display_url" : "bit.ly/VgumbF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275701020582105088",
  "text" : "RT @shanecelis: Really cool. A network of axioms and theorems by @andyreagan http://t.co/zguIOufY",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 49, 60 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/zguIOufY",
        "expanded_url" : "http://bit.ly/VgumbF",
        "display_url" : "bit.ly/VgumbF"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275662038351622144",
    "text" : "Really cool. A network of axioms and theorems by @andyreagan http://t.co/zguIOufY",
    "id" : 275662038351622144,
    "created_at" : "Mon Dec 03 18:05:26 +0000 2012",
    "user" : {
      "name" : "Shane Celis",
      "screen_name" : "shanecelis",
      "protected" : false,
      "id_str" : "25248496",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2230873627/my-photo_copy_normal.jpeg",
      "id" : 25248496,
      "verified" : false
    }
  },
  "id" : 275701020582105088,
  "created_at" : "Mon Dec 03 20:40:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 20, 31 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "storylab",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "math",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275700862905630720",
  "text" : "RT @dr_pyser: guys, @andyreagan produced another #win for #storylab, blogging about networks of theorems in #math. check it out! http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 6, 17 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 35, 39 ]
      }, {
        "text" : "storylab",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "math",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/UyTAWSCk",
        "expanded_url" : "http://bit.ly/QCyyFT",
        "display_url" : "bit.ly/QCyyFT"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275697989593485312",
    "text" : "guys, @andyreagan produced another #win for #storylab, blogging about networks of theorems in #math. check it out! http://t.co/UyTAWSCk",
    "id" : 275697989593485312,
    "created_at" : "Mon Dec 03 20:28:17 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 275700862905630720,
  "created_at" : "Mon Dec 03 20:39:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48217585, -73.20400939 ]
  },
  "id_str" : "275697591658872835",
  "text" : "tried to push car, wouldn't budge. (sitting for a month) 10 munchkins walking home from school help, and it's movin! many hands = light work",
  "id" : 275697591658872835,
  "created_at" : "Mon Dec 03 20:26:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 0, 15 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/YW5CvZHC",
      "expanded_url" : "http://bit.ly/VgumbF",
      "display_url" : "bit.ly/VgumbF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275660568256458752",
  "in_reply_to_user_id" : 579299426,
  "text" : "@stevenstrogatz I've organized the theorems in analysis into a network, I think you'd enjoy this: http://t.co/YW5CvZHC",
  "id" : 275660568256458752,
  "created_at" : "Mon Dec 03 17:59:35 +0000 2012",
  "in_reply_to_screen_name" : "stevenstrogatz",
  "in_reply_to_user_id_str" : "579299426",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 8, 15 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 16, 27 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 29, 45 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 46, 55 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 56, 65 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 66, 81 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/YW5CvZHC",
      "expanded_url" : "http://bit.ly/VgumbF",
      "display_url" : "bit.ly/VgumbF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275659924577603584",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @DZdan1 @skholden17  @RumblinStumblin @dmreagan @DKnick88 @ryandelgiudice this is what I do: http://t.co/YW5CvZHC",
  "id" : 275659924577603584,
  "created_at" : "Mon Dec 03 17:57:02 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/YW5CvZHC",
      "expanded_url" : "http://bit.ly/VgumbF",
      "display_url" : "bit.ly/VgumbF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275643169369120768",
  "text" : "searching for the most important theorem, and a look at the true structure of math!! http://t.co/YW5CvZHC #storylab",
  "id" : 275643169369120768,
  "created_at" : "Mon Dec 03 16:50:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/HfmihxQO",
      "expanded_url" : "http://www.youtube.com/watch?v=PXchNeYUmPA&feature=g-all",
      "display_url" : "youtube.com/watch?v=PXchNe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275624075047628801",
  "text" : "RT @mrfrank5790: @andyreagan http://t.co/HfmihxQO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http://t.co/HfmihxQO",
        "expanded_url" : "http://www.youtube.com/watch?v=PXchNeYUmPA&feature=g-all",
        "display_url" : "youtube.com/watch?v=PXchNe…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "275621619920154624",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan http://t.co/HfmihxQO",
    "id" : 275621619920154624,
    "created_at" : "Mon Dec 03 15:24:49 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 275624075047628801,
  "created_at" : "Mon Dec 03 15:34:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excellent",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/J8yE0l4g",
      "expanded_url" : "http://www.youtube.com/watch?v=qybUFnY7Y8w",
      "display_url" : "youtube.com/watch?v=qybUFn…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275315101496668160",
  "text" : "Rube Goldberg would be very proud http://t.co/J8yE0l4g #excellent",
  "id" : 275315101496668160,
  "created_at" : "Sun Dec 02 19:06:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 19, 26 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badass",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "1continentdown",
      "indices" : [ 87, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/FkZywFxR",
      "expanded_url" : "http://app.strava.com/activities/30608641",
      "display_url" : "app.strava.com/activities/306…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275305419612778497",
  "text" : "congratulations to @sspis1 for finishing her first marathon this AM in Chile!! #badass #1continentdown http://t.co/FkZywFxR",
  "id" : 275305419612778497,
  "created_at" : "Sun Dec 02 18:28:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275256609687629824",
  "text" : ".@sspis1 should be finishing a marathon in Chile anytime now!! Go Sam go!",
  "id" : 275256609687629824,
  "created_at" : "Sun Dec 02 15:14:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RSVP",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275256509762527232",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash count me in for Hashtivus #RSVP",
  "id" : 275256509762527232,
  "created_at" : "Sun Dec 02 15:14:00 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 22, 29 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4amwakeup",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "marathontime",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/Kb8qezLg",
      "expanded_url" : "http://yfrog.com/ny70041201j",
      "display_url" : "yfrog.com/ny70041201j"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821193, -73.2030239 ]
  },
  "id_str" : "275095784310059009",
  "text" : "she's gonna do great \"@sspis1: http://t.co/Kb8qezLg all ready to go #4amwakeup #marathontime\"",
  "id" : 275095784310059009,
  "created_at" : "Sun Dec 02 04:35:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisa McGowan",
      "screen_name" : "AMCG913",
      "indices" : [ 0, 8 ],
      "id_str" : "351965147",
      "id" : 351965147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/nOjql6bB",
      "expanded_url" : "http://twitpic.com/biauma",
      "display_url" : "twitpic.com/biauma"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46680357, -73.19884471 ]
  },
  "id_str" : "275087850133942272",
  "in_reply_to_user_id" : 351965147,
  "text" : "@AMCG913 http://t.co/nOjql6bB",
  "id" : 275087850133942272,
  "created_at" : "Sun Dec 02 04:03:49 +0000 2012",
  "in_reply_to_screen_name" : "AMCG913",
  "in_reply_to_user_id_str" : "351965147",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 8, 23 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 24, 33 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 34, 41 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 42, 53 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/275013351485087744/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/jQco2Fpg",
      "media_url" : "http://pbs.twimg.com/media/A9ELL6UCIAAx0kI.png",
      "id_str" : "275013351506059264",
      "id" : 275013351506059264,
      "media_url_https" : "https://pbs.twimg.com/media/A9ELL6UCIAAx0kI.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/jQco2Fpg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275013351485087744",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @ryandelgiudice @DKnick88 @DZdan1 @skholden17 let's do it guys. http://t.co/jQco2Fpg",
  "id" : 275013351485087744,
  "created_at" : "Sat Dec 01 23:07:47 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/Cywva4yy",
      "expanded_url" : "http://andyreagan.wordpress.com/wp-admin/post.php?post=2953&action=edit&message=1",
      "display_url" : "andyreagan.wordpress.com/wp-admin/post.…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275004661088542721",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/Cywva4yy",
  "id" : 275004661088542721,
  "created_at" : "Sat Dec 01 22:33:15 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]