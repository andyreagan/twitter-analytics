Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219146174572134400",
  "text" : "RT @sspis1: Great ride through old forge today! Great riding yet again",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "219140847663464449",
    "text" : "Great ride through old forge today! Great riding yet again",
    "id" : 219140847663464449,
    "created_at" : "Sat Jun 30 18:50:24 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 219146174572134400,
  "created_at" : "Sat Jun 30 19:11:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 0, 11 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218808873149136896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7835927667, -74.2719771167 ]
  },
  "id_str" : "218815185144647680",
  "in_reply_to_user_id" : 606793907,
  "text" : "@withane271 and we did both! check out the picture I just sent before this tweet :)",
  "id" : 218815185144647680,
  "in_reply_to_status_id" : 218808873149136896,
  "created_at" : "Fri Jun 29 21:16:20 +0000 2012",
  "in_reply_to_screen_name" : "withane271",
  "in_reply_to_user_id_str" : "606793907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 119, 128 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7833615, -74.2720706 ]
  },
  "id_str" : "218814829383782400",
  "text" : "and again no cell service in Indian Lake, currently stealing wireless outside the library :P @RumblinStumblin@dmreagan @dmreagan",
  "id" : 218814829383782400,
  "created_at" : "Fri Jun 29 21:14:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/218814439040876544/photo/1",
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/CfZSB4cZ",
      "media_url" : "http://pbs.twimg.com/media/Awlikq9CAAErxM8.jpg",
      "id_str" : "218814439049265153",
      "id" : 218814439049265153,
      "media_url_https" : "https://pbs.twimg.com/media/Awlikq9CAAErxM8.jpg",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1952,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/CfZSB4cZ"
    } ],
    "hashtags" : [ {
      "text" : "pictureperfect",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7833632, -74.2720697 ]
  },
  "id_str" : "218814439040876544",
  "text" : "chillin in the shade on some rocks with our feet in the Hudson #pictureperfect http://t.co/CfZSB4cZ",
  "id" : 218814439040876544,
  "created_at" : "Fri Jun 29 21:13:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 46, 57 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218811420291235841",
  "text" : "RT @sspis1: Just rolled into Indian Lake with @andyreagan after a 58 mile ride into the wind. Lots of hills gorgeous views and great adv ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 34, 45 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hungry",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "218811273033433088",
    "text" : "Just rolled into Indian Lake with @andyreagan after a 58 mile ride into the wind. Lots of hills gorgeous views and great adventures #hungry",
    "id" : 218811273033433088,
    "created_at" : "Fri Jun 29 21:00:47 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 218811420291235841,
  "created_at" : "Fri Jun 29 21:01:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 81, 88 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218750685016100864",
  "text" : "with a suprise 2mi climb to start, a beautiful day in the ADK's! At lunch stop w @sspis1",
  "id" : 218750685016100864,
  "created_at" : "Fri Jun 29 17:00:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6951075, -73.5063994 ]
  },
  "id_str" : "218688796009578497",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan no cell service, camping tonight in Indian Lake. On the wireless here. Tell Carl I'd like to meet in Boonville",
  "id" : 218688796009578497,
  "created_at" : "Fri Jun 29 12:54:06 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MichelinBikeUSA",
      "screen_name" : "MichelinBikeUSA",
      "indices" : [ 0, 16 ],
      "id_str" : "515857528",
      "id" : 515857528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218382036359061504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6951544, -73.5064626 ]
  },
  "id_str" : "218688604426346496",
  "in_reply_to_user_id" : 515857528,
  "text" : "@MichelinBikeUSA that would be awesome! Can I take is my LBS, Skirack of Burlington VT?",
  "id" : 218688604426346496,
  "in_reply_to_status_id" : 218382036359061504,
  "created_at" : "Fri Jun 29 12:53:20 +0000 2012",
  "in_reply_to_screen_name" : "MichelinBikeUSA",
  "in_reply_to_user_id_str" : "515857528",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218688420006985728",
  "text" : "sad to leave the resort on Lake George, headed to Indian Lake tonight! Excited to camp tonight. Reception spotty in ADK's though",
  "id" : 218688420006985728,
  "created_at" : "Fri Jun 29 12:52:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218479843925442562",
  "text" : "ferried into NY and staying at a RESORT! Recovery class, dinner, then sailing on lake george!",
  "id" : 218479843925442562,
  "created_at" : "Thu Jun 28 23:03:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/218398061104345088/photo/1",
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/rfhLj4y3",
      "media_url" : "http://pbs.twimg.com/media/Awfn4SQCMAAIsml.jpg",
      "id_str" : "218398061108539392",
      "id" : 218398061108539392,
      "media_url_https" : "https://pbs.twimg.com/media/Awfn4SQCMAAIsml.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/rfhLj4y3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.8557761, -73.3762794 ]
  },
  "id_str" : "218398061104345088",
  "text" : "taking the ferry to NYS! http://t.co/rfhLj4y3",
  "id" : 218398061104345088,
  "created_at" : "Thu Jun 28 17:38:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/218342117183983616/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/ChPJpHyn",
      "media_url" : "http://pbs.twimg.com/media/Awe0_66CEAI7Xp9.jpg",
      "id_str" : "218342117188177922",
      "id" : 218342117188177922,
      "media_url_https" : "https://pbs.twimg.com/media/Awe0_66CEAI7Xp9.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ChPJpHyn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.84459605, -72.9641841833 ]
  },
  "id_str" : "218342117183983616",
  "text" : "from Great Cliffs, a great hike from the top of Brandon Gap http://t.co/ChPJpHyn",
  "id" : 218342117183983616,
  "created_at" : "Thu Jun 28 13:56:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 24, 34 ],
      "id_str" : "19693586",
      "id" : 19693586
    }, {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 107, 118 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "218132342307422208",
  "text" : ".@sspis1 and I are with @bikebuild in Rochester, VT!! Awesome ride despite the sideways pouring cold rain! @withane271",
  "id" : 218132342307422208,
  "created_at" : "Thu Jun 28 00:02:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freezing",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.182986, -72.8296289 ]
  },
  "id_str" : "218077109053169666",
  "text" : "over Appalachain Gap in 40mph wind and ice cold rain #freezing. hot chocolate and. nachoes on the other side yesss",
  "id" : 218077109053169666,
  "created_at" : "Wed Jun 27 20:23:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/218022293782278144/photo/1",
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/WPxFEfT9",
      "media_url" : "http://pbs.twimg.com/media/AwaSHv5CMAAWPdy.jpg",
      "id_str" : "218022293786472448",
      "id" : 218022293786472448,
      "media_url_https" : "https://pbs.twimg.com/media/AwaSHv5CMAAWPdy.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/WPxFEfT9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.32865075, -73.1102741833 ]
  },
  "id_str" : "218022293782278144",
  "text" : "from Hinesburg, VT http://t.co/WPxFEfT9",
  "id" : 218022293782278144,
  "created_at" : "Wed Jun 27 16:45:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burlington2buffalo",
      "indices" : [ 15, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4758099, -73.2154200333 ]
  },
  "id_str" : "217998813883924480",
  "text" : "and we're off! #burlington2buffalo",
  "id" : 217998813883924480,
  "created_at" : "Wed Jun 27 15:12:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 18, 25 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 70, 79 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 80, 96 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 97, 108 ],
      "id_str" : "606793907",
      "id" : 606793907
    }, {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 109, 118 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/HdRIghFs",
      "expanded_url" : "http://bit.ly/KDqFs8",
      "display_url" : "bit.ly/KDqFs8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217985910959120385",
  "text" : "a complete map of @sspis1 and my trip this week: http://t.co/HdRIghFs @dmreagan @RumblinStumblin @withane271 @RBSherfy",
  "id" : 217985910959120385,
  "created_at" : "Wed Jun 27 14:21:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 82, 89 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/217964494771597312/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/FVZnsa7b",
      "media_url" : "http://pbs.twimg.com/media/AwZdjZ0CMAAlMZc.jpg",
      "id_str" : "217964494779985920",
      "id" : 217964494779985920,
      "media_url_https" : "https://pbs.twimg.com/media/AwZdjZ0CMAAlMZc.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/FVZnsa7b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820171167, -73.2031090333 ]
  },
  "id_str" : "217964494771597312",
  "text" : "vegan peanut butter banana pancakes for fuel! (w VT maple syrup, obvvv) Good work @sspis1 http://t.co/FVZnsa7b",
  "id" : 217964494771597312,
  "created_at" : "Wed Jun 27 12:56:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 1, 10 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 94, 104 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217962886469914625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820051333, -73.2031065833 ]
  },
  "id_str" : "217964174901387264",
  "in_reply_to_user_id" : 64328794,
  "text" : ".@RBSherfy road biking 60-70 miles per day to a DMB concert in Buffalo on July 3, mostly with @bikebuild's NUS route! Camping if need be yup",
  "id" : 217964174901387264,
  "in_reply_to_status_id" : 217962886469914625,
  "created_at" : "Wed Jun 27 12:54:43 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbad",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819936333, -73.20292715 ]
  },
  "id_str" : "217955064390754306",
  "text" : "pack weight 15.6 pounds...including a pound each of gummies, nuts, and granola #notbad",
  "id" : 217955064390754306,
  "created_at" : "Wed Jun 27 12:18:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/217822772326440964/photo/1",
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/0I6ZQyb1",
      "media_url" : "http://pbs.twimg.com/media/AwXcqEkCIAAhVUK.jpg",
      "id_str" : "217822772334829568",
      "id" : 217822772334829568,
      "media_url_https" : "https://pbs.twimg.com/media/AwXcqEkCIAAhVUK.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/0I6ZQyb1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820868333, -73.20310355 ]
  },
  "id_str" : "217822772326440964",
  "text" : "packed for a 1.5 week bike trip to Buffalo, NY tomorrow morning (450ish miles from Burlington!) http://t.co/0I6ZQyb1",
  "id" : 217822772326440964,
  "created_at" : "Wed Jun 27 03:32:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 13, 20 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikeskillz",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/YJdL3BAH",
      "expanded_url" : "http://www.youtube.com/watch?v=Z19zFlPah-o",
      "display_url" : "youtube.com/watch?v=Z19zFl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217639390313316352",
  "text" : "just showing @sspis1 some Danny MacaSKILL #bikeskillz if you haven't seen: http://t.co/YJdL3BAH",
  "id" : 217639390313316352,
  "created_at" : "Tue Jun 26 15:24:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217639119902347264",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 dead dog's got skidmarks leading up to it",
  "id" : 217639119902347264,
  "created_at" : "Tue Jun 26 15:23:04 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217638265438736385",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 what's the difference between a dead chemistry major in the road and a dead dog in the road?",
  "id" : 217638265438736385,
  "created_at" : "Tue Jun 26 15:19:40 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217637722939080705",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 bigfoot's been spotted",
  "id" : 217637722939080705,
  "created_at" : "Tue Jun 26 15:17:31 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "217637651891765248",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 what's the difference between a worthwhile chemisty major and bigfoot?",
  "id" : 217637651891765248,
  "created_at" : "Tue Jun 26 15:17:14 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 0, 11 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/tHermId3",
      "expanded_url" : "http://bikeandbuild.org/rider/route.php?route=NUS&year=2012",
      "display_url" : "bikeandbuild.org/rider/route.ph…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217630679402430465",
  "in_reply_to_user_id" : 606793907,
  "text" : "@withane271 http://t.co/tHermId3",
  "id" : 217630679402430465,
  "created_at" : "Tue Jun 26 14:49:32 +0000 2012",
  "in_reply_to_screen_name" : "withane271",
  "in_reply_to_user_id_str" : "606793907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sad",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820586167, -73.2031399 ]
  },
  "id_str" : "217559908046995457",
  "text" : "4day forecasts, burlington: rain, tstorms, cloudy, p cloudy. blacksburg: sun, sun, sun, sun. i really need to remove bburg from the app #sad",
  "id" : 217559908046995457,
  "created_at" : "Tue Jun 26 10:08:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 8, 17 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 18, 29 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/x66n7YRY",
      "expanded_url" : "http://www.bikeandbuild.org/cms/content/view/38/54/",
      "display_url" : "bikeandbuild.org/cms/content/vi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217420433073516544",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @DKnick88 @skholden17 at night on july 1 I'll be close to SYR biking. I'll be driving bak thru july 4 or 5 too http://t.co/x66n7YRY",
  "id" : 217420433073516544,
  "created_at" : "Tue Jun 26 00:54:05 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/x66n7YRY",
      "expanded_url" : "http://www.bikeandbuild.org/cms/content/view/38/54/",
      "display_url" : "bikeandbuild.org/cms/content/vi…"
    }, {
      "indices" : [ 73, 94 ],
      "url" : "https://t.co/OaxNtRsw",
      "expanded_url" : "https://maps.google.com/maps?saddr=Palermo,+NY&daddr=Henderson+Harbor,+NY&hl=en&sll=43.831307,-76.257133&sspn=0.155782,0.317574&geocode=Fc2ylQIdwgV0-ykbnceBN9vZiTGzlkJ_p9zb_g%3BFdFSnQIdcEB1-yk1xxbNij3YiTHCPhpu4G35zg&oq=Henderson+harbor,+NY&mra=ls&t=m&z=10",
      "display_url" : "maps.google.com/maps?saddr=Pal…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217420008928722944",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice Sunday night I'll be in Palermo, NY http://t.co/x66n7YRY https://t.co/OaxNtRsw",
  "id" : 217420008928722944,
  "created_at" : "Tue Jun 26 00:52:24 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/217341029140008960/photo/1",
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/lKm4RTu6",
      "media_url" : "http://pbs.twimg.com/media/AwQmg7VCEAItBvO.jpg",
      "id_str" : "217341029144203266",
      "id" : 217341029144203266,
      "media_url_https" : "https://pbs.twimg.com/media/AwQmg7VCEAItBvO.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/lKm4RTu6"
    } ],
    "hashtags" : [ {
      "text" : "oxyacetylenefun",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819776833, -73.2030668333 ]
  },
  "id_str" : "217341029140008960",
  "text" : "check the geo-tag on this tweet...you might want to keep some distance #oxyacetylenefun http://t.co/lKm4RTu6",
  "id" : 217341029140008960,
  "created_at" : "Mon Jun 25 19:38:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/217269816623509505/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/kRi7onVV",
      "media_url" : "http://pbs.twimg.com/media/AwPlv0CCMAEgozs.jpg",
      "id_str" : "217269816627703809",
      "id" : 217269816627703809,
      "media_url_https" : "https://pbs.twimg.com/media/AwPlv0CCMAEgozs.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/kRi7onVV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792787, -73.207013 ]
  },
  "id_str" : "217269816623509505",
  "text" : "time to build bikes! http://t.co/kRi7onVV",
  "id" : 217269816623509505,
  "created_at" : "Mon Jun 25 14:55:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/pXK6jyhs",
      "expanded_url" : "http://app.strava.com/activities/11671340#202065637",
      "display_url" : "app.strava.com/activities/116…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "217084231669649408",
  "text" : "dropped a minute off my Philo time (8:19 now) on a solid ride today http://t.co/pXK6jyhs",
  "id" : 217084231669649408,
  "created_at" : "Mon Jun 25 02:38:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/217010777410912257/photo/1",
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/sJ2ocOLR",
      "media_url" : "http://pbs.twimg.com/media/AwL6JvxCQAE2RSv.jpg",
      "id_str" : "217010777415106561",
      "id" : 217010777415106561,
      "media_url_https" : "https://pbs.twimg.com/media/AwL6JvxCQAE2RSv.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/sJ2ocOLR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2540826667, -73.1812707667 ]
  },
  "id_str" : "217010777410912257",
  "text" : "solid mid-ride find http://t.co/sJ2ocOLR",
  "id" : 217010777410912257,
  "created_at" : "Sun Jun 24 21:46:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/216989434845990912/photo/1",
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/3JxJDJJ8",
      "media_url" : "http://pbs.twimg.com/media/AwLmvchCEAIpgbU.jpg",
      "id_str" : "216989434850185218",
      "id" : 216989434850185218,
      "media_url_https" : "https://pbs.twimg.com/media/AwLmvchCEAIpgbU.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/3JxJDJJ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3840190333, -73.1398311333 ]
  },
  "id_str" : "216989434845990912",
  "text" : "solid mid-ride find http://t.co/3JxJDJJ8",
  "id" : 216989434845990912,
  "created_at" : "Sun Jun 24 20:21:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MichelinBikeUSA",
      "screen_name" : "MichelinBikeUSA",
      "indices" : [ 1, 17 ],
      "id_str" : "515857528",
      "id" : 515857528
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/216972035614720001/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/ShsJumr3",
      "media_url" : "http://pbs.twimg.com/media/AwLW6rWCQAEoqXj.jpg",
      "id_str" : "216972035623108609",
      "id" : 216972035623108609,
      "media_url_https" : "https://pbs.twimg.com/media/AwLW6rWCQAEoqXj.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ShsJumr3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822449667, -73.2031020167 ]
  },
  "id_str" : "216972035614720001",
  "text" : ".@MichelinBikeUSA is it normal for a Pro 3 to explode after 2.25 miles on its first ride? http://t.co/ShsJumr3",
  "id" : 216972035614720001,
  "created_at" : "Sun Jun 24 19:12:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 9, 16 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/216948732044914688/photo/1",
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/avzxS5a1",
      "media_url" : "http://pbs.twimg.com/media/AwLBuOxCMAAm76H.jpg",
      "id_str" : "216948732049108992",
      "id" : 216948732049108992,
      "media_url_https" : "https://pbs.twimg.com/media/AwLBuOxCMAAm76H.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/avzxS5a1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4579999167, -73.1900285 ]
  },
  "id_str" : "216948732044914688",
  "text" : "just not @sspis1's day... http://t.co/avzxS5a1",
  "id" : 216948732044914688,
  "created_at" : "Sun Jun 24 17:39:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KODescent",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/umydEDig",
      "expanded_url" : "http://app.strava.com/rides/11540787#200010513",
      "display_url" : "app.strava.com/rides/11540787…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "216623505263964161",
  "text" : "fun ride up Philo w Dan, the compact is blissful. dropped 1min, less effort. also KOD'ed down irish hill! #KODescent http://t.co/umydEDig",
  "id" : 216623505263964161,
  "created_at" : "Sat Jun 23 20:07:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/216047643766435840/photo/1",
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/VAPqW9GK",
      "media_url" : "http://pbs.twimg.com/media/Av-OL_XCMAEAWR7.jpg",
      "id_str" : "216047643774824449",
      "id" : 216047643774824449,
      "media_url_https" : "https://pbs.twimg.com/media/Av-OL_XCMAEAWR7.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/VAPqW9GK"
    } ],
    "hashtags" : [ {
      "text" : "weirdtimetorun",
      "indices" : [ 37, 52 ]
    }, {
      "text" : "stoked",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792787, -73.207013 ]
  },
  "id_str" : "216047643766435840",
  "text" : "broke out for a midnight 11 mile yog #weirdtimetorun and assembled todays present from UPS: it's brazin' time #stoked http://t.co/VAPqW9GK",
  "id" : 216047643766435840,
  "created_at" : "Fri Jun 22 05:59:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 91, 102 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/naw8Oavf",
      "expanded_url" : "http://nyti.ms/KUSsG2",
      "display_url" : "nyti.ms/KUSsG2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "215874009986895874",
  "text" : "here's to the 5 (...or 30) second rule. I've definitely thought about this before too, via @peterdodds http://t.co/naw8Oavf",
  "id" : 215874009986895874,
  "created_at" : "Thu Jun 21 18:29:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "215630126900191234",
  "text" : "after chillin at the beach, grillin dogs and drinkin' brews #america",
  "id" : 215630126900191234,
  "created_at" : "Thu Jun 21 02:20:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/215551848877268993/photo/1",
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/YVPDQiMt",
      "media_url" : "http://pbs.twimg.com/media/Av3LQ7dCIAEg2CZ.jpg",
      "id_str" : "215551848881463297",
      "id" : 215551848881463297,
      "media_url_https" : "https://pbs.twimg.com/media/Av3LQ7dCIAEg2CZ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/YVPDQiMt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.49172445, -73.2385214667 ]
  },
  "id_str" : "215551848877268993",
  "text" : "beachhhh http://t.co/YVPDQiMt",
  "id" : 215551848877268993,
  "created_at" : "Wed Jun 20 21:09:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "northbeach",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "btv",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820823167, -73.20298305 ]
  },
  "id_str" : "215538487200460800",
  "text" : ".@sspis1 is here and we're headed to the beachhh #northbeach #btv",
  "id" : 215538487200460800,
  "created_at" : "Wed Jun 20 20:15:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtherightgear",
      "indices" : [ 63, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820941667, -73.2031574833 ]
  },
  "id_str" : "215292134906007552",
  "text" : "my apologies to non bike geek peeps, you can see the quest for #justtherightgear isn't so easy after all",
  "id" : 215292134906007552,
  "created_at" : "Wed Jun 20 03:56:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821087833, -73.203171 ]
  },
  "id_str" : "215291859969392642",
  "text" : "compact rotor q-rings are 53 power stroke, 48 dead spots btw. and shown to give 3-5% ftp gain. but they're prohibitively expensive 4 student",
  "id" : 215291859969392642,
  "created_at" : "Wed Jun 20 03:55:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821227, -73.2031592833 ]
  },
  "id_str" : "215290733320605697",
  "text" : "from the 11-28 b4 I went to a 12-26, but am finally getting compact cranks bc get this: 50x11 is bigger than 53x12. not man enough 4 53x11",
  "id" : 215290733320605697,
  "created_at" : "Wed Jun 20 03:51:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grannygear",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821692, -73.2032528 ]
  },
  "id_str" : "215289458726141952",
  "text" : "deciding now between 11-25 and 11-28 cassette. had the latter before, didnt like it. but only diff is biggest two 23/25 vs 24/28 #grannygear",
  "id" : 215289458726141952,
  "created_at" : "Wed Jun 20 03:46:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215282134217261057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792787, -73.207013 ]
  },
  "id_str" : "215282864487530497",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn 60% of my last 5 tweets, not even including this one! blowing up! maybe you should stop following me to Burlington Bay all the time",
  "id" : 215282864487530497,
  "in_reply_to_status_id" : 215282134217261057,
  "created_at" : "Wed Jun 20 03:20:09 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coveringtheirasses",
      "indices" : [ 63, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215251564359716864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792787, -73.207013 ]
  },
  "id_str" : "215266119060160513",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy had the sammme exact thought when I checked my email #coveringtheirasses. but not really their fault for fostering competition",
  "id" : 215266119060160513,
  "in_reply_to_status_id" : 215251564359716864,
  "created_at" : "Wed Jun 20 02:13:36 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 99, 107 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cremeeaddict",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4823615833, -73.2033521167 ]
  },
  "id_str" : "215265017967296512",
  "text" : "post run cremee's are always a good idea...as a celebration or a pick up. somehow every time I go, @Karo1yn is there too #cremeeaddict",
  "id" : 215265017967296512,
  "created_at" : "Wed Jun 20 02:09:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 65, 73 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gloatmobiletweet",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4584643667, -73.1420277833 ]
  },
  "id_str" : "215192534828335105",
  "text" : "time to win the @catamountOC trail race w Mark #gloatmobiletweet @Karo1yn",
  "id" : 215192534828335105,
  "created_at" : "Tue Jun 19 21:21:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215168184561573891",
  "geo" : {
  },
  "id_str" : "215169143526273024",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn you're bringing those home, right?",
  "id" : 215169143526273024,
  "in_reply_to_status_id" : 215168184561573891,
  "created_at" : "Tue Jun 19 19:48:16 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dominatenoobs",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215058575121330176",
  "geo" : {
  },
  "id_str" : "215141357608644609",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill looks super fun. what are you, a cat 5? #dominatenoobs",
  "id" : 215141357608644609,
  "in_reply_to_status_id" : 215058575121330176,
  "created_at" : "Tue Jun 19 17:57:51 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214886944948224000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792787, -73.207013 ]
  },
  "id_str" : "215120604326670339",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy nice catch! I have tri coll nats on there as one file, and put it as a run ;)",
  "id" : 215120604326670339,
  "in_reply_to_status_id" : 214886944948224000,
  "created_at" : "Tue Jun 19 16:35:23 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 16, 24 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Matthew Buckley",
      "screen_name" : "mmbuckley",
      "indices" : [ 25, 35 ],
      "id_str" : "33749249",
      "id" : 33749249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campeggos",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4817277333, -73.20294985 ]
  },
  "id_str" : "214938717159297024",
  "text" : "solid bonfire w @Karo1yn @mmbuckley &amp; twitterless folks #campeggos \"its the people around the circle, not the fire itself\"",
  "id" : 214938717159297024,
  "created_at" : "Tue Jun 19 04:32:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4712108833, -73.1904771 ]
  },
  "id_str" : "214911726167134208",
  "text" : ".@sumillie makes a mean keish, just sayin",
  "id" : 214911726167134208,
  "created_at" : "Tue Jun 19 02:45:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214795078391185408",
  "geo" : {
  },
  "id_str" : "214795804412620801",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yeah I'm thinking 5%...the question came up because that 1/4 mile at the pace of the world record marathon!",
  "id" : 214795804412620801,
  "in_reply_to_status_id" : 214795078391185408,
  "created_at" : "Mon Jun 18 19:04:45 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialsearch",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "214761844030717952",
  "text" : "what percentage of Americans can run a 70 second 400 meter dash? #socialsearch",
  "id" : 214761844030717952,
  "created_at" : "Mon Jun 18 16:49:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 31, 41 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/otebLB2O",
      "expanded_url" : "http://www.bikeandbuild.org",
      "display_url" : "bikeandbuild.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "214754869263876098",
  "text" : "just supported two riders from @bikebuild's Northern route this year! The best way to support affordable housing http://t.co/otebLB2O",
  "id" : 214754869263876098,
  "created_at" : "Mon Jun 18 16:22:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 21, 35 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/hm30FbWI",
      "expanded_url" : "http://app.strava.com/segments/1557643",
      "display_url" : "app.strava.com/segments/15576…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "214748807064326144",
  "text" : "ante has been upped, @ChrisDanforth http://t.co/hm30FbWI",
  "id" : 214748807064326144,
  "created_at" : "Mon Jun 18 15:58:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214743518361559040",
  "geo" : {
  },
  "id_str" : "214745103451955200",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill make some segments and set some unbeatable records yo",
  "id" : 214745103451955200,
  "in_reply_to_status_id" : 214743518361559040,
  "created_at" : "Mon Jun 18 15:43:17 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214106357173989378",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4794613, -73.2071415 ]
  },
  "id_str" : "214159995284103168",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser it was cool! I jumped! My secret plan to become the whole geo database has been leaked...",
  "id" : 214159995284103168,
  "in_reply_to_status_id" : 214106357173989378,
  "created_at" : "Sun Jun 17 00:58:16 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/214095586373271553/photo/1",
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/BEcxLwY6",
      "media_url" : "http://pbs.twimg.com/media/AviezS8CAAEj0qU.jpg",
      "id_str" : "214095586394243073",
      "id" : 214095586394243073,
      "media_url_https" : "https://pbs.twimg.com/media/AviezS8CAAEj0qU.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/BEcxLwY6"
    } ],
    "hashtags" : [ {
      "text" : "wanttojump",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3680954333, -72.9684723167 ]
  },
  "id_str" : "214095586373271553",
  "text" : "mid ride at the Huntington Gorge! #wanttojump http://t.co/BEcxLwY6",
  "id" : 214095586373271553,
  "created_at" : "Sat Jun 16 20:42:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebest",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213830439369060354",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820468333, -73.2031116167 ]
  },
  "id_str" : "213872298749468672",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 make it to Mad River? #thebest",
  "id" : 213872298749468672,
  "in_reply_to_status_id" : 213830439369060354,
  "created_at" : "Sat Jun 16 05:55:04 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/213871097723109376/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/A72fcjfk",
      "media_url" : "http://pbs.twimg.com/media/AvfSoVfCQAA5gES.jpg",
      "id_str" : "213871097727303680",
      "id" : 213871097727303680,
      "media_url_https" : "https://pbs.twimg.com/media/AvfSoVfCQAA5gES.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/A72fcjfk"
    } ],
    "hashtags" : [ {
      "text" : "bummer",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48190505, -73.2031190333 ]
  },
  "id_str" : "213871097723109376",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 no crossing streams at this bar #bummer http://t.co/A72fcjfk",
  "id" : 213871097723109376,
  "created_at" : "Sat Jun 16 05:50:19 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/8wYR5w6I",
      "expanded_url" : "http://connect.garmin.com/activity/189193445",
      "display_url" : "connect.garmin.com/activity/18919…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "213690132052705280",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn http://t.co/8wYR5w6I",
  "id" : 213690132052705280,
  "created_at" : "Fri Jun 15 17:51:12 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213609006386774017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820865167, -73.20308115 ]
  },
  "id_str" : "213636637463298049",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia thanks so much!!",
  "id" : 213636637463298049,
  "in_reply_to_status_id" : 213609006386774017,
  "created_at" : "Fri Jun 15 14:18:38 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213482912589422592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820884833, -73.2030567 ]
  },
  "id_str" : "213495585171447808",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy alcoholllll. ha",
  "id" : 213495585171447808,
  "in_reply_to_status_id" : 213482912589422592,
  "created_at" : "Fri Jun 15 04:58:08 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 61, 68 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820122333, -73.20307505 ]
  },
  "id_str" : "213495399657390080",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia kaity!! random q: where did you live in Chile? My gf @sspis1 is going to live in Vino del Mar for four months this fall!",
  "id" : 213495399657390080,
  "created_at" : "Fri Jun 15 04:57:24 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suckers",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48187895, -73.203179 ]
  },
  "id_str" : "213374161161162752",
  "text" : "ride to work included some cyclocross through the woods, and back I rolled past a quarter mile of stuck traffic #suckers",
  "id" : 213374161161162752,
  "created_at" : "Thu Jun 14 20:55:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/9PoSV7rj",
      "expanded_url" : "http://bicycling.com/blogs/theselection/2011/11/08/finally-atmo/",
      "display_url" : "bicycling.com/blogs/theselec…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "213357267645497345",
  "text" : "perspective http://t.co/9PoSV7rj",
  "id" : 213357267645497345,
  "created_at" : "Thu Jun 14 19:48:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213332367169945600",
  "geo" : {
  },
  "id_str" : "213338681975652352",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy so you need the torch, flashbacks (one way valves), regulators, hose, and tips. I just emailed you the receipt actually",
  "id" : 213338681975652352,
  "in_reply_to_status_id" : 213332367169945600,
  "created_at" : "Thu Jun 14 18:34:40 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 84 ],
      "url" : "https://t.co/36YV4sLg",
      "expanded_url" : "https://www.weldfabulous.com/p-21798-smith-equipment-aw1a-standard-duty-torch-handle-airline.aspx",
      "display_url" : "weldfabulous.com/p-21798-smith-…"
    } ]
  },
  "in_reply_to_status_id_str" : "213306069211037696",
  "geo" : {
  },
  "id_str" : "213329652025004032",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy scoured the interwebs past few hours, made purchase: https://t.co/36YV4sLg",
  "id" : 213329652025004032,
  "in_reply_to_status_id" : 213306069211037696,
  "created_at" : "Thu Jun 14 17:58:47 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213306069211037696",
  "geo" : {
  },
  "id_str" : "213308055784394753",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy checking it out now, thanks",
  "id" : 213308055784394753,
  "in_reply_to_status_id" : 213306069211037696,
  "created_at" : "Thu Jun 14 16:32:58 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/pZgvrOY9",
      "expanded_url" : "http://www.northerntool.com/shop/tools/product_200313416_200313416",
      "display_url" : "northerntool.com/shop/tools/pro…"
    }, {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/CpMKhE2C",
      "expanded_url" : "http://www.northerntool.com/shop/tools/product_200413934_200413934",
      "display_url" : "northerntool.com/shop/tools/pro…"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/I9u5N0yX",
      "expanded_url" : "http://www.northerntool.com/shop/tools/product_200357990_200357990",
      "display_url" : "northerntool.com/shop/tools/pro…"
    } ]
  },
  "in_reply_to_status_id_str" : "213303611810267139",
  "geo" : {
  },
  "id_str" : "213304662185619456",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy any thoughts about these for brazing? http://t.co/pZgvrOY9 http://t.co/CpMKhE2C http://t.co/I9u5N0yX",
  "id" : 213304662185619456,
  "in_reply_to_status_id" : 213303611810267139,
  "created_at" : "Thu Jun 14 16:19:29 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 10, 20 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213301452083445760",
  "geo" : {
  },
  "id_str" : "213302466974982145",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie @jcusick13 yessss",
  "id" : 213302466974982145,
  "in_reply_to_status_id" : 213301452083445760,
  "created_at" : "Thu Jun 14 16:10:45 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213253248386203648",
  "geo" : {
  },
  "id_str" : "213279242656559104",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson those are classy. I've got a big trailer, and kegerator right now...",
  "id" : 213279242656559104,
  "in_reply_to_status_id" : 213253248386203648,
  "created_at" : "Thu Jun 14 14:38:28 +0000 2012",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 10, 24 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213052559676542977",
  "geo" : {
  },
  "id_str" : "213277784687128578",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser @ChrisDanforth @SuMillie if @AftonDanforth was on my committee, I may as well quit now!",
  "id" : 213277784687128578,
  "in_reply_to_status_id" : 213052559676542977,
  "created_at" : "Thu Jun 14 14:32:41 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213035604450095104",
  "geo" : {
  },
  "id_str" : "213277200336699393",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill yeah it's gonna be tough...gahh!",
  "id" : 213277200336699393,
  "in_reply_to_status_id" : 213035604450095104,
  "created_at" : "Thu Jun 14 14:30:21 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 0, 10 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/CPKcp7rv",
      "expanded_url" : "http://www.northernbrewer.com/shop/brewing/recipe-kits/extract-kits",
      "display_url" : "northernbrewer.com/shop/brewing/r…"
    } ]
  },
  "in_reply_to_status_id_str" : "213036832424861696",
  "geo" : {
  },
  "id_str" : "213277146641219584",
  "in_reply_to_user_id" : 528928681,
  "text" : "@jcusick13 if you want to split shipping, pick something out! http://t.co/CPKcp7rv",
  "id" : 213277146641219584,
  "in_reply_to_status_id" : 213036832424861696,
  "created_at" : "Thu Jun 14 14:30:08 +0000 2012",
  "in_reply_to_screen_name" : "jcusick13",
  "in_reply_to_user_id_str" : "528928681",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213114190334930944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821572833, -73.20331715 ]
  },
  "id_str" : "213133004837621760",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw sounds like the plan!",
  "id" : 213133004837621760,
  "in_reply_to_status_id" : 213114190334930944,
  "created_at" : "Thu Jun 14 04:57:22 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213016548623917056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821252, -73.2032296833 ]
  },
  "id_str" : "213026453992902656",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 yeahhhh. i have a book of intense training plans if you're interested",
  "id" : 213026453992902656,
  "in_reply_to_status_id" : 213016548623917056,
  "created_at" : "Wed Jun 13 21:53:59 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 0, 10 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213023031944155136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821333667, -73.2031660167 ]
  },
  "id_str" : "213025965146771457",
  "in_reply_to_user_id" : 528928681,
  "text" : "@jcusick13 yeah man, Bay State Marathon on Oct 21 is pancake flat and only $70 (philly is nov 18, $125) both sound good",
  "id" : 213025965146771457,
  "in_reply_to_status_id" : 213023031944155136,
  "created_at" : "Wed Jun 13 21:52:02 +0000 2012",
  "in_reply_to_screen_name" : "jcusick13",
  "in_reply_to_user_id_str" : "528928681",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "213000614744031232",
  "text" : "is debating whether to do a marathon this fall...and shoot for 3hrs. and still mtb. and do tris.",
  "id" : 213000614744031232,
  "created_at" : "Wed Jun 13 20:11:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 60, 71 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/y7kIWFwq",
      "expanded_url" : "http://twitter.com/ChrisDanforth/status/212981962275700736/photo/1",
      "display_url" : "pic.twitter.com/y7kIWFwq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "212995289567596544",
  "text" : "RT @ChrisDanforth: Afton taking in a talk on rogue waves by @andyreagan. Yes that is a spacesuit. http://t.co/y7kIWFwq",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 41, 52 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ChrisDanforth/status/212981962275700736/photo/1",
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/y7kIWFwq",
        "media_url" : "http://pbs.twimg.com/media/AvSp911CQAAQeVG.jpg",
        "id_str" : "212981962279895040",
        "id" : 212981962279895040,
        "media_url_https" : "https://pbs.twimg.com/media/AvSp911CQAAQeVG.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com/y7kIWFwq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "212981962275700736",
    "text" : "Afton taking in a talk on rogue waves by @andyreagan. Yes that is a spacesuit. http://t.co/y7kIWFwq",
    "id" : 212981962275700736,
    "created_at" : "Wed Jun 13 18:57:12 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 212995289567596544,
  "created_at" : "Wed Jun 13 19:50:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212929736819752961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.491702, -73.1910614 ]
  },
  "id_str" : "212933743185367040",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 I believe your internet is down, sir",
  "id" : 212933743185367040,
  "in_reply_to_status_id" : 212929736819752961,
  "created_at" : "Wed Jun 13 15:45:35 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 8, 17 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212904264899633152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4833832167, -73.1936058333 ]
  },
  "id_str" : "212933567267880963",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e @jpbeatty sooo old he is!!",
  "id" : 212933567267880963,
  "in_reply_to_status_id" : 212904264899633152,
  "created_at" : "Wed Jun 13 15:44:53 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212909792191193088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.491702, -73.1910614 ]
  },
  "id_str" : "212933263054999552",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie would you care to elaborate?",
  "id" : 212933263054999552,
  "in_reply_to_status_id" : 212909792191193088,
  "created_at" : "Wed Jun 13 15:43:40 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/PHPpgv4f",
      "expanded_url" : "http://app.strava.com/activities/10296938?segment_created=true#188046911",
      "display_url" : "app.strava.com/activities/102…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "212931128720494592",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth best of luck http://t.co/PHPpgv4f",
  "id" : 212931128720494592,
  "created_at" : "Wed Jun 13 15:35:11 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "212654133801529345",
  "text" : "found a path through the woods to the office! now to watch my computer count verrry slowly to 100",
  "id" : 212654133801529345,
  "created_at" : "Tue Jun 12 21:14:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212552448705966080",
  "geo" : {
  },
  "id_str" : "212553217769345024",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie creeeeep",
  "id" : 212553217769345024,
  "in_reply_to_status_id" : 212552448705966080,
  "created_at" : "Tue Jun 12 14:33:30 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/212351891865210882/photo/1",
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/kTKragM4",
      "media_url" : "http://pbs.twimg.com/media/AvJs66qCEAAz8st.jpg",
      "id_str" : "212351891873599488",
      "id" : 212351891873599488,
      "media_url_https" : "https://pbs.twimg.com/media/AvJs66qCEAAz8st.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/kTKragM4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482247, -73.2031583167 ]
  },
  "id_str" : "212351891865210882",
  "text" : "still getting settled in the new house today and its almost there, and the \"jiggernaut\" has arrived! (+ been assembled) http://t.co/kTKragM4",
  "id" : 212351891865210882,
  "created_at" : "Tue Jun 12 01:13:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 30, 37 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820177, -73.2031727 ]
  },
  "id_str" : "212045997747085312",
  "text" : "after 10 days of adventures w @sspis1, including a 14hr drive today, I'm finally back in the #btv",
  "id" : 212045997747085312,
  "created_at" : "Mon Jun 11 04:58:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburgmust",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/rktmS443",
      "expanded_url" : "http://www.gilliesrestaurant.net/",
      "display_url" : "gilliesrestaurant.net"
    } ]
  },
  "geo" : {
  },
  "id_str" : "211465677981220864",
  "text" : "breakfast at Gillies http://t.co/rktmS443 #blacksburgmust",
  "id" : 211465677981220864,
  "created_at" : "Sat Jun 09 14:32:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211419508932489216",
  "geo" : {
  },
  "id_str" : "211437917766287360",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yayy, safe travels!!",
  "id" : 211437917766287360,
  "in_reply_to_status_id" : 211419508932489216,
  "created_at" : "Sat Jun 09 12:41:42 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 17, 28 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 66 ],
      "url" : "https://t.co/Vr11Hc0r",
      "expanded_url" : "https://www.youtube.com/watch?v=1hjfjlu5eFA&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=1hjfjl…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2385848167, -80.4287628333 ]
  },
  "id_str" : "211304754717011968",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @kreagannet sound familiar? https://t.co/Vr11Hc0r",
  "id" : 211304754717011968,
  "created_at" : "Sat Jun 09 03:52:34 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "floydjamboree",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/w4zkLl8S",
      "expanded_url" : "http://yfrog.com/oegf6kzj",
      "display_url" : "yfrog.com/oegf6kzj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "211303755612831746",
  "text" : "RT @sspis1: http://t.co/w4zkLl8S in the heart of America #floydjamboree",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "floydjamboree",
        "indices" : [ 45, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/w4zkLl8S",
        "expanded_url" : "http://yfrog.com/oegf6kzj",
        "display_url" : "yfrog.com/oegf6kzj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "211270727431761920",
    "text" : "http://t.co/w4zkLl8S in the heart of America #floydjamboree",
    "id" : 211270727431761920,
    "created_at" : "Sat Jun 09 01:37:21 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 211303755612831746,
  "created_at" : "Sat Jun 09 03:48:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 12, 19 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 40, 52 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 53, 63 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Dave Bunce",
      "screen_name" : "ISMsaddles",
      "indices" : [ 85, 96 ],
      "id_str" : "18658970",
      "id" : 18658970
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/211214619530899456/photo/1",
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/iJoCxbBQ",
      "media_url" : "http://pbs.twimg.com/media/Au5ik9DCMAE6W_f.jpg",
      "id_str" : "211214619535093761",
      "id" : 211214619535093761,
      "media_url_https" : "https://pbs.twimg.com/media/Au5ik9DCMAE6W_f.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/iJoCxbBQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/x6KP0KrU",
      "expanded_url" : "http://bit.ly/LEHRwB",
      "display_url" : "bit.ly/LEHRwB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2384690167, -80.42874585 ]
  },
  "id_str" : "211214619530899456",
  "text" : "this ride w @sspis1 goes out to America @UVM_cycling @VTCycling, comfort provided by @ISMsaddles http://t.co/x6KP0KrU http://t.co/iJoCxbBQ",
  "id" : 211214619530899456,
  "created_at" : "Fri Jun 08 21:54:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2385579167, -80.42880135 ]
  },
  "id_str" : "211120416591319042",
  "text" : "has been slacking on the tweets in VA, but headed out for to ride Allegheny Springs now. wish I had a MTB!",
  "id" : 211120416591319042,
  "created_at" : "Fri Jun 08 15:40:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210879821276905473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2385578667, -80.4287581167 ]
  },
  "id_str" : "211120161057542145",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud excellent work, sir. America is strong in this one",
  "id" : 211120161057542145,
  "in_reply_to_status_id" : 210879821276905473,
  "created_at" : "Fri Jun 08 15:39:03 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 68, 75 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 76, 85 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Jacob Aber",
      "screen_name" : "jabervt",
      "indices" : [ 86, 94 ],
      "id_str" : "370283022",
      "id" : 370283022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "210594967247265794",
  "text" : "wednesday worlds was as fun as I remember, and good times chillin w @sspis1 @ajohnnyd @jabervt",
  "id" : 210594967247265794,
  "created_at" : "Thu Jun 07 04:52:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2153589, -80.4243863 ]
  },
  "id_str" : "210451856869163011",
  "text" : "back at the VBI for a visit!",
  "id" : 210451856869163011,
  "created_at" : "Wed Jun 06 19:23:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305373667, -80.41538155 ]
  },
  "id_str" : "209703980027215872",
  "text" : "MTB frame = cracked",
  "id" : 209703980027215872,
  "created_at" : "Mon Jun 04 17:51:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/Y3ZQwjtN",
      "expanded_url" : "http://drivesmarterchallenge.org/money-saving-tips/myths.aspx",
      "display_url" : "drivesmarterchallenge.org/money-saving-t…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.22642605, -80.4413445667 ]
  },
  "id_str" : "209657922676981761",
  "text" : "sitting in standstill traffic for 15 minutes, I turned my car off...you should too (for stops &gt;30 sec): http://t.co/Y3ZQwjtN",
  "id" : 209657922676981761,
  "created_at" : "Mon Jun 04 14:48:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thelife",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2390067, -80.4280764 ]
  },
  "id_str" : "209514422010511360",
  "text" : "perfect mountain bike and rope swing action w David, stretching what I thought was rideable! Sunset from the pond then beers dtown #thelife",
  "id" : 209514422010511360,
  "created_at" : "Mon Jun 04 05:18:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.7658999833, -77.1849549833 ]
  },
  "id_str" : "209011290218303492",
  "text" : "beautiful ceremony, congratulations to Hayden and Mariah Shea!! #fb",
  "id" : 209011290218303492,
  "created_at" : "Sat Jun 02 19:59:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metrorap",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "notquittingmydayjobyet",
      "indices" : [ 85, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.7994278667, -77.1292912167 ]
  },
  "id_str" : "208973504736006146",
  "text" : "lookin fly with my pink tie, cuz it's Hayden's wedding day, that sh!t cray #metrorap #notquittingmydayjobyet",
  "id" : 208973504736006146,
  "created_at" : "Sat Jun 02 17:29:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9013763, -77.0124912 ]
  },
  "id_str" : "208927245388099584",
  "text" : "DC classy: world class cuts for a haircut. quite an experience. on another note: lots of people using the capital bikeshare!",
  "id" : 208927245388099584,
  "created_at" : "Sat Jun 02 14:25:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbad",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "fb",
      "indices" : [ 103, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.767737, -77.1836745 ]
  },
  "id_str" : "208728234534240256",
  "text" : "landed in Springfield, VA! Only 12hrs w traffic, and despite all the brake checks, got 36.5mpg #notbad #fb",
  "id" : 208728234534240256,
  "created_at" : "Sat Jun 02 01:14:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 19, 26 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 28, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "208557102417977344",
  "text" : "on the way to VA w @sspis1! #fb",
  "id" : 208557102417977344,
  "created_at" : "Fri Jun 01 13:54:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]