Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 8, 15 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263761791539085313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.475945, -73.2112712 ]
  },
  "id_str" : "263808226464759811",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @sspis1 ha you wish. no treats for you, just tricks! ps come visit again lol",
  "id" : 263808226464759811,
  "in_reply_to_status_id" : 263761791539085313,
  "created_at" : "Thu Nov 01 01:02:37 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 89, 100 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/8QuHZfi2",
      "expanded_url" : "http://twitpic.com/b96a0a",
      "display_url" : "twitpic.com/b96a0a"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208797, -73.20307889 ]
  },
  "id_str" : "263759951221125120",
  "text" : "totally awesome halloween package from the Spisiaks arrived with perfect timing!! thanks @withane271 http://t.co/8QuHZfi2",
  "id" : 263759951221125120,
  "created_at" : "Wed Oct 31 21:50:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 1, 8 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263657059436871680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4700832, -73.1946619 ]
  },
  "id_str" : "263699390756171776",
  "in_reply_to_user_id" : 26517690,
  "text" : ".@k8eb8e it's funny, cuz most people don't think I'm in costume #whoops",
  "id" : 263699390756171776,
  "in_reply_to_status_id" : 263657059436871680,
  "created_at" : "Wed Oct 31 17:50:08 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 0, 12 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263647074233491457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4700789, -73.1946531 ]
  },
  "id_str" : "263699218487709696",
  "in_reply_to_user_id" : 276236513,
  "text" : "@bikingbiebs now's the chance to pick one up for cheap lol",
  "id" : 263699218487709696,
  "in_reply_to_status_id" : 263647074233491457,
  "created_at" : "Wed Oct 31 17:49:27 +0000 2012",
  "in_reply_to_screen_name" : "bikingbiebs",
  "in_reply_to_user_id_str" : "276236513",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/jrOVoupp",
      "expanded_url" : "http://twitpic.com/b92myh",
      "display_url" : "twitpic.com/b92myh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4829045, -73.1934136 ]
  },
  "id_str" : "263643585428197378",
  "text" : "halloween costume complete. can you guess who I am? http://t.co/jrOVoupp",
  "id" : 263643585428197378,
  "created_at" : "Wed Oct 31 14:08:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 16, 28 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822547, -73.2030801 ]
  },
  "id_str" : "263627678811312131",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash @mrfrank5790 caught myself humming \"more beer for all the hashers\" making breakfast this AM...must be Wed",
  "id" : 263627678811312131,
  "created_at" : "Wed Oct 31 13:05:11 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metapaper",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263458724629331968",
  "text" : "I even use Tex to do my algebra these days #metapaper",
  "id" : 263458724629331968,
  "created_at" : "Wed Oct 31 01:53:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "itson",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263452424671477760",
  "in_reply_to_user_id" : 78184204,
  "text" : "@rumblinstumblin another reason to come to #btv... just discovered pool tables in the student center #itson",
  "id" : 263452424671477760,
  "created_at" : "Wed Oct 31 01:28:47 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 67, 80 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurt",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263451693960790016",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT can't believe you exposed my 10PM nacho habit to all of @UVMTriathlon #hurt",
  "id" : 263451693960790016,
  "created_at" : "Wed Oct 31 01:25:53 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interestingtweets",
      "indices" : [ 50, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263451443154001920",
  "text" : "the other three have all involved open face PBJ's #interestingtweets",
  "id" : 263451443154001920,
  "created_at" : "Wed Oct 31 01:24:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodstuff",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "263450991670738945",
  "text" : "3 out of my 6 last meals have been burritos #goodstuff",
  "id" : 263450991670738945,
  "created_at" : "Wed Oct 31 01:23:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 0, 11 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263445146903912448",
  "geo" : {
  },
  "id_str" : "263450662124285952",
  "in_reply_to_user_id" : 15408193,
  "text" : "@fatcyclist good news. I just purchased a turkey baster in preparation",
  "id" : 263450662124285952,
  "in_reply_to_status_id" : 263445146903912448,
  "created_at" : "Wed Oct 31 01:21:47 +0000 2012",
  "in_reply_to_screen_name" : "fatcyclist",
  "in_reply_to_user_id_str" : "15408193",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 24, 40 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 45, 54 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 103, 110 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/w6bY3koF",
      "expanded_url" : "http://twitpic.com/b8s4yv",
      "display_url" : "twitpic.com/b8s4yv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4834508, -73.19377733 ]
  },
  "id_str" : "263279943314706433",
  "text" : "just got this book from @RumblinStumblin and @dmreagan, photo on the cover is exactly where I'm headed @sspis1 http://t.co/w6bY3koF",
  "id" : 263279943314706433,
  "created_at" : "Tue Oct 30 14:03:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instacane",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "sandy",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/ozsudFjw",
      "expanded_url" : "http://bit.ly/qwofYl",
      "display_url" : "bit.ly/qwofYl"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/SSgwxfVt",
      "expanded_url" : "http://hint.fm/wind/",
      "display_url" : "hint.fm/wind/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "263019533663621121",
  "text" : "RT @dr_pyser: #instacane. nice. http://t.co/ozsudFjw don't forget to keep an eye on http://t.co/SSgwxfVt during #sandy as well!",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "instacane",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "sandy",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http://t.co/ozsudFjw",
        "expanded_url" : "http://bit.ly/qwofYl",
        "display_url" : "bit.ly/qwofYl"
      }, {
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/SSgwxfVt",
        "expanded_url" : "http://hint.fm/wind/",
        "display_url" : "hint.fm/wind/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "263001061642612736",
    "text" : "#instacane. nice. http://t.co/ozsudFjw don't forget to keep an eye on http://t.co/SSgwxfVt during #sandy as well!",
    "id" : 263001061642612736,
    "created_at" : "Mon Oct 29 19:35:14 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 263019533663621121,
  "created_at" : "Mon Oct 29 20:48:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 0, 13 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262978202102804480",
  "geo" : {
  },
  "id_str" : "262982444708417537",
  "in_reply_to_user_id" : 14630047,
  "text" : "@usatriathlon it's always a good reason to go train...gotta catch that 90mph tailwind!",
  "id" : 262982444708417537,
  "in_reply_to_status_id" : 262978202102804480,
  "created_at" : "Mon Oct 29 18:21:15 +0000 2012",
  "in_reply_to_screen_name" : "usatriathlon",
  "in_reply_to_user_id_str" : "14630047",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "262755983972003840",
  "text" : "RT @DZdan1 Tip 17: Be prepared to make tough decisions. Only one person can float on the door.",
  "id" : 262755983972003840,
  "created_at" : "Mon Oct 29 03:21:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 12, 23 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/WTgLfv9V",
      "expanded_url" : "http://amzn.com/k/4WxTQDHbQi6zuVPMPAa0DA",
      "display_url" : "amzn.com/k/4WxTQDHbQi6z…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262755462666129408",
  "text" : "RT @sspis1: @andyreagan http://t.co/WTgLfv9V #Kindle",
  "retweeted_status" : {
    "source" : "<a href=\"https://kindle.amazon.com\" rel=\"nofollow\">Kindle</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http://t.co/WTgLfv9V",
        "expanded_url" : "http://amzn.com/k/4WxTQDHbQi6zuVPMPAa0DA",
        "display_url" : "amzn.com/k/4WxTQDHbQi6z…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "262751883041570817",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan http://t.co/WTgLfv9V #Kindle",
    "id" : 262751883041570817,
    "created_at" : "Mon Oct 29 03:05:05 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 262755462666129408,
  "created_at" : "Mon Oct 29 03:19:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 3, 14 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/YW41RJ79",
      "expanded_url" : "http://youtu.be/6TiXUF9xbTo",
      "display_url" : "youtu.be/6TiXUF9xbTo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262714117419331584",
  "text" : "RT @fatcyclist: In a perfect world, all political ads would entertain me like this one: http://t.co/YW41RJ79",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http://t.co/YW41RJ79",
        "expanded_url" : "http://youtu.be/6TiXUF9xbTo",
        "display_url" : "youtu.be/6TiXUF9xbTo"
      } ]
    },
    "geo" : {
    },
    "id_str" : "262709455068753921",
    "text" : "In a perfect world, all political ads would entertain me like this one: http://t.co/YW41RJ79",
    "id" : 262709455068753921,
    "created_at" : "Mon Oct 29 00:16:29 +0000 2012",
    "user" : {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "protected" : false,
      "id_str" : "15408193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3010461639/c3edf0ff84ed9988d5e552032346e5d4_normal.jpeg",
      "id" : 15408193,
      "verified" : false
    }
  },
  "id" : 262714117419331584,
  "created_at" : "Mon Oct 29 00:35:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262681331899723776",
  "geo" : {
  },
  "id_str" : "262682268915613696",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 you know that's the world championship that he did, right?",
  "id" : 262682268915613696,
  "in_reply_to_status_id" : 262681331899723776,
  "created_at" : "Sun Oct 28 22:28:27 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 24, 37 ],
      "id_str" : "17900130",
      "id" : 17900130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/8qpg732z",
      "expanded_url" : "http://ow.ly/eIksV",
      "display_url" : "ow.ly/eIksV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262659573448585216",
  "text" : "it just sounds awesome \"@bicyclingmag Iceman Cometh – An oldschool adventure race…with lots of snow and freezing temps http://t.co/8qpg732z\"",
  "id" : 262659573448585216,
  "created_at" : "Sun Oct 28 20:58:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 72, 79 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ironmanNZ",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/n4Omk13Z",
      "expanded_url" : "http://www.ironman.com/triathlon/events/ironman/new-zealand.aspx#axzz2AcjZg04J",
      "display_url" : "ironman.com/triathlon/even…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262658713033256960",
  "text" : "who wants to cover my $960 entry fee?!? #ironmanNZ http://t.co/n4Omk13Z @sspis1",
  "id" : 262658713033256960,
  "created_at" : "Sun Oct 28 20:54:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262529363575189504",
  "geo" : {
  },
  "id_str" : "262582569739091969",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee that's not a lot (it's normal to spend 1000/year just INSURING a car), but check out the upstairs of Old Spokes Home",
  "id" : 262582569739091969,
  "in_reply_to_status_id" : 262529363575189504,
  "created_at" : "Sun Oct 28 15:52:17 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "262383691114889216",
  "text" : "as it turns out, it's much harder than you might think to get a wikipedia page (no guys, not for myself)",
  "id" : 262383691114889216,
  "created_at" : "Sun Oct 28 02:42:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burritos",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "running",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "perfectcombo",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820161, -73.20304761 ]
  },
  "id_str" : "262351981581058049",
  "text" : "running straight to bueno y sano... #burritos and #running #perfectcombo",
  "id" : 262351981581058049,
  "created_at" : "Sun Oct 28 00:36:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48202256, -73.20304588 ]
  },
  "id_str" : "262349557571137536",
  "text" : "want a real  spooky Halloween? run the waterfront bike path at night and dodge the skunks and drunks in the dark!",
  "id" : 262349557571137536,
  "created_at" : "Sun Oct 28 00:26:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262192509676048386",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822622, -73.2030957 ]
  },
  "id_str" : "262203538665521152",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium n+3...where n is the number of bikes a sane person would own",
  "id" : 262203538665521152,
  "in_reply_to_status_id" : 262192509676048386,
  "created_at" : "Sat Oct 27 14:46:09 +0000 2012",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/62zVwLAY",
      "expanded_url" : "http://twitpic.com/b7qs4n",
      "display_url" : "twitpic.com/b7qs4n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822646, -73.2030954 ]
  },
  "id_str" : "262067333793734657",
  "text" : "flat bars on the commuter. a world more comfortable...shoulda done it 8 months and 700 miles ago! http://t.co/62zVwLAY",
  "id" : 262067333793734657,
  "created_at" : "Sat Oct 27 05:44:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 90, 105 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/E0TxJAog",
      "expanded_url" : "http://www.phillybikeexpo.com/2012_Exhibitors.html",
      "display_url" : "phillybikeexpo.com/2012_Exhibitor…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "262023612326875136",
  "in_reply_to_user_id" : 44471444,
  "text" : "just realized that the Philly Bike Expo is this weekend. missing out http://t.co/E0TxJAog\n@ryandelgiudice",
  "id" : 262023612326875136,
  "created_at" : "Sat Oct 27 02:51:11 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822366, -73.2030505 ]
  },
  "id_str" : "262021911112978432",
  "text" : "and pour forth generously over the world\" -London (2/2)",
  "id" : 262021911112978432,
  "created_at" : "Sat Oct 27 02:44:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822407, -73.2030585 ]
  },
  "id_str" : "262021750626324480",
  "text" : "\"Life streamed though him in splendid flood, glad and rampant, until it seemed that it would burst him asunder in sheer ecstasy (1/2)",
  "id" : 262021750626324480,
  "created_at" : "Sat Oct 27 02:43:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "watchout",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822899, -73.203042 ]
  },
  "id_str" : "261963929314537472",
  "text" : "snuck in 30 miles in the 1.5hrs before dark...getting more comfortable on the TT rig #watchout",
  "id" : 261963929314537472,
  "created_at" : "Fri Oct 26 22:54:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261937220582256640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822228, -73.2030544 ]
  },
  "id_str" : "261959134038065152",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 and they were spot on! lol",
  "id" : 261959134038065152,
  "in_reply_to_status_id" : 261937220582256640,
  "created_at" : "Fri Oct 26 22:34:59 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikeshopexploring",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822502, -73.2030757 ]
  },
  "id_str" : "261899833189752835",
  "text" : "headed to check out the tiny, and hidden, winooski bicycle shop #bikeshopexploring",
  "id" : 261899833189752835,
  "created_at" : "Fri Oct 26 18:39:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 36, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822386, -73.2030672 ]
  },
  "id_str" : "261899584761102336",
  "text" : "registered to vote!! if you live in #btv just roll down to 149 church street, takes 30sec",
  "id" : 261899584761102336,
  "created_at" : "Fri Oct 26 18:38:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 0, 12 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "studyholic",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261860359474905088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822568, -73.2030785 ]
  },
  "id_str" : "261899303520444416",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SumaNMNDesu ya missed out! #studyholic",
  "id" : 261899303520444416,
  "in_reply_to_status_id" : 261860359474905088,
  "created_at" : "Fri Oct 26 18:37:14 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48240161, -73.2030695 ]
  },
  "id_str" : "261896277023936513",
  "text" : "calling a few strong lads to help me push my car 200yd to the shop #btv",
  "id" : 261896277023936513,
  "created_at" : "Fri Oct 26 18:25:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261653108470452224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482226, -73.2030572 ]
  },
  "id_str" : "261658691638550528",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C IPA at the moment, then adding some fall maple in secondary and bottling with extracted jalapeno for a little.kick!",
  "id" : 261658691638550528,
  "in_reply_to_status_id" : 261653108470452224,
  "created_at" : "Fri Oct 26 02:41:08 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261654413033218048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48162271, -73.20291318 ]
  },
  "id_str" : "261658210228903936",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee I got a wonderful attic. smells like beer up there now I bet #yum",
  "id" : 261658210228903936,
  "in_reply_to_status_id" : 261654413033218048,
  "created_at" : "Fri Oct 26 02:39:13 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 41, 50 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madscientistsatwork",
      "indices" : [ 20, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/qmmRFbIZ",
      "expanded_url" : "http://twitpic.com/b7e3gk",
      "display_url" : "twitpic.com/b7e3gk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822537, -73.2030672 ]
  },
  "id_str" : "261635474861457409",
  "text" : "now THIS is science #madscientistsatwork @eclark66 http://t.co/qmmRFbIZ",
  "id" : 261635474861457409,
  "created_at" : "Fri Oct 26 01:08:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whaddup",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/18hcGOCr",
      "expanded_url" : "http://twitpic.com/b7dupg",
      "display_url" : "twitpic.com/b7dupg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822579, -73.20308 ]
  },
  "id_str" : "261625526928678912",
  "text" : "frying up some streak fried rice on the WOK #whaddup http://t.co/18hcGOCr",
  "id" : 261625526928678912,
  "created_at" : "Fri Oct 26 00:29:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/vFYGcm7i",
      "expanded_url" : "http://twitpic.com/b7dtss",
      "display_url" : "twitpic.com/b7dtss"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822791, -73.2031218 ]
  },
  "id_str" : "261624548787625984",
  "text" : "the boil has a life of it's own, coolest part of the brew http://t.co/vFYGcm7i",
  "id" : 261624548787625984,
  "created_at" : "Fri Oct 26 00:25:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 47, 56 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/Z3EbDE1g",
      "expanded_url" : "http://twitpic.com/b7dt99",
      "display_url" : "twitpic.com/b7dt99"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48194674, -73.20312907 ]
  },
  "id_str" : "261623961337610240",
  "text" : "this is I how I do automation, homebrew style. @eclark66  and I whipping up a late season Jalapeno Maple IPA http://t.co/Z3EbDE1g",
  "id" : 261623961337610240,
  "created_at" : "Fri Oct 26 00:23:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Clark",
      "screen_name" : "eclark66",
      "indices" : [ 27, 36 ],
      "id_str" : "538423908",
      "id" : 538423908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/prdFtzTX",
      "expanded_url" : "http://twitpic.com/b7di7m",
      "display_url" : "twitpic.com/b7di7m"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822483, -73.2030667 ]
  },
  "id_str" : "261610863549620226",
  "text" : "switchback is in bottles!! @eclark66 http://t.co/prdFtzTX",
  "id" : 261610863549620226,
  "created_at" : "Thu Oct 25 23:31:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/ICksP9Mr",
      "expanded_url" : "http://twitpic.com/b7cjgn",
      "display_url" : "twitpic.com/b7cjgn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4809033, -73.1989422 ]
  },
  "id_str" : "261566198930604032",
  "text" : "Jake Williams telling the UVM Applied Math Colloquium about how to find meaning in language #storylab http://t.co/ICksP9Mr",
  "id" : 261566198930604032,
  "created_at" : "Thu Oct 25 20:33:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/261530795678769154/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/z8bre9so",
      "media_url" : "http://pbs.twimg.com/media/A6Ek337CIAABbf-.png",
      "id_str" : "261530795687157760",
      "id" : 261530795687157760,
      "media_url_https" : "https://pbs.twimg.com/media/A6Ek337CIAABbf-.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 722
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 722
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/z8bre9so"
    } ],
    "hashtags" : [ {
      "text" : "prettypictures",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "science",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "storylab",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "261530795678769154",
  "text" : "#prettypictures  = #science, #storylab http://t.co/z8bre9so",
  "id" : 261530795678769154,
  "created_at" : "Thu Oct 25 18:12:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "indices" : [ 3, 10 ],
      "id_str" : "394388191",
      "id" : 394388191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/aDKHeO3c",
      "expanded_url" : "http://twitpic.com/b7bj4u",
      "display_url" : "twitpic.com/b7bj4u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261522452566388736",
  "text" : "RT @UVMBUG: Bike Fix-It Stations are here at UVM! http://t.co/aDKHeO3c",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http://t.co/aDKHeO3c",
        "expanded_url" : "http://twitpic.com/b7bj4u",
        "display_url" : "twitpic.com/b7bj4u"
      } ]
    },
    "geo" : {
    },
    "id_str" : "261520527653474304",
    "text" : "Bike Fix-It Stations are here at UVM! http://t.co/aDKHeO3c",
    "id" : 261520527653474304,
    "created_at" : "Thu Oct 25 17:32:07 +0000 2012",
    "user" : {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "protected" : false,
      "id_str" : "394388191",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1597116048/bug_normal.jpg",
      "id" : 394388191,
      "verified" : false
    }
  },
  "id" : 261522452566388736,
  "created_at" : "Thu Oct 25 17:39:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 3, 16 ],
      "id_str" : "17900130",
      "id" : 17900130
    }, {
      "name" : "Ira Ryan",
      "screen_name" : "IraRyanCycles",
      "indices" : [ 25, 39 ],
      "id_str" : "117503293",
      "id" : 117503293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/9bPjDbSf",
      "expanded_url" : "http://ow.ly/eK9XO",
      "display_url" : "ow.ly/eK9XO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "261491840254091264",
  "text" : "RT @BicyclingMag: Video: @IraRyanCycles gives a tour of his custom frame workshop http://t.co/9bPjDbSf",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ira Ryan",
        "screen_name" : "IraRyanCycles",
        "indices" : [ 7, 21 ],
        "id_str" : "117503293",
        "id" : 117503293
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http://t.co/9bPjDbSf",
        "expanded_url" : "http://ow.ly/eK9XO",
        "display_url" : "ow.ly/eK9XO"
      } ]
    },
    "geo" : {
    },
    "id_str" : "261413351727456256",
    "text" : "Video: @IraRyanCycles gives a tour of his custom frame workshop http://t.co/9bPjDbSf",
    "id" : 261413351727456256,
    "created_at" : "Thu Oct 25 10:26:14 +0000 2012",
    "user" : {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "protected" : false,
      "id_str" : "17900130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1555023497/Bicycling-Twitter-icon_normal.jpg",
      "id" : 17900130,
      "verified" : false
    }
  },
  "id" : 261491840254091264,
  "created_at" : "Thu Oct 25 15:38:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    }, {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 21, 33 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261471780596744192",
  "geo" : {
  },
  "id_str" : "261478122455711745",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo maybe @LeeRMatthis can point you in the right direction",
  "id" : 261478122455711745,
  "in_reply_to_status_id" : 261471780596744192,
  "created_at" : "Thu Oct 25 14:43:37 +0000 2012",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 102, 114 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 115, 130 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48196618, -73.20299863 ]
  },
  "id_str" : "261293482197536768",
  "text" : "beer and flour combine to make an impressively difficult to remove mixture...definitely non-newtonian @mrfrank5790 @BurlingtonHash",
  "id" : 261293482197536768,
  "created_at" : "Thu Oct 25 02:29:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 45, 52 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everynight",
      "indices" : [ 67, 78 ]
    }, {
      "text" : "needit",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260931248216739840",
  "text" : "enjoyed the Levi Effect! chatting it up with @sspis1 for the night #everynight #needit",
  "id" : 260931248216739840,
  "created_at" : "Wed Oct 24 02:30:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/M3Tf77yk",
      "expanded_url" : "http://connect.garmin.com/activity/236566316",
      "display_url" : "connect.garmin.com/activity/23656…"
    } ]
  },
  "in_reply_to_status_id_str" : "260894540959997952",
  "geo" : {
  },
  "id_str" : "260930620249759744",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/M3Tf77yk",
  "id" : 260930620249759744,
  "in_reply_to_status_id" : 260894540959997952,
  "created_at" : "Wed Oct 24 02:28:02 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260912373349617664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4370708, -73.2091614 ]
  },
  "id_str" : "260917143518973952",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 you're writing math lessons?",
  "id" : 260917143518973952,
  "in_reply_to_status_id" : 260912373349617664,
  "created_at" : "Wed Oct 24 01:34:29 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Dorfman",
      "screen_name" : "Mizz_Dawfmin",
      "indices" : [ 0, 13 ],
      "id_str" : "256324509",
      "id" : 256324509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260557958117736449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4370708, -73.2091614 ]
  },
  "id_str" : "260908143264034816",
  "in_reply_to_user_id" : 256324509,
  "text" : "@Mizz_Dawfmin perfect for whippin up some cookies in transistion, ask Mary",
  "id" : 260908143264034816,
  "in_reply_to_status_id" : 260557958117736449,
  "created_at" : "Wed Oct 24 00:58:43 +0000 2012",
  "in_reply_to_screen_name" : "Mizz_Dawfmin",
  "in_reply_to_user_id_str" : "256324509",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "movietheaterfooled",
      "indices" : [ 33, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/ub3lHrEL",
      "expanded_url" : "http://twitpic.com/b6u9uq",
      "display_url" : "twitpic.com/b6u9uq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4370708, -73.2091614 ]
  },
  "id_str" : "260885702768730112",
  "text" : "yes, this fit-shirts in my pants #movietheaterfooled http://t.co/ub3lHrEL",
  "id" : 260885702768730112,
  "created_at" : "Tue Oct 23 23:29:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4370708, -73.2091614 ]
  },
  "id_str" : "260885634510635008",
  "text" : "at premiere of The Levi Effect, an interesting time for professional cycling!!",
  "id" : 260885634510635008,
  "created_at" : "Tue Oct 23 23:29:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 5, 17 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfcontrol",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.44179481, -73.21323519 ]
  },
  "id_str" : "260882013496680448",
  "text" : "5 of @UVM_cycling walk into McDonalds, realize we're cyclists....walk out empty handed #selfcontrol",
  "id" : 260882013496680448,
  "created_at" : "Tue Oct 23 23:14:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 3, 14 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/9hPu8AW0",
      "expanded_url" : "http://bit.ly/P0hdWG",
      "display_url" : "bit.ly/P0hdWG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260874782445281280",
  "text" : "RT @peterdodds: Easily the best thing you'll hear all week: a beluga whale mimicking human speech http://t.co/9hPu8AW0",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http://t.co/9hPu8AW0",
        "expanded_url" : "http://bit.ly/P0hdWG",
        "display_url" : "bit.ly/P0hdWG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "260858248968679424",
    "text" : "Easily the best thing you'll hear all week: a beluga whale mimicking human speech http://t.co/9hPu8AW0",
    "id" : 260858248968679424,
    "created_at" : "Tue Oct 23 21:40:27 +0000 2012",
    "user" : {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "protected" : false,
      "id_str" : "16174144",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/294761101/IMG_7808_small_normal.JPG",
      "id" : 16174144,
      "verified" : false
    }
  },
  "id" : 260874782445281280,
  "created_at" : "Tue Oct 23 22:46:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "running",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "friends",
      "indices" : [ 120, 128 ]
    }, {
      "text" : "btvsunset",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48212528, -73.20308346 ]
  },
  "id_str" : "260871273847091200",
  "text" : "solo 5mi \"return of the harvest cafe soup\" cruise turned into a really fun 9 with friends and beautiful sunset #running #friends #btvsunset",
  "id" : 260871273847091200,
  "created_at" : "Tue Oct 23 22:32:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "broad",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4972448, -73.1983219 ]
  },
  "id_str" : "260840204254998529",
  "text" : "just realized I'm writing my new hw on the back of hw from exactly 1 year ago. last fall: abstract algebra. this fall: applied pde's. #broad",
  "id" : 260840204254998529,
  "created_at" : "Tue Oct 23 20:28:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 3, 14 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/dGs6Xkc4",
      "expanded_url" : "http://fatcy.cl/OZBagh",
      "display_url" : "fatcy.cl/OZBagh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260794671637336064",
  "text" : "RT @fatcyclist: Talking about Judging, Doping, and The Levi Effect http://t.co/dGs6Xkc4",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http://t.co/dGs6Xkc4",
        "expanded_url" : "http://fatcy.cl/OZBagh",
        "display_url" : "fatcy.cl/OZBagh"
      } ]
    },
    "geo" : {
    },
    "id_str" : "260788633664094209",
    "text" : "Talking about Judging, Doping, and The Levi Effect http://t.co/dGs6Xkc4",
    "id" : 260788633664094209,
    "created_at" : "Tue Oct 23 17:03:50 +0000 2012",
    "user" : {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "protected" : false,
      "id_str" : "15408193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3010461639/c3edf0ff84ed9988d5e552032346e5d4_normal.jpeg",
      "id" : 15408193,
      "verified" : false
    }
  },
  "id" : 260794671637336064,
  "created_at" : "Tue Oct 23 17:27:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260559078487650304",
  "text" : "watching the debate... [insert witty comment]",
  "id" : 260559078487650304,
  "created_at" : "Tue Oct 23 01:51:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 27, 35 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792598, -73.2069087 ]
  },
  "id_str" : "260491902003052544",
  "text" : "beautiful day for a ride w @pkemp33",
  "id" : 260491902003052544,
  "created_at" : "Mon Oct 22 21:24:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48138979, -73.19495596 ]
  },
  "id_str" : "260175685887348736",
  "text" : "almost always regret walking to the office...when I leave",
  "id" : 260175685887348736,
  "created_at" : "Mon Oct 22 00:28:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 117, 128 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/4EaSRqz5",
      "expanded_url" : "http://www.newyorker.com/online/blogs/culture/2012/10/the-onion-tees-up-ted-talks.html?mobify=0",
      "display_url" : "newyorker.com/online/blogs/c…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260161291350577153",
  "text" : "\"get the best engineers, pay them double what they make, and I'm confident this can happen\" http://t.co/4EaSRqz5 via @JadAbumrad",
  "id" : 260161291350577153,
  "created_at" : "Sun Oct 21 23:31:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/YnU0yX3Y",
      "expanded_url" : "http://bit.ly/T8itrg",
      "display_url" : "bit.ly/T8itrg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "260119763899019265",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/YnU0yX3Y",
  "id" : 260119763899019265,
  "created_at" : "Sun Oct 21 20:45:59 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 62, 74 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 75, 89 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 90, 101 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/260091866677129216/photo/1",
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/K8t3Wrd3",
      "media_url" : "http://pbs.twimg.com/media/A5wILLrCMAEZPHY.png",
      "id_str" : "260091866685517825",
      "id" : 260091866685517825,
      "media_url_https" : "https://pbs.twimg.com/media/A5wILLrCMAEZPHY.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 228
      } ],
      "display_url" : "pic.twitter.com/K8t3Wrd3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "260091866677129216",
  "text" : "the sidebar on wolfram alpha is getting a bit presumptious... @SumaNMNDesu @ChrisDanforth @peterdodds http://t.co/K8t3Wrd3",
  "id" : 260091866677129216,
  "created_at" : "Sun Oct 21 18:55:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gross",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "fail",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822313, -73.2030374 ]
  },
  "id_str" : "259754025099067392",
  "text" : "great run: pushed myself hard, and accidentally Tarzan'ed into the middle of a flooded Winooski River #gross #fail",
  "id" : 259754025099067392,
  "created_at" : "Sat Oct 20 20:32:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259730963913920513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820357, -73.20303805 ]
  },
  "id_str" : "259753496453185539",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee chyeah! intervale was totally flooded out",
  "id" : 259753496453185539,
  "in_reply_to_status_id" : 259730963913920513,
  "created_at" : "Sat Oct 20 20:30:34 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48202609, -73.20306664 ]
  },
  "id_str" : "259717957901512704",
  "text" : "beautiful weather...must run",
  "id" : 259717957901512704,
  "created_at" : "Sat Oct 20 18:09:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 46, 56 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259518739240861696",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw 33rd place, nice job today man!! @VTCycling",
  "id" : 259518739240861696,
  "created_at" : "Sat Oct 20 04:57:43 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "processingstill",
      "indices" : [ 71, 87 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832084, -73.1933497 ]
  },
  "id_str" : "259406360532353024",
  "text" : "altogether an excellent TEDx. A lot of ideas worth spreading, for sure #processingstill #TEDxUVM",
  "id" : 259406360532353024,
  "created_at" : "Fri Oct 19 21:31:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259394344677670913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786658, -73.1941135 ]
  },
  "id_str" : "259396859108417536",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT live stream it!",
  "id" : 259396859108417536,
  "in_reply_to_status_id" : 259394344677670913,
  "created_at" : "Fri Oct 19 20:53:25 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigscale",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "hard",
      "indices" : [ 64, 69 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/4CXymCNY",
      "expanded_url" : "http://twitpic.com/b5m0oc",
      "display_url" : "twitpic.com/b5m0oc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786726, -73.1941605 ]
  },
  "id_str" : "259396723863068672",
  "text" : "Neal Rothleder of MITRE Corporation on cyber security #bigscale #hard #TEDxUVM http://t.co/4CXymCNY",
  "id" : 259396723863068672,
  "created_at" : "Fri Oct 19 20:52:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/k5cfcIJ3",
      "expanded_url" : "http://twitpic.com/b5lxge",
      "display_url" : "twitpic.com/b5lxge"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786789, -73.1941168 ]
  },
  "id_str" : "259392602745487360",
  "text" : "UVM's John Voight on cryptography for everyone #cool #TEDxUVM http://t.co/k5cfcIJ3",
  "id" : 259392602745487360,
  "created_at" : "Fri Oct 19 20:36:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDxUVM",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786754, -73.1941422 ]
  },
  "id_str" : "259388909547552768",
  "text" : "\"weak need to think and act on a global scale\" -Zia #TEDxUVM",
  "id" : 259388909547552768,
  "created_at" : "Fri Oct 19 20:21:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ideasworthsharing",
      "indices" : [ 72, 90 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786656, -73.1941501 ]
  },
  "id_str" : "259388313293697024",
  "text" : "Asim Zia, UVM CDAE, on the impact of human activities on a global scale #ideasworthsharing #TEDxUVM",
  "id" : 259388313293697024,
  "created_at" : "Fri Oct 19 20:19:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 1, 12 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "compstorylab",
      "screen_name" : "compstorylab",
      "indices" : [ 21, 34 ],
      "id_str" : "473353790",
      "id" : 473353790
    }, {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 39, 53 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/WrzZGSXJ",
      "expanded_url" : "http://twitpic.com/b5lrxe",
      "display_url" : "twitpic.com/b5lrxe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786652, -73.1941209 ]
  },
  "id_str" : "259385421342072832",
  "text" : ".@peterdodds of UVM, @compstorylab and @uvmcomplexity letting us in on the secrets to superstardom #storylab #TEDxUVM http://t.co/WrzZGSXJ",
  "id" : 259385421342072832,
  "created_at" : "Fri Oct 19 20:07:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDxUVM",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/wcLZn75p",
      "expanded_url" : "http://twitpic.com/b5lfpf",
      "display_url" : "twitpic.com/b5lfpf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786519, -73.1941557 ]
  },
  "id_str" : "259369495867568128",
  "text" : "Brian Wansink from Cornell to tell us about the collective America failure to stay skinny #TEDxUVM http://t.co/wcLZn75p",
  "id" : 259369495867568128,
  "created_at" : "Fri Oct 19 19:04:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/Rsx4XQsn",
      "expanded_url" : "http://twitpic.com/b5ldd3",
      "display_url" : "twitpic.com/b5ldd3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786592, -73.1941263 ]
  },
  "id_str" : "259366785059540993",
  "text" : ".@dr_pyser on Big Happy! #storylab #TEDxUVM http://t.co/Rsx4XQsn",
  "id" : 259366785059540993,
  "created_at" : "Fri Oct 19 18:53:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786517, -73.1941447 ]
  },
  "id_str" : "259365417921953792",
  "text" : "but can a 3D printer print a 3D printer...?",
  "id" : 259365417921953792,
  "created_at" : "Fri Oct 19 18:48:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 112, 124 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.478646, -73.1941422 ]
  },
  "id_str" : "259363569534107648",
  "text" : "3D printers now printing chocolate (and concrete, metal, plastic...but chocolate!) #storylab needs one of these @mrfrank5790 #TEDxUVM",
  "id" : 259363569534107648,
  "created_at" : "Fri Oct 19 18:41:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDxUVM",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/sNlVoik7",
      "expanded_url" : "http://twitpic.com/b5l9pw",
      "display_url" : "twitpic.com/b5l9pw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4785646, -73.1940352 ]
  },
  "id_str" : "259362574800404480",
  "text" : "Triple Helix Innovation's Melba Kurman on large scale production #TEDxUVM http://t.co/sNlVoik7",
  "id" : 259362574800404480,
  "created_at" : "Fri Oct 19 18:37:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complex",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/feREGEwy",
      "expanded_url" : "http://instagr.am/p/Q-UdHzuS2u/",
      "display_url" : "instagr.am/p/Q-UdHzuS2u/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259359316866379776",
  "text" : "MITRE and UVM Complex Systems Spire's Brian Tinvan on the rise of the machines in financial markets #complex http://t.co/feREGEwy",
  "id" : 259359316866379776,
  "created_at" : "Fri Oct 19 18:24:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complexity",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/fupOUT5N",
      "expanded_url" : "http://instagr.am/p/Q-TNKouS13/",
      "display_url" : "instagr.am/p/Q-TNKouS13/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259356685649469440",
  "text" : "UVM's Paul Hines on when and how power grids fail #complexity #TEDxUVM http://t.co/fupOUT5N",
  "id" : 259356685649469440,
  "created_at" : "Fri Oct 19 18:13:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 84, 98 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complexsystemsspire",
      "indices" : [ 53, 73 ]
    }, {
      "text" : "storylab",
      "indices" : [ 74, 83 ]
    }, {
      "text" : "TEDxUVM",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "259354215917441024",
  "text" : "at the TEDxUVM!! \"may you live in interesting times\" #complexsystemsspire #storylab @uvmcomplexity #TEDxUVM",
  "id" : 259354215917441024,
  "created_at" : "Fri Oct 19 18:03:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/VhjQRw0z",
      "expanded_url" : "http://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/",
      "display_url" : "terrytao.wordpress.com/2009/05/04/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259014264310865920",
  "text" : "a step towards making the federal budget understandable: http://t.co/VhjQRw0z",
  "id" : 259014264310865920,
  "created_at" : "Thu Oct 18 19:33:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259010927951753216",
  "geo" : {
  },
  "id_str" : "259014074870943745",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw sweeeeet!!",
  "id" : 259014074870943745,
  "in_reply_to_status_id" : 259010927951753216,
  "created_at" : "Thu Oct 18 19:32:22 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/JOpONuJR",
      "expanded_url" : "http://www.google.com/about/datacenters/gallery/#/tech/2",
      "display_url" : "google.com/about/datacent…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "259013921745285120",
  "text" : "I imagine this is what the Vermont Computer Core looks like: http://t.co/JOpONuJR",
  "id" : 259013921745285120,
  "created_at" : "Thu Oct 18 19:31:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47971827, -73.1975799 ]
  },
  "id_str" : "258913070842257408",
  "text" : "let's fit experimental data with legendre polynomials... worst idea ever",
  "id" : 258913070842257408,
  "created_at" : "Thu Oct 18 12:51:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 12, 26 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 27, 39 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 40, 48 ],
      "id_str" : "811907299",
      "id" : 811907299
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 75, 87 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superhashname",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258763849757499393",
  "geo" : {
  },
  "id_str" : "258775948932030464",
  "in_reply_to_user_id" : 468499498,
  "text" : "@peterdodds @ChrisDanforth @SumaNMNDesu @linzvee and I'll second that: let @mrfrank5790 be forever known as dodecahardon #superhashname",
  "id" : 258775948932030464,
  "in_reply_to_status_id" : 258763849757499393,
  "created_at" : "Thu Oct 18 03:46:08 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 17, 28 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 29, 43 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 44, 56 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 57, 65 ],
      "id_str" : "811907299",
      "id" : 811907299
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 78, 89 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258775347737264129",
  "text" : "RT @mrfrank5790: @peterdodds @ChrisDanforth @SumaNMNDesu @linzvee congrats to @andyreagan  who is forever more known as \"Rogue Erection\" ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Sheridan Dodds",
        "screen_name" : "peterdodds",
        "indices" : [ 0, 11 ],
        "id_str" : "16174144",
        "id" : 16174144
      }, {
        "name" : "Chris Danforth",
        "screen_name" : "ChrisDanforth",
        "indices" : [ 12, 26 ],
        "id_str" : "301579658",
        "id" : 301579658
      }, {
        "name" : "Suma",
        "screen_name" : "SumaNMNDesu",
        "indices" : [ 27, 39 ],
        "id_str" : "320551143",
        "id" : 320551143
      }, {
        "name" : "Lindsay Van Leir",
        "screen_name" : "linzvee",
        "indices" : [ 40, 48 ],
        "id_str" : "811907299",
        "id" : 811907299
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 61, 72 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "superheroname",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "258694839300923392",
    "geo" : {
    },
    "id_str" : "258763849757499393",
    "in_reply_to_user_id" : 16174144,
    "text" : "@peterdodds @ChrisDanforth @SumaNMNDesu @linzvee congrats to @andyreagan  who is forever more known as \"Rogue Erection\" #superheroname",
    "id" : 258763849757499393,
    "in_reply_to_status_id" : 258694839300923392,
    "created_at" : "Thu Oct 18 02:58:04 +0000 2012",
    "in_reply_to_screen_name" : "peterdodds",
    "in_reply_to_user_id_str" : "16174144",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 258775347737264129,
  "created_at" : "Thu Oct 18 03:43:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 58, 65 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfevident",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822531, -73.2030365 ]
  },
  "id_str" : "258412078279323648",
  "text" : "#selfevident \"I am a better talker than a write downer.\" -@sspis1",
  "id" : 258412078279323648,
  "created_at" : "Wed Oct 17 03:40:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/VhjQRw0z",
      "expanded_url" : "http://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/",
      "display_url" : "terrytao.wordpress.com/2009/05/04/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "258410134722723840",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/VhjQRw0z",
  "id" : 258410134722723840,
  "created_at" : "Wed Oct 17 03:32:31 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/YR5XgRWD",
      "expanded_url" : "http://www.radiolab.org/archive/",
      "display_url" : "radiolab.org/archive/"
    } ]
  },
  "in_reply_to_status_id_str" : "258387037730775041",
  "geo" : {
  },
  "id_str" : "258388313843568640",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr not the radiolab? you should check it out: http://t.co/YR5XgRWD",
  "id" : 258388313843568640,
  "in_reply_to_status_id" : 258387037730775041,
  "created_at" : "Wed Oct 17 02:05:49 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 76, 84 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258386549719322624",
  "text" : "time to put radiolab in the ears, open a beer, and clean the kitchen (sorry @Karo1yn )",
  "id" : 258386549719322624,
  "created_at" : "Wed Oct 17 01:58:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 54, 63 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258386312455942144",
  "text" : "if you've never played broomball, you're missing out (@dmreagan). what a fun, silly game",
  "id" : 258386312455942144,
  "created_at" : "Wed Oct 17 01:57:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 28, 41 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258385738452844544",
  "text" : "a flat-changing demo at the @UVMTriathlon meeting digressing into wheel building theory, design, the future of wheel design and braking...",
  "id" : 258385738452844544,
  "created_at" : "Wed Oct 17 01:55:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/dBcKatwg",
      "expanded_url" : "http://twitpic.com/b4t5fe",
      "display_url" : "twitpic.com/b4t5fe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822805, -73.2030363 ]
  },
  "id_str" : "258345424916725760",
  "text" : "from my dining room floor to the deep wilderness of patagonia, Stan the Stove's adventures await http://t.co/dBcKatwg",
  "id" : 258345424916725760,
  "created_at" : "Tue Oct 16 23:15:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 34, 41 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822738, -73.203038 ]
  },
  "id_str" : "258340302555865088",
  "text" : "@chaosdynamics all fun this time (@sspis1). ever been?",
  "id" : 258340302555865088,
  "created_at" : "Tue Oct 16 22:55:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258332106487382016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822791, -73.2030341 ]
  },
  "id_str" : "258340114042875905",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee only if you consider the galloping dance running!",
  "id" : 258340114042875905,
  "in_reply_to_status_id" : 258332106487382016,
  "created_at" : "Tue Oct 16 22:54:17 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258329876262699008",
  "text" : "@chaosdynamics santiago, then to puerto natales. flight to puerto natales got moved up, only 70min after i'm supposed to land in santiago...",
  "id" : 258329876262699008,
  "created_at" : "Tue Oct 16 22:13:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258328282800484352",
  "text" : "airlines suck. gahhh they decide to move a flight, i'll miss a connection in chile. (well, I'll have 70min including customs)",
  "id" : 258328282800484352,
  "created_at" : "Tue Oct 16 22:07:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "258049207573831684",
  "text" : "\"Under these circumstances it seems better to live a life in which you do important things\" -Hamming",
  "id" : 258049207573831684,
  "created_at" : "Tue Oct 16 03:38:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257983359211425792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822779, -73.2030391 ]
  },
  "id_str" : "257983603638693888",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr nah not really, oh yeah PEPPERS IN THE FRIDGE thanks for the reminder!!",
  "id" : 257983603638693888,
  "in_reply_to_status_id" : 257983359211425792,
  "created_at" : "Mon Oct 15 23:17:38 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257979520777347072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822756, -73.2030367 ]
  },
  "id_str" : "257983388424749056",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee we're both dishin out the recipes! sounds good",
  "id" : 257983388424749056,
  "in_reply_to_status_id" : 257979520777347072,
  "created_at" : "Mon Oct 15 23:16:47 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "easy",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "delicious",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "burritoman",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/AN462e0R",
      "expanded_url" : "http://twitpic.com/b4j5h3",
      "display_url" : "twitpic.com/b4j5h3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482267, -73.2030396 ]
  },
  "id_str" : "257983232098852864",
  "text" : "how to make burritos: find these and combine #easy #delicious. recipes from the #burritoman himself (me) http://t.co/AN462e0R",
  "id" : 257983232098852864,
  "created_at" : "Mon Oct 15 23:16:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 77, 84 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/M2WkDaeq",
      "expanded_url" : "http://instagr.am/p/Q0cNAkOS0v/",
      "display_url" : "instagr.am/p/Q0cNAkOS0v/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4813814261, -73.2201004028 ]
  },
  "id_str" : "257968565309816832",
  "text" : "spear-dorset loop TT'ed in &lt;1hr and back in #btv for a beautiful sunset!! @sspis1  @ Battery Park http://t.co/M2WkDaeq",
  "id" : 257968565309816832,
  "created_at" : "Mon Oct 15 22:17:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 16, 28 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 38, 51 ],
      "id_str" : "14630047",
      "id" : 14630047
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 66, 79 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 80, 92 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 93, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/IHOMMNWD",
      "expanded_url" : "http://twitpic.com/b4i85c",
      "display_url" : "twitpic.com/b4i85c"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48230854, -73.20306653 ]
  },
  "id_str" : "257942837340028928",
  "text" : "we're so famous @mrfrank5790! p 46 of @usatriathlon fall magazine @UVMTriathlon @VTTriathlon #fb http://t.co/IHOMMNWD",
  "id" : 257942837340028928,
  "created_at" : "Mon Oct 15 20:35:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/z57q9SEP",
      "expanded_url" : "http://www.forbes.com/sites/jennagoudreau/2012/10/11/the-10-worst-college-majors/",
      "display_url" : "forbes.com/sites/jennagou…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257940220622807040",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 at least you got out of Rec http://t.co/z57q9SEP",
  "id" : 257940220622807040,
  "created_at" : "Mon Oct 15 20:25:15 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/8wNBWliE",
      "expanded_url" : "http://upload.wikimedia.org/wikipedia/commons/c/cb/Replica_catapult.jpg",
      "display_url" : "upload.wikimedia.org/wikipedia/comm…"
    }, {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/P8PRJUVP",
      "expanded_url" : "http://www.uvm.edu/president/?Page=news&&storyID=14555&category=adminall",
      "display_url" : "uvm.edu/president/?Pag…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257938858786832385",
  "text" : "i've been meaning to build this to defend Farrell Hall http://t.co/8wNBWliE ...who thinks the NSF is in? http://t.co/P8PRJUVP",
  "id" : 257938858786832385,
  "created_at" : "Mon Oct 15 20:19:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 27, 42 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashnames",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "letthembenamed",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822245, -73.2030386 ]
  },
  "id_str" : "257934812319477760",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 #hashnames MT @BurlingtonHash yes, for ur own sake, it would be nice to have nice weather for circle Wednesday! #letthembenamed",
  "id" : 257934812319477760,
  "created_at" : "Mon Oct 15 20:03:46 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48216827, -73.20310687 ]
  },
  "id_str" : "257933868013854720",
  "text" : "yumm post run fresh bread!!",
  "id" : 257933868013854720,
  "created_at" : "Mon Oct 15 20:00:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257933419781181440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822394, -73.20300047 ]
  },
  "id_str" : "257933630310072320",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash sure did! hoping for this warmth to stick around!!",
  "id" : 257933630310072320,
  "in_reply_to_status_id" : 257933419781181440,
  "created_at" : "Mon Oct 15 19:59:04 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257915563689529344",
  "text" : "so warm out all the sudden! sneaking in a run",
  "id" : 257915563689529344,
  "created_at" : "Mon Oct 15 18:47:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "needtobakemoreduringtheday",
      "indices" : [ 32, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257915481468567552",
  "text" : "house smells like a bakery #yum #needtobakemoreduringtheday",
  "id" : 257915481468567552,
  "created_at" : "Mon Oct 15 18:46:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257876988965040128",
  "geo" : {
  },
  "id_str" : "257915090945310720",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 from what I can tell there were at least 79 in your age group, 180 overall so that's awesome!!",
  "id" : 257915090945310720,
  "in_reply_to_status_id" : 257876988965040128,
  "created_at" : "Mon Oct 15 18:45:24 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "indices" : [ 3, 10 ],
      "id_str" : "24074204",
      "id" : 24074204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257599876781731840",
  "text" : "RT @BenCiv: Attempting to jump from the Procrastosphere and free-fall into the Efficiezone where I will deploy my Productochute.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "257595913411887104",
    "text" : "Attempting to jump from the Procrastosphere and free-fall into the Efficiezone where I will deploy my Productochute.",
    "id" : 257595913411887104,
    "created_at" : "Sun Oct 14 21:37:06 +0000 2012",
    "user" : {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "protected" : false,
      "id_str" : "24074204",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1439138593/IMG_0964_normal.JPG",
      "id" : 24074204,
      "verified" : false
    }
  },
  "id" : 257599876781731840,
  "created_at" : "Sun Oct 14 21:52:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257582738050281472",
  "geo" : {
  },
  "id_str" : "257585196805795841",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I call next!",
  "id" : 257585196805795841,
  "in_reply_to_status_id" : 257582738050281472,
  "created_at" : "Sun Oct 14 20:54:31 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Men's Humor",
      "screen_name" : "MensHumor",
      "indices" : [ 3, 13 ],
      "id_str" : "355741893",
      "id" : 355741893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sp",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257546851430051841",
  "text" : "RT @MensHumor: Not only did Felix Baumgartner break the sound barrier, he's the first man who will never have to pay for beer again. #sp ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spacejump",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "257546300680187904",
    "text" : "Not only did Felix Baumgartner break the sound barrier, he's the first man who will never have to pay for beer again. #spacejump",
    "id" : 257546300680187904,
    "created_at" : "Sun Oct 14 18:19:57 +0000 2012",
    "user" : {
      "name" : "Men's Humor",
      "screen_name" : "MensHumor",
      "protected" : false,
      "id_str" : "355741893",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1497390278/mhlogo5_normal.jpg",
      "id" : 355741893,
      "verified" : true
    }
  },
  "id" : 257546851430051841,
  "created_at" : "Sun Oct 14 18:22:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livejump",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257546754399035392",
  "text" : "can't blame a man for pulling his chute when his visor is so fogged he can't see the ground!! three records broken anyway #livejump",
  "id" : 257546754399035392,
  "created_at" : "Sun Oct 14 18:21:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livejump",
      "indices" : [ 7, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257542848419860480",
  "text" : "jump!! #livejump",
  "id" : 257542848419860480,
  "created_at" : "Sun Oct 14 18:06:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/FXnx28Uo",
      "expanded_url" : "http://redbullstratos.com/live/",
      "display_url" : "redbullstratos.com/live/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257542762528911360",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 watch now http://t.co/FXnx28Uo",
  "id" : 257542762528911360,
  "created_at" : "Sun Oct 14 18:05:54 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badass",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "livejump",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257531930927566848",
  "text" : "still most impressed by Kittinger doing this in an open basket with a ripped glove in 1960 #badass #livejump",
  "id" : 257531930927566848,
  "created_at" : "Sun Oct 14 17:22:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822586, -73.203007 ]
  },
  "id_str" : "257290326832713728",
  "text" : "day well spent watching Kona, brewin and drinkin beers! Almost done with the boil",
  "id" : 257290326832713728,
  "created_at" : "Sun Oct 14 01:22:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/MXjmdVnE",
      "expanded_url" : "http://connect.garmin.com/activity/232977921",
      "display_url" : "connect.garmin.com/activity/23297…"
    }, {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/3Qd8o5PS",
      "expanded_url" : "http://connect.garmin.com/activity/232977933",
      "display_url" : "connect.garmin.com/activity/23297…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "257190080677027841",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 ride http://t.co/MXjmdVnE race http://t.co/3Qd8o5PS being just like you :)",
  "id" : 257190080677027841,
  "created_at" : "Sat Oct 13 18:44:28 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyclocross",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "biathlon",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "EABC",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822063, -73.2030234 ]
  },
  "id_str" : "257170743857647616",
  "text" : "had a great time racing bikes and shooting guns! #cyclocross #biathlon #EABC",
  "id" : 257170743857647616,
  "created_at" : "Sat Oct 13 17:27:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notreally",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.467635, -72.93588041 ]
  },
  "id_str" : "257129481758732288",
  "text" : "target practice was fun! they nicknamed me \"dead eye reagan\" #notreally",
  "id" : 257129481758732288,
  "created_at" : "Sat Oct 13 14:43:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gettinit",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/c3XrnEFB",
      "expanded_url" : "http://twitpic.com/b3risc",
      "display_url" : "twitpic.com/b3risc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46740564, -72.93585158 ]
  },
  "id_str" : "257118979791941632",
  "text" : "twas a cold ride, and I'm at the EABC! bib #1 #gettinit http://t.co/c3XrnEFB",
  "id" : 257118979791941632,
  "created_at" : "Sat Oct 13 14:01:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 67, 74 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "257080426882007041",
  "text" : "a balmy 27deg out right now (\"feels like\" 22)...here goes nothing! @sspis1",
  "id" : 257080426882007041,
  "created_at" : "Sat Oct 13 11:28:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/53k6Ezq1",
      "expanded_url" : "http://twitpic.com/b3kl1x",
      "display_url" : "twitpic.com/b3kl1x"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822828, -73.2030114 ]
  },
  "id_str" : "256932520820604928",
  "text" : "all set to race the cyclocross biathlon tomorrow! 17mi ride there, forecast 34deg then w.o. wind chill! http://t.co/53k6Ezq1",
  "id" : 256932520820604928,
  "created_at" : "Sat Oct 13 01:41:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256930134156779520",
  "geo" : {
  },
  "id_str" : "256931361842155520",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser wait, I thought I got the laptop/serving tray model... haha I do have a dining table that I actually ate at, don't worry",
  "id" : 256931361842155520,
  "in_reply_to_status_id" : 256930134156779520,
  "created_at" : "Sat Oct 13 01:36:24 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "college",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/A4HNvbNE",
      "expanded_url" : "http://twitpic.com/b3jqyo",
      "display_url" : "twitpic.com/b3jqyo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822712, -73.2030224 ]
  },
  "id_str" : "256903578147487744",
  "text" : "burritos and O.J. for dinner #college http://t.co/A4HNvbNE",
  "id" : 256903578147487744,
  "created_at" : "Fri Oct 12 23:46:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256880306051764224",
  "text" : "accidentally deleted code files in terminal. LIFE SAVED by time machine. I may officially be a Mac convert now",
  "id" : 256880306051764224,
  "created_at" : "Fri Oct 12 22:13:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 1, 15 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/D6ghjRc5",
      "expanded_url" : "http://instagr.am/p/QsppzkOS1P/",
      "display_url" : "instagr.am/p/QsppzkOS1P/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4833664126, -73.1935658515 ]
  },
  "id_str" : "256872379261784064",
  "text" : ".@chriskingbuzz R45 Hub Tool has arrived, I can't wait to open up the hubs!!  @ UVM Farrell Hall http://t.co/D6ghjRc5",
  "id" : 256872379261784064,
  "created_at" : "Fri Oct 12 21:42:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toosoon",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256857618784612352",
  "text" : "no wonder I put on the winter jacket...it's 42 and really windy here #toosoon",
  "id" : 256857618784612352,
  "created_at" : "Fri Oct 12 20:43:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256857357974376448",
  "text" : "nothing quite like assembling a bike for my roommate two hours before the team leaves for the race weekend! riding around two bikes one guy",
  "id" : 256857357974376448,
  "created_at" : "Fri Oct 12 20:42:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 3, 13 ],
      "id_str" : "14666918",
      "id" : 14666918
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256856339362484224",
  "text" : "RT @axetickle @andyreagan step six: make her open the box",
  "id" : 256856339362484224,
  "created_at" : "Fri Oct 12 20:38:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "indices" : [ 3, 15 ],
      "id_str" : "19368361",
      "id" : 19368361
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/bikesnobnyc/status/256801561685139456/photo/1",
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/cKHolYOQ",
      "media_url" : "http://pbs.twimg.com/media/A5BXqShCIAA2mPS.jpg",
      "id_str" : "256801562796630016",
      "id" : 256801562796630016,
      "media_url_https" : "https://pbs.twimg.com/media/A5BXqShCIAA2mPS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/cKHolYOQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256803786805370880",
  "text" : "RT @bikesnobnyc: Added security. http://t.co/cKHolYOQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/bikesnobnyc/status/256801561685139456/photo/1",
        "indices" : [ 16, 36 ],
        "url" : "http://t.co/cKHolYOQ",
        "media_url" : "http://pbs.twimg.com/media/A5BXqShCIAA2mPS.jpg",
        "id_str" : "256801562796630016",
        "id" : 256801562796630016,
        "media_url_https" : "https://pbs.twimg.com/media/A5BXqShCIAA2mPS.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/cKHolYOQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "256801561685139456",
    "text" : "Added security. http://t.co/cKHolYOQ",
    "id" : 256801561685139456,
    "created_at" : "Fri Oct 12 17:00:38 +0000 2012",
    "user" : {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "protected" : false,
      "id_str" : "19368361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/700549149/Seal-2009-Combo-REF_normal.jpg",
      "id" : 19368361,
      "verified" : false
    }
  },
  "id" : 256803786805370880,
  "created_at" : "Fri Oct 12 17:09:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 67, 78 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCRAPS",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "fundamentality",
      "indices" : [ 91, 106 ]
    }, {
      "text" : "storylab",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256801384169615360",
  "text" : "RT @SumaNMNDesu: Awesome Analysis theorem network visualization by @andyreagan at #SCRAPS. #fundamentality #storylab",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 50, 61 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCRAPS",
        "indices" : [ 65, 72 ]
      }, {
        "text" : "fundamentality",
        "indices" : [ 74, 89 ]
      }, {
        "text" : "storylab",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "256784170272051200",
    "text" : "Awesome Analysis theorem network visualization by @andyreagan at #SCRAPS. #fundamentality #storylab",
    "id" : 256784170272051200,
    "created_at" : "Fri Oct 12 15:51:31 +0000 2012",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 256801384169615360,
  "created_at" : "Fri Oct 12 16:59:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 3, 11 ],
      "id_str" : "811907299",
      "id" : 811907299
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 13, 24 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "SCRAPS",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256801332571287552",
  "text" : "RT @linzvee: @andyreagan The connectedness of all theorems of analysis... what can we conclude about our own logic? #sick #SCRAPS http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/linzvee/status/256785846911520768/photo/1",
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/Q9tmzlgR",
        "media_url" : "http://pbs.twimg.com/media/A5BJXgUCUAEI9b3.jpg",
        "id_str" : "256785846919909377",
        "id" : 256785846919909377,
        "media_url_https" : "https://pbs.twimg.com/media/A5BJXgUCUAEI9b3.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com/Q9tmzlgR"
      } ],
      "hashtags" : [ {
        "text" : "sick",
        "indices" : [ 103, 108 ]
      }, {
        "text" : "SCRAPS",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 44.4894191, -73.179073 ]
    },
    "id_str" : "256785846911520768",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan The connectedness of all theorems of analysis... what can we conclude about our own logic? #sick #SCRAPS http://t.co/Q9tmzlgR",
    "id" : 256785846911520768,
    "created_at" : "Fri Oct 12 15:58:12 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "protected" : false,
      "id_str" : "811907299",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2609674893/816m0iuvbbybuvqvb8io_normal.jpeg",
      "id" : 811907299,
      "verified" : false
    }
  },
  "id" : 256801332571287552,
  "created_at" : "Fri Oct 12 16:59:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256798494642274304",
  "text" : "step four: come up to your office, and immediately find your (missing for two days) cell phone. step five: find a borrowed mac vga adapter",
  "id" : 256798494642274304,
  "created_at" : "Fri Oct 12 16:48:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256798223807692801",
  "text" : "step three: give a well received talk about logical structure, and eat free pizza for lunch.",
  "id" : 256798223807692801,
  "created_at" : "Fri Oct 12 16:47:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256798024406286336",
  "text" : "bike to class in 2:20 min, passing \\infty cars, and cover the MCT, Fatou's Lemma, and Lebesgue Dominated Conv in one day",
  "id" : 256798024406286336,
  "created_at" : "Fri Oct 12 16:46:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256797793518247936",
  "text" : "how to have an excellent day, step one: wake up early and finish code, run it just in time for class",
  "id" : 256797793518247936,
  "created_at" : "Fri Oct 12 16:45:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/BkhfhF8T",
      "expanded_url" : "http://connect.garmin.com/activity/232467798",
      "display_url" : "connect.garmin.com/activity/23246…"
    } ]
  },
  "in_reply_to_status_id_str" : "256442589463584768",
  "geo" : {
  },
  "id_str" : "256571868532842496",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash sure! http://t.co/BkhfhF8T",
  "id" : 256571868532842496,
  "in_reply_to_status_id" : 256442589463584768,
  "created_at" : "Fri Oct 12 01:47:54 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Kaelyn Madden",
      "screen_name" : "C00lAsACucumber",
      "indices" : [ 12, 28 ],
      "id_str" : "447619620",
      "id" : 447619620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256523602223054848",
  "geo" : {
  },
  "id_str" : "256543677114114049",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 @C00lAsACucumber like bosses we did. and by bosses, I mean slowly and carefully :P",
  "id" : 256543677114114049,
  "in_reply_to_status_id" : 256523602223054848,
  "created_at" : "Thu Oct 11 23:55:53 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "256513015220953088",
  "text" : "lost in coding...missed lunch and my one appt for the day #whoops. on another note, I've calculated the most fundamental thm in analysis",
  "id" : 256513015220953088,
  "created_at" : "Thu Oct 11 21:54:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/rtZLOGq2",
      "expanded_url" : "http://hilljunkie.blogspot.com/2012/10/watts-in-kilojoule.html",
      "display_url" : "hilljunkie.blogspot.com/2012/10/watts-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256410512525516800",
  "text" : "a good piece on some basic energy literacy: http://t.co/rtZLOGq2",
  "id" : 256410512525516800,
  "created_at" : "Thu Oct 11 15:06:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256400176976125952",
  "geo" : {
  },
  "id_str" : "256406903503077377",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw excellent!! scary part is, I have some idea what these things are...",
  "id" : 256406903503077377,
  "in_reply_to_status_id" : 256400176976125952,
  "created_at" : "Thu Oct 11 14:52:24 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/bqDJyPTe",
      "expanded_url" : "http://theproofistrivial.com",
      "display_url" : "theproofistrivial.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256406751254028288",
  "text" : "\"Trivial! Just biject it to a Noetherian Hilbert space whose elements are computable unbounded-fan-in circuits\" http://t.co/bqDJyPTe",
  "id" : 256406751254028288,
  "created_at" : "Thu Oct 11 14:51:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 12, 23 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/7csNP18I",
      "expanded_url" : "http://amzn.com/k/ph_VMrQYRVmKxrd7iR5cKA",
      "display_url" : "amzn.com/k/ph_VMrQYRVmK…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "256217018502627329",
  "text" : "RT @sspis1: @andyreagan ...reminded me of your hw http://t.co/7csNP18I #Kindle",
  "retweeted_status" : {
    "source" : "<a href=\"https://kindle.amazon.com\" rel=\"nofollow\">Kindle</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http://t.co/7csNP18I",
        "expanded_url" : "http://amzn.com/k/ph_VMrQYRVmKxrd7iR5cKA",
        "display_url" : "amzn.com/k/ph_VMrQYRVmK…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "256066798011678720",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan ...reminded me of your hw http://t.co/7csNP18I #Kindle",
    "id" : 256066798011678720,
    "created_at" : "Wed Oct 10 16:20:56 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 256217018502627329,
  "created_at" : "Thu Oct 11 02:17:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikesandguns",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255842774140735488",
  "text" : "watching the 2010 olympic biathlon...in preparation for this Saturday's CYCLOCROSS BIATHLON #bikesandguns",
  "id" : 255842774140735488,
  "created_at" : "Wed Oct 10 01:30:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/ozFxH29K",
      "expanded_url" : "http://twitpic.com/b2pbua",
      "display_url" : "twitpic.com/b2pbua"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822079, -73.2030155 ]
  },
  "id_str" : "255842276394299393",
  "text" : "my roommate comes into the living room with my new mountain bike fork \"andy, why the heck did you buy a pogo stick?\" http://t.co/ozFxH29K",
  "id" : 255842276394299393,
  "created_at" : "Wed Oct 10 01:28:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/FS786X3y",
      "expanded_url" : "http://twitpic.com/b2oftj",
      "display_url" : "twitpic.com/b2oftj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822704, -73.2030185 ]
  },
  "id_str" : "255803341941141504",
  "text" : "bike all set up! test spin around neighborhood success. next up: strava crushing tomorrow AM http://t.co/FS786X3y",
  "id" : 255803341941141504,
  "created_at" : "Tue Oct 09 22:54:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/rjnFJ3hN",
      "expanded_url" : "http://twitpic.com/b2o2do",
      "display_url" : "twitpic.com/b2o2do"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822634, -73.2030068 ]
  },
  "id_str" : "255786755008118784",
  "text" : "need a can to shim the FD for a ride...time to start drinking! http://t.co/rjnFJ3hN",
  "id" : 255786755008118784,
  "created_at" : "Tue Oct 09 21:48:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255716479922737153",
  "geo" : {
  },
  "id_str" : "255717087123755008",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 probably around 4?",
  "id" : 255717087123755008,
  "in_reply_to_status_id" : 255716479922737153,
  "created_at" : "Tue Oct 09 17:11:19 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.redbullstratos.com/\" rel=\"nofollow\">Red Bull Stratos</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull Stratos",
      "screen_name" : "RedBullStratos",
      "indices" : [ 67, 82 ],
      "id_str" : "64767273",
      "id" : 64767273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/Af5uLB0p",
      "expanded_url" : "http://win.gs/MMskNw",
      "display_url" : "win.gs/MMskNw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "255716393822076929",
  "text" : "I estimated where Felix Baumgartner will land when he attempts the @redbullstratos record breaking freefall jump http://t.co/Af5uLB0p",
  "id" : 255716393822076929,
  "created_at" : "Tue Oct 09 17:08:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255670046150508544",
  "text" : "no time for breakfast: make it in class, get called out by professor for not bringing him some",
  "id" : 255670046150508544,
  "created_at" : "Tue Oct 09 14:04:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/Z2dEDpFn",
      "expanded_url" : "http://nyti.ms/UASnA2",
      "display_url" : "nyti.ms/UASnA2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "255493271307026432",
  "text" : "RT @dr_pyser: guys, just FYI, this is some crazy and amazing bullshit that some lunatic is about to do: http://t.co/Z2dEDpFn",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/Z2dEDpFn",
        "expanded_url" : "http://nyti.ms/UASnA2",
        "display_url" : "nyti.ms/UASnA2"
      } ]
    },
    "geo" : {
    },
    "id_str" : "255490694125330432",
    "text" : "guys, just FYI, this is some crazy and amazing bullshit that some lunatic is about to do: http://t.co/Z2dEDpFn",
    "id" : 255490694125330432,
    "created_at" : "Tue Oct 09 02:11:42 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 255493271307026432,
  "created_at" : "Tue Oct 09 02:21:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 11, 18 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255488983323254784",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 yo @sspis1 and I were wondering what that photo app was??",
  "id" : 255488983323254784,
  "created_at" : "Tue Oct 09 02:04:55 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 12, 19 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 46, 57 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truestory",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "18holesin22minutes",
      "indices" : [ 58, 77 ]
    }, {
      "text" : "mustbethebeard",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255169114220408832",
  "text" : "#truestory \"@dzdan1 They call me 'The Runner' @andyreagan #18holesin22minutes #mustbethebeard\"",
  "id" : 255169114220408832,
  "created_at" : "Mon Oct 08 04:53:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255128355924488194",
  "geo" : {
  },
  "id_str" : "255129997084340224",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 I guess we're all one tweet away from hitting a tree and dying",
  "id" : 255129997084340224,
  "in_reply_to_status_id" : 255128355924488194,
  "created_at" : "Mon Oct 08 02:18:26 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "255037430963527680",
  "text" : "stellar foliage out in Waterbury",
  "id" : 255037430963527680,
  "created_at" : "Sun Oct 07 20:10:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Otto the Ottoman",
      "screen_name" : "ottotheotto",
      "indices" : [ 3, 15 ],
      "id_str" : "865842546",
      "id" : 865842546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254833450899632128",
  "text" : "RT @ottotheotto: get yo smelly feet off me",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "254827115684442112",
    "text" : "get yo smelly feet off me",
    "id" : 254827115684442112,
    "created_at" : "Sun Oct 07 06:14:53 +0000 2012",
    "user" : {
      "name" : "Otto the Ottoman",
      "screen_name" : "ottotheotto",
      "protected" : false,
      "id_str" : "865842546",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2689501518/e9ee3e07224dddb1fa3c98b00b2a666a_normal.jpeg",
      "id" : 865842546,
      "verified" : false
    }
  },
  "id" : 254833450899632128,
  "created_at" : "Sun Oct 07 06:40:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaelyn Madden",
      "screen_name" : "C00lAsACucumber",
      "indices" : [ 0, 16 ],
      "id_str" : "447619620",
      "id" : 447619620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254806044063186944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208985, -73.20325013 ]
  },
  "id_str" : "254831370818445312",
  "in_reply_to_user_id" : 447619620,
  "text" : "@C00lAsACucumber omg kaelyn!! that sounds sooo tough, get outside girl!",
  "id" : 254831370818445312,
  "in_reply_to_status_id" : 254806044063186944,
  "created_at" : "Sun Oct 07 06:31:47 +0000 2012",
  "in_reply_to_screen_name" : "C00lAsACucumber",
  "in_reply_to_user_id_str" : "447619620",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48173824, -73.20339539 ]
  },
  "id_str" : "254825838762143744",
  "text" : "crazy times, lessons learned",
  "id" : 254825838762143744,
  "created_at" : "Sun Oct 07 06:09:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254752014083432448",
  "text" : "table next to us talking about \"indiana pale ale\" hahaha",
  "id" : 254752014083432448,
  "created_at" : "Sun Oct 07 01:16:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 1, 8 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "dasbierhaus",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254751368122859520",
  "text" : ".@DZdan1 in the #btv!! #dasbierhaus",
  "id" : 254751368122859520,
  "created_at" : "Sun Oct 07 01:13:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Monty ",
      "screen_name" : "VermontSongbird",
      "indices" : [ 0, 16 ],
      "id_str" : "21343505",
      "id" : 21343505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254682446702977024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46040508, -73.20883722 ]
  },
  "id_str" : "254696347477872640",
  "in_reply_to_user_id" : 21343505,
  "text" : "@VermontSongbird where is that??",
  "id" : 254696347477872640,
  "in_reply_to_status_id" : 254682446702977024,
  "created_at" : "Sat Oct 06 21:35:15 +0000 2012",
  "in_reply_to_screen_name" : "VermontSongbird",
  "in_reply_to_user_id_str" : "21343505",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goals",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820942, -73.20309578 ]
  },
  "id_str" : "254665302237929472",
  "text" : "made enough progress on my hw to play with powertools for the motorcycle now #goals",
  "id" : 254665302237929472,
  "created_at" : "Sat Oct 06 19:31:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "karma",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "mathgradlife",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254662848716886016",
  "text" : "chuckling at how obvious a proof is...then spending 30 minutes trying to formalize that #karma #mathgradlife",
  "id" : 254662848716886016,
  "created_at" : "Sat Oct 06 19:22:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254576754360975361",
  "geo" : {
  },
  "id_str" : "254594110663557120",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 woooo!!",
  "id" : 254594110663557120,
  "in_reply_to_status_id" : 254576754360975361,
  "created_at" : "Sat Oct 06 14:49:00 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254375503136428032",
  "geo" : {
  },
  "id_str" : "254381232102707200",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill haha just in time to put on the trainer and get ready for next year I hope",
  "id" : 254381232102707200,
  "in_reply_to_status_id" : 254375503136428032,
  "created_at" : "Sat Oct 06 00:43:06 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/254366186794528768/photo/1",
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/BZFG5cg0",
      "media_url" : "http://pbs.twimg.com/media/A4ewsv8CMAIh3bj.jpg",
      "id_str" : "254366186798723074",
      "id" : 254366186798723074,
      "media_url_https" : "https://pbs.twimg.com/media/A4ewsv8CMAIh3bj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com/BZFG5cg0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254319745640312833",
  "geo" : {
  },
  "id_str" : "254366186794528768",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT I'm in, check out the new rig http://t.co/BZFG5cg0",
  "id" : 254366186794528768,
  "in_reply_to_status_id" : 254319745640312833,
  "created_at" : "Fri Oct 05 23:43:20 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisa McGowan",
      "screen_name" : "AMCG913",
      "indices" : [ 0, 8 ],
      "id_str" : "351965147",
      "id" : 351965147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "champstatus",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254359887876853760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48206508, -73.20314206 ]
  },
  "id_str" : "254363164286791680",
  "in_reply_to_user_id" : 351965147,
  "text" : "@AMCG913 heard you did 10 miles #champstatus",
  "id" : 254363164286791680,
  "in_reply_to_status_id" : 254359887876853760,
  "created_at" : "Fri Oct 05 23:31:18 +0000 2012",
  "in_reply_to_screen_name" : "AMCG913",
  "in_reply_to_user_id_str" : "351965147",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/wIHeyFgu",
      "expanded_url" : "http://twitpic.com/b1d6ls",
      "display_url" : "twitpic.com/b1d6ls"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208126, -73.20312568 ]
  },
  "id_str" : "254363124830969856",
  "text" : "fitted and assembled the TT machine all afternoon, it's looking mean!! http://t.co/wIHeyFgu",
  "id" : 254363124830969856,
  "created_at" : "Fri Oct 05 23:31:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254272707615662081",
  "text" : "looked at the motorcycle with patience, found the choke cable going into carbs, followed under the seat...used it and bike fired right up",
  "id" : 254272707615662081,
  "created_at" : "Fri Oct 05 17:31:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/BQW2x3lI",
      "expanded_url" : "http://bit.ly/WupPp5",
      "display_url" : "bit.ly/WupPp5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "254220851367522304",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/BQW2x3lI",
  "id" : 254220851367522304,
  "created_at" : "Fri Oct 05 14:05:48 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/BQW2x3lI",
      "expanded_url" : "http://bit.ly/WupPp5",
      "display_url" : "bit.ly/WupPp5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "254220762750267392",
  "text" : "between a rock and carburetor rebuild http://t.co/BQW2x3lI",
  "id" : 254220762750267392,
  "created_at" : "Fri Oct 05 14:05:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damn",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48213885, -73.20304832 ]
  },
  "id_str" : "254202570229293056",
  "text" : "so we go to take the motorcycle. won't start. cant find choke. eventually realize choke lever broken off. now that battery is dead too #damn",
  "id" : 254202570229293056,
  "created_at" : "Fri Oct 05 12:53:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48218883, -73.20287352 ]
  },
  "id_str" : "254202226602553344",
  "text" : "go to start my car for first time in a month (to take roommate to train) and it's dead. go figure. probably just needs a jump",
  "id" : 254202226602553344,
  "created_at" : "Fri Oct 05 12:51:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classic",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "254047469569204224",
  "text" : "woke up from a nap and thought it was the morning #classic",
  "id" : 254047469569204224,
  "created_at" : "Fri Oct 05 02:36:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48210598, -73.20311362 ]
  },
  "id_str" : "253948619256913920",
  "text" : "thunderstorm = naptime",
  "id" : 253948619256913920,
  "created_at" : "Thu Oct 04 20:04:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253626738658140160",
  "geo" : {
  },
  "id_str" : "253932506762579968",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 I would SO be there!!",
  "id" : 253932506762579968,
  "in_reply_to_status_id" : 253626738658140160,
  "created_at" : "Thu Oct 04 19:00:02 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VIM4life",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "nerdtweet",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253932275329273858",
  "text" : "who writes MATLAB code in MATLAB these days anyway? #VIM4life #nerdtweet",
  "id" : 253932275329273858,
  "created_at" : "Thu Oct 04 18:59:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 17, 29 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/4YzW8xsS",
      "expanded_url" : "http://www.collegehumor.com/video/6830834",
      "display_url" : "collegehumor.com/video/6830834"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253930258041024512",
  "text" : "RT @mrfrank5790: @SumaNMNDesu Watching Mitt Romney Style (Gangnam Style Parody) on CollegeHumor http://t.co/4YzW8xsS",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Suma",
        "screen_name" : "SumaNMNDesu",
        "indices" : [ 0, 12 ],
        "id_str" : "320551143",
        "id" : 320551143
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/4YzW8xsS",
        "expanded_url" : "http://www.collegehumor.com/video/6830834",
        "display_url" : "collegehumor.com/video/6830834"
      } ]
    },
    "geo" : {
    },
    "id_str" : "253925448780771328",
    "in_reply_to_user_id" : 320551143,
    "text" : "@SumaNMNDesu Watching Mitt Romney Style (Gangnam Style Parody) on CollegeHumor http://t.co/4YzW8xsS",
    "id" : 253925448780771328,
    "created_at" : "Thu Oct 04 18:31:59 +0000 2012",
    "in_reply_to_screen_name" : "SumaNMNDesu",
    "in_reply_to_user_id_str" : "320551143",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 253930258041024512,
  "created_at" : "Thu Oct 04 18:51:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 54 ],
      "url" : "https://t.co/lRinaSfj",
      "expanded_url" : "https://www.bikereg.com/Net/17411",
      "display_url" : "bikereg.com/Net/17411"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253921553593552896",
  "text" : "a cyclocross biathlon?? awesome! https://t.co/lRinaSfj",
  "id" : 253921553593552896,
  "created_at" : "Thu Oct 04 18:16:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny",
      "screen_name" : "magoonski",
      "indices" : [ 0, 10 ],
      "id_str" : "16171391",
      "id" : 16171391
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hadtosayit",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253614685100843009",
  "geo" : {
  },
  "id_str" : "253667386547396610",
  "in_reply_to_user_id" : 16171391,
  "text" : "@magoonski bitch I go to work #hadtosayit",
  "id" : 253667386547396610,
  "in_reply_to_status_id" : 253614685100843009,
  "created_at" : "Thu Oct 04 01:26:32 +0000 2012",
  "in_reply_to_screen_name" : "magoonski",
  "in_reply_to_user_id_str" : "16171391",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 9, 22 ],
      "id_str" : "17900130",
      "id" : 17900130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/RYkuAFJH",
      "expanded_url" : "http://ow.ly/ea7Tr",
      "display_url" : "ow.ly/ea7Tr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253666364378738689",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill \"@bicyclingmag Big hills, fast descents and local wine make central New York a cycling nirvana: http://t.co/RYkuAFJH\"",
  "id" : 253666364378738689,
  "created_at" : "Thu Oct 04 01:22:28 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 99, 111 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/9ZOEQled",
      "expanded_url" : "http://xkcd.com/323/",
      "display_url" : "xkcd.com/323/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253665659345584130",
  "text" : "after a fantastic hash, I'm hoping for the elusive balmer's peak on my PDE hw http://t.co/9ZOEQled @mrfrank5790",
  "id" : 253665659345584130,
  "created_at" : "Thu Oct 04 01:19:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 69, 81 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uhoh",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/SOUUmB1O",
      "expanded_url" : "http://twitpic.com/b0qyms",
      "display_url" : "twitpic.com/b0qyms"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4914175, -73.1908945 ]
  },
  "id_str" : "253586616344514560",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash I think we've got an overachiever on our hands #uhoh @mrfrank5790 http://t.co/SOUUmB1O",
  "id" : 253586616344514560,
  "created_at" : "Wed Oct 03 20:05:35 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 48, 60 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/m3kfUWk8",
      "expanded_url" : "http://twitpic.com/b0qts2",
      "display_url" : "twitpic.com/b0qts2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47572422, -73.19603854 ]
  },
  "id_str" : "253580705269940224",
  "text" : "UVM Student Scholar Poster Competition CHAMPION @mrfrank5790 #storylab http://t.co/m3kfUWk8",
  "id" : 253580705269940224,
  "created_at" : "Wed Oct 03 19:42:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 108, 115 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/BeK8BIIh",
      "expanded_url" : "http://www.gochile.cl/en/index.php?view=article&catid=62%3Atorres-del-paine&id=1429%3Amap-parque-nacional-torres-del-paine&tmpl=component&print=1&layout=default&page=&option=com_content&Itemid=76",
      "display_url" : "gochile.cl/en/index.php?v…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253538765728010240",
  "text" : "were you looking for a good map of Torres Del Paine national park in Patagonia, Chile? http://t.co/BeK8BIIh @sspis1",
  "id" : 253538765728010240,
  "created_at" : "Wed Oct 03 16:55:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "indices" : [ 3, 16 ],
      "id_str" : "14882900",
      "id" : 14882900
    }, {
      "name" : "Altra Footwear",
      "screen_name" : "AltraZeroDrop",
      "indices" : [ 78, 92 ],
      "id_str" : "146668923",
      "id" : 146668923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/6zYUxzjY",
      "expanded_url" : "http://twitpic.com/b0nrja",
      "display_url" : "twitpic.com/b0nrja"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253538567656202240",
  "text" : "RT @runnersworld: SPONSORED: Add some LIFE to your days! From your friends at @AltraZeroDrop http://t.co/6zYUxzjY",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Altra Footwear",
        "screen_name" : "AltraZeroDrop",
        "indices" : [ 60, 74 ],
        "id_str" : "146668923",
        "id" : 146668923
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/6zYUxzjY",
        "expanded_url" : "http://twitpic.com/b0nrja",
        "display_url" : "twitpic.com/b0nrja"
      } ]
    },
    "geo" : {
    },
    "id_str" : "253537816649285632",
    "text" : "SPONSORED: Add some LIFE to your days! From your friends at @AltraZeroDrop http://t.co/6zYUxzjY",
    "id" : 253537816649285632,
    "created_at" : "Wed Oct 03 16:51:40 +0000 2012",
    "user" : {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "protected" : false,
      "id_str" : "14882900",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3207393329/d6f10524b380d7bb42b1ae48ca839d79_normal.jpeg",
      "id" : 14882900,
      "verified" : true
    }
  },
  "id" : 253538567656202240,
  "created_at" : "Wed Oct 03 16:54:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 107, 118 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253524878211309569",
  "text" : "RT @SumaNMNDesu: \"The director of homeland security is a woman? They should rename it homeland insecurity\" @andyreagan",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 90, 101 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "253524547993755648",
    "text" : "\"The director of homeland security is a woman? They should rename it homeland insecurity\" @andyreagan",
    "id" : 253524547993755648,
    "created_at" : "Wed Oct 03 15:58:57 +0000 2012",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 253524878211309569,
  "created_at" : "Wed Oct 03 16:00:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48211475, -73.2030217 ]
  },
  "id_str" : "253471197281529857",
  "in_reply_to_user_id" : 16174144,
  "text" : "@peterdodds bring your copy of USA Triathlon Magazine to the meeting if you have it!",
  "id" : 253471197281529857,
  "created_at" : "Wed Oct 03 12:26:57 +0000 2012",
  "in_reply_to_screen_name" : "peterdodds",
  "in_reply_to_user_id_str" : "16174144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https://t.co/yS7FjFdF",
      "expanded_url" : "https://www.facebook.com/newenglandbuildersball",
      "display_url" : "facebook.com/newenglandbuil…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "253211402838368256",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 if you're looking for something to do Fri night... I'd be here if I were you lol https://t.co/yS7FjFdF",
  "id" : 253211402838368256,
  "created_at" : "Tue Oct 02 19:14:37 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "253117924607397888",
  "text" : "RT @MotherJones: 5 big things will decide the future of this country, but you're not going to hear about them in the debates. http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/k3lOZQTJ",
        "expanded_url" : "http://ow.ly/e8tIm",
        "display_url" : "ow.ly/e8tIm"
      } ]
    },
    "geo" : {
    },
    "id_str" : "253087344096329728",
    "text" : "5 big things will decide the future of this country, but you're not going to hear about them in the debates. http://t.co/k3lOZQTJ",
    "id" : 253087344096329728,
    "created_at" : "Tue Oct 02 11:01:39 +0000 2012",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2151511111/twitter-logo128_normal.jpg",
      "id" : 18510860,
      "verified" : false
    }
  },
  "id" : 253117924607397888,
  "created_at" : "Tue Oct 02 13:03:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/8KVGNxWK",
      "expanded_url" : "http://connect.garmin.com/activity/229114959",
      "display_url" : "connect.garmin.com/activity/22911…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252963920288034816",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/8KVGNxWK",
  "id" : 252963920288034816,
  "created_at" : "Tue Oct 02 02:51:13 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252840657469722624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.483168, -73.1932317 ]
  },
  "id_str" : "252847119239639040",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill trainer? what is that?",
  "id" : 252847119239639040,
  "in_reply_to_status_id" : 252840657469722624,
  "created_at" : "Mon Oct 01 19:07:05 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 1, 13 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252830856178200576",
  "text" : ".@mrfrank5790 and I have determined that I can produce 1,133 HP (HAMSTER POWER)",
  "id" : 252830856178200576,
  "created_at" : "Mon Oct 01 18:02:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 79, 91 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/Ge37gTXE",
      "expanded_url" : "http://twitter.com/ChrisDanforth/status/252803990432133120/photo/1",
      "display_url" : "pic.twitter.com/Ge37gTXE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252804979788759041",
  "text" : "RT @ChrisDanforth: Athletic excitement in #storylab as heard and translated by @SumaNMNDesu http://t.co/Ge37gTXE",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Suma",
        "screen_name" : "SumaNMNDesu",
        "indices" : [ 60, 72 ],
        "id_str" : "320551143",
        "id" : 320551143
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/ChrisDanforth/status/252803990432133120/photo/1",
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/Ge37gTXE",
        "media_url" : "http://pbs.twimg.com/media/A4Ij48_CMAEUogi.jpg",
        "id_str" : "252803990436327425",
        "id" : 252803990436327425,
        "media_url_https" : "https://pbs.twimg.com/media/A4Ij48_CMAEUogi.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/Ge37gTXE"
      } ],
      "hashtags" : [ {
        "text" : "storylab",
        "indices" : [ 23, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "252803990432133120",
    "text" : "Athletic excitement in #storylab as heard and translated by @SumaNMNDesu http://t.co/Ge37gTXE",
    "id" : 252803990432133120,
    "created_at" : "Mon Oct 01 16:15:43 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 252804979788759041,
  "created_at" : "Mon Oct 01 16:19:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252778231554531328",
  "geo" : {
  },
  "id_str" : "252797173337571328",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill sounds like something you could do in one day, to me",
  "id" : 252797173337571328,
  "in_reply_to_status_id" : 252778231554531328,
  "created_at" : "Mon Oct 01 15:48:37 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]