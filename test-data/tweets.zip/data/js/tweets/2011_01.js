Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32177035191255040",
  "geo" : {
  },
  "id_str" : "32265291551473664",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan it was from 11-1 and I went but the line was too long to get in lol...thx tho! Sorry to hear abt u n jenny",
  "id" : 32265291551473664,
  "in_reply_to_status_id" : 32177035191255040,
  "created_at" : "Tue Feb 01 02:33:39 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Rec Sports",
      "screen_name" : "VTRecSports",
      "indices" : [ 13, 25 ],
      "id_str" : "22190611",
      "id" : 22190611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32154534079889408",
  "text" : "worth it? RT @VTRecSports Price for BodPod test has been set. $12.50 for a full test.",
  "id" : 32154534079889408,
  "created_at" : "Mon Jan 31 19:13:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32154245763436544",
  "text" : "will they be studying \"Reagan's Observation,\" as Dr Brown named it, in future number theory courses?? Maybe...",
  "id" : 32154245763436544,
  "created_at" : "Mon Jan 31 19:12:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32151288703614977",
  "text" : "according to Dr Brown my comment in class was \"the first revision of the Euclidean Algorithm in 2000 yrs\" the work of a \"true mathematician\"",
  "id" : 32151288703614977,
  "created_at" : "Mon Jan 31 19:00:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "32127957602402306",
  "text" : "class... I'm really thinking abt dropping graph theory. We'll see when we get the hw back today (@ McBryde Hall) http://4sq.com/fqISWT",
  "id" : 32127957602402306,
  "created_at" : "Mon Jan 31 17:27:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31853732052340736",
  "text" : "just witnessed the worst call of all time. Dude dribblin the ball down the court falls facefirst by himself, and they call a trip on delaney",
  "id" : 31853732052340736,
  "created_at" : "Sun Jan 30 23:18:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2228619568, -80.4193693399 ]
  },
  "id_str" : "31841972016652288",
  "text" : "Tech v. Miami!! (@ Cassell Coliseum w/ 6 others) [pic]: http://4sq.com/hRrUd5",
  "id" : 31841972016652288,
  "created_at" : "Sun Jan 30 22:31:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "replyall",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "fail",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31837671277985792",
  "text" : "just announced the triathlon listserv that i was bringing a keg to the super bowl party, not cool... #replyall #fail",
  "id" : 31837671277985792,
  "created_at" : "Sun Jan 30 22:14:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31823738521518080",
  "geo" : {
  },
  "id_str" : "31832990640246784",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice 5 weeks till spring break, i expect a serenade from my front lawn when you arrive!",
  "id" : 31832990640246784,
  "in_reply_to_status_id" : 31823738521518080,
  "created_at" : "Sun Jan 30 21:55:51 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "31814409177272320",
  "text" : "Doin HW b4 the bball game (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/i0FkkN",
  "id" : 31814409177272320,
  "created_at" : "Sun Jan 30 20:42:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31493928465203201",
  "text" : "spring semester laundry day #1: just put in 4 loads of laundry...dang those cycling clothes brought stank to a new level, extra detergent!!",
  "id" : 31493928465203201,
  "created_at" : "Sat Jan 29 23:28:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31474275818934272",
  "text" : "had a good time at the Andrew Gold race, rode hard until I bonked.  Just volunteered at Kids Tech...time to nap after this brooklyn pils",
  "id" : 31474275818934272,
  "created_at" : "Sat Jan 29 22:10:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 3, 15 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheAndrewGold",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31223264055398400",
  "text" : "RT @LeeRMatthis: #TheAndrewGold is tomorrow!!  I wonder if Navy Cycling will know what hit them come ACCC RoadChamp time???????  Get 'em ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.ubertwitter.com/bb/download.php\" rel=\"nofollow\">ÜberSocialOrig</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Virginia Tech ",
        "screen_name" : "VTCycling",
        "indices" : [ 120, 130 ],
        "id_str" : "117782776",
        "id" : 117782776
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheAndrewGold",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "31211356099182593",
    "text" : "#TheAndrewGold is tomorrow!!  I wonder if Navy Cycling will know what hit them come ACCC RoadChamp time???????  Get 'em @VTCycling!!!",
    "id" : 31211356099182593,
    "created_at" : "Sat Jan 29 04:45:41 +0000 2011",
    "user" : {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "protected" : false,
      "id_str" : "70417462",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1402226998/image_normal.jpg",
      "id" : 70417462,
      "verified" : false
    }
  },
  "id" : 31223264055398400,
  "created_at" : "Sat Jan 29 05:33:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31206826938728448",
  "geo" : {
  },
  "id_str" : "31221480712830976",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis definitely! I've got a black IPA that's gonna need to be outta the keg to make room for the dfh in a couple weeks...",
  "id" : 31221480712830976,
  "in_reply_to_status_id" : 31206826938728448,
  "created_at" : "Sat Jan 29 05:25:55 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 32, 44 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31183915276312576",
  "text" : "Just brewed the Raison d'etre w @MechE_Hokie , waitin for it to cool. He took one look at my keg, and its pourin beer!!",
  "id" : 31183915276312576,
  "created_at" : "Sat Jan 29 02:56:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31131182313775104",
  "text" : "just got back from vintage cellar beer tasting, and about to brew beer my dfh raison d'etre clone!",
  "id" : 31131182313775104,
  "created_at" : "Fri Jan 28 23:27:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "31078312755335168",
  "text" : "just finished up HW, heading home then a SAYG Ride (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/gVWwip",
  "id" : 31078312755335168,
  "created_at" : "Fri Jan 28 19:57:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "31028971231510528",
  "text" : "office hrs, two classes then done this week!! (@ McBryde Hall) http://4sq.com/fJt4AG",
  "id" : 31028971231510528,
  "created_at" : "Fri Jan 28 16:40:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31025986145353728",
  "text" : "And a wintry va tech today http://yfrog.com/h4apbzj",
  "id" : 31025986145353728,
  "created_at" : "Fri Jan 28 16:29:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "31025601812897793",
  "text" : "RT @DZdan1: Thank. Goodness. Its. Friday.",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "31014336948342784",
    "text" : "Thank. Goodness. Its. Friday.",
    "id" : 31014336948342784,
    "created_at" : "Fri Jan 28 15:42:48 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 31025601812897793,
  "created_at" : "Fri Jan 28 16:27:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2341, -80.4091 ]
  },
  "id_str" : "30864793623592960",
  "text" : "home! after 6.5 hrs of str8 hw. dinner? (@ International Bicycle Barracks) http://4sq.com/gqwXer",
  "id" : 30864793623592960,
  "created_at" : "Fri Jan 28 05:48:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30840480530956289",
  "geo" : {
  },
  "id_str" : "30864475607277568",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e good ol' days my ass lol...I sat down at 6 to do a little work, and just got home at quarter of 1am. No dinner, no swim, no brew...",
  "id" : 30864475607277568,
  "in_reply_to_status_id" : 30840480530956289,
  "created_at" : "Fri Jan 28 05:47:19 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30839486556413952",
  "text" : "has been doing math for nearly five hours straight...ugh. can barely see straight...time to bike home and sleep.",
  "id" : 30839486556413952,
  "created_at" : "Fri Jan 28 04:08:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "30769118302961664",
  "text" : "HW time (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/i2JS4k",
  "id" : 30769118302961664,
  "created_at" : "Thu Jan 27 23:28:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.228671143, -80.4246425629 ]
  },
  "id_str" : "30759377954672640",
  "text" : "C++ class (@ Pamplin Hall w/ 2 others) http://4sq.com/eWeVoP",
  "id" : 30759377954672640,
  "created_at" : "Thu Jan 27 22:49:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30733634407239680",
  "text" : "got up at 6:45am for pancakes, then a cold but great ~3hr ride. had time for a shower, 11am class, then d2 and doing HW since. 1 more class!",
  "id" : 30733634407239680,
  "created_at" : "Thu Jan 27 21:07:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30666879425060864",
  "geo" : {
  },
  "id_str" : "30733147670847488",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet haha not on purpose, i'm just always speeding somewhere late on the bike, and don't get a chance to!",
  "id" : 30733147670847488,
  "in_reply_to_status_id" : 30666879425060864,
  "created_at" : "Thu Jan 27 21:05:28 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30461395946442755",
  "text" : "trip was a complete success!! but no brewing tonight...no time.  Up at 7AM to ride, then body comp analysis, class, hw, more class...etc",
  "id" : 30461395946442755,
  "created_at" : "Thu Jan 27 03:05:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30431575820734464",
  "text" : "Just went on a solid 1hr run w Justin, goin to pick up fermenters, brewing indgredients + yeast, and bike parts!!",
  "id" : 30431575820734464,
  "created_at" : "Thu Jan 27 01:07:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30381194625421312",
  "text" : "auto insurance and registration coming due...i could buy another bike!",
  "id" : 30381194625421312,
  "created_at" : "Wed Jan 26 21:46:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30378077120888832",
  "text" : "bean burrito for dinner yum, doing HW maybe getting a run or trainer ride in, brewing, and laundry on the list for tonight!",
  "id" : 30378077120888832,
  "created_at" : "Wed Jan 26 21:34:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 0, 13 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30357792724357121",
  "geo" : {
  },
  "id_str" : "30377891434860545",
  "in_reply_to_user_id" : 18204345,
  "text" : "@blogblogblog the bicycle design prof doesn't have a location listed, and i emailed him before the last class, and he got back last night...",
  "id" : 30377891434860545,
  "in_reply_to_status_id" : 30357792724357121,
  "created_at" : "Wed Jan 26 21:33:48 +0000 2011",
  "in_reply_to_screen_name" : "blogblogblog",
  "in_reply_to_user_id_str" : "18204345",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburgblizzard",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30319036956938240",
  "text" : "so much for the #blacksburgblizzard...I've seen about 10 total snowflakes stick",
  "id" : 30319036956938240,
  "created_at" : "Wed Jan 26 17:39:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30302248592478208",
  "text" : "And after talking to the professor last night, just realized that I totally forgot about bicycle design this morning...probably a good thing",
  "id" : 30302248592478208,
  "created_at" : "Wed Jan 26 16:33:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30298262518894592",
  "text" : "also lost track of time w/ email, thought I was gonna be late to class, sprinted on the bike and was early! New record, 5 minutes (in rain!)",
  "id" : 30298262518894592,
  "created_at" : "Wed Jan 26 16:17:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30297654500003840",
  "text" : "No eggs so brkfst declined to two rolls of ritz, but I love ritz so I'm not complainin...and grabbed a clif bar for lunch, yum yum",
  "id" : 30297654500003840,
  "created_at" : "Wed Jan 26 16:14:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30288190644424704",
  "text" : "woke up @ 7:30 and Ive been writing proofs for graph theory nonstop since..my brain is fried! I'm done, so now to fry some eggs 4 brkfst :)",
  "id" : 30288190644424704,
  "created_at" : "Wed Jan 26 15:37:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30087222485057536",
  "geo" : {
  },
  "id_str" : "30122646460964864",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice sounds great! Come down earlier if you want to",
  "id" : 30122646460964864,
  "in_reply_to_status_id" : 30087222485057536,
  "created_at" : "Wed Jan 26 04:39:33 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30122408987860992",
  "text" : "Got the keg flowing great at the homebrew meeting after much tinkering....now what to do with all this beer lol",
  "id" : 30122408987860992,
  "created_at" : "Wed Jan 26 04:38:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30053822965489664",
  "text" : "New water bottle samples are in! Order going in tomorrow, have them in 10 days http://yfrog.com/hs4yfoj",
  "id" : 30053822965489664,
  "created_at" : "Wed Jan 26 00:06:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 61, 70 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "30041927852236800",
  "geo" : {
  },
  "id_str" : "30048676692889600",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan if you're still got extra venison let me know! @dknick88 can it lol",
  "id" : 30048676692889600,
  "in_reply_to_status_id" : 30041927852236800,
  "created_at" : "Tue Jan 25 23:45:37 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin",
      "screen_name" : "shitmydadsays",
      "indices" : [ 3, 17 ],
      "id_str" : "62581962",
      "id" : 62581962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "30002795818000384",
  "text" : "RT @shitmydadsays: \"No. Aliens exist, I just don't think they came millions of light years\njust to see earth. Be like driving 1000 miles ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "29966714343002112",
    "text" : "\"No. Aliens exist, I just don't think they came millions of light years\njust to see earth. Be like driving 1000 miles to go to an Arby's\"",
    "id" : 29966714343002112,
    "created_at" : "Tue Jan 25 18:19:56 +0000 2011",
    "user" : {
      "name" : "Justin",
      "screen_name" : "shitmydadsays",
      "protected" : false,
      "id_str" : "62581962",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/362705903/dad_normal.jpg",
      "id" : 62581962,
      "verified" : true
    }
  },
  "id" : 30002795818000384,
  "created_at" : "Tue Jan 25 20:43:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29982786882371585",
  "geo" : {
  },
  "id_str" : "29998797174083584",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 it's 45 out right now here... :-P",
  "id" : 29998797174083584,
  "in_reply_to_status_id" : 29982786882371585,
  "created_at" : "Tue Jan 25 20:27:25 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29997318887444480",
  "text" : "I would love to do this for a living http://bit.ly/eXBu1Q",
  "id" : 29997318887444480,
  "created_at" : "Tue Jan 25 20:21:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 3, 16 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29990723675754496",
  "text" : "RT @williamenium: Beautiful day in sunny blacksburg",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "29948327869022208",
    "text" : "Beautiful day in sunny blacksburg",
    "id" : 29948327869022208,
    "created_at" : "Tue Jan 25 17:06:52 +0000 2011",
    "user" : {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "protected" : false,
      "id_str" : "25713870",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3000920642/c373789737cf47f7a99efe0a4b414eb3_normal.jpeg",
      "id" : 25713870,
      "verified" : false
    }
  },
  "id" : 29990723675754496,
  "created_at" : "Tue Jan 25 19:55:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29938081100464128",
  "text" : "got a good spin and stretch in before class this morning, then going to d2 lunch after numerical analysis!",
  "id" : 29938081100464128,
  "created_at" : "Tue Jan 25 16:26:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29768571798163456",
  "text" : "is bedtime! new post on http://andyreagan.com, and im gonna try to get early to train before class tomorrow",
  "id" : 29768571798163456,
  "created_at" : "Tue Jan 25 05:12:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29624835034316800",
  "geo" : {
  },
  "id_str" : "29767013215764480",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan I read that the other way around the first time, and was like yeah what's the big deal I do that all the time lol",
  "id" : 29767013215764480,
  "in_reply_to_status_id" : 29624835034316800,
  "created_at" : "Tue Jan 25 05:06:23 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 73, 83 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29692264913567745",
  "text" : "just rebuilt the rear hub on the commuter, spins like new!! going to the @VTCycling meeting, then numerical analysis HW @vbiatvt",
  "id" : 29692264913567745,
  "created_at" : "Tue Jan 25 00:09:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29569731052707840",
  "text" : "just wrote a pretty cool program to find all the primes of alternating factorials, but it runs into the limit of floating point values, darn",
  "id" : 29569731052707840,
  "created_at" : "Mon Jan 24 16:02:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29321408362323969",
  "geo" : {
  },
  "id_str" : "29388712043347968",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr yeah, I'm sure you're more used to the NBA rims though...they've got to be softer",
  "id" : 29388712043347968,
  "in_reply_to_status_id" : 29321408362323969,
  "created_at" : "Mon Jan 24 04:03:09 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 41, 50 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29163940491558912",
  "geo" : {
  },
  "id_str" : "29388487249625088",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis very tempting, but I'm with @aJohnnyD on this one, sorry! Make-up day on Sunday?",
  "id" : 29388487249625088,
  "in_reply_to_status_id" : 29163940491558912,
  "created_at" : "Mon Jan 24 04:02:16 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29308707812679680",
  "geo" : {
  },
  "id_str" : "29387860331200514",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 and with a volleyball so I can palm it, of course",
  "id" : 29387860331200514,
  "in_reply_to_status_id" : 29308707812679680,
  "created_at" : "Mon Jan 24 03:59:46 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29386304928096256",
  "text" : "is sleepin in the hammock tonight!",
  "id" : 29386304928096256,
  "created_at" : "Mon Jan 24 03:53:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29318127867138048",
  "text" : "is goin home to make dinner then mass",
  "id" : 29318127867138048,
  "created_at" : "Sun Jan 23 23:22:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29301763009941504",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin call me @ 540 231 5119 when you get a chance",
  "id" : 29301763009941504,
  "created_at" : "Sun Jan 23 22:17:39 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29301430288384000",
  "text" : "just played an hour of pickup basketball, i had almost forgot what the round leather thing was called. cut my hand on the rim though...",
  "id" : 29301430288384000,
  "created_at" : "Sun Jan 23 22:16:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 60, 69 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29222112384253953",
  "text" : "so much HW to do today, going to @vbiatvt to do some work.  @dmreagan i'll call when i finish numerical analysis and graph theory",
  "id" : 29222112384253953,
  "created_at" : "Sun Jan 23 17:01:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 16, 27 ],
      "id_str" : "18855629",
      "id" : 18855629
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 106, 116 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29221524183453696",
  "text" : "just renewed my @usacycling license for 2011! We won MTB season, now it's time to take down Navy for road @VTCycling",
  "id" : 29221524183453696,
  "created_at" : "Sun Jan 23 16:58:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29041863709167616",
  "geo" : {
  },
  "id_str" : "29055190074134528",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan he was playin hard, f throw and pray...did you see him on d??",
  "id" : 29055190074134528,
  "in_reply_to_status_id" : 29041863709167616,
  "created_at" : "Sun Jan 23 05:57:51 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29044474537574400",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice you better be practicing that guitar brah",
  "id" : 29044474537574400,
  "created_at" : "Sun Jan 23 05:15:17 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29032760953806850",
  "in_reply_to_user_id" : 219863324,
  "text" : "@meche_hokie dannnnnnnnnnceeeee",
  "id" : 29032760953806850,
  "created_at" : "Sun Jan 23 04:28:44 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "29019210973712384",
  "text" : "good win for the #hokies, eric green played really well I thought. Live blues guitar at the cellar!",
  "id" : 29019210973712384,
  "created_at" : "Sun Jan 23 03:34:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28987558788595712",
  "text" : "@ the #hokies bball game, we're up 49-38 8min left. I'm excited to play intramurals this spring!",
  "id" : 28987558788595712,
  "created_at" : "Sun Jan 23 01:29:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28955515526582272",
  "geo" : {
  },
  "id_str" : "28957744362954752",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium I figured you'd get to in the class. what're you up to tonight?",
  "id" : 28957744362954752,
  "in_reply_to_status_id" : 28955515526582272,
  "created_at" : "Sat Jan 22 23:30:38 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 14, 22 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 33, 43 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 57, 68 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28956818508087296",
  "text" : "new post, and @twitter widget on @VTCycling's webpage by @andyreagan http://www.cycling.org.vt.edu \"Casual Clothing and Water Bottle orders\"",
  "id" : 28956818508087296,
  "created_at" : "Sat Jan 22 23:26:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28953616387678208",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium http://bit.ly/gBdW1V http://bit.ly/h3qhPn",
  "id" : 28953616387678208,
  "created_at" : "Sat Jan 22 23:14:14 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 80, 89 ],
      "id_str" : "195438525",
      "id" : 195438525
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 98, 108 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28568433222221824",
  "text" : "Ride was fun, a good turnout! Food, shower, vintage cellar beer tasting, dinner @cafezulu's, then @vtcycling officer meeting!",
  "id" : 28568433222221824,
  "created_at" : "Fri Jan 21 21:43:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28541276617969664",
  "text" : "Goin for a ride! 20deg F and I'm all bundled up",
  "id" : 28541276617969664,
  "created_at" : "Fri Jan 21 19:55:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28531337178652672",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan got your package! cookies are delicious (one bag gone) and the shirt looks awesome!",
  "id" : 28531337178652672,
  "created_at" : "Fri Jan 21 19:16:15 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 0, 10 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28139316492378112",
  "geo" : {
  },
  "id_str" : "28318799312723968",
  "in_reply_to_user_id" : 73786966,
  "text" : "@SH13LDS21 I just watched bill and teds excellent adventure lol, as great as I remembered it",
  "id" : 28318799312723968,
  "in_reply_to_status_id" : 28139316492378112,
  "created_at" : "Fri Jan 21 05:11:42 +0000 2011",
  "in_reply_to_screen_name" : "SH13LDS21",
  "in_reply_to_user_id_str" : "73786966",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28184743988166656",
  "text" : "has homework due friday or monday in all of four math classes...time to get crackin! (after I eat some lunch)",
  "id" : 28184743988166656,
  "created_at" : "Thu Jan 20 20:19:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 61, 77 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28126299478298624",
  "text" : "Made omlets for Dave and myself for breakfast sooo good, thx @rumblinstumblin for teachin me how! Rode to cburg 4 co2 refill, in class now",
  "id" : 28126299478298624,
  "created_at" : "Thu Jan 20 16:26:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27894671493570561",
  "text" : "survived the rat race for books and got the ones I needed. Just had an awesome venison dinner with Dave, Drew, Hayden, and Nick W",
  "id" : 27894671493570561,
  "created_at" : "Thu Jan 20 01:06:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27844539003707392",
  "text" : "going to buy books, here goes $370",
  "id" : 27844539003707392,
  "created_at" : "Wed Jan 19 21:47:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27832054339076096",
  "geo" : {
  },
  "id_str" : "27834335130292224",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 mmmmm cheesecake",
  "id" : 27834335130292224,
  "in_reply_to_status_id" : 27832054339076096,
  "created_at" : "Wed Jan 19 21:06:37 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27829792317378560",
  "text" : "has really got my work cut for myself out this semester...learning three programming languages, the \"hardest ugrad class\", and grad class",
  "id" : 27829792317378560,
  "created_at" : "Wed Jan 19 20:48:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "freshmanmistake",
      "indices" : [ 100, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27776173551386625",
  "text" : "turns out I don't have three classes in the same room, I was in the wrong one. 231 not 321... #fail #freshmanmistake",
  "id" : 27776173551386625,
  "created_at" : "Wed Jan 19 17:15:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27757753363595264",
  "text" : "three of my four math classes are in the same room...two of them back to back starting right now (advanced calculus now, number theory next)",
  "id" : 27757753363595264,
  "created_at" : "Wed Jan 19 16:02:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27735358372319234",
  "text" : "theres an opening in bicycle design, although I cant add it bc time conflict...I was going to check it out today, but no location is listed!",
  "id" : 27735358372319234,
  "created_at" : "Wed Jan 19 14:33:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27729800231653376",
  "text" : "slept in till 20 minutes before my philosophy class, and with 1/5 functional commuting bikes...dropping the class.",
  "id" : 27729800231653376,
  "created_at" : "Wed Jan 19 14:11:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27568954444615681",
  "geo" : {
  },
  "id_str" : "27573793622851584",
  "in_reply_to_user_id" : 33612141,
  "text" : "@jade_lemmerman definitely creepy, lol",
  "id" : 27573793622851584,
  "in_reply_to_status_id" : 27568954444615681,
  "created_at" : "Wed Jan 19 03:51:19 +0000 2011",
  "in_reply_to_screen_name" : "jadelemmerman",
  "in_reply_to_user_id_str" : "33612141",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27537930633355264",
  "text" : "Homebrew club! Didn't realize the time was different and ate my ziti frozen",
  "id" : 27537930633355264,
  "created_at" : "Wed Jan 19 01:28:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27507569916383232",
  "text" : "wants it to be warm already. what to make for dinner....",
  "id" : 27507569916383232,
  "created_at" : "Tue Jan 18 23:28:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27427821022347264",
  "text" : "Numerical analysis is going to be tough, but I have a friend in the class. On the bicycle trainer 4 a 2hr VO2max workout",
  "id" : 27427821022347264,
  "created_at" : "Tue Jan 18 18:11:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27357935428440067",
  "text" : "got up early for class, and looked at my schedule, no class till 11!",
  "id" : 27357935428440067,
  "created_at" : "Tue Jan 18 13:33:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27192395728683008",
  "geo" : {
  },
  "id_str" : "27195239936565249",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis yup, different trips! you've kegged before, right?",
  "id" : 27195239936565249,
  "in_reply_to_status_id" : 27192395728683008,
  "created_at" : "Tue Jan 18 02:47:05 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27187248285876225",
  "text" : "just learned first hand what happens on a fixie without a perfectly straight chainline and too much slack.... snapped chain!",
  "id" : 27187248285876225,
  "created_at" : "Tue Jan 18 02:15:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27172796056469504",
  "text" : "just put my beer in a keg and biked it home!! trailer for the win",
  "id" : 27172796056469504,
  "created_at" : "Tue Jan 18 01:17:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27130248122335232",
  "text" : "revised my vegetarian rule yesterday to include meat that I know where it was grown/killed. And just stir fried some venison mmmmm so tender",
  "id" : 27130248122335232,
  "created_at" : "Mon Jan 17 22:28:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27111553115361280",
  "text" : "is gettin hungry, time to finish these applications and go home...but one last question left: read it @ http://andyreagan.com",
  "id" : 27111553115361280,
  "created_at" : "Mon Jan 17 21:14:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "27039572193968128",
  "text" : "got my books sold and talked to all my professors in the math department, I know a lot! Now I'm gonna write some essays!!",
  "id" : 27039572193968128,
  "created_at" : "Mon Jan 17 16:28:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26852098041716736",
  "text" : "is goin to bed radically early tonight. big to-do list tomorrow, for my biggest semester yet",
  "id" : 26852098041716736,
  "created_at" : "Mon Jan 17 04:03:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 73, 89 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26849373321175040",
  "text" : "just spent an hour resolving our continual heaps of dishes...and adopted @RumblinStumblin's old system. one plate, cup, and utensil each!",
  "id" : 26849373321175040,
  "created_at" : "Mon Jan 17 03:52:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26803034516361218",
  "text" : "website is back up and running!!",
  "id" : 26803034516361218,
  "created_at" : "Mon Jan 17 00:48:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26794359152185344",
  "text" : "Dave is here!! Gettin stuff unpacked and headin out to return a book and loosen up my legs from that drive",
  "id" : 26794359152185344,
  "created_at" : "Mon Jan 17 00:14:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26779414503096321",
  "text" : "is at my house and unloaded the car. Now I understand why people clean *before* they leave...",
  "id" : 26779414503096321,
  "created_at" : "Sun Jan 16 23:14:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bburg",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26755400019742720",
  "text" : "10min away from #bburg!",
  "id" : 26755400019742720,
  "created_at" : "Sun Jan 16 21:39:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26709170824679424",
  "text" : "is back to my birth state! 3 hours lefttt",
  "id" : 26709170824679424,
  "created_at" : "Sun Jan 16 18:35:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26687697879834624",
  "text" : "On good ol' 81",
  "id" : 26687697879834624,
  "created_at" : "Sun Jan 16 17:10:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26667798079995904",
  "text" : "good thing I gas and some peanut butter crackers in the passenger seat! http://yfrog.com/gz7dnnij",
  "id" : 26667798079995904,
  "created_at" : "Sun Jan 16 15:51:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26655158238711808",
  "text" : "was gonna stay in philly another night....but I'm headed back to Tech to get moved in and organized to start the semester off",
  "id" : 26655158238711808,
  "created_at" : "Sun Jan 16 15:00:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26546909501980672",
  "in_reply_to_user_id" : 204631321,
  "text" : "@dknick88 yes? http://yfrog.com/h4er1mrj",
  "id" : 26546909501980672,
  "created_at" : "Sun Jan 16 07:50:51 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26533026250887168",
  "geo" : {
  },
  "id_str" : "26545517517348864",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 you wouldn't even believe...",
  "id" : 26545517517348864,
  "in_reply_to_status_id" : 26533026250887168,
  "created_at" : "Sun Jan 16 07:45:19 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 21, 36 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26469463477985283",
  "text" : "Goin to the yunk wit @ryandelgiudice",
  "id" : 26469463477985283,
  "created_at" : "Sun Jan 16 02:43:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26461828783546368",
  "text" : "my website got hacked...so I called my host and they took it down. Hopefully ill get it back up soon, maybe Monday? Damn hackers",
  "id" : 26461828783546368,
  "created_at" : "Sun Jan 16 02:12:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26409164297216000",
  "geo" : {
  },
  "id_str" : "26428068088254464",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 jock joke",
  "id" : 26428068088254464,
  "in_reply_to_status_id" : 26409164297216000,
  "created_at" : "Sat Jan 15 23:58:37 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 105, 120 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26420570803412992",
  "text" : "Finished working at obg early, were done done!! Gonna go to tech tmrw instead of Monday. Headin out with @ryandelgiudice!",
  "id" : 26420570803412992,
  "created_at" : "Sat Jan 15 23:28:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26308963590995968",
  "geo" : {
  },
  "id_str" : "26319828759347200",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice how close r u to east norriton?",
  "id" : 26319828759347200,
  "in_reply_to_status_id" : 26308963590995968,
  "created_at" : "Sat Jan 15 16:48:30 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26123767084220416",
  "geo" : {
  },
  "id_str" : "26308060540571648",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice what's gay abt that? Hike out with a guitar, bottle of jack, smokeables, make a bonfire and chill",
  "id" : 26308060540571648,
  "in_reply_to_status_id" : 26123767084220416,
  "created_at" : "Sat Jan 15 16:01:45 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26285937138860032",
  "geo" : {
  },
  "id_str" : "26302852091613184",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 I hope you're not pourin em like you did that pbr at my house lol...or else it'd b \"servin up foamskis\"",
  "id" : 26302852091613184,
  "in_reply_to_status_id" : 26285937138860032,
  "created_at" : "Sat Jan 15 15:41:03 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26126401442676736",
  "text" : "\"Alarm is now set for 8 hours 2 minutes from now\" -My Droid.  Seriously a record this whole winter \"break\"",
  "id" : 26126401442676736,
  "created_at" : "Sat Jan 15 03:59:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 52, 67 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26112834999947264",
  "geo" : {
  },
  "id_str" : "26125609398706176",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice I got on twitter just to say I hope @ryandelgiudice is NOT on his way to Philly yet...lol. I'm pumped for tomorrow night!",
  "id" : 26125609398706176,
  "in_reply_to_status_id" : 26112834999947264,
  "created_at" : "Sat Jan 15 03:56:45 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "26124349610139648",
  "text" : "another long day at the office, left at 9pm to have a few beers and veg watchin espn. Crashin \"early\" for break at least now, out tmrw nite!",
  "id" : 26124349610139648,
  "created_at" : "Sat Jan 15 03:51:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25983775938707457",
  "geo" : {
  },
  "id_str" : "25994257865117696",
  "in_reply_to_user_id" : 33612141,
  "text" : "@jade_lemmerman yup, went with IT, we're migrating all of the computers in Bluebell to Microsoft Active Directory, getting rid of Novell",
  "id" : 25994257865117696,
  "in_reply_to_status_id" : 25983775938707457,
  "created_at" : "Fri Jan 14 19:14:48 +0000 2011",
  "in_reply_to_screen_name" : "jadelemmerman",
  "in_reply_to_user_id_str" : "33612141",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25983394793918465",
  "text" : "finish a good ride, and I'm manning the it command center: http://yfrog.com/h3ivpvxj",
  "id" : 25983394793918465,
  "created_at" : "Fri Jan 14 18:31:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25945963528986625",
  "text" : "just deactivated my facebook",
  "id" : 25945963528986625,
  "created_at" : "Fri Jan 14 16:02:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25919307674288128",
  "text" : "was thinking about riding outside today...probably should too...but I'd get lost or frozen probably. on the indoor trainer :(",
  "id" : 25919307674288128,
  "created_at" : "Fri Jan 14 14:16:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25908646202318848",
  "text" : "powertap didn't save my last two workout...damnit.  and I don't think it's gonna save this one either (flashing \"data\" at the bottom still)",
  "id" : 25908646202318848,
  "created_at" : "Fri Jan 14 13:34:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25581037014749184",
  "geo" : {
  },
  "id_str" : "25791178985185280",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 damn that sucks!! ....new plan: backpacking on the Appalachian Trail!?",
  "id" : 25791178985185280,
  "in_reply_to_status_id" : 25581037014749184,
  "created_at" : "Fri Jan 14 05:47:50 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25790188076666880",
  "text" : "clocked 15 hours today working!! just came back to the hotel at 12:30, my own room with a living room and kitchen...business travel rocks",
  "id" : 25790188076666880,
  "created_at" : "Fri Jan 14 05:43:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O'Brien & Gere",
      "screen_name" : "OBRIEN_GERE",
      "indices" : [ 81, 93 ],
      "id_str" : "87009488",
      "id" : 87009488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25663896341716992",
  "text" : "Is at the Norriton (Bluebell) office. Had lunch at damons, a whole veggie pizza, @obrien_gere roadtrip yeahhh!!",
  "id" : 25663896341716992,
  "created_at" : "Thu Jan 13 21:22:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O'Brien & Gere",
      "screen_name" : "OBRIEN_GERE",
      "indices" : [ 10, 22 ],
      "id_str" : "87009488",
      "id" : 87009488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25557918308896768",
  "text" : "Headed to @OBRIEN_GERE then down to PA!",
  "id" : 25557918308896768,
  "created_at" : "Thu Jan 13 14:20:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 8, 17 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 18, 33 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "su",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25317878068682754",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 @dknick88 @ryandelgiudice if y'all don't wanna drive to tullys we can watch the #su game at my house in hd on the projector",
  "id" : 25317878068682754,
  "created_at" : "Wed Jan 12 22:27:07 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25317588376485888",
  "text" : "To train or to nap.... here's the winner: http://yfrog.com/gyrg5qoj",
  "id" : 25317588376485888,
  "created_at" : "Wed Jan 12 22:25:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 20, 29 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 35, 42 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25305279805530113",
  "text" : "Waiting for my ride @dmreagan. And @dzdan1 look at the roads, not bad: http://yfrog.com/gypjlmkj",
  "id" : 25305279805530113,
  "created_at" : "Wed Jan 12 21:37:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25292564013785088",
  "text" : "anyone want a basketball ticket for this weekend? Saturday at 8pm vs Wake Forest, asking $7 (cost) and it's a good seat...",
  "id" : 25292564013785088,
  "created_at" : "Wed Jan 12 20:46:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25272255718100993",
  "text" : "whole new theme and a new post about DC on http://andyreagan.com",
  "id" : 25272255718100993,
  "created_at" : "Wed Jan 12 19:25:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25245662870245377",
  "geo" : {
  },
  "id_str" : "25246407879294977",
  "in_reply_to_user_id" : 70474456,
  "text" : "@bpolson89 you shoulda seen the heads turn when i walked through lee hall with my plastic soled biking shoes on lol",
  "id" : 25246407879294977,
  "in_reply_to_status_id" : 25245662870245377,
  "created_at" : "Wed Jan 12 17:43:07 +0000 2011",
  "in_reply_to_screen_name" : "britty_kitty89",
  "in_reply_to_user_id_str" : "70474456",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fact",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "fb",
      "indices" : [ 55, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25200320124559360",
  "text" : "there is no way to be alive and not take risks, #fact. #fb",
  "id" : 25200320124559360,
  "created_at" : "Wed Jan 12 14:39:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25196334457819136",
  "geo" : {
  },
  "id_str" : "25200136846053377",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr i can't chill with the bros in the hot tub?",
  "id" : 25200136846053377,
  "in_reply_to_status_id" : 25196334457819136,
  "created_at" : "Wed Jan 12 14:39:15 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25177470680432640",
  "text" : "snowmobile broke down last night...but I still had a fun night w/ the bros in the hot tub!",
  "id" : 25177470680432640,
  "created_at" : "Wed Jan 12 13:09:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 47, 63 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24941596164231168",
  "text" : "heading up to Uncle Carl's to go snowmobiling! @RumblinStumblin how did the keg pickup go?",
  "id" : 24941596164231168,
  "created_at" : "Tue Jan 11 21:31:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24866698737750016",
  "geo" : {
  },
  "id_str" : "24937128601329665",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 when were you at coppertop last night??",
  "id" : 24937128601329665,
  "in_reply_to_status_id" : 24866698737750016,
  "created_at" : "Tue Jan 11 21:14:09 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24923152672890880",
  "geo" : {
  },
  "id_str" : "24926740677664768",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 get a job you bum",
  "id" : 24926740677664768,
  "in_reply_to_status_id" : 24923152672890880,
  "created_at" : "Tue Jan 11 20:32:52 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24851962411352064",
  "geo" : {
  },
  "id_str" : "24853855674040321",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 those are posts from foursquare that I share with twitter...it's a social media thing, you'll be using it in a few months",
  "id" : 24853855674040321,
  "in_reply_to_status_id" : 24851962411352064,
  "created_at" : "Tue Jan 11 15:43:15 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24852365832093697",
  "geo" : {
  },
  "id_str" : "24853522948296705",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 i'll hit the ATM tonight",
  "id" : 24853522948296705,
  "in_reply_to_status_id" : 24852365832093697,
  "created_at" : "Tue Jan 11 15:41:56 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 12, 27 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 28, 37 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 38, 49 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 50, 61 ],
      "id_str" : "40995810",
      "id" : 40995810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24853443562700800",
  "text" : "RT @DZdan1: @ryandelgiudice @DKnick88 @andyreagan @anasemanas we need to get that house THIS week. No buts. Put our money where our mout ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan DelGiudice",
        "screen_name" : "ryandelgiudice",
        "indices" : [ 0, 15 ],
        "id_str" : "44471444",
        "id" : 44471444
      }, {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 16, 25 ],
        "id_str" : "204631321",
        "id" : 204631321
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 26, 37 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Hannah Weeks",
        "screen_name" : "anasemanas",
        "indices" : [ 38, 49 ],
        "id_str" : "40995810",
        "id" : 40995810
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "24852365832093697",
    "in_reply_to_user_id" : 44471444,
    "text" : "@ryandelgiudice @DKnick88 @andyreagan @anasemanas we need to get that house THIS week. No buts. Put our money where our mouths are.",
    "id" : 24852365832093697,
    "created_at" : "Tue Jan 11 15:37:20 +0000 2011",
    "in_reply_to_screen_name" : "ryandelgiudice",
    "in_reply_to_user_id_str" : "44471444",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 24853443562700800,
  "created_at" : "Tue Jan 11 15:41:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24851909324046336",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice disregard that comment abt losing  you cd's, I only lost one and the other one I had ripped on my pc!",
  "id" : 24851909324046336,
  "created_at" : "Tue Jan 11 15:35:31 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24846727173373953",
  "geo" : {
  },
  "id_str" : "24851441566875648",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 i'm not sure what you mean? if i post via foursquare then it does but that's foursquare doing the location, not twitter",
  "id" : 24851441566875648,
  "in_reply_to_status_id" : 24846727173373953,
  "created_at" : "Tue Jan 11 15:33:40 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "r*becca",
      "screen_name" : "brownshu",
      "indices" : [ 0, 9 ],
      "id_str" : "12543092",
      "id" : 12543092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24650700730400769",
  "geo" : {
  },
  "id_str" : "24843259163443201",
  "in_reply_to_user_id" : 12543092,
  "text" : "@brownshu had the cajun pizza, i was def eyeing that sandwhich though! i'll have to get that next time, the pizza was great",
  "id" : 24843259163443201,
  "in_reply_to_status_id" : 24650700730400769,
  "created_at" : "Tue Jan 11 15:01:09 +0000 2011",
  "in_reply_to_screen_name" : "brownshu",
  "in_reply_to_user_id_str" : "12543092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Obenauer",
      "screen_name" : "alexobenauer",
      "indices" : [ 3, 16 ],
      "id_str" : "14676432",
      "id" : 14676432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24842930078359552",
  "text" : "RT @alexobenauer: I never really would have thought of using FourSquare or Gowalla - But then there was this. This could get... http://t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "24821916200083456",
    "text" : "I never really would have thought of using FourSquare or Gowalla - But then there was this. This could get... http://tumblr.com/xtk18m6klb",
    "id" : 24821916200083456,
    "created_at" : "Tue Jan 11 13:36:20 +0000 2011",
    "user" : {
      "name" : "Alex Obenauer",
      "screen_name" : "alexobenauer",
      "protected" : false,
      "id_str" : "14676432",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3088723872/3e1114dda1a0c0b75653a547a8e0535c_normal.jpeg",
      "id" : 14676432,
      "verified" : false
    }
  },
  "id" : 24842930078359552,
  "created_at" : "Tue Jan 11 14:59:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 100, 109 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackswan",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24806477797527553",
  "text" : "#blackswan was pretty crazy last night... I got four hrs sleep and off at 7AM for work! woke up w.o @dmreagan for the first time this break",
  "id" : 24806477797527553,
  "created_at" : "Tue Jan 11 12:34:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 14, 29 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 30, 39 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0693110123, -76.1734700203 ]
  },
  "id_str" : "24668842894561280",
  "text" : "Black swan w/ @ryandelgiudice @dknick88 (@ Regal Carousel Mall Stadium 17) [pic]: http://4sq.com/fHVoIl",
  "id" : 24668842894561280,
  "created_at" : "Tue Jan 11 03:28:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.048035758, -76.2278652191 ]
  },
  "id_str" : "24660280768208896",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice's dinner! (@ McDonald's) http://4sq.com/dHuteo",
  "id" : 24660280768208896,
  "created_at" : "Tue Jan 11 02:54:03 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.051538, -76.241118 ]
  },
  "id_str" : "24648436309561344",
  "text" : "Awesome food and drank (@ CopperTop Tavern) [pic]: http://4sq.com/gIJEpH",
  "id" : 24648436309561344,
  "created_at" : "Tue Jan 11 02:06:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 101, 112 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 113, 122 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 123, 139 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24624944277098496",
  "text" : "got in a hard days work today, busy all 8 hrs, then an easy 1.5hr spin @ home. Headed to dinner with @kreagannet @dmreagan @rumblinstumblin",
  "id" : 24624944277098496,
  "created_at" : "Tue Jan 11 00:33:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0482435293, -76.1555099487 ]
  },
  "id_str" : "24524110549753856",
  "text" : "Lunch @ryandelguidice and his grandma (@ Pastabilities) http://4sq.com/eDJ1Mb",
  "id" : 24524110549753856,
  "created_at" : "Mon Jan 10 17:52:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7503780899, -73.9928770065 ]
  },
  "id_str" : "24075286916104192",
  "text" : "Boarded on the train to SYR (@ New York Penn Station w/ 3 others) http://4sq.com/heXXlv",
  "id" : 24075286916104192,
  "created_at" : "Sun Jan 09 12:09:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24012287853465600",
  "text" : "boarded on the train to NYC",
  "id" : 24012287853465600,
  "created_at" : "Sun Jan 09 07:59:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24002803496124416",
  "geo" : {
  },
  "id_str" : "24012155116331008",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 damn wish I coulda been there tonight!",
  "id" : 24012155116331008,
  "in_reply_to_status_id" : 24002803496124416,
  "created_at" : "Sun Jan 09 07:58:38 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89774647, -77.0064783096 ]
  },
  "id_str" : "24007167027712000",
  "text" : "train home leaves in half an hour (@ Union Station w/ 2 others) http://4sq.com/hziS8v",
  "id" : 24007167027712000,
  "created_at" : "Sun Jan 09 07:38:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23956583096520704",
  "text" : "is having the hardest time deciding which way to come home......ahhh. leave on the train in 3 hours or wait for alyson's car to be fixed mon",
  "id" : 23956583096520704,
  "created_at" : "Sun Jan 09 04:17:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9287636, -77.0326686 ]
  },
  "id_str" : "23759590952804352",
  "text" : "I'm at IHOP (1401 irving st nw, Washington) http://4sq.com/gnCPj7",
  "id" : 23759590952804352,
  "created_at" : "Sat Jan 08 15:15:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9305, -77.032 ]
  },
  "id_str" : "23755569449930753",
  "text" : "Mmmm oatmeal raisin (@ Sticky Fingers Bakery) http://4sq.com/eDFZFu",
  "id" : 23755569449930753,
  "created_at" : "Sat Jan 08 14:59:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23752103532957696",
  "text" : "Got up early and ran to the capitol, beautiful in the snow!",
  "id" : 23752103532957696,
  "created_at" : "Sat Jan 08 14:45:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23516134917541888",
  "text" : "Almost just lost my leg in the metro",
  "id" : 23516134917541888,
  "created_at" : "Fri Jan 07 23:07:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.928524, -77.059317 ]
  },
  "id_str" : "23461744164741120",
  "text" : "I'm at Washington DC Zoo http://4sq.com/giIoBj",
  "id" : 23461744164741120,
  "created_at" : "Fri Jan 07 19:31:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.923715, -77.052006 ]
  },
  "id_str" : "23444858513395712",
  "text" : "I'm at Chipotle (2600 Connecticut Ave NW, at Calvert St, Washington) http://4sq.com/g6qW1V",
  "id" : 23444858513395712,
  "created_at" : "Fri Jan 07 18:24:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23408036554997761",
  "text" : "great long run around DC, ran by all the embassies and checked out the beautiful cathedral. Iz cold here!",
  "id" : 23408036554997761,
  "created_at" : "Fri Jan 07 15:58:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23390163174432769",
  "text" : "is goin for a run before everyone comes to sharifs!",
  "id" : 23390163174432769,
  "created_at" : "Fri Jan 07 14:47:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23248018681634817",
  "text" : "made it to Sharif's!! A very long day of travel... http://yfrog.com/gzebjdj",
  "id" : 23248018681634817,
  "created_at" : "Fri Jan 07 05:22:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23240922691010560",
  "text" : "is one metro stop away from Sharif's!!!",
  "id" : 23240922691010560,
  "created_at" : "Fri Jan 07 04:54:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89774647, -77.0064783096 ]
  },
  "id_str" : "23233036170567680",
  "text" : "DC!!! (@ Union Station w/ 5 others) [pic]: http://4sq.com/hKcoUq",
  "id" : 23233036170567680,
  "created_at" : "Fri Jan 07 04:22:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.307345, -76.615675 ]
  },
  "id_str" : "23220328247336960",
  "text" : "another hour to DC.... (@ Baltimore Penn Station) http://4sq.com/fnuFKs",
  "id" : 23220328247336960,
  "created_at" : "Fri Jan 07 03:32:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.737316, -75.5511395 ]
  },
  "id_str" : "23209405273079808",
  "text" : "I'm at Amtrak: Wilmington (WIL) (200 East Front Street, Wilmington) http://4sq.com/hWiIWR",
  "id" : 23209405273079808,
  "created_at" : "Fri Jan 07 02:48:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23204819946704897",
  "geo" : {
  },
  "id_str" : "23206392135426048",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice word, there were some really cool christmas light outlined houses on the water, ever see those?",
  "id" : 23206392135426048,
  "in_reply_to_status_id" : 23204819946704897,
  "created_at" : "Fri Jan 07 02:36:49 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.9557901518, -75.1820611954 ]
  },
  "id_str" : "23203515824349184",
  "text" : "Philllllyyyy (@ 30th Street Station w/ 8 others) http://4sq.com/gEjNEH",
  "id" : 23203515824349184,
  "created_at" : "Fri Jan 07 02:25:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.2185893898, -74.7538250685 ]
  },
  "id_str" : "23196831164928000",
  "text" : "I'm at Trenton Transit Center (72 S Clinton Ave, Barlow St, Trenton) w/ 6 others [pic]: http://4sq.com/dWN4mQ",
  "id" : 23196831164928000,
  "created_at" : "Fri Jan 07 01:58:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.5686216512, -74.3293762207 ]
  },
  "id_str" : "23191225901260800",
  "text" : "Gettin closer! (@ Metropark Station (NJT/Amtrak) w/ 3 others) http://4sq.com/gDgInN",
  "id" : 23191225901260800,
  "created_at" : "Fri Jan 07 01:36:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23172361205321728",
  "text" : "ate really fast, awesome pizza, to rush back to penn station...now I've got 40 min to kill (train's on time)",
  "id" : 23172361205321728,
  "created_at" : "Fri Jan 07 00:21:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7519916, -73.989969 ]
  },
  "id_str" : "23166498965032960",
  "text" : "I'm at The Bread Factory Café (470 Seventh Ave, W 35th St & W 36th St, New York) http://4sq.com/fYVK8W",
  "id" : 23166498965032960,
  "created_at" : "Thu Jan 06 23:58:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7503780899, -73.9928770065 ]
  },
  "id_str" : "23158226602172416",
  "text" : "I'm at New York Penn Station (1-2 Penn Plz, btw 31st St & 33rd St, New York) w/ 62 others http://4sq.com/eOhSwL",
  "id" : 23158226602172416,
  "created_at" : "Thu Jan 06 23:25:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23147830835154945",
  "text" : "next stop 20min, NEW YORK!",
  "id" : 23147830835154945,
  "created_at" : "Thu Jan 06 22:44:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1898936423, -73.8824987411 ]
  },
  "id_str" : "23146956335349760",
  "text" : "I'm at Amtrak - Croton Harmon Train Station (1 Croton Point Avenue, Croton-on-Hudson) http://4sq.com/f1lpE3",
  "id" : 23146956335349760,
  "created_at" : "Thu Jan 06 22:40:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23140673137938432",
  "text" : "Clif bar for dinner, or to hold me off until I grab somethin at penn station...",
  "id" : 23140673137938432,
  "created_at" : "Thu Jan 06 22:15:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23135251857412096",
  "text" : "Sunset over the hudson, not a great picture: http://yfrog.com/h4kynvj",
  "id" : 23135251857412096,
  "created_at" : "Thu Jan 06 21:54:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23120620610920448",
  "geo" : {
  },
  "id_str" : "23122136092639232",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e thru Sunday morning, we'll def have to meet up!!",
  "id" : 23122136092639232,
  "in_reply_to_status_id" : 23120620610920448,
  "created_at" : "Thu Jan 06 21:02:01 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.6409358844, -73.7411785126 ]
  },
  "id_str" : "23121167657205760",
  "text" : "I'm at Albany-Rensselaer Train Station (525 East St, Rensselaer) http://4sq.com/ie9REZ",
  "id" : 23121167657205760,
  "created_at" : "Thu Jan 06 20:58:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 56, 65 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23120976069791744",
  "text" : "Finally leaving albany! Felt like half an hour sitting. @RBSherfy yeah now I'm just hopin to make it to my transfer in time...",
  "id" : 23120976069791744,
  "created_at" : "Thu Jan 06 20:57:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23114533153280001",
  "geo" : {
  },
  "id_str" : "23119472508276736",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yup, on the train now. We've been stopped at albany for what feels like an hour now. Should be to dc by midnight",
  "id" : 23119472508276736,
  "in_reply_to_status_id" : 23114533153280001,
  "created_at" : "Thu Jan 06 20:51:26 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.065903, -76.205612 ]
  },
  "id_str" : "23068324086685697",
  "text" : "Boarded! Window seat baby (@ Lake Shore Limited (Amtrak)) [pic]: http://4sq.com/dMnoZx",
  "id" : 23068324086685697,
  "created_at" : "Thu Jan 06 17:28:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23060620081373187",
  "text" : "Apparently the train is running 30-40min late...",
  "id" : 23060620081373187,
  "created_at" : "Thu Jan 06 16:57:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21620813350309888",
  "geo" : {
  },
  "id_str" : "23060350635085824",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan what was the message that you got from it?",
  "id" : 23060350635085824,
  "in_reply_to_status_id" : 21620813350309888,
  "created_at" : "Thu Jan 06 16:56:30 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 16, 23 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 51, 66 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23053639610273792",
  "geo" : {
  },
  "id_str" : "23057838779662336",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @dzdan1 that's strange, I remember @ryandelgiudice listening to him in like 10th grade",
  "id" : 23057838779662336,
  "in_reply_to_status_id" : 23053639610273792,
  "created_at" : "Thu Jan 06 16:46:31 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23021301408993281",
  "geo" : {
  },
  "id_str" : "23055934930554880",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 thanks buddy! As soon as I get back I'm going to the atm for the beachhouse, we need to reserve asap, hold me to it!",
  "id" : 23055934930554880,
  "in_reply_to_status_id" : 23021301408993281,
  "created_at" : "Thu Jan 06 16:38:57 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.073155, -76.179403 ]
  },
  "id_str" : "23055206006657024",
  "text" : "I'm at Amtrak - Syracuse Station http://4sq.com/hYT07e",
  "id" : 23055206006657024,
  "created_at" : "Thu Jan 06 16:36:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 73, 88 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23052828998115328",
  "text" : "waitin at the station, got my tickets printed! Thanks again for the ride @ryandelgiudice",
  "id" : 23052828998115328,
  "created_at" : "Thu Jan 06 16:26:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 43, 58 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23043450739888128",
  "text" : "fast run (some 6:30 miles), packed up, and @ryandelgiudice takin me to the train station!!",
  "id" : 23043450739888128,
  "created_at" : "Thu Jan 06 15:49:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23020982205685760",
  "text" : "couldn't find my under armour long sleeve...runnin on the treadmill",
  "id" : 23020982205685760,
  "created_at" : "Thu Jan 06 14:20:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 27, 43 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 69, 84 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23010804425031680",
  "text" : "omlette for breakfast from @rumblinstumblin then goin for a run with @ryandelgiudice, wake up! http://yfrog.com/gyvjwtsj",
  "id" : 23010804425031680,
  "created_at" : "Thu Jan 06 13:39:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 84, 91 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 92, 107 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 108, 119 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22877922800967680",
  "text" : "Might learn to play poker some day, but I don't have the patience now.... good game @dzdan1 @ryandelgiudice @kreagannet",
  "id" : 22877922800967680,
  "created_at" : "Thu Jan 06 04:51:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 54, 61 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22849549047439360",
  "geo" : {
  },
  "id_str" : "22850054003884033",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice nope but I know what fag does...cough @DZdan1 cough",
  "id" : 22850054003884033,
  "in_reply_to_status_id" : 22849549047439360,
  "created_at" : "Thu Jan 06 03:00:52 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 45, 52 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "np",
      "indices" : [ 37, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22849245165920257",
  "text" : "Black Eyed Peas - Love You Long Time #np via @DZdan1",
  "id" : 22849245165920257,
  "created_at" : "Thu Jan 06 02:57:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 85, 92 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 97, 112 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22848173907120128",
  "text" : "the software lost my workout data!!!!! ahh?!?!  ...maybe goin to village tavern with @DZdan1 and @ryandelgiudice",
  "id" : 22848173907120128,
  "created_at" : "Thu Jan 06 02:53:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22834262189285376",
  "text" : "solid workout: 5x6min 110% FTP -&gt; short run -&gt; abs/pushups -&gt; yoga/stretching. Chocolate milk time!",
  "id" : 22834262189285376,
  "created_at" : "Thu Jan 06 01:58:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22798149097623554",
  "text" : "Got home from work, shoveled some food and its straight on the trainer for me",
  "id" : 22798149097623554,
  "created_at" : "Wed Jan 05 23:34:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22698745686654976",
  "text" : "headed to La Tacqueria for lunch! And a new post (and theme) on http://andyreagan.com",
  "id" : 22698745686654976,
  "created_at" : "Wed Jan 05 16:59:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22676548939157504",
  "text" : "check out the sticker they put on the new crackberries (and the new torch is a really really sweet phone) http://yfrog.com/gzh13aj",
  "id" : 22676548939157504,
  "created_at" : "Wed Jan 05 15:31:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 56, 65 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22647814542589952",
  "text" : "6 inches of snow but work doesn't get cancelled, thanks @dmreagan for letting me take your subaru!",
  "id" : 22647814542589952,
  "created_at" : "Wed Jan 05 13:37:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 59, 66 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 68, 77 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22453646054658048",
  "text" : "Solid ~7 mile run through the woods, we need more trails!! @DZdan1: @dmreagan (my mom) ran 5.5, you're comin with me tmrw!",
  "id" : 22453646054658048,
  "created_at" : "Wed Jan 05 00:45:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 10, 17 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 18, 33 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22427279099432960",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @DZdan1 @ryandelgiudice any of you guys wanna come for a short run?",
  "id" : 22427279099432960,
  "created_at" : "Tue Jan 04 23:00:54 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22356948074627072",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan are you home today?",
  "id" : 22356948074627072,
  "created_at" : "Tue Jan 04 18:21:26 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O'Brien & Gere",
      "screen_name" : "OBRIEN_GERE",
      "indices" : [ 40, 52 ],
      "id_str" : "87009488",
      "id" : 87009488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22340259220037633",
  "text" : "One weak microwave for a whole floor... @OBRIEN_GERE #fail",
  "id" : 22340259220037633,
  "created_at" : "Tue Jan 04 17:15:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22327478253002753",
  "text" : "noticed my watch was slow this morning, and now its dead....maybe I slept holding the backlight on? Less than a month battery life...weak",
  "id" : 22327478253002753,
  "created_at" : "Tue Jan 04 16:24:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22284446111637505",
  "text" : "whipped up a delicious omlet for breakfast and got gas on the way to work: a poor 29.1mpg on the last tank...60 miles driven in the new year",
  "id" : 22284446111637505,
  "created_at" : "Tue Jan 04 13:33:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "wtf",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22154458402131969",
  "text" : "got a sick new sleeping bag today, and made a T-SHIRT WITH POCKETS IN THE BACK!!! f'ing #hokies couldn't pull through though #wtf",
  "id" : 22154458402131969,
  "created_at" : "Tue Jan 04 04:56:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22101609223815169",
  "text" : "let's go #hokies!!!",
  "id" : 22101609223815169,
  "created_at" : "Tue Jan 04 01:26:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21660672311959552",
  "text" : "Just woke up and looked at a clock...whoops",
  "id" : 21660672311959552,
  "created_at" : "Sun Jan 02 20:14:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 48, 57 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 108, 115 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21478167466217472",
  "text" : "great first day of 2011. the bars sucked DT but @DKnick88 with the win, id just like to note my early lead. @dzdan1 you speak whale??",
  "id" : 21478167466217472,
  "created_at" : "Sun Jan 02 08:09:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 10, 17 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 25, 40 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 41, 50 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21399859353358336",
  "text" : "Headed to @dzdan1's with @ryandelgiudice @DKnick88, then DT!",
  "id" : 21399859353358336,
  "created_at" : "Sun Jan 02 02:58:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SU",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21306366140358656",
  "text" : "watchin the #SU game!",
  "id" : 21306366140358656,
  "created_at" : "Sat Jan 01 20:46:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21269538024718336",
  "geo" : {
  },
  "id_str" : "21281919161335808",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice take her for a run!",
  "id" : 21281919161335808,
  "in_reply_to_status_id" : 21269538024718336,
  "created_at" : "Sat Jan 01 19:09:39 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 40, 49 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 75, 84 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21259381349814272",
  "text" : "Bike: 13 Car: 0.2, a good start to 2011 @RBSherfy. The \"Resolution Run\" w/ @dmreagan, ~5mi, was fun! Abt 600ppl there!!",
  "id" : 21259381349814272,
  "created_at" : "Sat Jan 01 17:40:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21222269242056704",
  "text" : "Headed downtown on my bike for the Resolution Run!",
  "id" : 21222269242056704,
  "created_at" : "Sat Jan 01 15:12:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 14, 23 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 24, 39 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 40, 51 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 71, 78 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 86, 95 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 106, 121 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21116310947627008",
  "text" : "fun new years @DKnick88 @ryandelgiudice @skholden17, thanks 4 the ride @DZdan1. Sorry @DKnick88 beat u up @ryandelgiudice",
  "id" : 21116310947627008,
  "created_at" : "Sat Jan 01 08:11:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21105646829047808",
  "text" : "2011 errrrbody!! Just image all the people, living life in peace",
  "id" : 21105646829047808,
  "created_at" : "Sat Jan 01 07:29:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]