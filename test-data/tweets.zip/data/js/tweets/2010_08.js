Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Morrow",
      "screen_name" : "jmorrow13",
      "indices" : [ 0, 10 ],
      "id_str" : "184125339",
      "id" : 184125339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22639290352",
  "in_reply_to_user_id" : 184125339,
  "text" : "@jmorrow13 you're embarrassing your followers with these tags haha get it right",
  "id" : 22639290352,
  "created_at" : "Tue Aug 31 18:30:02 +0000 2010",
  "in_reply_to_screen_name" : "jmorrow13",
  "in_reply_to_user_id_str" : "184125339",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 53, 66 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22639274863",
  "text" : "has got two more classes, then dinner on campus with @laurentappan! :)  then swimming maybe",
  "id" : 22639274863,
  "created_at" : "Tue Aug 31 18:29:47 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22570112634",
  "text" : "On my way to Roanoke to pick Nick and Nicole up from the hospital, a rider on his ride today got hit but she's ok",
  "id" : 22570112634,
  "created_at" : "Tue Aug 31 00:27:45 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22548322192",
  "text" : "ran for an hour, showered and now headed to campus to do work until the cycling meeting, moes, and warren's!",
  "id" : 22548322192,
  "created_at" : "Mon Aug 30 19:01:35 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.203509, -80.4316373333 ]
  },
  "id_str" : "22523588216",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet good luck on your first day of classes bro!!",
  "id" : 22523588216,
  "created_at" : "Mon Aug 30 13:23:46 +0000 2010",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22473835702",
  "text" : "got back from MTB'ing at 4 (5 hours later haha), ate a whole pizza at sport club officers workshop and now an hour of work b4 mass!",
  "id" : 22473835702,
  "created_at" : "Sun Aug 29 22:49:29 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.282278, -80.465448 ]
  },
  "id_str" : "22446555906",
  "text" : "is goin mountain biking!",
  "id" : 22446555906,
  "created_at" : "Sun Aug 29 15:37:39 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Morrow",
      "screen_name" : "jmorrow13",
      "indices" : [ 3, 13 ],
      "id_str" : "184125339",
      "id" : 184125339
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 48, 61 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 66, 77 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.389272, -80.083944 ]
  },
  "id_str" : "22389154559",
  "text" : "RT @jmorrow13: Double date to homeplace :) with @laurentappan and @andyreagan, 100+ ppl waiting, 1 hr wait but it'll be worth it!",
  "id" : 22389154559,
  "created_at" : "Sat Aug 28 22:50:52 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22370713041",
  "text" : "just went for a half hour run, the internet is down at the house so ill probably be heading to campus to do some work",
  "id" : 22370713041,
  "created_at" : "Sat Aug 28 17:34:29 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22271452417",
  "text" : "made a delicious egg and cheese bagel for breakfast this morning haha i'm gettin the hang of it, now errands then ....brewing science today!",
  "id" : 22271452417,
  "created_at" : "Fri Aug 27 14:32:03 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22217263798",
  "text" : "well apparently the tri team doesn't swim till after their first meeting next week lol...wait an hour for open pool or call it a night?",
  "id" : 22217263798,
  "created_at" : "Thu Aug 26 23:08:07 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22215705468",
  "text" : "just made myself another delicious hot ham egg and cheese! headed to swim practice with the tri team (broken bike...gotta swim lol)",
  "id" : 22215705468,
  "created_at" : "Thu Aug 26 22:44:54 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22212221501",
  "text" : "having a hard time deciding whether to audit human origins or not....and trying to stay awake in stat lol",
  "id" : 22212221501,
  "created_at" : "Thu Aug 26 21:51:49 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22193173242",
  "text" : "has undergraduate research!! Now just need to take care of paperwork and I get my 24/7 VBI badge and office haha",
  "id" : 22193173242,
  "created_at" : "Thu Aug 26 16:50:27 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22178463963",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet happy birthday bro!!",
  "id" : 22178463963,
  "created_at" : "Thu Aug 26 13:42:49 +0000 2010",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22137814105",
  "text" : "rode the race ride anyway with just one gear, my 39x14 and finished haha, rode up harding in that gear!! Excited to look at powermeter data",
  "id" : 22137814105,
  "created_at" : "Thu Aug 26 01:38:02 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22121270553",
  "text" : "'s shift lever just broke off! SRAM will warranty it most likely...but no race for me tonight",
  "id" : 22121270553,
  "created_at" : "Wed Aug 25 21:34:20 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22117957417",
  "text" : "Just made two delicious grilled ham egg and cheese sandwhiches! Now mentally preparing for WW haha http://twitpic.com/2i4iqy",
  "id" : 22117957417,
  "created_at" : "Wed Aug 25 20:42:46 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22105096011",
  "text" : "found out that I have till friday to find ugrad research haha...and there currently is no BS/MS program, they're workin on it",
  "id" : 22105096011,
  "created_at" : "Wed Aug 25 17:16:02 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22103121721",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet good luck moving in to UB!",
  "id" : 22103121721,
  "created_at" : "Wed Aug 25 16:46:57 +0000 2010",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22041808357",
  "text" : "we just used my kill-a-watt power meter to determine that an energy star fridge would save us $164/year...but that's a 6-year ROI for us",
  "id" : 22041808357,
  "created_at" : "Tue Aug 24 23:46:32 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22041734147",
  "text" : "And I'm meeting tmrw with the vt math ugrad research director, hopefully to get some research! And Dave is a 5 star chef haha great dinner",
  "id" : 22041734147,
  "created_at" : "Tue Aug 24 23:45:28 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22041681259",
  "text" : "and so my Human Origins and Statistics class are going to be great as well! Only one more class, brewing science!!",
  "id" : 22041681259,
  "created_at" : "Tue Aug 24 23:44:43 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22019967873",
  "text" : "stopped in the new bike shop in town (there are 4 now haha) and saw Zach Morrey and he gave me some locktight for my self-loosening crank!",
  "id" : 22019967873,
  "created_at" : "Tue Aug 24 18:03:23 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22019881154",
  "text" : "it was great seeing another Marcellian 4 lunch. i'm excited for Modern Algebra too, it's purely abstract and that's what i'm in the mood for",
  "id" : 22019881154,
  "created_at" : "Tue Aug 24 18:01:58 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22009007941",
  "text" : "cycling meeting and first class were great! Linear algebra will be fun. Seeing people I know on campus too!! Now lunch at west end :)",
  "id" : 22009007941,
  "created_at" : "Tue Aug 24 15:25:37 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21956925098",
  "text" : "PBJ's for dinner tonight it looks like haha",
  "id" : 21956925098,
  "created_at" : "Tue Aug 24 00:31:02 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21956608566",
  "text" : "and my car is good now, all it really did need was some driving and engine cleaner stuff!",
  "id" : 21956608566,
  "created_at" : "Tue Aug 24 00:26:29 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21956542535",
  "text" : "got the powertap on and just went for a test ride up Roanoke St, 1417 WATTS baby!!",
  "id" : 21956542535,
  "created_at" : "Tue Aug 24 00:25:31 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21923842843",
  "text" : "Got my fixie all put back together, bought my books, and now headed to Roanoke...we'll see if this helps the car (that's the goal)",
  "id" : 21923842843,
  "created_at" : "Mon Aug 23 15:52:23 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21876984884",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan i have your phone, you left it here PS I love the poster",
  "id" : 21876984884,
  "created_at" : "Mon Aug 23 01:58:57 +0000 2010",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 26, 39 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21876914695",
  "text" : "got a powertap wheel from @blogblogblog (Reid) tonight! Can't wait to get on the road with it",
  "id" : 21876914695,
  "created_at" : "Mon Aug 23 01:57:52 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21867526119",
  "text" : "fantasy football begins!! drafting now",
  "id" : 21867526119,
  "created_at" : "Sun Aug 22 23:32:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21842911801",
  "text" : "has got my desk together and now my computer on for the first time in four days! Still a lot of moving in to do...",
  "id" : 21842911801,
  "created_at" : "Sun Aug 22 16:44:37 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21784338591",
  "text" : "Hooked up the tv and 5.1 surrond stereo, now building my desk...check out the layout: http://twitpic.com/2gyqbq",
  "id" : 21784338591,
  "created_at" : "Sat Aug 21 23:13:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21767296137",
  "text" : "just rode the century (100 miles on my bike) in 5hrs and 4min, just under 20mph average!!",
  "id" : 21767296137,
  "created_at" : "Sat Aug 21 18:00:48 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21742134226",
  "text" : "Doin the burkes garden century this morning! 100 flat miles comin up, course record is a crazy 3hrs 45min",
  "id" : 21742134226,
  "created_at" : "Sat Aug 21 11:33:12 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21705521747",
  "text" : "after moving all the heavy stuff into Laurens apt, I worked all day on building bombproof shelves and a desk http://twitpic.com/2gm3jo",
  "id" : 21705521747,
  "created_at" : "Sat Aug 21 00:04:51 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 11, 24 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21666892978",
  "text" : "is helping @laurentappan move in this morning, her apt is really nice...our off campus housing is completely opposite haha",
  "id" : 21666892978,
  "created_at" : "Fri Aug 20 14:05:30 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21623556862",
  "text" : "got a great dinner at Mikes Grill, and got my car FULL of stuff to move in now...the car is running like sh*t tho, it revs on idle by itself",
  "id" : 21623556862,
  "created_at" : "Fri Aug 20 01:10:59 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21608055893",
  "text" : "at my house!!",
  "id" : 21608055893,
  "created_at" : "Thu Aug 19 21:11:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21596374486",
  "text" : "blinked and missed Maryland and WV haha, in the home stretch VA...another three or so hours till Blacksburg!",
  "id" : 21596374486,
  "created_at" : "Thu Aug 19 17:53:15 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21576188295",
  "text" : "Hello PA! Driving through you sucks",
  "id" : 21576188295,
  "created_at" : "Thu Aug 19 13:15:49 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21531388838",
  "geo" : {
  },
  "id_str" : "21575935272",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr yup I won the series!",
  "id" : 21575935272,
  "in_reply_to_status_id" : 21531388838,
  "created_at" : "Thu Aug 19 13:12:12 +0000 2010",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21566620516",
  "text" : "is Blacksburg, here we come!",
  "id" : 21566620516,
  "created_at" : "Thu Aug 19 10:28:15 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21522465659",
  "text" : "had a delicious lunch at the Sherwood Inn, thanks Mrs. Scheutzow, beat up on Zdanowski & John in disc golf, and now its time to pack!!",
  "id" : 21522465659,
  "created_at" : "Wed Aug 18 21:41:11 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21489343537",
  "text" : "is going for a short bike ride this morning, the first in a week, to begin a busy last day in NY!",
  "id" : 21489343537,
  "created_at" : "Wed Aug 18 13:17:14 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 33, 46 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 48, 63 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21356626128",
  "text" : "going to Tully's for dinner with @laurentappan, @ryandelgiudice, @hweeks0 and the whole gang!!",
  "id" : 21356626128,
  "created_at" : "Tue Aug 17 00:03:35 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 19, 32 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 52, 61 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21182360795",
  "text" : "is hangin out with @laurentappan at my house :) and @vmhilljr!",
  "id" : 21182360795,
  "created_at" : "Sat Aug 14 22:23:49 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 59, 72 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21099998841",
  "text" : "at Rico's Ristorante with my parents, super excited to see @laurentappan tomorrow!!",
  "id" : 21099998841,
  "created_at" : "Fri Aug 13 22:18:55 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21093086755",
  "text" : "just got done mowin the lawn! I'm a pro haha still got the touch",
  "id" : 21093086755,
  "created_at" : "Fri Aug 13 20:27:47 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "21016496645",
  "text" : "Goin down to play some pick up basketball!",
  "id" : 21016496645,
  "created_at" : "Thu Aug 12 23:54:01 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20929028087",
  "text" : "and tonight eating at \"five gays\" according to my mom haha http://twitpic.com/2dtntm",
  "id" : 20929028087,
  "created_at" : "Thu Aug 12 00:15:59 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "training",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.049158, -76.260385 ]
  },
  "id_str" : "20926602207",
  "text" : "biked 13 miles, did 7 hours of yard work in the hott sun and when there wasn't a dry spot left on my shirt, 13 miles home today! #training",
  "id" : 20926602207,
  "created_at" : "Wed Aug 11 23:39:38 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20824197928",
  "text" : "headin up to the TNTS local race tonight!! Just pounded three grilled cheese though haha whoops",
  "id" : 20824197928,
  "created_at" : "Tue Aug 10 20:48:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20745072116",
  "text" : "went on a nice 30mi bike ride with Sarah Holden today! Good thing, it's pouring out now #FB",
  "id" : 20745072116,
  "created_at" : "Mon Aug 09 23:18:14 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20680098465",
  "text" : "finished the book \"Ender's Game\" tonight, it was good. And just put my class schedule & finals in gmail and made a printable one...school?!",
  "id" : 20680098465,
  "created_at" : "Mon Aug 09 04:04:56 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.971281, -76.344385 ]
  },
  "id_str" : "20644568019",
  "text" : "got 2nd place in the bike leg!!! Out of 394 people, not too shabby haha, passed alllll those cervelo p4s on zipp 808s with my aero power :-P",
  "id" : 20644568019,
  "created_at" : "Sun Aug 08 17:51:31 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.897668, -76.537088 ]
  },
  "id_str" : "20628092887",
  "text" : "warmin up for the bike leg of the Great Race!",
  "id" : 20628092887,
  "created_at" : "Sun Aug 08 13:25:42 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.971281, -76.344385 ]
  },
  "id_str" : "20600408541",
  "text" : "had a fun day of sleeping and bridge jumping after going out last night downtown :) Hittin the hay for the Great Race tomorrow!",
  "id" : 20600408541,
  "created_at" : "Sun Aug 08 03:43:32 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20490166732",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.971281, -76.344385 ]
  },
  "id_str" : "20504747372",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice dude don't worry lol we're havin one when you get here! That's the 10th, right?",
  "id" : 20504747372,
  "in_reply_to_status_id" : 20490166732,
  "created_at" : "Fri Aug 06 22:51:35 +0000 2010",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.971281, -76.344385 ]
  },
  "id_str" : "20500108934",
  "text" : "Goin for a short bike ride in the TT stuff, gearin up for Sunday's race!",
  "id" : 20500108934,
  "created_at" : "Fri Aug 06 21:31:41 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20486629095",
  "text" : "slept in till noon for the second day in a row after a great bonfire, goin disc golfing now!",
  "id" : 20486629095,
  "created_at" : "Fri Aug 06 17:40:44 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 66, 76 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.970842, -76.34472 ]
  },
  "id_str" : "20412168654",
  "text" : "Goin for a bike ride around Otisco Lake! It will be weird without @bikebuild #FB",
  "id" : 20412168654,
  "created_at" : "Thu Aug 05 19:48:18 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 9, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.121616, -76.128086 ]
  },
  "id_str" : "20317882202",
  "text" : "Is HOME! #FB",
  "id" : 20317882202,
  "created_at" : "Wed Aug 04 16:49:45 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 114, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20295091669",
  "text" : "is in JFK, 3 hour layover then going to SYR! Took 74 days to the west coast by bike, 4.5 hrs back in the air haha #FB",
  "id" : 20295091669,
  "created_at" : "Wed Aug 04 10:41:03 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.596179, -122.599204 ]
  },
  "id_str" : "20281640606",
  "text" : "Boarding the plane, be in JFK @ 3:30AM PST, so 6:30 there!",
  "id" : 20281640606,
  "created_at" : "Wed Aug 04 05:28:47 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 61, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.596179, -122.599204 ]
  },
  "id_str" : "20278729930",
  "text" : "waiting for my plane HOME! My bike got checked for free haha #FB",
  "id" : 20278729930,
  "created_at" : "Wed Aug 04 04:34:38 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "indices" : [ 3, 9 ],
      "id_str" : "30967859",
      "id" : 30967859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "20234028660",
  "text" : "RT @bsim9: biiiiikkkkkeeee and buuuuiiiilllldddd! come back to me! i miss you already! woop woop! cus 2010!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "20168092102",
    "text" : "biiiiikkkkkeeee and buuuuiiiilllldddd! come back to me! i miss you already! woop woop! cus 2010!",
    "id" : 20168092102,
    "created_at" : "Mon Aug 02 21:15:34 +0000 2010",
    "user" : {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "protected" : false,
      "id_str" : "30967859",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/136469345/Me_kicking_normal.jpg",
      "id" : 30967859,
      "verified" : false
    }
  },
  "id" : 20234028660,
  "created_at" : "Tue Aug 03 16:32:18 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 58, 67 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.588348, -122.574198 ]
  },
  "id_str" : "20143705346",
  "text" : "going downtown to rent a tandem and explore Portland with @dmreagan!",
  "id" : 20143705346,
  "created_at" : "Mon Aug 02 14:35:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]