Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/VDcfA7Uh",
      "expanded_url" : "http://twitpic.com/azt7j6",
      "display_url" : "twitpic.com/azt7j6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.03414071, -71.94374182 ]
  },
  "id_str" : "252419013932621824",
  "text" : "tough race today, with a mechanical on the bike and a biological on the run, but still wasn't much slower http://t.co/VDcfA7Uh",
  "id" : 252419013932621824,
  "created_at" : "Sun Sep 30 14:45:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 53, 60 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 61, 74 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/Mhl1XpBn",
      "expanded_url" : "http://twitpic.com/azpi1b",
      "display_url" : "twitpic.com/azpi1b"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.0739069, -71.9427543 ]
  },
  "id_str" : "252329219873456128",
  "text" : "how did just the middle of my  race number wipe off? @ttmill @UVMTriathlon http://t.co/Mhl1XpBn",
  "id" : 252329219873456128,
  "created_at" : "Sun Sep 30 08:49:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 18, 29 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allofthefame",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/AQPDnhUH",
      "expanded_url" : "http://twitter.com/UVMTriathlon/status/252186458197221376/photo/1",
      "display_url" : "pic.twitter.com/AQPDnhUH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252189738407170048",
  "text" : "RT @UVMTriathlon: @andyreagan getting interview by NECTC. #allofthefame http://t.co/AQPDnhUH",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/UVMTriathlon/status/252186458197221376/photo/1",
        "indices" : [ 54, 74 ],
        "url" : "http://t.co/AQPDnhUH",
        "media_url" : "http://pbs.twimg.com/media/A3_yP2JCYAE-me3.jpg",
        "id_str" : "252186458201415681",
        "id" : 252186458201415681,
        "media_url_https" : "https://pbs.twimg.com/media/A3_yP2JCYAE-me3.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/AQPDnhUH"
      } ],
      "hashtags" : [ {
        "text" : "allofthefame",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "252186458197221376",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan getting interview by NECTC. #allofthefame http://t.co/AQPDnhUH",
    "id" : 252186458197221376,
    "created_at" : "Sat Sep 29 23:21:53 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 252189738407170048,
  "created_at" : "Sat Sep 29 23:34:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tri",
      "indices" : [ 82, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.03441752, -71.94506884 ]
  },
  "id_str" : "252168597680574464",
  "text" : "set up my bike, went for quick run, napped and now for the prerace pasta dinner!! #tri",
  "id" : 252168597680574464,
  "created_at" : "Sat Sep 29 22:10:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ultraVT",
      "screen_name" : "ultraVT",
      "indices" : [ 0, 8 ],
      "id_str" : "728575250",
      "id" : 728575250
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 9, 18 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252151394226810880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.04451663, -71.95055172 ]
  },
  "id_str" : "252167604138020867",
  "in_reply_to_user_id" : 728575250,
  "text" : "@ultraVT @Run_Rudy awesome job!!!",
  "id" : 252167604138020867,
  "in_reply_to_status_id" : 252151394226810880,
  "created_at" : "Sat Sep 29 22:06:56 +0000 2012",
  "in_reply_to_screen_name" : "ultraVT",
  "in_reply_to_user_id_str" : "728575250",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.34357721, -72.41053274 ]
  },
  "id_str" : "251888036969865216",
  "text" : "excellent dinner from Ike's parents in Essex. Down for the night, the journey to Montauk continues tomorrow!",
  "id" : 251888036969865216,
  "created_at" : "Sat Sep 29 03:36:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 3, 11 ],
      "id_str" : "811907299",
      "id" : 811907299
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 36, 50 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beer",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "running",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "math",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251838595365752832",
  "text" : "RT @linzvee: I decided I agree with @ChrisDanforth , #beer #running and studying #math *is* the best life ever. That's some solid advising!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Danforth",
        "screen_name" : "ChrisDanforth",
        "indices" : [ 23, 37 ],
        "id_str" : "301579658",
        "id" : 301579658
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beer",
        "indices" : [ 40, 45 ]
      }, {
        "text" : "running",
        "indices" : [ 46, 54 ]
      }, {
        "text" : "math",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 44.47923452, -73.21302785 ]
    },
    "id_str" : "251823045885448192",
    "text" : "I decided I agree with @ChrisDanforth , #beer #running and studying #math *is* the best life ever. That's some solid advising!",
    "id" : 251823045885448192,
    "created_at" : "Fri Sep 28 23:17:47 +0000 2012",
    "user" : {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "protected" : false,
      "id_str" : "811907299",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2609674893/816m0iuvbbybuvqvb8io_normal.jpeg",
      "id" : 811907299,
      "verified" : false
    }
  },
  "id" : 251838595365752832,
  "created_at" : "Sat Sep 29 00:19:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251794331424419840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6695564, -72.3844766 ]
  },
  "id_str" : "251797189880336384",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr I just follow the GPS, looks like I'm about to drive into this big blue thing?",
  "id" : 251797189880336384,
  "in_reply_to_status_id" : 251794331424419840,
  "created_at" : "Fri Sep 28 21:35:02 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 19, 32 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triathlon",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.39406707, -72.96425715 ]
  },
  "id_str" : "251781370580447234",
  "text" : "on the way to CT w @UVMTriathlon uvmtrifor the Mightyman Tri this Sunday in Montauk #triathlon",
  "id" : 251781370580447234,
  "created_at" : "Fri Sep 28 20:32:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 126, 140 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4759226, -73.1969015 ]
  },
  "id_str" : "251762343762071552",
  "text" : "good talk by Dan Rothman: \"Methanogenic Blowup in End-Permian Carbon Cycle: Microbial Prelude to Earth's Greatest Extinction\" @uvmcomplexity",
  "id" : 251762343762071552,
  "created_at" : "Fri Sep 28 19:16:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "indices" : [ 61, 68 ],
      "id_str" : "394388191",
      "id" : 394388191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/q4lsen65",
      "expanded_url" : "http://unconsumption.tumblr.com/post/32465690813/woodguards-alternative-to-traditional-bike",
      "display_url" : "unconsumption.tumblr.com/post/324656908…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47606001, -73.19604523 ]
  },
  "id_str" : "251756567756685314",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 you definitely need to MAKE fenders for the trek :) \"@UVMBUG: cool fenders! http://t.co/q4lsen65\"",
  "id" : 251756567756685314,
  "created_at" : "Fri Sep 28 18:53:37 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science247",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/d1bHS2iC",
      "expanded_url" : "http://twitpic.com/az5tde",
      "display_url" : "twitpic.com/az5tde"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4833572, -73.1936142 ]
  },
  "id_str" : "251735192727851009",
  "text" : "connected to the VACC from my phone #science247 http://t.co/d1bHS2iC",
  "id" : 251735192727851009,
  "created_at" : "Fri Sep 28 17:28:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "calcjokes",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832421, -73.1934421 ]
  },
  "id_str" : "251732243872112641",
  "text" : "note to self: when indexing a series of B sets, don't index over j. good thing I asked if our sum in class was finite... #calcjokes",
  "id" : 251732243872112641,
  "created_at" : "Fri Sep 28 17:16:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 16, 28 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 29, 42 ],
      "id_str" : "328777340",
      "id" : 328777340
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 54, 62 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "addicts",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251484941353897985",
  "text" : "welcome to Moes @bikingbiebs @DaBrownNoise #addicts.  @Karo1yn and I WOULD see you there",
  "id" : 251484941353897985,
  "created_at" : "Fri Sep 28 00:54:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/qhXVWbet",
      "expanded_url" : "http://www.technologyreview.com/news/428530/facebook-the-real-presidential-swing-state/?nlid=nldly&nld=2012-08-29",
      "display_url" : "technologyreview.com/news/428530/fa…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251450564964151296",
  "text" : "\"Facebook: The Real Presidential Swing State\" http://t.co/qhXVWbet",
  "id" : 251450564964151296,
  "created_at" : "Thu Sep 27 22:37:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boss",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251434626470535168",
  "text" : "rode home with three group sets in panniers and TT bike on the shoulder from the bike shop #boss no reason for parking at a bike shop!",
  "id" : 251434626470535168,
  "created_at" : "Thu Sep 27 21:34:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251413791970045952",
  "geo" : {
  },
  "id_str" : "251433950923354112",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill veryyy nice!!! what kind of hub/rim? what ever happened to Argon??",
  "id" : 251433950923354112,
  "in_reply_to_status_id" : 251413791970045952,
  "created_at" : "Thu Sep 27 21:31:39 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/GX7JelGY",
      "expanded_url" : "http://twitpic.com/aywe1l",
      "display_url" : "twitpic.com/aywe1l"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48197953, -73.20320017 ]
  },
  "id_str" : "251425076447178752",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan hope youre ready to start training http://t.co/GX7JelGY",
  "id" : 251425076447178752,
  "created_at" : "Thu Sep 27 20:56:24 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251145063890026496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48192209, -73.20318698 ]
  },
  "id_str" : "251162480804495360",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser oh hang on!!",
  "id" : 251162480804495360,
  "in_reply_to_status_id" : 251145063890026496,
  "created_at" : "Thu Sep 27 03:32:56 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 14, 25 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peakfoliage",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/Np8uO2ie",
      "expanded_url" : "http://twitter.com/fatcyclist/status/251152600781713408/photo/1",
      "display_url" : "pic.twitter.com/Np8uO2ie"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4818413, -73.20322947 ]
  },
  "id_str" : "251162374697005057",
  "text" : "#peakfoliage \"@fatcyclist: Good riding on the local trails today. Shame about the scenery. http://t.co/Np8uO2ie\"",
  "id" : 251162374697005057,
  "created_at" : "Thu Sep 27 03:32:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hash",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48218699, -73.20323747 ]
  },
  "id_str" : "251076217409773568",
  "text" : "after a very busy day, I'm pumped for a fast #hash",
  "id" : 251076217409773568,
  "created_at" : "Wed Sep 26 21:50:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "college",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/9N6C0ARx",
      "expanded_url" : "http://twitpic.com/aym1bw",
      "display_url" : "twitpic.com/aym1bw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822744, -73.2029127 ]
  },
  "id_str" : "251073828564901890",
  "text" : "Marc couldn't find anything else...put Srirache on his bagel #college http://t.co/9N6C0ARx",
  "id" : 251073828564901890,
  "created_at" : "Wed Sep 26 21:40:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/1F7whM9q",
      "expanded_url" : "http://twitter.com/sspis1/status/250794061823369216/photo/1",
      "display_url" : "pic.twitter.com/1F7whM9q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250799390871146497",
  "text" : "RT @sspis1: Valle de la muerte http://t.co/1F7whM9q",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/sspis1/status/250794061823369216/photo/1",
        "indices" : [ 19, 39 ],
        "url" : "http://t.co/1F7whM9q",
        "media_url" : "http://pbs.twimg.com/media/A3r_3tcCYAAbccT.jpg",
        "id_str" : "250794061827563520",
        "id" : 250794061827563520,
        "media_url_https" : "https://pbs.twimg.com/media/A3r_3tcCYAAbccT.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 660
        } ],
        "display_url" : "pic.twitter.com/1F7whM9q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "250794061823369216",
    "text" : "Valle de la muerte http://t.co/1F7whM9q",
    "id" : 250794061823369216,
    "created_at" : "Wed Sep 26 03:08:58 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 250799390871146497,
  "created_at" : "Wed Sep 26 03:30:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250431866723778561",
  "geo" : {
  },
  "id_str" : "250440257521188865",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I feel so uncultured, I have never seen this show!",
  "id" : 250440257521188865,
  "in_reply_to_status_id" : 250431866723778561,
  "created_at" : "Tue Sep 25 03:43:05 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/Qy4wGB7c",
      "expanded_url" : "http://demonocracy.info/infographics/usa/us_government_budget/us_govt_budget.html",
      "display_url" : "demonocracy.info/infographics/u…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250429889457582080",
  "text" : "neat vis: http://t.co/Qy4wGB7c",
  "id" : 250429889457582080,
  "created_at" : "Tue Sep 25 03:01:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250410961872252928",
  "geo" : {
  },
  "id_str" : "250412915352555521",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 excellent film!!! I've watched \\geq 12 times",
  "id" : 250412915352555521,
  "in_reply_to_status_id" : 250410961872252928,
  "created_at" : "Tue Sep 25 01:54:26 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/Wkp34Wh7",
      "expanded_url" : "http://www.youtube.com/watch?v=1wJB6uMt21c",
      "display_url" : "youtube.com/watch?v=1wJB6u…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250412820661956609",
  "text" : "RT @mrfrank5790: @andyreagan did they film the beginning of this in your garage? http://t.co/Wkp34Wh7",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http://t.co/Wkp34Wh7",
        "expanded_url" : "http://www.youtube.com/watch?v=1wJB6uMt21c",
        "display_url" : "youtube.com/watch?v=1wJB6u…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "250410961872252928",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan did they film the beginning of this in your garage? http://t.co/Wkp34Wh7",
    "id" : 250410961872252928,
    "created_at" : "Tue Sep 25 01:46:40 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 250412820661956609,
  "created_at" : "Tue Sep 25 01:54:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/AKadYMzC",
      "expanded_url" : "http://instagr.am/p/P-jg1XOS4I/",
      "display_url" : "instagr.am/p/P-jg1XOS4I/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250384735803678721",
  "text" : "dropped off a letter and picked up avocados on tonight's run: #fb http://t.co/AKadYMzC",
  "id" : 250384735803678721,
  "created_at" : "Tue Sep 25 00:02:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250359683850858496",
  "geo" : {
  },
  "id_str" : "250370733375635456",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee magic mile pace??",
  "id" : 250370733375635456,
  "in_reply_to_status_id" : 250359683850858496,
  "created_at" : "Mon Sep 24 23:06:49 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250297991888506880",
  "text" : "RT @dr_pyser: teaching vermonters the word \"flanno\".",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "250284749531275264",
    "text" : "teaching vermonters the word \"flanno\".",
    "id" : 250284749531275264,
    "created_at" : "Mon Sep 24 17:25:09 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 250297991888506880,
  "created_at" : "Mon Sep 24 18:17:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "indices" : [ 3, 16 ],
      "id_str" : "49445813",
      "id" : 49445813
    }, {
      "name" : "Sandra Upson",
      "screen_name" : "sandraupson",
      "indices" : [ 118, 130 ],
      "id_str" : "63157272",
      "id" : 63157272
    }, {
      "name" : "Brian Griffing",
      "screen_name" : "b",
      "indices" : [ 134, 136 ],
      "id_str" : "11266532",
      "id" : 11266532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/0i6QGArO",
      "expanded_url" : "http://ow.ly/dX2WS",
      "display_url" : "ow.ly/dX2WS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250297888205307904",
  "text" : "RT @MarkChangizi: Nature-bending: toward the one-ton pumpkin. [Biggest fruit ever (I presume?).] http://t.co/0i6QGArO @sandraupson by @b ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandra Upson",
        "screen_name" : "sandraupson",
        "indices" : [ 100, 112 ],
        "id_str" : "63157272",
        "id" : 63157272
      }, {
        "name" : "Billy Baker",
        "screen_name" : "billy_baker",
        "indices" : [ 116, 128 ],
        "id_str" : "21248962",
        "id" : 21248962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/0i6QGArO",
        "expanded_url" : "http://ow.ly/dX2WS",
        "display_url" : "ow.ly/dX2WS"
      } ]
    },
    "in_reply_to_status_id_str" : "250286575378919424",
    "geo" : {
    },
    "id_str" : "250289179211202560",
    "in_reply_to_user_id" : 63157272,
    "text" : "Nature-bending: toward the one-ton pumpkin. [Biggest fruit ever (I presume?).] http://t.co/0i6QGArO @sandraupson by @billy_baker",
    "id" : 250289179211202560,
    "in_reply_to_status_id" : 250286575378919424,
    "created_at" : "Mon Sep 24 17:42:45 +0000 2012",
    "in_reply_to_screen_name" : "sandraupson",
    "in_reply_to_user_id_str" : "63157272",
    "user" : {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "protected" : false,
      "id_str" : "49445813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3170948141/9590642bbc2fba2279db6ead55b66fb0_normal.jpeg",
      "id" : 49445813,
      "verified" : false
    }
  },
  "id" : 250297888205307904,
  "created_at" : "Mon Sep 24 18:17:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250209399510028288",
  "geo" : {
  },
  "id_str" : "250296210718613504",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee that sounds enticing!! gah I hate speed work though ha",
  "id" : 250296210718613504,
  "in_reply_to_status_id" : 250209399510028288,
  "created_at" : "Mon Sep 24 18:10:41 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 25, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/gss6vTWG",
      "expanded_url" : "http://picard.ytmnd.com/",
      "display_url" : "picard.ytmnd.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250078540601643009",
  "text" : "on repeat in the dungeon #fb http://t.co/gss6vTWG",
  "id" : 250078540601643009,
  "created_at" : "Mon Sep 24 03:45:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4808885, -73.1988987 ]
  },
  "id_str" : "250044627745378304",
  "text" : "ahhh, that feeling that you've given a small part of your sanity to a math problem...",
  "id" : 250044627745378304,
  "created_at" : "Mon Sep 24 01:30:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 67, 74 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socool",
      "indices" : [ 58, 65 ]
    }, {
      "text" : "incredible",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/nm8gsGXJ",
      "expanded_url" : "http://yfrog.com/h770ycrj",
      "display_url" : "yfrog.com/h770ycrj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822677, -73.2028576 ]
  },
  "id_str" : "249671482211450881",
  "text" : ".@sspis1 can check visiting surface of moon off checklist #socool \"@sspis1: Valle de la Luna #incredible http://t.co/nm8gsGXJ\"",
  "id" : 249671482211450881,
  "created_at" : "Sun Sep 23 00:48:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249630785945075713",
  "geo" : {
  },
  "id_str" : "249643643923734528",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn and salsa",
  "id" : 249643643923734528,
  "in_reply_to_status_id" : 249630785945075713,
  "created_at" : "Sat Sep 22 22:57:37 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wth",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4823002, -73.2027786 ]
  },
  "id_str" : "249626365152862208",
  "text" : "18 miles of running and my shoulders are sore #wth",
  "id" : 249626365152862208,
  "created_at" : "Sat Sep 22 21:48:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 118, 125 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 127, 135 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/H4gKpSl3",
      "expanded_url" : "http://bit.ly/UDq6WV",
      "display_url" : "bit.ly/UDq6WV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249618692629999617",
  "text" : "long run in the rain, felt great...almost thought about going for my marathon PR, I was on pace! http://t.co/H4gKpSl3 @sspis1  @linzvee",
  "id" : 249618692629999617,
  "created_at" : "Sat Sep 22 21:18:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249359633372827648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208119, -73.20354215 ]
  },
  "id_str" : "249548092750315520",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser nobody loves me on the internet...",
  "id" : 249548092750315520,
  "in_reply_to_status_id" : 249359633372827648,
  "created_at" : "Sat Sep 22 16:37:56 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Chandler Delinks",
      "screen_name" : "cdelinks",
      "indices" : [ 9, 18 ],
      "id_str" : "36920127",
      "id" : 36920127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/E1n2QQrf",
      "expanded_url" : "http://bikeportland.org/2012/06/28/with-six-kids-and-no-car-this-mom-does-it-all-by-bike-73731",
      "display_url" : "bikeportland.org/2012/06/28/wit…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822585, -73.2029141 ]
  },
  "id_str" : "249519300895973376",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@cdelinks: Momma bikes. http://t.co/E1n2QQrf\"",
  "id" : 249519300895973376,
  "created_at" : "Sat Sep 22 14:43:31 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.465933, -73.2130007 ]
  },
  "id_str" : "249369240484839424",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee  gangham style!",
  "id" : 249369240484839424,
  "created_at" : "Sat Sep 22 04:47:14 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 24, 32 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46555237, -73.21335436 ]
  },
  "id_str" : "249345984663003137",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 sneak peak @linzvee",
  "id" : 249345984663003137,
  "created_at" : "Sat Sep 22 03:14:50 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proud",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/8gUtyW4L",
      "expanded_url" : "http://slamthatstem.com",
      "display_url" : "slamthatstem.com"
    } ]
  },
  "in_reply_to_status_id_str" : "249274437248094208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822821, -73.2028259 ]
  },
  "id_str" : "249285220929515520",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud #proud. cut that steer tube and send it to http://t.co/8gUtyW4L!!",
  "id" : 249285220929515520,
  "in_reply_to_status_id" : 249274437248094208,
  "created_at" : "Fri Sep 21 23:13:22 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248913720724566017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48210856, -73.20318692 ]
  },
  "id_str" : "248915456549871616",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee yes, and yes!",
  "id" : 248915456549871616,
  "in_reply_to_status_id" : 248913720724566017,
  "created_at" : "Thu Sep 20 22:44:04 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 12, 20 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Boston Marathon",
      "screen_name" : "bostonmarathon",
      "indices" : [ 52, 67 ],
      "id_str" : "111037335",
      "id" : 111037335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48214427, -73.20315121 ]
  },
  "id_str" : "248915381425676288",
  "text" : "congrats!! \"@Karo1yn: Finally got accepted into the @bostonmarathon!!!! Bahh those guys at baa know how to freak a girl out!\"",
  "id" : 248915381425676288,
  "created_at" : "Thu Sep 20 22:43:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48215635, -73.20319076 ]
  },
  "id_str" : "248915279516667905",
  "text" : "run core stretch eat math",
  "id" : 248915279516667905,
  "created_at" : "Thu Sep 20 22:43:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248902197235027969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48216378, -73.20319669 ]
  },
  "id_str" : "248915182078799872",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy looks PERFECT!!",
  "id" : 248915182078799872,
  "in_reply_to_status_id" : 248902197235027969,
  "created_at" : "Thu Sep 20 22:42:58 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 3, 12 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 23, 34 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "breadmachinehoneywholewheat",
      "indices" : [ 97, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248915118925152258",
  "text" : "RT @RBSherfy: Doing it @andyreagan style leave for math class come home to a warm loaf of bread. #breadmachinehoneywholewheat http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 9, 20 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/RBSherfy/status/248902197235027969/photo/1",
        "indices" : [ 112, 132 ],
        "url" : "http://t.co/uLVJ8dD3",
        "media_url" : "http://pbs.twimg.com/media/A3RHOspCEAEUbkl.jpg",
        "id_str" : "248902197239222273",
        "id" : 248902197239222273,
        "media_url_https" : "https://pbs.twimg.com/media/A3RHOspCEAEUbkl.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com/uLVJ8dD3"
      } ],
      "hashtags" : [ {
        "text" : "breadmachinehoneywholewheat",
        "indices" : [ 83, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "248902197235027969",
    "text" : "Doing it @andyreagan style leave for math class come home to a warm loaf of bread. #breadmachinehoneywholewheat http://t.co/uLVJ8dD3",
    "id" : 248902197235027969,
    "created_at" : "Thu Sep 20 21:51:23 +0000 2012",
    "user" : {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "protected" : false,
      "id_str" : "64328794",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2814889039/e6959e62768a895f3f8a4107a411edb5_normal.png",
      "id" : 64328794,
      "verified" : false
    }
  },
  "id" : 248915118925152258,
  "created_at" : "Thu Sep 20 22:42:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "consumerism",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48217457, -73.20282974 ]
  },
  "id_str" : "248891803338690561",
  "text" : "\"Indebtedness could discipline workers, keeping them at routinized jobs in factories and offices\" Jackson Years #consumerism",
  "id" : 248891803338690561,
  "created_at" : "Thu Sep 20 21:10:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 30, 42 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hash",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48215859, -73.20296896 ]
  },
  "id_str" : "248538291928981504",
  "text" : "headed to #hash, rumor has it @mrfrank5790 and I will hey hash names? we'll see",
  "id" : 248538291928981504,
  "created_at" : "Wed Sep 19 21:45:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 0, 12 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248444843431440386",
  "geo" : {
  },
  "id_str" : "248493155350085632",
  "in_reply_to_user_id" : 47645908,
  "text" : "@VTTriathlon that's very cool! jealous!",
  "id" : 248493155350085632,
  "in_reply_to_status_id" : 248444843431440386,
  "created_at" : "Wed Sep 19 18:45:59 +0000 2012",
  "in_reply_to_screen_name" : "VTTriathlon",
  "in_reply_to_user_id_str" : "47645908",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM GSS",
      "screen_name" : "UVMGSS",
      "indices" : [ 78, 85 ],
      "id_str" : "611854937",
      "id" : 611854937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVMGSS",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/dwKzzA0h",
      "expanded_url" : "http://twitpic.com/awb805",
      "display_url" : "twitpic.com/awb805"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4781987, -73.2008619 ]
  },
  "id_str" : "248446453918355457",
  "text" : "won my first ever election (...unopposed), @ the first senate meeting #UVMGSS @UVMGSS http://t.co/dwKzzA0h",
  "id" : 248446453918355457,
  "created_at" : "Wed Sep 19 15:40:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sorryancientgreeks",
      "indices" : [ 46, 65 ]
    }, {
      "text" : "measuretheory",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47959777, -73.19799606 ]
  },
  "id_str" : "248442083365490690",
  "text" : "\"nobody cares about the rationals there days\" #sorryancientgreeks #measuretheory",
  "id" : 248442083365490690,
  "created_at" : "Wed Sep 19 15:23:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 56, 61 ]
    }, {
      "text" : "lebesguemeasure",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4794892, -73.19824122 ]
  },
  "id_str" : "248440209581146113",
  "text" : "\"almost everywhere is really as good as everywhere now\" #math #lebesguemeasure",
  "id" : 248440209581146113,
  "created_at" : "Wed Sep 19 15:15:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 1, 13 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/cNotae5V",
      "expanded_url" : "http://twitpic.com/awaej3",
      "display_url" : "twitpic.com/awaej3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832842, -73.1935262 ]
  },
  "id_str" : "248427680633065472",
  "text" : ".@mrfrank5790 looking at the tweets, this one would be up there http://t.co/cNotae5V",
  "id" : 248427680633065472,
  "created_at" : "Wed Sep 19 14:25:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 42, 49 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/wEHnMr4L",
      "expanded_url" : "http://bit.ly/NBZwMB",
      "display_url" : "bit.ly/NBZwMB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248409676335706112",
  "text" : "easy morning 5 miler http://t.co/wEHnMr4L @sspis1",
  "id" : 248409676335706112,
  "created_at" : "Wed Sep 19 13:14:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/4lui80V4",
      "expanded_url" : "http://connect.garmin.com/activity/224539015",
      "display_url" : "connect.garmin.com/activity/22453…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248409335137464320",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan http://t.co/4lui80V4",
  "id" : 248409335137464320,
  "created_at" : "Wed Sep 19 13:12:55 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "success",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248240859672350720",
  "text" : "only busted my ass once in broomball #success",
  "id" : 248240859672350720,
  "created_at" : "Wed Sep 19 02:03:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 56, 65 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248210154594643968",
  "text" : "waiting to hit the ice for my first game of BROOMBALL!! @dmreagan's sport!",
  "id" : 248210154594643968,
  "created_at" : "Wed Sep 19 00:01:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248182683199488001",
  "geo" : {
  },
  "id_str" : "248183707851190272",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin okay I see you changed numbers, call me if you want",
  "id" : 248183707851190272,
  "in_reply_to_status_id" : 248182683199488001,
  "created_at" : "Tue Sep 18 22:16:21 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248182326926929920",
  "in_reply_to_user_id" : 78184204,
  "text" : "@rumblinstumblin check your email",
  "id" : 248182326926929920,
  "created_at" : "Tue Sep 18 22:10:52 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shopclassassoulcraft",
      "indices" : [ 97, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248152360419991552",
  "text" : "reading Matthew Crawford's story, a philosophy ph.d. gone mechanic and feeling all too much vibe #shopclassassoulcraft",
  "id" : 248152360419991552,
  "created_at" : "Tue Sep 18 20:11:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/Ox4goHaD",
      "expanded_url" : "http://twitpic.com/avtp2a",
      "display_url" : "twitpic.com/avtp2a"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247893638019952640",
  "text" : "previous tweet's pic: http://t.co/Ox4goHaD",
  "id" : 247893638019952640,
  "created_at" : "Tue Sep 18 03:03:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 93, 106 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247891866756984833",
  "text" : "very excited to read...but to read or actually spend time in shop? well, after HW of course (@williamenium )",
  "id" : 247891866756984833,
  "created_at" : "Tue Sep 18 02:56:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classic",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247891458353397760",
  "text" : "slipping into the basement of the Math Department though the window, they're used to it by now #classic",
  "id" : 247891458353397760,
  "created_at" : "Tue Sep 18 02:55:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 89, 98 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 99, 115 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burrrrrn",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247876658013536257",
  "geo" : {
  },
  "id_str" : "247891038990106624",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr the only ghosts I've seen appear to be your fantasy football players #burrrrrn @dmreagan @RumblinStumblin",
  "id" : 247891038990106624,
  "in_reply_to_status_id" : 247876658013536257,
  "created_at" : "Tue Sep 18 02:53:23 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247811673266720768",
  "geo" : {
  },
  "id_str" : "247890137726455808",
  "in_reply_to_user_id" : 313762318,
  "text" : "@DeSmashie yo DeSmashie you in the #btv right now??",
  "id" : 247890137726455808,
  "in_reply_to_status_id" : 247811673266720768,
  "created_at" : "Tue Sep 18 02:49:49 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Fox",
      "screen_name" : "El__Capitan1",
      "indices" : [ 0, 13 ],
      "id_str" : "91222764",
      "id" : 91222764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247804089193336833",
  "geo" : {
  },
  "id_str" : "247889088970125315",
  "in_reply_to_user_id" : 91222764,
  "text" : "@El__Capitan1 dudeman I live in Burlington! Let me know if you're around again!",
  "id" : 247889088970125315,
  "in_reply_to_status_id" : 247804089193336833,
  "created_at" : "Tue Sep 18 02:45:39 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247846588242857984",
  "geo" : {
  },
  "id_str" : "247876990496038912",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 EXACT SAME CALL TONIGHT",
  "id" : 247876990496038912,
  "in_reply_to_status_id" : 247846588242857984,
  "created_at" : "Tue Sep 18 01:57:34 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 49, 58 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247876287451000832",
  "text" : "an excellent dinner at Sweetwater on Church St w @dmreagan. Branching out from Farmhouse and Flatbread is going well so far.",
  "id" : 247876287451000832,
  "created_at" : "Tue Sep 18 01:54:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 1, 10 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/4N6LwohF",
      "expanded_url" : "http://twitpic.com/avrals",
      "display_url" : "twitpic.com/avrals"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247809362997960706",
  "text" : ".@dmreagan's first maple creamie after hiking to VT's highest peak http://t.co/4N6LwohF",
  "id" : 247809362997960706,
  "created_at" : "Mon Sep 17 21:28:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 19, 28 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitmom",
      "indices" : [ 31, 38 ]
    }, {
      "text" : "notintimidated",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247740897368887296",
  "text" : "hiking Mansfield w @dmreagan ! #fitmom #notintimidated",
  "id" : 247740897368887296,
  "created_at" : "Mon Sep 17 16:56:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 24, 33 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 42, 58 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/iwL6X8kL",
      "expanded_url" : "http://instagr.am/p/PqBxeqOS5e/",
      "display_url" : "instagr.am/p/PqBxeqOS5e/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247495674877321216",
  "text" : "Sam Adams Oktoberfest w @dmreagan! I hear @rumblinstumblin has one of these glasses http://t.co/iwL6X8kL",
  "id" : 247495674877321216,
  "created_at" : "Mon Sep 17 00:42:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 33, 44 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 59, 68 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 8, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247461457602686976",
  "text" : "back in #btv. was awesome to see @skholden17 in MA and now @dmreagan is in Burlington!!",
  "id" : 247461457602686976,
  "created_at" : "Sun Sep 16 22:26:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Fox",
      "screen_name" : "El__Capitan1",
      "indices" : [ 0, 13 ],
      "id_str" : "91222764",
      "id" : 91222764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247391605831655424",
  "geo" : {
  },
  "id_str" : "247460911399464961",
  "in_reply_to_user_id" : 91222764,
  "text" : "@El__Capitan1 where are you in the green mountain state?",
  "id" : 247460911399464961,
  "in_reply_to_status_id" : 247391605831655424,
  "created_at" : "Sun Sep 16 22:24:13 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Coleman",
      "screen_name" : "Haydocktor",
      "indices" : [ 0, 11 ],
      "id_str" : "167971811",
      "id" : 167971811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guessingallyourrides",
      "indices" : [ 22, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247431085678555136",
  "geo" : {
  },
  "id_str" : "247460329083269120",
  "in_reply_to_user_id" : 167971811,
  "text" : "@Haydocktor Mt Lake?? #guessingallyourrides",
  "id" : 247460329083269120,
  "in_reply_to_status_id" : 247431085678555136,
  "created_at" : "Sun Sep 16 22:21:54 +0000 2012",
  "in_reply_to_screen_name" : "Haydocktor",
  "in_reply_to_user_id_str" : "167971811",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 54, 67 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247383459402743808",
  "text" : "had a good race this morning at Buzzards Bay Sprint w @UVMTriathlon this morning!!",
  "id" : 247383459402743808,
  "created_at" : "Sun Sep 16 17:16:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247370361086300160",
  "geo" : {
  },
  "id_str" : "247375705254555649",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan headed there now",
  "id" : 247375705254555649,
  "in_reply_to_status_id" : 247370361086300160,
  "created_at" : "Sun Sep 16 16:45:38 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 3, 14 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 28, 39 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/dwvxlLkN",
      "expanded_url" : "http://lockerz.com/s/244912298",
      "display_url" : "lockerz.com/s/244912298"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247375630486884353",
  "text" : "RT @skholden17: So proud of @andyreagan killing it in his Tri this morning!!!  http://t.co/dwvxlLkN",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetcaster.com\" rel=\"nofollow\">TweetCaster for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 12, 23 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http://t.co/dwvxlLkN",
        "expanded_url" : "http://lockerz.com/s/244912298",
        "display_url" : "lockerz.com/s/244912298"
      } ]
    },
    "geo" : {
    },
    "id_str" : "247340487030239232",
    "text" : "So proud of @andyreagan killing it in his Tri this morning!!!  http://t.co/dwvxlLkN",
    "id" : 247340487030239232,
    "created_at" : "Sun Sep 16 14:25:42 +0000 2012",
    "user" : {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "protected" : false,
      "id_str" : "214582389",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3122605201/bbe442be6791d79c0b7662898c2dcd57_normal.png",
      "id" : 214582389,
      "verified" : false
    }
  },
  "id" : 247375630486884353,
  "created_at" : "Sun Sep 16 16:45:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 12, 25 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crazyeyes",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "vtproblems",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/AheQQKzU",
      "expanded_url" : "http://twitter.com/UVMTriathlon/status/247144253371863042/photo/1",
      "display_url" : "pic.twitter.com/AheQQKzU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247164737924763650",
  "text" : "#crazyeyes \"@UVMTriathlon: Just preforming nice pre race hammock tricks before Buzzards Bay #vtproblems http://t.co/AheQQKzU\"",
  "id" : 247164737924763650,
  "created_at" : "Sun Sep 16 02:47:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246763576449196032",
  "geo" : {
  },
  "id_str" : "247008534296944640",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee which one did you sign up for?",
  "id" : 247008534296944640,
  "in_reply_to_status_id" : 246763576449196032,
  "created_at" : "Sat Sep 15 16:26:38 +0000 2012",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/nBhbrUpu",
      "expanded_url" : "http://twitpic.com/auwrtg",
      "display_url" : "twitpic.com/auwrtg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247005872147025921",
  "text" : "apples from the tree on my street, doesn't get any more \"local and organic\" that that http://t.co/nBhbrUpu",
  "id" : 247005872147025921,
  "created_at" : "Sat Sep 15 16:16:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 4, 11 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/ITXXUepi",
      "expanded_url" : "http://twitpic.com/aub9en",
      "display_url" : "twitpic.com/aub9en"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246426179115032577",
  "text" : "was @sspis1 insinuating something when she got me this? http://t.co/ITXXUepi",
  "id" : 246426179115032577,
  "created_at" : "Fri Sep 14 01:52:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246328537961869312",
  "text" : "Trying to explain how all of our attitudes and beliefs fits together, we would encounter all kinds of inconsistency and contradiction.-Watts",
  "id" : 246328537961869312,
  "created_at" : "Thu Sep 13 19:24:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0344278, -71.5663127333 ]
  },
  "id_str" : "246120545941344256",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan miss you mom!",
  "id" : 246120545941344256,
  "created_at" : "Thu Sep 13 05:38:05 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0343714, -71.5663709 ]
  },
  "id_str" : "246120045900603392",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 missing my bro cuddle",
  "id" : 246120045900603392,
  "created_at" : "Thu Sep 13 05:36:06 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.0343714, -71.5663709 ]
  },
  "id_str" : "246119689506402304",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 you are the greatest thing ever",
  "id" : 246119689506402304,
  "created_at" : "Thu Sep 13 05:34:41 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "common squirrel",
      "screen_name" : "common_squirrel",
      "indices" : [ 3, 19 ],
      "id_str" : "18001717",
      "id" : 18001717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246112678710505472",
  "text" : "RT @common_squirrel: sleep",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "246106095343517696",
    "text" : "sleep",
    "id" : 246106095343517696,
    "created_at" : "Thu Sep 13 04:40:40 +0000 2012",
    "user" : {
      "name" : "common squirrel",
      "screen_name" : "common_squirrel",
      "protected" : false,
      "id_str" : "18001717",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/66898028/699px-Eastern_Gray_Squirrel_800_normal.jpg",
      "id" : 18001717,
      "verified" : false
    }
  },
  "id" : 246112678710505472,
  "created_at" : "Thu Sep 13 05:06:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/P1YShy5m",
      "expanded_url" : "http://coletassoft.tumblr.com/post/31392478540/treadlyandme-ive-never-understood-these-road",
      "display_url" : "coletassoft.tumblr.com/post/313924785…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246098136228052992",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/P1YShy5m skype me when you get back :)",
  "id" : 246098136228052992,
  "created_at" : "Thu Sep 13 04:09:02 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 36, 51 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/6Ok5EkAU",
      "expanded_url" : "http://instagr.am/p/Pfymn6uS5f/",
      "display_url" : "instagr.am/p/Pfymn6uS5f/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246094135528943616",
  "text" : "excellent time as an hare! on-after @BurlingtonHash http://t.co/6Ok5EkAU",
  "id" : 246094135528943616,
  "created_at" : "Thu Sep 13 03:53:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ -33.03352145, -71.5671699 ]
  },
  "id_str" : "246057653514694656",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 esta bien chico",
  "id" : 246057653514694656,
  "created_at" : "Thu Sep 13 01:28:10 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Coleman",
      "screen_name" : "Haydocktor",
      "indices" : [ 0, 11 ],
      "id_str" : "167971811",
      "id" : 167971811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245640385827844096",
  "geo" : {
  },
  "id_str" : "245648032786419712",
  "in_reply_to_user_id" : 167971811,
  "text" : "@Haydocktor sounds like you discovered Harding Rd! Jealous!",
  "id" : 245648032786419712,
  "in_reply_to_status_id" : 245640385827844096,
  "created_at" : "Tue Sep 11 22:20:29 +0000 2012",
  "in_reply_to_screen_name" : "Haydocktor",
  "in_reply_to_user_id_str" : "167971811",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 0, 15 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https://t.co/p403BV4f",
      "expanded_url" : "https://maps.google.com/maps/ms?msid=208687371047587284823.0004c96ede6918a708b15&msa=0&ll=44.473029,-73.220031&spn=0.001129,0.002275",
      "display_url" : "maps.google.com/maps/ms?msid=2…"
    } ]
  },
  "in_reply_to_status_id_str" : "245536355793379328",
  "geo" : {
  },
  "id_str" : "245547788434305025",
  "in_reply_to_user_id" : 320947874,
  "text" : "@BurlingtonHash the \"Recovering Racist Hash\" will start at 6PM here (dog-friendly): https://t.co/p403BV4f",
  "id" : 245547788434305025,
  "in_reply_to_status_id" : 245536355793379328,
  "created_at" : "Tue Sep 11 15:42:09 +0000 2012",
  "in_reply_to_screen_name" : "BurlingtonHash",
  "in_reply_to_user_id_str" : "320947874",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna without an H ",
      "screen_name" : "HannaRuns2Live",
      "indices" : [ 0, 15 ],
      "id_str" : "368621257",
      "id" : 368621257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245413242191634432",
  "geo" : {
  },
  "id_str" : "245413881781043202",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaRuns2Live even better to wake up to clean house!",
  "id" : 245413881781043202,
  "in_reply_to_status_id" : 245413242191634432,
  "created_at" : "Tue Sep 11 06:50:03 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latenightcleaningspree",
      "indices" : [ 0, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245412738845777920",
  "text" : "#latenightcleaningspree",
  "id" : 245412738845777920,
  "created_at" : "Tue Sep 11 06:45:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/245401295542960128/photo/1",
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/525afzyT",
      "media_url" : "http://pbs.twimg.com/media/A2fXLZiCQAAm2dG.jpg",
      "id_str" : "245401295547154432",
      "id" : 245401295547154432,
      "media_url_https" : "https://pbs.twimg.com/media/A2fXLZiCQAAm2dG.jpg",
      "sizes" : [ {
        "h" : 119,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 1044
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/525afzyT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245401295542960128",
  "text" : "first late night of the semester, in the books http://t.co/525afzyT",
  "id" : 245401295542960128,
  "created_at" : "Tue Sep 11 06:00:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VThomebrewClub ",
      "screen_name" : "VThomebrewClub",
      "indices" : [ 70, 85 ],
      "id_str" : "401026838",
      "id" : 401026838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/tpXwdUy3",
      "expanded_url" : "http://troyandgay.com/2012/05/18/sankey-to-cornelius-keg-tap-conversion/",
      "display_url" : "troyandgay.com/2012/05/18/san…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245314949969240064",
  "text" : "very cool homebrew tap to sankey tap conversion: http://t.co/tpXwdUy3 @VThomebrewClub",
  "id" : 245314949969240064,
  "created_at" : "Tue Sep 11 00:16:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 35, 47 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 74, 89 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245265620558553088",
  "text" : "headed to scout Wednesdays trail w @mrfrank5790 , its gonna be a good one @BurlingtonHash",
  "id" : 245265620558553088,
  "created_at" : "Mon Sep 10 21:00:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 0, 12 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aluminumprobz",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245238177332346882",
  "geo" : {
  },
  "id_str" : "245244570458284033",
  "in_reply_to_user_id" : 75351547,
  "text" : "@UVM_cycling #aluminumprobz",
  "id" : 245244570458284033,
  "in_reply_to_status_id" : 245238177332346882,
  "created_at" : "Mon Sep 10 19:37:16 +0000 2012",
  "in_reply_to_screen_name" : "UVM_cycling",
  "in_reply_to_user_id_str" : "75351547",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 46, 59 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "domination",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "NECTC",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245208764465172481",
  "text" : "6 of 10 in UVM's pool today were training for @UVMTriathlon preparing for #domination #NECTC",
  "id" : 245208764465172481,
  "created_at" : "Mon Sep 10 17:14:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/ZOVraqoZ",
      "expanded_url" : "http://twitpic.com/asytvc",
      "display_url" : "twitpic.com/asytvc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244949070676889600",
  "text" : "in tight miters we trust http://t.co/ZOVraqoZ",
  "id" : 244949070676889600,
  "created_at" : "Mon Sep 10 00:03:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244929235129618432",
  "geo" : {
  },
  "id_str" : "244930126134009856",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud close, but no internet",
  "id" : 244930126134009856,
  "in_reply_to_status_id" : 244929235129618432,
  "created_at" : "Sun Sep 09 22:47:47 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244912955123171328",
  "geo" : {
  },
  "id_str" : "244913364130746368",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn dustin alerted me that Mathematica can actually do the integral so you're saved...",
  "id" : 244913364130746368,
  "in_reply_to_status_id" : 244912955123171328,
  "created_at" : "Sun Sep 09 21:41:10 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244902630147620864",
  "text" : "roommates thought \"liveloveride\" too corny of a pw: changed the wireless from NETGEAR to \\int_0^{inf}(\\log x)^2/(1+x^2)dx told them guess",
  "id" : 244902630147620864,
  "created_at" : "Sun Sep 09 20:58:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244885513117523968",
  "geo" : {
  },
  "id_str" : "244893537450225666",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser hahah team math needed you",
  "id" : 244893537450225666,
  "in_reply_to_status_id" : 244885513117523968,
  "created_at" : "Sun Sep 09 20:22:23 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/huxZRGsm",
      "expanded_url" : "http://twitpic.com/aswmzg",
      "display_url" : "twitpic.com/aswmzg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244877891362500608",
  "text" : "math dept wiffle ball  game! http://t.co/huxZRGsm",
  "id" : 244877891362500608,
  "created_at" : "Sun Sep 09 19:20:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244671146937688064",
  "text" : "bike ride back from the airport was needed. cool fresh vermont air was missed. #btv",
  "id" : 244671146937688064,
  "created_at" : "Sun Sep 09 05:38:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 0, 12 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "airplane",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244636221375123456",
  "geo" : {
  },
  "id_str" : "244640363690725376",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SumaNMNDesu every time I'm near a plane I was for them to pop the hood for engine troubles #airplane",
  "id" : 244640363690725376,
  "in_reply_to_status_id" : 244636221375123456,
  "created_at" : "Sun Sep 09 03:36:22 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244640177765634048",
  "text" : "boarded and heading to #btv finally. hopefully the pilot has experience with tornados",
  "id" : 244640177765634048,
  "created_at" : "Sun Sep 09 03:35:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Vines",
      "screen_name" : "creatorvines",
      "indices" : [ 0, 13 ],
      "id_str" : "811996891",
      "id" : 811996891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creatorvines",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244637854570000384",
  "in_reply_to_user_id" : 811996891,
  "text" : "@creatorvines I wait with great anticipation for the first tweet from the creator #creatorvines",
  "id" : 244637854570000384,
  "created_at" : "Sun Sep 09 03:26:24 +0000 2012",
  "in_reply_to_screen_name" : "creatorvines",
  "in_reply_to_user_id_str" : "811996891",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/wbQXV1hh",
      "expanded_url" : "http://i.imgur.com/TtNF4.jpg",
      "display_url" : "i.imgur.com/TtNF4.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244593418234372096",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 http://t.co/wbQXV1hh",
  "id" : 244593418234372096,
  "created_at" : "Sun Sep 09 00:29:49 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 52, 63 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/MbbPQ9GI",
      "expanded_url" : "http://ideas.time.com/2011/12/09/why-are-the-rich-so-interested-in-public-school-reform/",
      "display_url" : "ideas.time.com/2011/12/09/why…"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/cTDONMKF",
      "expanded_url" : "http://TIME.com",
      "display_url" : "TIME.com"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/Y0dC0OLo",
      "expanded_url" : "http://ti.me/NidhzQ",
      "display_url" : "ti.me/NidhzQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244582720896892928",
  "text" : "on making bootstrapping real http://t.co/MbbPQ9GI  \"@peterdodds: The Myth of Bootstrapping | http://t.co/cTDONMKF http://t.co/Y0dC0OLo\"",
  "id" : 244582720896892928,
  "created_at" : "Sat Sep 08 23:47:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flightdrama",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244582222512939009",
  "text" : "delayed again, looks like I'll get that quesadilla after all #flightdrama",
  "id" : 244582222512939009,
  "created_at" : "Sat Sep 08 23:45:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boredinairport",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244578910401085440",
  "text" : "new defn of speedwalking: passing walkers who are on people movers, while walking on the one going opposite direction #boredinairport",
  "id" : 244578910401085440,
  "created_at" : "Sat Sep 08 23:32:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244578426630066177",
  "text" : "phone shows alert for local flash flood warning as Im doin reverse people mover lap looking 4 decent food...and my flight boarding hr early!",
  "id" : 244578426630066177,
  "created_at" : "Sat Sep 08 23:30:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244560665656844288",
  "geo" : {
  },
  "id_str" : "244563687724154880",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 *skaneateles you pretty much live there...time to learn how to spell it lol",
  "id" : 244563687724154880,
  "in_reply_to_status_id" : 244560665656844288,
  "created_at" : "Sat Sep 08 22:31:41 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bookstorechillin",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244563010134343680",
  "text" : "\"system two is in charge of self control\" -kahneman's thinking fast and slow. interesting so far! #bookstorechillin",
  "id" : 244563010134343680,
  "created_at" : "Sat Sep 08 22:29:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amtrak",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244538735155351553",
  "text" : "we seriously need more rail options in the states. want: safer, much cleaner, and on time. #amtrak",
  "id" : 244538735155351553,
  "created_at" : "Sat Sep 08 20:52:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Allgaier",
      "screen_name" : "nallgaier",
      "indices" : [ 3, 13 ],
      "id_str" : "84344714",
      "id" : 84344714
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 14, 23 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244536319265619968",
  "text" : "as @nallgaier @dr_pyser and my flights are demonstrating, flying is a pain in the arse. delayed, leaving myself 15min for connection @ JFK",
  "id" : 244536319265619968,
  "created_at" : "Sat Sep 08 20:42:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/AzzxQnR2",
      "expanded_url" : "http://www.nytimes.com/2012/09/09/magazine/the-weatherman-is-not-a-moron.html?pagewanted=1&_r=1",
      "display_url" : "nytimes.com/2012/09/09/mag…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244531267041894400",
  "text" : "spending 3 days learning about mathematics of weather, here's a good overview of current predictions: http://t.co/AzzxQnR2",
  "id" : 244531267041894400,
  "created_at" : "Sat Sep 08 20:22:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notfun",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "wimp",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244522770262806528",
  "text" : "arms still suffering hard from 3000yd in the pool today. is this how biking makes people's legs feel? #notfun #wimp",
  "id" : 244522770262806528,
  "created_at" : "Sat Sep 08 19:49:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244520918330773505",
  "geo" : {
  },
  "id_str" : "244521816784257024",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia fun! not in particular, but campus is beautiful. the Arborium at UNC is a hidden gem.",
  "id" : 244521816784257024,
  "in_reply_to_status_id" : 244520918330773505,
  "created_at" : "Sat Sep 08 19:45:18 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MCRN",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244478099155189760",
  "geo" : {
  },
  "id_str" : "244514885197762560",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia was at UNC for the week for a #MCRN conference, it's nice down here. have you been??",
  "id" : 244514885197762560,
  "in_reply_to_status_id" : 244478099155189760,
  "created_at" : "Sat Sep 08 19:17:46 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "244506400888324099",
  "geo" : {
  },
  "id_str" : "244513619570728960",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud awesome!!!",
  "id" : 244513619570728960,
  "in_reply_to_status_id" : 244506400888324099,
  "created_at" : "Sat Sep 08 19:12:44 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/yjF9OWEQ",
      "expanded_url" : "http://instagr.am/p/PU0MzTuS7u/",
      "display_url" : "instagr.am/p/PU0MzTuS7u/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244510697160069123",
  "text" : "first instagram photo: iced chai at three cups in chapel hill nc #yum http://t.co/yjF9OWEQ",
  "id" : 244510697160069123,
  "created_at" : "Sat Sep 08 19:01:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "postMCRNncchillin",
      "indices" : [ 72, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "244477364258627584",
  "text" : "found the Chapel Hill community center pool after some intense frogger. #postMCRNncchillin",
  "id" : 244477364258627584,
  "created_at" : "Sat Sep 08 16:48:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 16, 32 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 37, 48 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/i42F878T",
      "expanded_url" : "http://www.churchkeycanco.com/home.html",
      "display_url" : "churchkeycanco.com/home.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244081113004396544",
  "text" : "looks tasty! RT @JacobnAndersson For @andyreagan , the beer snob, http://t.co/i42F878T",
  "id" : 244081113004396544,
  "created_at" : "Fri Sep 07 14:34:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfectmoment",
      "indices" : [ 73, 87 ]
    }, {
      "text" : "MCRN",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/kL07DoKN",
      "expanded_url" : "http://twitpic.com/arusic",
      "display_url" : "twitpic.com/arusic"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243892465399128066",
  "text" : ".@dr_pyser makes amazing shot, ACDC \"back in black\" cranks on the stereo #perfectmoment #MCRN http://t.co/kL07DoKN",
  "id" : 243892465399128066,
  "created_at" : "Fri Sep 07 02:04:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 19, 28 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 36, 47 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Nicholas Allgaier",
      "screen_name" : "nallgaier",
      "indices" : [ 93, 103 ],
      "id_str" : "84344714",
      "id" : 84344714
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MCRN",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243891868075704320",
  "text" : "I scored 9th ball \"@dr_pyser: Guys. @andyreagan just got schooled in foosball, losing 8-0 to @nallgaier. I never thought Id c the day #MCRN\"",
  "id" : 243891868075704320,
  "created_at" : "Fri Sep 07 02:02:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Nathan Scharf",
      "screen_name" : "natescharf",
      "indices" : [ 8, 19 ],
      "id_str" : "64093685",
      "id" : 64093685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243886310325100547",
  "geo" : {
  },
  "id_str" : "243891626341199872",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @natescharf I'm in NC so Otto will come to life next week!!",
  "id" : 243891626341199872,
  "in_reply_to_status_id" : 243886310325100547,
  "created_at" : "Fri Sep 07 02:01:09 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FireFly",
      "screen_name" : "fireflybicycles",
      "indices" : [ 3, 19 ],
      "id_str" : "213918484",
      "id" : 213918484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/RU0O9o5o",
      "expanded_url" : "http://www.nytimes.com/2012/09/09/magazine/whats-a-4000-suit-worth.html?_r=1&smid=fb-share",
      "display_url" : "nytimes.com/2012/09/09/mag…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243754185542221826",
  "text" : "RT @fireflybicycles: \"there is now a large difference between what is monetizable and what is actually valuable\" http://t.co/RU0O9o5o",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http://t.co/RU0O9o5o",
        "expanded_url" : "http://www.nytimes.com/2012/09/09/magazine/whats-a-4000-suit-worth.html?_r=1&smid=fb-share",
        "display_url" : "nytimes.com/2012/09/09/mag…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243752665232850944",
    "text" : "\"there is now a large difference between what is monetizable and what is actually valuable\" http://t.co/RU0O9o5o",
    "id" : 243752665232850944,
    "created_at" : "Thu Sep 06 16:48:58 +0000 2012",
    "user" : {
      "name" : "FireFly",
      "screen_name" : "fireflybicycles",
      "protected" : false,
      "id_str" : "213918484",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1226605454/tumbler-logo_normal.jpg",
      "id" : 213918484,
      "verified" : false
    }
  },
  "id" : 243754185542221826,
  "created_at" : "Thu Sep 06 16:55:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 20, 27 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/243751221343694849/photo/1",
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/qKWuAbGC",
      "media_url" : "http://pbs.twimg.com/media/A2H6ccJCMAAeqy4.png",
      "id_str" : "243751221352083456",
      "id" : 243751221352083456,
      "media_url_https" : "https://pbs.twimg.com/media/A2H6ccJCMAAeqy4.png",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 701
      } ],
      "display_url" : "pic.twitter.com/qKWuAbGC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243751221343694849",
  "text" : "forgot the picture: @sspis1 http://t.co/qKWuAbGC",
  "id" : 243751221343694849,
  "created_at" : "Thu Sep 06 16:43:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gladsheputsupwithme",
      "indices" : [ 15, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243750985778999296",
  "text" : ".@sspis1 and I #gladsheputsupwithme",
  "id" : 243750985778999296,
  "created_at" : "Thu Sep 06 16:42:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243456964401692672",
  "geo" : {
  },
  "id_str" : "243506040367374336",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia going over thanksgiving break! Flying to Santiago then to Puerto Natales to backpack in Patagonia for five days",
  "id" : 243506040367374336,
  "in_reply_to_status_id" : 243456964401692672,
  "created_at" : "Thu Sep 06 00:28:58 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B0b W@ss3ll",
      "screen_name" : "bobwassell",
      "indices" : [ 0, 11 ],
      "id_str" : "117072907",
      "id" : 117072907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243481349783187458",
  "geo" : {
  },
  "id_str" : "243481680508252160",
  "in_reply_to_user_id" : 117072907,
  "text" : "@bobwassell lost 9 pounds. the real question is...can you drink a gallon of beer in half an hour #beermile",
  "id" : 243481680508252160,
  "in_reply_to_status_id" : 243481349783187458,
  "created_at" : "Wed Sep 05 22:52:10 +0000 2012",
  "in_reply_to_screen_name" : "bobwassell",
  "in_reply_to_user_id_str" : "117072907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243481385694818304",
  "text" : "what was becoming a sidewalk-along-highway run from mapmyrun turned into incredible suburban trail run, when I spotted gap in trees by road",
  "id" : 243481385694818304,
  "created_at" : "Wed Sep 05 22:51:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perspiration",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243481111508955136",
  "text" : "if anyone was wondering (guiness book of world records?)...it is possible to sweat over 1 gallon in an hour #perspiration",
  "id" : 243481111508955136,
  "created_at" : "Wed Sep 05 22:49:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243457541156257792",
  "text" : "here goes nothing... 85deg, 60% humidity is going to make running fun",
  "id" : 243457541156257792,
  "created_at" : "Wed Sep 05 21:16:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 70, 79 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MCRN",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243453575370530817",
  "text" : "excellent talks on grant writing and dater assimiliation (as rockstar @dr_pyser put's it :P) #MCRN",
  "id" : 243453575370530817,
  "created_at" : "Wed Sep 05 21:00:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MCRN",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243322493891407873",
  "text" : "first one at the meeting #MCRN",
  "id" : 243322493891407873,
  "created_at" : "Wed Sep 05 12:19:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MCRN",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243217897382637568",
  "text" : "in Chapel Hill, NC #MCRN",
  "id" : 243217897382637568,
  "created_at" : "Wed Sep 05 05:24:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "filmmaking",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243076203345489920",
  "geo" : {
  },
  "id_str" : "243079546298052608",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser PS I moved the sticky note shade back an inch before leaving the office! #storylab #filmmaking",
  "id" : 243079546298052608,
  "in_reply_to_status_id" : 243076203345489920,
  "created_at" : "Tue Sep 04 20:14:14 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243078105651085312",
  "geo" : {
  },
  "id_str" : "243079264688295936",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser other side... see ya there!",
  "id" : 243079264688295936,
  "in_reply_to_status_id" : 243078105651085312,
  "created_at" : "Tue Sep 04 20:13:07 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243076203345489920",
  "geo" : {
  },
  "id_str" : "243077254471614465",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I'm chillin at gate 15",
  "id" : 243077254471614465,
  "in_reply_to_status_id" : 243076203345489920,
  "created_at" : "Tue Sep 04 20:05:08 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTV",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243075484534050817",
  "text" : "surprised to find a bike rack and three other bikes at #BTV airport!",
  "id" : 243075484534050817,
  "created_at" : "Tue Sep 04 19:58:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243038473844584448",
  "geo" : {
  },
  "id_str" : "243038903660072961",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser Nick's Delta from LGA to RDU is rescheduled to get in 10:40 tomorrow. Who r u flying with?",
  "id" : 243038903660072961,
  "in_reply_to_status_id" : 243038473844584448,
  "created_at" : "Tue Sep 04 17:32:44 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243035112080551937",
  "text" : "quick swim before class and heading to NC!",
  "id" : 243035112080551937,
  "created_at" : "Tue Sep 04 17:17:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soclose",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/76EdwEBN",
      "expanded_url" : "http://app.strava.com/rides/20783135",
      "display_url" : "app.strava.com/rides/20783135"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242826876182224896",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill went for spear north. needed you #soclose http://t.co/76EdwEBN",
  "id" : 242826876182224896,
  "created_at" : "Tue Sep 04 03:30:13 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 3, 12 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242826163934863360",
  "text" : "RT @jpbeatty: ROLL HOKIES!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "242825941758394370",
    "text" : "ROLL HOKIES!",
    "id" : 242825941758394370,
    "created_at" : "Tue Sep 04 03:26:30 +0000 2012",
    "user" : {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "protected" : false,
      "id_str" : "23640974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/601624441/john_head_normal.jpg",
      "id" : 23640974,
      "verified" : false
    }
  },
  "id" : 242826163934863360,
  "created_at" : "Tue Sep 04 03:27:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen",
      "screen_name" : "KathleenLS",
      "indices" : [ 3, 14 ],
      "id_str" : "237485783",
      "id" : 237485783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovemyhokies",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242826153457508352",
  "text" : "RT @KathleenLS: We did it again!! VT beats GT!! #lovemyhokies",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lovemyhokies",
        "indices" : [ 32, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "242825750221316097",
    "text" : "We did it again!! VT beats GT!! #lovemyhokies",
    "id" : 242825750221316097,
    "created_at" : "Tue Sep 04 03:25:44 +0000 2012",
    "user" : {
      "name" : "Kathleen",
      "screen_name" : "KathleenLS",
      "protected" : true,
      "id_str" : "237485783",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3233871681/18a26774453b60cd8d9ce49f20dd8b06_normal.jpeg",
      "id" : 237485783,
      "verified" : false
    }
  },
  "id" : 242826153457508352,
  "created_at" : "Tue Sep 04 03:27:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HOKIES",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242822491498766336",
  "text" : "FIELD GOAL IS GOOOOD! TIE GAME!! #HOKIES",
  "id" : 242822491498766336,
  "created_at" : "Tue Sep 04 03:12:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242789340340686848",
  "geo" : {
  },
  "id_str" : "242817958353727488",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan woo go hokies!!!",
  "id" : 242817958353727488,
  "in_reply_to_status_id" : 242789340340686848,
  "created_at" : "Tue Sep 04 02:54:47 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242722464398979072",
  "geo" : {
  },
  "id_str" : "242739937106087936",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e aww :) thanks!",
  "id" : 242739937106087936,
  "in_reply_to_status_id" : 242722464398979072,
  "created_at" : "Mon Sep 03 21:44:45 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 1, 9 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/jqKznLDf",
      "expanded_url" : "http://twitpic.com/aqsvrx",
      "display_url" : "twitpic.com/aqsvrx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242697896997310465",
  "text" : ".@Karo1yn being a badass too http://t.co/jqKznLDf",
  "id" : 242697896997310465,
  "created_at" : "Mon Sep 03 18:57:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 3, 11 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 27, 38 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/aSAUZVor",
      "expanded_url" : "http://twitter.com/Karo1yn/status/242697251753967616/photo/1",
      "display_url" : "pic.twitter.com/aSAUZVor"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242697487687770112",
  "text" : "RT @Karo1yn: What a badass @andyreagan is http://t.co/aSAUZVor",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 14, 25 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/Karo1yn/status/242697251753967616/photo/1",
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/aSAUZVor",
        "media_url" : "http://pbs.twimg.com/media/A1473VcCQAAd4bX.jpg",
        "id_str" : "242697251758161920",
        "id" : 242697251758161920,
        "media_url_https" : "https://pbs.twimg.com/media/A1473VcCQAAd4bX.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/aSAUZVor"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "242697251753967616",
    "text" : "What a badass @andyreagan is http://t.co/aSAUZVor",
    "id" : 242697251753967616,
    "created_at" : "Mon Sep 03 18:55:10 +0000 2012",
    "user" : {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "protected" : true,
      "id_str" : "101351006",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2080762059/derpyyy_normal.jpg",
      "id" : 101351006,
      "verified" : false
    }
  },
  "id" : 242697487687770112,
  "created_at" : "Mon Sep 03 18:56:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242481970616082433",
  "geo" : {
  },
  "id_str" : "242503456894615553",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 quick what's the path integral of tanh(x) around the unit circle in the complex plane??",
  "id" : 242503456894615553,
  "in_reply_to_status_id" : 242481970616082433,
  "created_at" : "Mon Sep 03 06:05:04 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfect",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242415595906273280",
  "text" : "ordered pizza from our roommate, delivered in his BMW M3, top down. Rock Art Red and Lake Placid Brown #perfect",
  "id" : 242415595906273280,
  "created_at" : "Mon Sep 03 00:15:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 0, 8 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242408563346137089",
  "geo" : {
  },
  "id_str" : "242409914616651776",
  "in_reply_to_user_id" : 103102170,
  "text" : "@pkemp33 i was scared to click with \"it's in\" and just a picture, for a totally different reason haha. where is that?",
  "id" : 242409914616651776,
  "in_reply_to_status_id" : 242408563346137089,
  "created_at" : "Sun Sep 02 23:53:22 +0000 2012",
  "in_reply_to_screen_name" : "pkemp33",
  "in_reply_to_user_id_str" : "103102170",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 9, 18 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 70, 86 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 87, 96 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 97, 108 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242403545343733763",
  "text" : "where is @vmhilljr in the family draft? auto-pick not doing so hot... @rumblinstumblin @dmreagan @kreagannet",
  "id" : 242403545343733763,
  "created_at" : "Sun Sep 02 23:28:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242394621651599364",
  "text" : "been ready to draft my fantasy football team ALL DAY and so now my internet stalls....",
  "id" : 242394621651599364,
  "created_at" : "Sun Sep 02 22:52:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 11, 22 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/VMamAQBA",
      "expanded_url" : "http://goo.gl/igLZR",
      "display_url" : "goo.gl/igLZR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242052804598964224",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan \"@bakadesuyo: What is the single strongest predictor of IQ? http://t.co/VMamAQBA\"",
  "id" : 242052804598964224,
  "created_at" : "Sun Sep 02 00:14:20 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Wlad M",
      "screen_name" : "El_Capitan1",
      "indices" : [ 8, 20 ],
      "id_str" : "97302575",
      "id" : 97302575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241964619177021441",
  "geo" : {
  },
  "id_str" : "241994269462773760",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @El_Capitan1 fox is hilarious",
  "id" : 241994269462773760,
  "in_reply_to_status_id" : 241964619177021441,
  "created_at" : "Sat Sep 01 20:21:44 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 50, 63 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lakegeorgetri",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/AYqx83Zk",
      "expanded_url" : "http://twitpic.com/apzonu",
      "display_url" : "twitpic.com/apzonu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241907271733485570",
  "text" : "finished in PR 2:28 w a tough swim #lakegeorgetri @UVMTriathlon http://t.co/AYqx83Zk",
  "id" : 241907271733485570,
  "created_at" : "Sat Sep 01 14:36:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]