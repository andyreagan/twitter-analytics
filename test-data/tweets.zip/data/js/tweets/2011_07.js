Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http://t.co/YtipcLL",
      "expanded_url" : "http://twitpic.com/5yzhrm",
      "display_url" : "twitpic.com/5yzhrm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97762878068752385",
  "text" : "108.76 amazing miles! #FB http://t.co/YtipcLL",
  "id" : 97762878068752385,
  "created_at" : "Sun Jul 31 20:17:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http://t.co/CHscxBS",
      "expanded_url" : "http://twitpic.com/5ysxih",
      "display_url" : "twitpic.com/5ysxih"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97648368582529024",
  "text" : "century time! http://t.co/CHscxBS",
  "id" : 97648368582529024,
  "created_at" : "Sun Jul 31 12:42:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RKay",
      "screen_name" : "RKay",
      "indices" : [ 15, 20 ],
      "id_str" : "15988365",
      "id" : 15988365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/KzehNVj",
      "expanded_url" : "http://twitpic.com/5yk5ag",
      "display_url" : "twitpic.com/5yk5ag"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97492946806509568",
  "text" : "movers brought @rkay's furniture! they get to do all the lifting, win for my back http://t.co/KzehNVj",
  "id" : 97492946806509568,
  "created_at" : "Sun Jul 31 02:25:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.38104945, -80.111326 ]
  },
  "id_str" : "97432499109629952",
  "text" : "I'm at Home Place Restaurant (4968 Catawba Valley Dr, 311, Catawba) http://4sq.com/psZD0Y",
  "id" : 97432499109629952,
  "created_at" : "Sat Jul 30 22:24:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 43 ],
      "url" : "http://t.co/171n4ew",
      "expanded_url" : "http://twitpic.com/5yfesz",
      "display_url" : "twitpic.com/5yfesz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97409476868587521",
  "text" : "frah geel ay p, for me! http://t.co/171n4ew",
  "id" : 97409476868587521,
  "created_at" : "Sat Jul 30 20:53:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 25, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 48 ],
      "url" : "http://t.co/400WKyo",
      "expanded_url" : "http://twitpic.com/5ydr26",
      "display_url" : "twitpic.com/5ydr26"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97379031615422464",
  "text" : "it's weldin' time y'all! #fb http://t.co/400WKyo",
  "id" : 97379031615422464,
  "created_at" : "Sat Jul 30 18:52:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97311376116166657",
  "text" : "after eating breakfast, running 13mi, and then drinking a half gallon of water...still lost 6.4lbs from the run. good thing i got a scale",
  "id" : 97311376116166657,
  "created_at" : "Sat Jul 30 14:23:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97304335612002304",
  "text" : "sweet 13mi trail run @ poverty creek. cleaning up and then welding things together!",
  "id" : 97304335612002304,
  "created_at" : "Sat Jul 30 13:55:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97272322381185025",
  "text" : "trail running!",
  "id" : 97272322381185025,
  "created_at" : "Sat Jul 30 11:48:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "score",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97130645528133632",
  "text" : "perhaps should've told them it broke 6 months ago, but our fix lasted awhile. smaller freezer = gotta eat what doesn't fit! #score",
  "id" : 97130645528133632,
  "created_at" : "Sat Jul 30 02:25:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweetness",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http://t.co/qPBk064",
      "expanded_url" : "http://twitpic.com/5xz6o2",
      "display_url" : "twitpic.com/5xz6o2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97130493983723521",
  "text" : "also came home to a new fridge today!! #sweetness http://t.co/qPBk064",
  "id" : 97130493983723521,
  "created_at" : "Sat Jul 30 02:24:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "97054439986311168",
  "text" : "strangest d2 ever, no one at the door, only two stations open....felt closed (@ Dietrick Dining Center) http://4sq.com/o9Lq8E",
  "id" : 97054439986311168,
  "created_at" : "Fri Jul 29 21:22:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 0, 7 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97041733799526400",
  "in_reply_to_user_id" : 20536157,
  "text" : "@google we need profiles for apps users!!! k thx",
  "id" : 97041733799526400,
  "created_at" : "Fri Jul 29 20:32:06 +0000 2011",
  "in_reply_to_screen_name" : "google",
  "in_reply_to_user_id_str" : "20536157",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http://t.co/eWWcJ4e",
      "expanded_url" : "http://twitpic.com/5xs321",
      "display_url" : "twitpic.com/5xs321"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96998993216798720",
  "text" : "mount airy. lol. http://t.co/eWWcJ4e",
  "id" : 96998993216798720,
  "created_at" : "Fri Jul 29 17:42:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96958197247647744",
  "geo" : {
  },
  "id_str" : "96996267938426880",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 do work son!",
  "id" : 96996267938426880,
  "in_reply_to_status_id" : 96958197247647744,
  "created_at" : "Fri Jul 29 17:31:27 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http://t.co/QVupbP9",
      "expanded_url" : "http://twitpic.com/5xrwcc",
      "display_url" : "twitpic.com/5xrwcc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96995754094235648",
  "text" : "older tweet from before the mtb race: brice's self epoxied carbon rear detailer fix http://t.co/QVupbP9",
  "id" : 96995754094235648,
  "created_at" : "Fri Jul 29 17:29:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96995011035529217",
  "text" : "presentation went very well, it was great meeting the people who write the papers we've been reading! on the way back to #blacksburg",
  "id" : 96995011035529217,
  "created_at" : "Fri Jul 29 17:26:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.0920251667, -80.2653008167 ]
  },
  "id_str" : "96917158822551553",
  "text" : "I'm at Wake Forest University Baptist Medical Center (105 S Hawthorne Road South, Winston-Salem) http://4sq.com/rfgU41",
  "id" : 96917158822551553,
  "created_at" : "Fri Jul 29 12:17:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "96891433830727680",
  "text" : "got up @ 5 to leave @ 6 for a 9am pres to WF cancer biology group. ate my breakfast while riding ha http://4sq.com/nxbbhG",
  "id" : 96891433830727680,
  "created_at" : "Fri Jul 29 10:34:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.socialoomph.com\" rel=\"nofollow\">SocialOomph</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 15, 24 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96792408309764096",
  "text" : "HAPPY BIRTHDAY @dmreagan!!!",
  "id" : 96792408309764096,
  "created_at" : "Fri Jul 29 04:01:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96757853141991425",
  "geo" : {
  },
  "id_str" : "96759401150550016",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 I made one with much much knobbier tires ...not comfortable",
  "id" : 96759401150550016,
  "in_reply_to_status_id" : 96757853141991425,
  "created_at" : "Fri Jul 29 01:50:13 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 75, 82 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/6RPXXVm",
      "expanded_url" : "http://twitpic.com/5xfg30",
      "display_url" : "twitpic.com/5xfg30"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96756747984842753",
  "text" : "that's right, a mountain bike tire belt!! check it out, made specially for @rkay21 http://t.co/6RPXXVm",
  "id" : 96756747984842753,
  "created_at" : "Fri Jul 29 01:39:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 40, 47 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "success",
      "indices" : [ 20, 28 ]
    }, {
      "text" : "greatidea",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96745615148593153",
  "text" : "buckles at goodwill #success #greatidea @rkay21",
  "id" : 96745615148593153,
  "created_at" : "Fri Jul 29 00:55:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "score",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96741113049788416",
  "text" : "found sex bolts at Lowes! didn't think they would even have them #score (what're they're for will make more sense soon, twitterati)",
  "id" : 96741113049788416,
  "created_at" : "Fri Jul 29 00:37:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 35, 44 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96695385573163008",
  "text" : "jealous! have a fun bday dinner RT @dmreagan going to empire brewing company!",
  "id" : 96695385573163008,
  "created_at" : "Thu Jul 28 21:35:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnasuck",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96651649942163456",
  "text" : "just signed up for the GRE on Aug 17 in Manlius, NY. 1.5 wks to study hard while I'm home #gonnasuck",
  "id" : 96651649942163456,
  "created_at" : "Thu Jul 28 18:42:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96646334928531457",
  "text" : "RT @garyvee: I love interaction- It's my oxygen",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "96643534182023168",
    "text" : "I love interaction- It's my oxygen",
    "id" : 96643534182023168,
    "created_at" : "Thu Jul 28 18:09:48 +0000 2011",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2686490082/def3702974d1d48abb19e04b8175beec_normal.jpeg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 96646334928531457,
  "created_at" : "Thu Jul 28 18:20:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96636565702451200",
  "geo" : {
  },
  "id_str" : "96636993890562048",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium 40 in a 25, this guy in a scooter was giving me a nice pull. haha im kidding, i wish it was for speeding. blew a stop sign",
  "id" : 96636993890562048,
  "in_reply_to_status_id" : 96636565702451200,
  "created_at" : "Thu Jul 28 17:43:49 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96583033737588736",
  "text" : "is beginning to really dislike the discrete part of discrete models.",
  "id" : 96583033737588736,
  "created_at" : "Thu Jul 28 14:09:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96577190703009792",
  "geo" : {
  },
  "id_str" : "96578898577461248",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy hah it is. and i do every morning, when it's clear. there are many factors that come to mind... and safety is a big one",
  "id" : 96578898577461248,
  "in_reply_to_status_id" : 96577190703009792,
  "created_at" : "Thu Jul 28 13:52:58 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96576686237298689",
  "geo" : {
  },
  "id_str" : "96576887354171392",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy blew an all way stop (with no cars at it). coming down roanoke, turning left onto draper",
  "id" : 96576887354171392,
  "in_reply_to_status_id" : 96576686237298689,
  "created_at" : "Thu Jul 28 13:44:58 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96576136305319936",
  "geo" : {
  },
  "id_str" : "96576334486192128",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 unfortunately, cav got away, left me to get the ticket",
  "id" : 96576334486192128,
  "in_reply_to_status_id" : 96576136305319936,
  "created_at" : "Thu Jul 28 13:42:47 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96574945714388992",
  "geo" : {
  },
  "id_str" : "96575410694922240",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 goin 55 in a 30, ya know",
  "id" : 96575410694922240,
  "in_reply_to_status_id" : 96574945714388992,
  "created_at" : "Thu Jul 28 13:39:06 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96567356284866561",
  "geo" : {
  },
  "id_str" : "96574585021022208",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 i'll be there soon....",
  "id" : 96574585021022208,
  "in_reply_to_status_id" : 96567356284866561,
  "created_at" : "Thu Jul 28 13:35:49 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 60, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96574488136785920",
  "text" : "got a ticket on my way to work today. on my bike. womp womp #fb",
  "id" : 96574488136785920,
  "created_at" : "Thu Jul 28 13:35:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 126, 134 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/o5laR3l",
      "expanded_url" : "http://bit.ly/qMzOCg",
      "display_url" : "bit.ly/qMzOCg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96367799592681472",
  "text" : "awesome wed worlds race. b group rode strong and smooth, best we ever have. Garmin Connect - Details: http://t.co/o5laR3l via @AddThis #fb",
  "id" : 96367799592681472,
  "created_at" : "Wed Jul 27 23:54:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wednesday Worlds",
      "screen_name" : "wednesdayworlds",
      "indices" : [ 9, 25 ],
      "id_str" : "161035957",
      "id" : 161035957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96338219192426496",
  "text" : "time for @wednesdayworlds",
  "id" : 96338219192426496,
  "created_at" : "Wed Jul 27 21:56:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96292672456765440",
  "text" : "if i wasnt already scared, my prof just sent out email: \"IMO, Real Analysis is the most difficult undergraduate course at VT ...\"",
  "id" : 96292672456765440,
  "created_at" : "Wed Jul 27 18:55:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "96254233325735936",
  "text" : "fresh, local peaches! #yum (@ Dietrick Dining Center) http://4sq.com/nnnAa7",
  "id" : 96254233325735936,
  "created_at" : "Wed Jul 27 16:22:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http://t.co/VizJmLA",
      "expanded_url" : "http://www.amazon.com/Keep-Your-Eye-Ball-Folklore/dp/0716722488",
      "display_url" : "amazon.com/Keep-Your-Eye-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96247043386916865",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 I got you this at some point, didn't I? http://t.co/VizJmLA I'm reading a very different book by the same author now",
  "id" : 96247043386916865,
  "created_at" : "Wed Jul 27 15:54:17 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96082316698456064",
  "text" : "and I made some pretty amazing stuff from recycled bike parts- blog post coming soon",
  "id" : 96082316698456064,
  "created_at" : "Wed Jul 27 04:59:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http://t.co/35gMzoh",
      "expanded_url" : "http://bit.ly/pLUfN4",
      "display_url" : "bit.ly/pLUfN4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "96079797976961024",
  "text" : "felt great running in the heat tonight so \"I just kept on running.\" 12mi total. Garmin Connect - Details: http://t.co/35gMzoh",
  "id" : 96079797976961024,
  "created_at" : "Wed Jul 27 04:49:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96004893785063424",
  "text" : "tried to wait for it to cool down...but it's still 88 after 1.5hrs, so gotta run in the heat",
  "id" : 96004893785063424,
  "created_at" : "Tue Jul 26 23:52:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95854303402655745",
  "text" : "is back with my DROID PRO! it survived a rainstorm!!",
  "id" : 95854303402655745,
  "created_at" : "Tue Jul 26 13:53:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2309007265, -80.4150295258 ]
  },
  "id_str" : "95645958595031040",
  "text" : "HAMMERTIME and pita pizza success! (@ The Cellar) http://4sq.com/ndJS11",
  "id" : 95645958595031040,
  "created_at" : "Tue Jul 26 00:05:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 87, 95 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http://t.co/O1z31Nz",
      "expanded_url" : "http://bit.ly/p4t8HX",
      "display_url" : "bit.ly/p4t8HX"
    } ]
  },
  "geo" : {
  },
  "id_str" : "95609322733699072",
  "text" : "6,27mi Birthday Run by andyreagan at Garmin Connect - Details: http://t.co/O1z31Nz via @AddThis",
  "id" : 95609322733699072,
  "created_at" : "Mon Jul 25 21:40:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "swiftwick",
      "screen_name" : "swiftwick",
      "indices" : [ 25, 35 ],
      "id_str" : "31128070",
      "id" : 31128070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95589650659426304",
  "text" : "excited to run in my new @swiftwick socks! just stopped raining so they'll be put to the test.",
  "id" : 95589650659426304,
  "created_at" : "Mon Jul 25 20:22:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95579089515192320",
  "text" : "and dipping early from work to head out for a run before HAMMERTIME",
  "id" : 95579089515192320,
  "created_at" : "Mon Jul 25 19:40:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 68, 77 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95578978571649024",
  "text" : "just applied to the Young Mathematicians Conference at Ohio State w @jdbrunnr, Emily, and Paul!",
  "id" : 95578978571649024,
  "created_at" : "Mon Jul 25 19:39:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 0, 14 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95551978175868928",
  "geo" : {
  },
  "id_str" : "95562692026306560",
  "in_reply_to_user_id" : 26010551,
  "text" : "@Thundercoffer sprint in your drops, man!",
  "id" : 95562692026306560,
  "in_reply_to_status_id" : 95551978175868928,
  "created_at" : "Mon Jul 25 18:34:55 +0000 2011",
  "in_reply_to_screen_name" : "Thundercoffer",
  "in_reply_to_user_id_str" : "26010551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95499665373532160",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLowdermilk have a great day, birthday twin!",
  "id" : 95499665373532160,
  "created_at" : "Mon Jul 25 14:24:29 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "95480812622983168",
  "text" : "Monday presentations (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/qQrSTm",
  "id" : 95480812622983168,
  "created_at" : "Mon Jul 25 13:09:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 39, 51 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.1579, -80.4173 ]
  },
  "id_str" : "95470982680166402",
  "text" : "gettin straightened out from MTBing by @leermatthis before work this AM (@ Tuck Chiropractic - Christiansburg) http://4sq.com/rngQyS",
  "id" : 95470982680166402,
  "created_at" : "Mon Jul 25 12:30:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 20, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95342559567679488",
  "text" : "spotted a gray hair #fb",
  "id" : 95342559567679488,
  "created_at" : "Mon Jul 25 04:00:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 29, 38 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 43, 59 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 70, 84 ],
      "id_str" : "113114946",
      "id" : 113114946
    }, {
      "name" : "Starlight Apparel",
      "screen_name" : "starlightbikes",
      "indices" : [ 101, 116 ],
      "id_str" : "109032076",
      "id" : 109032076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95234145596346368",
  "text" : "ordered my bday present from @dmreagan and @RumblinStumblin, a set of @ChrisKingBuzz wheels, through @starlightbikes!! Pumped!!",
  "id" : 95234145596346368,
  "created_at" : "Sun Jul 24 20:49:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95223510439428096",
  "text" : "While cleaning the pile of mud I brought home this weekend, I found a mountain bike, but it had a broken rear spoke.",
  "id" : 95223510439428096,
  "created_at" : "Sun Jul 24 20:07:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95143425715863552",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan \"What was the name of your first school?\"",
  "id" : 95143425715863552,
  "created_at" : "Sun Jul 24 14:48:55 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94865585971806209",
  "geo" : {
  },
  "id_str" : "95129475385270275",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet i've played a few games before haha...but I think that bikes are better suited to moving forward. how did u ever hear abt it?",
  "id" : 95129475385270275,
  "in_reply_to_status_id" : 94865585971806209,
  "created_at" : "Sun Jul 24 13:53:29 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94961607230226432",
  "text" : "3rd place, 0 stiches (but an ER visit), 8000ft climbing, 48.5mi, 8300 calories burned in 6.5 hrs. EPIC race!!!",
  "id" : 94961607230226432,
  "created_at" : "Sun Jul 24 02:46:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94932793213194241",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin hey guys, answer your cells from any number that calls. my cell is dead, and I'm fine, but I'm going to the ER",
  "id" : 94932793213194241,
  "created_at" : "Sun Jul 24 00:51:56 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hammocking",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "ftw",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94612173371883520",
  "text" : "a little too overcast for the stars, but im sleepin under 'em anyway #hammocking #ftw",
  "id" : 94612173371883520,
  "created_at" : "Sat Jul 23 03:37:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.233589, -80.418047 ]
  },
  "id_str" : "94554157788307456",
  "text" : "got my comfiest kit washed for the 6hrs of riding (@ EZ Way Laundromat) http://4sq.com/nKiHtR",
  "id" : 94554157788307456,
  "created_at" : "Fri Jul 22 23:47:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94537306677051392",
  "text" : "walk home wouldn't have been complete w.o some good ol picking and a digging, free bluegrass performance on the lawn I can hear all way home",
  "id" : 94537306677051392,
  "created_at" : "Fri Jul 22 22:40:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94536353286594560",
  "text" : "SOLID 1500m in the pool w Chrissy! I was planning an easy swim, but she was there w a sweet workout from edie",
  "id" : 94536353286594560,
  "created_at" : "Fri Jul 22 22:36:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lesliepun",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/QGHSvoq",
      "expanded_url" : "http://twitpic.com/5u6lop",
      "display_url" : "twitpic.com/5u6lop"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94520440113991680",
  "text" : "well that's gonna take the air outta my plans #lesliepun http://t.co/QGHSvoq",
  "id" : 94520440113991680,
  "created_at" : "Fri Jul 22 21:33:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minitri",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "94518712526323712",
  "text" : "quick dinner then swimming, biking home and going for a short run #minitri (@ Dietrick Dining Center) http://4sq.com/nh7M0t",
  "id" : 94518712526323712,
  "created_at" : "Fri Jul 22 21:26:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http://t.co/2yA0Kxt",
      "expanded_url" : "http://twitpic.com/5u3oyy",
      "display_url" : "twitpic.com/5u3oyy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94466084614311937",
  "text" : "now I can trackstand without my front wheel coming off http://t.co/2yA0Kxt",
  "id" : 94466084614311937,
  "created_at" : "Fri Jul 22 17:57:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94453753960349696",
  "text" : "stopped by east coasters and got mtb cleats for tomorrow, and a lug nut for my fixie finally. excited",
  "id" : 94453753960349696,
  "created_at" : "Fri Jul 22 17:08:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94397371999453185",
  "geo" : {
  },
  "id_str" : "94410282092331008",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 what? that's exactly how it works, way to make me go look it up. just like regular BA, but doubles count as two hits, etc ...?",
  "id" : 94410282092331008,
  "in_reply_to_status_id" : 94397371999453185,
  "created_at" : "Fri Jul 22 14:15:39 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "94392892885450752",
  "text" : "nope, off by 2min. I did, however, eat a bowl of oatmeal and 3 glasses of choc milk and bike here before @shaydub61... http://4sq.com/puZZz1",
  "id" : 94392892885450752,
  "created_at" : "Fri Jul 22 13:06:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "94389812957691904",
  "text" : "can I eat breakfast and make it to work in 7min, we'll see (@ Dietrick Dining Center) http://4sq.com/r28ibx",
  "id" : 94389812957691904,
  "created_at" : "Fri Jul 22 12:54:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94381825291591680",
  "text" : "2 loaves of homemade bread, gallon of Gatorade, jar of PB, and lots of water = set for camping and a 6hr mtb race!",
  "id" : 94381825291591680,
  "created_at" : "Fri Jul 22 12:22:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94378864356241408",
  "text" : "goin to get honey so I can make more bread for this weekend",
  "id" : 94378864356241408,
  "created_at" : "Fri Jul 22 12:10:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bedtime",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94246267349241858",
  "text" : "that's all folks #bedtime",
  "id" : 94246267349241858,
  "created_at" : "Fri Jul 22 03:23:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 42, 52 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cus10",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "liveslovesrides",
      "indices" : [ 60, 76 ]
    }, {
      "text" : "fb",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http://t.co/tsOe12K",
      "expanded_url" : "http://twitpic.com/5tslow",
      "display_url" : "twitpic.com/5tslow"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94245482808872960",
  "text" : "taking off my anklet today after one year @bikebuild #cus10 #liveslovesrides #fb http://t.co/tsOe12K",
  "id" : 94245482808872960,
  "created_at" : "Fri Jul 22 03:20:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94245407823114240",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin when you come down to Blacksburg, we're coming to a Salem Red Sox game. Together, we'd be unbeatable at cornhole",
  "id" : 94245407823114240,
  "created_at" : "Fri Jul 22 03:20:30 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/ivv1obX",
      "expanded_url" : "http://twitpic.com/5tslgx",
      "display_url" : "twitpic.com/5tslgx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94245385442295808",
  "text" : "1 panged 2 red and black 3 90 min 4 spirited flight http://t.co/ivv1obX",
  "id" : 94245385442295808,
  "created_at" : "Fri Jul 22 03:20:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetexplosion",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http://t.co/IwOaPP1",
      "expanded_url" : "http://twitpic.com/5ffjxz",
      "display_url" : "twitpic.com/5ffjxz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94245285513011200",
  "text" : "and check out the two books I got in yesterday #tweetexplosion http://t.co/IwOaPP1",
  "id" : 94245285513011200,
  "created_at" : "Fri Jul 22 03:20:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterexplosion",
      "indices" : [ 93, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94245189689946112",
  "text" : "just realized my twitter failed on some tweets, as far back as jun 22...so here they all go! #twitterexplosion",
  "id" : 94245189689946112,
  "created_at" : "Fri Jul 22 03:19:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 47, 62 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94211549220188160",
  "geo" : {
  },
  "id_str" : "94244775447904256",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 haha I def told them abt that! and how @ryandelgiudice CALLED that HR hit against you there lol. told them doubles count double, etc",
  "id" : 94244775447904256,
  "in_reply_to_status_id" : 94211549220188160,
  "created_at" : "Fri Jul 22 03:18:00 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94223622746542080",
  "geo" : {
  },
  "id_str" : "94244428633473024",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis okay no worries! i was doing dirty dawg sat either way",
  "id" : 94244428633473024,
  "in_reply_to_status_id" : 94223622746542080,
  "created_at" : "Fri Jul 22 03:16:37 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94169862213087232",
  "geo" : {
  },
  "id_str" : "94244206285033473",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 haha word...I must be losin' it",
  "id" : 94244206285033473,
  "in_reply_to_status_id" : 94169862213087232,
  "created_at" : "Fri Jul 22 03:15:44 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 5, 17 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Ben King",
      "screen_name" : "BenKing89",
      "indices" : [ 96, 106 ],
      "id_str" : "18171525",
      "id" : 18171525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94179567908044800",
  "geo" : {
  },
  "id_str" : "94211728740581376",
  "in_reply_to_user_id" : 70417462,
  "text" : "im w @LeeRMatthis, Sunday EPIC ride instead of Blacksburg classic! blue ridge parkway! jus like @BenKing89 today crushing it in the heat",
  "id" : 94211728740581376,
  "in_reply_to_status_id" : 94179567908044800,
  "created_at" : "Fri Jul 22 01:06:41 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94211087100162048",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 you would be so proud of me!! im at a Salem red sox minor league game and just had to explain what slug % was to the ppl im with!",
  "id" : 94211087100162048,
  "created_at" : "Fri Jul 22 01:04:08 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http://t.co/c8xYj7t",
      "expanded_url" : "http://www.sivtac.org/mtlake/beforeafter.php",
      "display_url" : "sivtac.org/mtlake/beforea…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94150935747624961",
  "text" : "really interesting pictures of mountain lake http://t.co/c8xYj7t",
  "id" : 94150935747624961,
  "created_at" : "Thu Jul 21 21:05:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94143219104882688",
  "text" : "blacksburg classic road race weekend cancelled...guess it's good that I decided to MTB! or bad, bc they cancelled due to lack of entrants",
  "id" : 94143219104882688,
  "created_at" : "Thu Jul 21 20:34:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94132213997772800",
  "text" : "hmm, should I do a sprint triathlon fo free or the home MTB race this fall?",
  "id" : 94132213997772800,
  "created_at" : "Thu Jul 21 19:50:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94040654891593728",
  "text" : "andy schleck attacks! 53sec out front of the malloit jaune",
  "id" : 94040654891593728,
  "created_at" : "Thu Jul 21 13:46:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "94027060858716161",
  "text" : "soupy oatmeal :( (@ Dietrick Dining Center) http://4sq.com/qvmkHG",
  "id" : 94027060858716161,
  "created_at" : "Thu Jul 21 12:52:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.227712, -80.412985 ]
  },
  "id_str" : "93855109703942145",
  "text" : "wednesday night comedy night! (@ Awful Arthur's) http://4sq.com/qX36Qk",
  "id" : 93855109703942145,
  "created_at" : "Thu Jul 21 01:29:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93845618765725697",
  "in_reply_to_user_id" : 78184204,
  "text" : "@rumblinstumblin @dmreagan check y'alls email",
  "id" : 93845618765725697,
  "created_at" : "Thu Jul 21 00:51:53 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 74, 82 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http://t.co/HQTdDj9",
      "expanded_url" : "http://bit.ly/pQIdCX",
      "display_url" : "bit.ly/pQIdCX"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93832676666130432",
  "text" : "Worlds by andyreagan at Garmin Connect - Details: http://t.co/HQTdDj9 via @AddThis",
  "id" : 93832676666130432,
  "created_at" : "Thu Jul 21 00:00:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wednesday Worlds",
      "screen_name" : "wednesdayworlds",
      "indices" : [ 46, 62 ],
      "id_str" : "161035957",
      "id" : 161035957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93796843238068225",
  "text" : "its hot, and its HUMID out here... racing A's @wednesdayworlds!",
  "id" : 93796843238068225,
  "created_at" : "Wed Jul 20 21:38:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.229591, -80.416328 ]
  },
  "id_str" : "93523150146519040",
  "text" : "oh boy (@ Top Of The Stairs (TOTS) w/ 3 others) http://4sq.com/qJDIAx",
  "id" : 93523150146519040,
  "created_at" : "Wed Jul 20 03:30:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Hughes",
      "screen_name" : "JameWOW",
      "indices" : [ 0, 8 ],
      "id_str" : "38811749",
      "id" : 38811749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93519094497804289",
  "text" : "@jameWoW im here for the gangbang",
  "id" : 93519094497804289,
  "created_at" : "Wed Jul 20 03:14:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2309007265, -80.4150295258 ]
  },
  "id_str" : "93516899505283072",
  "text" : "hoppyum a must (@ The Cellar) http://4sq.com/nHbq06",
  "id" : 93516899505283072,
  "created_at" : "Wed Jul 20 03:05:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 126, 134 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/B6GfwUQ",
      "expanded_url" : "http://bit.ly/qnY1Xc",
      "display_url" : "bit.ly/qnY1Xc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93491060218675201",
  "text" : "easy, somewhat long run was good! 10mi general aerobic run by andyreagan at Garmin Connect - Details: http://t.co/B6GfwUQ via @AddThis",
  "id" : 93491060218675201,
  "created_at" : "Wed Jul 20 01:23:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lego",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93451675746045953",
  "text" : "somewhat dreading a long run, its hot and humid out. but im lacing up anyway #lego",
  "id" : 93451675746045953,
  "created_at" : "Tue Jul 19 22:46:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "orientation",
      "indices" : [ 47, 59 ]
    }, {
      "text" : "crazyparents",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "93438933496631297",
  "text" : "the food is better, but its a madhouse in here #orientation #crazyparents (@ Dietrick Dining Center) http://4sq.com/oOtbdv",
  "id" : 93438933496631297,
  "created_at" : "Tue Jul 19 21:55:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93433893629341696",
  "text" : "dinner time, looked at a lot of different grad schools today",
  "id" : 93433893629341696,
  "created_at" : "Tue Jul 19 21:35:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93417756220854272",
  "geo" : {
  },
  "id_str" : "93424290397044737",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 isn't that why you left early, to avoid the traffic?",
  "id" : 93424290397044737,
  "in_reply_to_status_id" : 93417756220854272,
  "created_at" : "Tue Jul 19 20:57:41 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snailmailmyemail",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http://t.co/RJGvZ95",
      "expanded_url" : "http://Snailmailmyemail.org",
      "display_url" : "Snailmailmyemail.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93375365627658240",
  "text" : "http://t.co/RJGvZ95 is an interactive art project that transforms emails to hand written letters, free of charge. #snailmailmyemail",
  "id" : 93375365627658240,
  "created_at" : "Tue Jul 19 17:43:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93373693522231298",
  "text" : "just registered for 6 Hours of Dirty Dawg mtb race this Sat, who else is camping Fri night? #fb",
  "id" : 93373693522231298,
  "created_at" : "Tue Jul 19 17:36:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93351030460399616",
  "text" : "lunch time, I brought banagrams today!",
  "id" : 93351030460399616,
  "created_at" : "Tue Jul 19 16:06:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bikes Belong",
      "screen_name" : "bikesbelong",
      "indices" : [ 3, 15 ],
      "id_str" : "19260113",
      "id" : 19260113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93350967889768449",
  "text" : "RT @bikesbelong: Here's an update to the famous Utrecht rush hour video: http://bit.ly/nBGNgm",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93347120010104833",
    "text" : "Here's an update to the famous Utrecht rush hour video: http://bit.ly/nBGNgm",
    "id" : 93347120010104833,
    "created_at" : "Tue Jul 19 15:51:02 +0000 2011",
    "user" : {
      "name" : "Bikes Belong",
      "screen_name" : "bikesbelong",
      "protected" : false,
      "id_str" : "19260113",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/101556638/bikes-belong-flower_normal.jpg",
      "id" : 19260113,
      "verified" : false
    }
  },
  "id" : 93350967889768449,
  "created_at" : "Tue Jul 19 16:06:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93305859299491840",
  "geo" : {
  },
  "id_str" : "93308589736869888",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice damn!! only day here that's close is 1deg hotter friday.",
  "id" : 93308589736869888,
  "in_reply_to_status_id" : 93305859299491840,
  "created_at" : "Tue Jul 19 13:17:56 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2300550302, -80.4158449173 ]
  },
  "id_str" : "93126854550110209",
  "text" : "Super 8 (@ The Lyric Theatre) http://4sq.com/nNbucx",
  "id" : 93126854550110209,
  "created_at" : "Tue Jul 19 01:15:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93122049123430400",
  "text" : "goin to watch super 8 at the Lyric!",
  "id" : 93122049123430400,
  "created_at" : "Tue Jul 19 00:56:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 92, 100 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/u4xW1oB",
      "expanded_url" : "http://bit.ly/qZwllZ",
      "display_url" : "bit.ly/qZwllZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93116718850916352",
  "text" : "followed by... Quick Run by andyreagan at Garmin Connect - Details: http://t.co/u4xW1oB via @AddThis",
  "id" : 93116718850916352,
  "created_at" : "Tue Jul 19 00:35:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 92, 100 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 101, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/M4tiU5D",
      "expanded_url" : "http://bit.ly/nlpfA6",
      "display_url" : "bit.ly/nlpfA6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93116635044519936",
  "text" : "awesome MTB Ride w Cecil by andyreagan at Garmin Connect - Details: http://t.co/M4tiU5D via @AddThis #fb",
  "id" : 93116635044519936,
  "created_at" : "Tue Jul 19 00:35:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93080560938926080",
  "text" : "going for a MTB ride w Cecil! He talked me out of a 5mi run, I'm excited to hit old farm with wheels",
  "id" : 93080560938926080,
  "created_at" : "Mon Jul 18 22:11:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 9, 16 ],
      "id_str" : "17882551",
      "id" : 17882551
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 50, 61 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http://t.co/Lf7YGSV",
      "expanded_url" : "http://4sq.com/nJrhw0",
      "display_url" : "4sq.com/nJrhw0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93041014532620289",
  "text" : "nice! RT @jbice0 Biked out from the house. I'm no @andyreagan, but it felt good (@ New River Valley Mall) http://t.co/Lf7YGSV",
  "id" : 93041014532620289,
  "created_at" : "Mon Jul 18 19:34:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "92998304467656704",
  "text" : "d2 forture: \"Now is the time to be spontaneous [in bed]\" (@ Dietrick Dining Center) http://4sq.com/mYxZRf",
  "id" : 92998304467656704,
  "created_at" : "Mon Jul 18 16:44:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 17, 26 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92983262653321216",
  "text" : "reading papers w @jdbrunnr on BJ Central, on iron metabolism?",
  "id" : 92983262653321216,
  "created_at" : "Mon Jul 18 15:45:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92973974782353408",
  "geo" : {
  },
  "id_str" : "92974783825854466",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 so, for 5% of the populus?",
  "id" : 92974783825854466,
  "in_reply_to_status_id" : 92973974782353408,
  "created_at" : "Mon Jul 18 15:11:30 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 30, 39 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "betteranyway",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "92733082817404928",
  "text" : "closed, damn. pasta at home w @dmreagan's sauce #betteranyway (@ Dietrick Dining Center) http://4sq.com/nDsmXH",
  "id" : 92733082817404928,
  "created_at" : "Sun Jul 17 23:11:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/Ue9M8Dx",
      "expanded_url" : "http://www.setupevents.com/index.cfm?fuseaction=event_results&id=2503",
      "display_url" : "setupevents.com/index.cfm?fuse…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92723786079682562",
  "text" : "back in #blacksburg, times are up for the triathlon: http://t.co/Ue9M8Dx",
  "id" : 92723786079682562,
  "created_at" : "Sun Jul 17 22:34:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http://t.co/rlrCWVQ",
      "expanded_url" : "http://twitpic.com/5rnixr",
      "display_url" : "twitpic.com/5rnixr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92634549380595712",
  "text" : "celebratory milkshake! http://t.co/rlrCWVQ",
  "id" : 92634549380595712,
  "created_at" : "Sun Jul 17 16:39:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92571418277060608",
  "text" : "finished 3Sports Triathlon in an unofficial 1:00:54 with a 20:57 5k!",
  "id" : 92571418277060608,
  "created_at" : "Sun Jul 17 12:28:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/M9r5IiA",
      "expanded_url" : "http://twitpic.com/5rifxs",
      "display_url" : "twitpic.com/5rifxs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92543143358119936",
  "text" : "transition set up! check it out. I might've looked fast if I matched at all http://t.co/M9r5IiA",
  "id" : 92543143358119936,
  "created_at" : "Sun Jul 17 10:36:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http://t.co/5rsGE6q",
      "expanded_url" : "http://twitpic.com/5rhm0y",
      "display_url" : "twitpic.com/5rhm0y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92527483131412480",
  "text" : "at the race, bright and early! (well, its actually still dark) http://t.co/5rsGE6q",
  "id" : 92527483131412480,
  "created_at" : "Sun Jul 17 09:34:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92428677777854464",
  "text" : "had a really good day setting up for the triathlon and hanging out with Grayson. Easy run in, shaved face, alarm set for 4:40AM",
  "id" : 92428677777854464,
  "created_at" : "Sun Jul 17 03:01:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92093717527281665",
  "geo" : {
  },
  "id_str" : "92188969680379904",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yayy!! i'll most likely be going up 81 the 7th, and back down the 20th",
  "id" : 92188969680379904,
  "in_reply_to_status_id" : 92093717527281665,
  "created_at" : "Sat Jul 16 11:08:57 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92188478430920704",
  "text" : "pretty sure I'm the only one who was at TOTS at 1:30 that is up at 7AM. Packing then headed to Richmond to race the 3Sports Triathlon!",
  "id" : 92188478430920704,
  "created_at" : "Sat Jul 16 11:07:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 125, 133 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http://t.co/MAFlPZh",
      "expanded_url" : "http://bit.ly/o2enyc",
      "display_url" : "bit.ly/o2enyc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92038826347859969",
  "text" : "then changed on went on a 20mi bike ride! SAYG Ride w Jaber and Jon by andyreagan at Garmin Connect: http://t.co/MAFlPZh via @AddThis",
  "id" : 92038826347859969,
  "created_at" : "Sat Jul 16 01:12:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 101, 109 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/hwSImBY",
      "expanded_url" : "http://bit.ly/pEp2QF",
      "display_url" : "bit.ly/pEp2QF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92038665995436032",
  "text" : "felt great with 4 6:40 miles for a hard tempo run. Garmin Connect - Details: http://t.co/hwSImBY via @AddThis",
  "id" : 92038665995436032,
  "created_at" : "Sat Jul 16 01:11:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "batteriessuck",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91981847835316225",
  "text" : "was headed out for a run, but left my garmin on overnight... gotta let it charge for a little #batteriessuck",
  "id" : 91981847835316225,
  "created_at" : "Fri Jul 15 21:25:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91975826291175424",
  "text" : "its quittin time! soo many decision...run or bike or swim or eat dinner? or all!",
  "id" : 91975826291175424,
  "created_at" : "Fri Jul 15 21:02:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http://t.co/8H7yFcd",
      "expanded_url" : "http://texastailwind.files.wordpress.com/2009/07/dave-zabriskie-time-trial.jpg",
      "display_url" : "texastailwind.files.wordpress.com/2009/07/dave-z…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91963202736369664",
  "text" : "needs to practice my TT position for Sunday...check out Zabriskie, this is what it's supposed to look like: http://t.co/8H7yFcd",
  "id" : 91963202736369664,
  "created_at" : "Fri Jul 15 20:11:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/NAP1LfM",
      "expanded_url" : "http://www.youtube.com/watch?v=azVqekQBK8g",
      "display_url" : "youtube.com/watch?v=azVqek…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91947135943196672",
  "text" : "the song which I have never heard before, but \"sang\" at karaoke last night: http://t.co/NAP1LfM",
  "id" : 91947135943196672,
  "created_at" : "Fri Jul 15 19:08:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "91907553549758464",
  "text" : "tortellini are soo good (@ Dietrick Dining Center) http://4sq.com/qKEOaA",
  "id" : 91907553549758464,
  "created_at" : "Fri Jul 15 16:30:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91877590104670208",
  "text" : "it's as if #fb wanted me to get rid of it.... no I don't want to be able to open any messages or my notifications for the past few days",
  "id" : 91877590104670208,
  "created_at" : "Fri Jul 15 14:31:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pastmybedtime",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91731197071343616",
  "text" : "Karaoke @ bull and bones was fun! So tired tho #pastmybedtime",
  "id" : 91731197071343616,
  "created_at" : "Fri Jul 15 04:49:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/7KVaIdG",
      "expanded_url" : "http://twitpic.com/5q8j78",
      "display_url" : "twitpic.com/5q8j78"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91663300219248640",
  "text" : "got a disc wheel for the tri this weekend! thanks Tyler. Check it out: http://t.co/7KVaIdG",
  "id" : 91663300219248640,
  "created_at" : "Fri Jul 15 00:20:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "91644441114329088",
  "text" : "was at the bottom of harding at 6:14...and D2 closes at 6:30, good thing my house was on the way! http://4sq.com/rpDNMj",
  "id" : 91644441114329088,
  "created_at" : "Thu Jul 14 23:05:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http://t.co/ShRhh1p",
      "expanded_url" : "http://twitpic.com/5q5pi4",
      "display_url" : "twitpic.com/5q5pi4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91606684191043584",
  "text" : "a bike tree! http://t.co/ShRhh1p",
  "id" : 91606684191043584,
  "created_at" : "Thu Jul 14 20:35:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chyeah",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.227712, -80.412985 ]
  },
  "id_str" : "91316402476167168",
  "text" : "comedy night #chyeah (@ Awful Arthur's) http://4sq.com/pczzlO",
  "id" : 91316402476167168,
  "created_at" : "Thu Jul 14 01:21:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91306258715521024",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis hey when's a good time I could come grab my aerobars? I'm racing 3Sports Tri in Richmond this weekend. Tmrw or Friday @ 5:30?",
  "id" : 91306258715521024,
  "created_at" : "Thu Jul 14 00:41:23 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 23, 39 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 48, 57 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91305607734374400",
  "text" : "just skyped with padre @RumblinStumblin and mah @dmreagan, now gettin ready to head to awful arthur's comedy night!",
  "id" : 91305607734374400,
  "created_at" : "Thu Jul 14 00:38:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweet",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http://t.co/ULgLQkM",
      "expanded_url" : "http://twitpic.com/5ppwwb",
      "display_url" : "twitpic.com/5ppwwb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91281132687081472",
  "text" : "creme brulee at d2 tonight #sweet http://t.co/ULgLQkM",
  "id" : 91281132687081472,
  "created_at" : "Wed Jul 13 23:01:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "s",
      "indices" : [ 113, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "91137362939219968",
  "text" : "forgot my meal card and had to bike home to get it #fail but cinnamon raisin oatmeal and veggie egg white omelet #s... http://4sq.com/nuR5hf",
  "id" : 91137362939219968,
  "created_at" : "Wed Jul 13 13:30:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 112, 120 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 121, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http://t.co/ElwVteI",
      "expanded_url" : "http://bit.ly/nJggBm",
      "display_url" : "bit.ly/nJggBm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91123758286372864",
  "text" : "got up at 6AM to beat the heat for an early morning long run. Garmin Connect - Details: http://t.co/ElwVteI via @AddThis #fb",
  "id" : 91123758286372864,
  "created_at" : "Wed Jul 13 12:36:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "こうすけ",
      "screen_name" : "kmyuh",
      "indices" : [ 0, 6 ],
      "id_str" : "573873054",
      "id" : 573873054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 26 ],
      "url" : "http://t.co/0U7aNJX",
      "expanded_url" : "http://market.android.com/details?id=com.thedeck.android.app",
      "display_url" : "market.android.com/details?id=com…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "90972209513906177",
  "in_reply_to_user_id" : 29261982,
  "text" : "@kmyuh http://t.co/0U7aNJX",
  "id" : 90972209513906177,
  "created_at" : "Wed Jul 13 02:33:59 +0000 2011",
  "in_reply_to_screen_name" : "uh_my_uh_kay",
  "in_reply_to_user_id_str" : "29261982",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "こうすけ",
      "screen_name" : "kmyuh",
      "indices" : [ 0, 6 ],
      "id_str" : "573873054",
      "id" : 573873054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90961414516260864",
  "geo" : {
  },
  "id_str" : "90962411976273920",
  "in_reply_to_user_id" : 29261982,
  "text" : "@kmyuh i used to use a dif one, forgot the name, but the newest twitter for droid works great for me",
  "id" : 90962411976273920,
  "in_reply_to_status_id" : 90961414516260864,
  "created_at" : "Wed Jul 13 01:55:03 +0000 2011",
  "in_reply_to_screen_name" : "uh_my_uh_kay",
  "in_reply_to_user_id_str" : "29261982",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 84, 92 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http://t.co/N7Z1M3a",
      "expanded_url" : "http://bit.ly/nseyPX",
      "display_url" : "bit.ly/nseyPX"
    } ]
  },
  "geo" : {
  },
  "id_str" : "90961283691708417",
  "text" : "got in an easy few miles tonight. Garmin Connect - Details: http://t.co/N7Z1M3a via @AddThis",
  "id" : 90961283691708417,
  "created_at" : "Wed Jul 13 01:50:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2263133508, -80.4206299782 ]
  },
  "id_str" : "90926018373746688",
  "text" : "10x100yd swim workout done, goin to bed early for a long run tmrw morning! (@ War Memorial Hall) http://4sq.com/nXUp8q",
  "id" : 90926018373746688,
  "created_at" : "Tue Jul 12 23:30:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 4, 11 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90782895802814465",
  "text" : "hey @google hurry up with adding profiles for google apps accounts so students can get on Plus without making a second google account :)",
  "id" : 90782895802814465,
  "created_at" : "Tue Jul 12 14:01:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unacceptable",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90619376398630912",
  "text" : "7-11 was out of free slurpies on 7/11.... #unacceptable",
  "id" : 90619376398630912,
  "created_at" : "Tue Jul 12 03:11:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90581035028451328",
  "text" : "playing cornhole at a minor league baseball game, drinking dollar PBR and eatin a hot dog #america",
  "id" : 90581035028451328,
  "created_at" : "Tue Jul 12 00:39:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90513778696925184",
  "text" : "meeting this AM with Dr. Adjerid (VT grad director) was okay, and I snuck in a 30min swim during my lunch hour chyeah!",
  "id" : 90513778696925184,
  "created_at" : "Mon Jul 11 20:12:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 3, 19 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90465261622280192",
  "text" : "RT @BlacksburgStuff: It's 7-11 today and you know what that means: Free 7.11oz Slurpees at 7-11 until midnight!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "90418538292051968",
    "text" : "It's 7-11 today and you know what that means: Free 7.11oz Slurpees at 7-11 until midnight!",
    "id" : 90418538292051968,
    "created_at" : "Mon Jul 11 13:53:54 +0000 2011",
    "user" : {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "protected" : false,
      "id_str" : "226946313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1354924918/Downtown_Blacksburg_from_top_of_crane_normal.jpg",
      "id" : 226946313,
      "verified" : false
    }
  },
  "id" : 90465261622280192,
  "created_at" : "Mon Jul 11 16:59:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90165834739220480",
  "text" : "has been looking at graduate schools for a while...it's about impossible to narrow them down",
  "id" : 90165834739220480,
  "created_at" : "Sun Jul 10 21:09:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90122259980759041",
  "text" : "RT @neiltyson: The US bank bailout exceeded the half-century lifetime budget of NASA.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "89347120833888256",
    "text" : "The US bank bailout exceeded the half-century lifetime budget of NASA.",
    "id" : 89347120833888256,
    "created_at" : "Fri Jul 08 14:56:28 +0000 2011",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 90122259980759041,
  "created_at" : "Sun Jul 10 18:16:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http://t.co/ibCfre1",
      "expanded_url" : "http://bit.ly/pkR5Q2",
      "display_url" : "bit.ly/pkR5Q2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "90111227157688321",
  "text" : "after d2 breakfast went to mass, ran myself into the ground, and then d2 lunch! time to work now. Garmin Connect: http://t.co/ibCfre1",
  "id" : 90111227157688321,
  "created_at" : "Sun Jul 10 17:32:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "90030358116040704",
  "text" : "could very well be the only person in the whole dining hall (@ Dietrick Dining Center) http://4sq.com/nfgWHH",
  "id" : 90030358116040704,
  "created_at" : "Sun Jul 10 12:11:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 106, 114 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/X2jfixg",
      "expanded_url" : "http://bit.ly/nCzOP9",
      "display_url" : "bit.ly/nCzOP9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89803145424805889",
  "text" : "todays ride Alleghany Springs w Atsuya by andyreagan at Garmin Connect - Details: http://t.co/X2jfixg via @AddThis",
  "id" : 89803145424805889,
  "created_at" : "Sat Jul 09 21:08:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89537205906849792",
  "text" : "just watched Pan's Labyrinth, pretty good",
  "id" : 89537205906849792,
  "created_at" : "Sat Jul 09 03:31:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "googleplus",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89423283522510849",
  "text" : "RT @garyvee: It’s never the platform, it’s always the message #googleplus",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "googleplus",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "89408724476764160",
    "text" : "It’s never the platform, it’s always the message #googleplus",
    "id" : 89408724476764160,
    "created_at" : "Fri Jul 08 19:01:15 +0000 2011",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2686490082/def3702974d1d48abb19e04b8175beec_normal.jpeg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 89423283522510849,
  "created_at" : "Fri Jul 08 19:59:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tough",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "89369234995552256",
  "text" : "passed on the white quest today #tough (@ Dietrick Dining Center) [pic]: http://4sq.com/nxpzAT",
  "id" : 89369234995552256,
  "created_at" : "Fri Jul 08 16:24:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89323262705807360",
  "text" : "late to work this morning...bc I got a call and the VT Cycling Team is going to start driving Hooptie Ride's Hokie Pokey Richshaw! #fb",
  "id" : 89323262705807360,
  "created_at" : "Fri Jul 08 13:21:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 10, 25 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89154118567997441",
  "geo" : {
  },
  "id_str" : "89186163813920768",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @ryandelgiudice jealoussssss",
  "id" : 89186163813920768,
  "in_reply_to_status_id" : 89154118567997441,
  "created_at" : "Fri Jul 08 04:16:53 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2297, -80.4164 ]
  },
  "id_str" : "89171031306158080",
  "text" : "running the cornhole! (@ Top Of The Stairs (TOTS)) http://4sq.com/n83s9C",
  "id" : 89171031306158080,
  "created_at" : "Fri Jul 08 03:16:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 89, 97 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http://t.co/C1aWvn6",
      "expanded_url" : "http://bit.ly/oscc0P",
      "display_url" : "bit.ly/oscc0P"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89115885964505088",
  "text" : "the rain let up for a nice short spin. Garmin Connect - Details: http://t.co/C1aWvn6 via @AddThis",
  "id" : 89115885964505088,
  "created_at" : "Thu Jul 07 23:37:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89086776962068480",
  "text" : "new cables too! but of course now it starts pouring...",
  "id" : 89086776962068480,
  "created_at" : "Thu Jul 07 21:41:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 27, 39 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "89081165285294080",
  "text" : "is a burrito wrapping pro. @shaydubb615 (@ Dietrick Dining Center) http://4sq.com/qvSoe0",
  "id" : 89081165285294080,
  "created_at" : "Thu Jul 07 21:19:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SRAMontheroad",
      "screen_name" : "SRAMontheroad",
      "indices" : [ 75, 89 ],
      "id_str" : "18837270",
      "id" : 18837270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89040099869863936",
  "text" : "new shifter got in today, 1.5wk warranty turnaround not bad at all! thanks @SRAMontheroad",
  "id" : 89040099869863936,
  "created_at" : "Thu Jul 07 18:36:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben King",
      "screen_name" : "BenKing89",
      "indices" : [ 0, 10 ],
      "id_str" : "18171525",
      "id" : 18171525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89022044108357632",
  "geo" : {
  },
  "id_str" : "89036200584814593",
  "in_reply_to_user_id" : 18171525,
  "text" : "@BenKing89 please say that max speed isn't right!",
  "id" : 89036200584814593,
  "in_reply_to_status_id" : 89022044108357632,
  "created_at" : "Thu Jul 07 18:20:59 +0000 2011",
  "in_reply_to_screen_name" : "BenKing89",
  "in_reply_to_user_id_str" : "18171525",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 57, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/tLc5avn",
      "expanded_url" : "http://twitpic.com/5mie7v",
      "display_url" : "twitpic.com/5mie7v"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88963090166714370",
  "text" : "a look at my secret training weapon (with upgraded seat) #fb http://t.co/tLc5avn",
  "id" : 88963090166714370,
  "created_at" : "Thu Jul 07 13:30:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "88953574918332416",
  "text" : "turned on the lights this morning (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/o4NLJV",
  "id" : 88953574918332416,
  "created_at" : "Thu Jul 07 12:52:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88758962270371840",
  "geo" : {
  },
  "id_str" : "88952727278850048",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet name this song: \"i make pretty good spaghetti sauce\"",
  "id" : 88952727278850048,
  "in_reply_to_status_id" : 88758962270371840,
  "created_at" : "Thu Jul 07 12:49:17 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88809432225546241",
  "geo" : {
  },
  "id_str" : "88809892965646337",
  "in_reply_to_user_id" : 253660652,
  "text" : "@J_Gardner90 dude for REAL, imma call hooptie to see if we can somehow partner. and duuude how/where have been this summer?! Call me sumtime",
  "id" : 88809892965646337,
  "in_reply_to_status_id" : 88809432225546241,
  "created_at" : "Thu Jul 07 03:21:43 +0000 2011",
  "in_reply_to_screen_name" : "Bugmanjg",
  "in_reply_to_user_id_str" : "253660652",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2277557, -80.4135753 ]
  },
  "id_str" : "88785515599507456",
  "text" : "Comedy night! (@ Awful Arthur's) http://4sq.com/o6u0ow",
  "id" : 88785515599507456,
  "created_at" : "Thu Jul 07 01:44:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88753843948621825",
  "text" : "new registration stickers on the car! its only been 5 months",
  "id" : 88753843948621825,
  "created_at" : "Wed Jul 06 23:39:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "businessopportunity",
      "indices" : [ 119, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88693392053248000",
  "text" : "got shouted taxi at and told today on the way into work that people would pay $5 for a ride across campus on the trike #businessopportunity",
  "id" : 88693392053248000,
  "created_at" : "Wed Jul 06 19:38:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http://t.co/Eh2Rt4m",
      "expanded_url" : "http://bit.ly/nWXDbS",
      "display_url" : "bit.ly/nWXDbS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88377307382824960",
  "text" : "great run, showered, cookout time!! roomate: \"did you run through a sprinkler!?!\" nope. garmin connect: http://t.co/Eh2Rt4m",
  "id" : 88377307382824960,
  "created_at" : "Tue Jul 05 22:42:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88357757446664192",
  "text" : "goin for a run and then to cookout!",
  "id" : 88357757446664192,
  "created_at" : "Tue Jul 05 21:25:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88302872785207296",
  "geo" : {
  },
  "id_str" : "88310839932764160",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy pure math, i'm going to be looking for applied math grad schools",
  "id" : 88310839932764160,
  "in_reply_to_status_id" : 88302872785207296,
  "created_at" : "Tue Jul 05 18:18:39 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88299337343447040",
  "geo" : {
  },
  "id_str" : "88300357477863425",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy yeah, I'll talk to them and start looking at other schools. good to diversify i've heard. saw u were in bburg, but i was gone too",
  "id" : 88300357477863425,
  "in_reply_to_status_id" : 88299337343447040,
  "created_at" : "Tue Jul 05 17:37:00 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88296968241156096",
  "text" : "did not get into VT's BS/MS program (grad school here)... :(",
  "id" : 88296968241156096,
  "created_at" : "Tue Jul 05 17:23:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "88224607592648704",
  "text" : "my group is doing the formal presentation this morning (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/lM2lTP",
  "id" : 88224607592648704,
  "created_at" : "Tue Jul 05 12:36:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "88222326235205632",
  "text" : "french toast this morning, its eh (@ Dietrick Dining Center) http://4sq.com/iXhamA",
  "id" : 88222326235205632,
  "created_at" : "Tue Jul 05 12:26:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88082455646584832",
  "text" : "powertools, grilling, PBR, bikes, and fireworks to cap off a #blacksburg celebration of Merica's bday",
  "id" : 88082455646584832,
  "created_at" : "Tue Jul 05 03:11:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87923927963279360",
  "text" : "almost back to #blacksburg",
  "id" : 87923927963279360,
  "created_at" : "Mon Jul 04 16:41:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.7154942, -75.0861492 ]
  },
  "id_str" : "87655194011238400",
  "text" : "I'm at Dogfish Head Brewings & Eats (320 Rehoboth Ave, Rehoboth Beach) w/ 8 others [pic]: http://4sq.com/juSUXU",
  "id" : 87655194011238400,
  "created_at" : "Sun Jul 03 22:53:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogfish Head Brewery",
      "screen_name" : "dogfishbeer",
      "indices" : [ 59, 71 ],
      "id_str" : "16721886",
      "id" : 16721886
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onabeah",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "alwayssunny",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "classy",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "evenbetter",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http://t.co/7fO1Kfg",
      "expanded_url" : "http://twitpic.com/5ks6ik",
      "display_url" : "twitpic.com/5ks6ik"
    } ]
  },
  "geo" : {
  },
  "id_str" : "87629153389654016",
  "text" : "wine in a can #onabeah #alwayssunny #classy and its really @dogfishbeer #evenbetter http://t.co/7fO1Kfg",
  "id" : 87629153389654016,
  "created_at" : "Sun Jul 03 21:09:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 50, 57 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 73, 84 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Taste T. Brew",
      "screen_name" : "dogfishhead",
      "indices" : [ 98, 110 ],
      "id_str" : "35206223",
      "id" : 35206223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http://t.co/F7p2Dh8",
      "expanded_url" : "http://twitpic.com/5kpq9h",
      "display_url" : "twitpic.com/5kpq9h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "87582840526610432",
  "text" : "a scorching hot 7mi run to the beach worth it! RT @rkay21 On the beach w @andyreagan and Paul and @dogfishhead! http://t.co/F7p2Dh8",
  "id" : 87582840526610432,
  "created_at" : "Sun Jul 03 18:05:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Lexie White",
      "screen_name" : "alexandramwhite",
      "indices" : [ 8, 24 ],
      "id_str" : "39083429",
      "id" : 39083429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http://t.co/MPYVSZU",
      "expanded_url" : "http://twitpic.com/5k7vbc",
      "display_url" : "twitpic.com/5k7vbc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "87248928583598080",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 @alexandramwhite http://t.co/MPYVSZU",
  "id" : 87248928583598080,
  "created_at" : "Sat Jul 02 19:59:00 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 26, 33 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87060878679224320",
  "text" : "arrived successfully, wow @rkay21 has an amazing beach house",
  "id" : 87060878679224320,
  "created_at" : "Sat Jul 02 07:31:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86990256590684160",
  "geo" : {
  },
  "id_str" : "87002820846424064",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr are you in Syr??",
  "id" : 87002820846424064,
  "in_reply_to_status_id" : 86990256590684160,
  "created_at" : "Sat Jul 02 03:41:03 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87002479245541376",
  "text" : "fondue stop was excellent! only three more hours",
  "id" : 87002479245541376,
  "created_at" : "Sat Jul 02 03:39:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http://t.co/Rs6kdz4",
      "expanded_url" : "http://twitpic.com/5jq5jk",
      "display_url" : "twitpic.com/5jq5jk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "86922197830086656",
  "text" : "stuck in traffic on Blacksburg Rd? somebody ran off the road... http://t.co/Rs6kdz4",
  "id" : 86922197830086656,
  "created_at" : "Fri Jul 01 22:20:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 26, 33 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86902684547952640",
  "text" : "goin to grab some d2 then @rkay21, Paul and I are headed to Rehoboth!",
  "id" : 86902684547952640,
  "created_at" : "Fri Jul 01 21:03:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "86830864935305216",
  "text" : "Quick lunch, goin home to bake bread for the trip (@ Dietrick Dining Center) http://4sq.com/jRBQBv",
  "id" : 86830864935305216,
  "created_at" : "Fri Jul 01 16:17:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]