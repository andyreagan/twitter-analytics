Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142101935892332544",
  "text" : "fun ~5 hours of roller racing!",
  "id" : 142101935892332544,
  "created_at" : "Thu Dec 01 04:45:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/KMgFroX5",
      "expanded_url" : "http://www.acccycling.org/files/Download/6-VT.pdf",
      "display_url" : "acccycling.org/files/Download…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141875786981457921",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 http://t.co/KMgFroX5 there is lots of time on Sunday to ride, maybe we want to watch the open race and then go? (race 1:45)",
  "id" : 141875786981457921,
  "created_at" : "Wed Nov 30 13:46:38 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wild",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/Gv9JKzkx",
      "expanded_url" : "http://en.m.wikipedia.org/wiki/Space-filling_curve",
      "display_url" : "en.m.wikipedia.org/wiki/Space-fil…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141683463853051905",
  "text" : "http://t.co/Gv9JKzkx #wild",
  "id" : 141683463853051905,
  "created_at" : "Wed Nov 30 01:02:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/lam0RMWp",
      "expanded_url" : "http://www.amazon.com/gp/product/B000OHZJFK?ie=UTF8&tag=spacforrent-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=B000OHZJFK",
      "display_url" : "amazon.com/gp/product/B00…"
    } ]
  },
  "in_reply_to_status_id_str" : "141670895856009216",
  "geo" : {
  },
  "id_str" : "141672095863160833",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT soo many interesting articles floating around there. next movie to watch: http://t.co/lam0RMWp",
  "id" : 141672095863160833,
  "in_reply_to_status_id" : 141670895856009216,
  "created_at" : "Wed Nov 30 00:17:14 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 99, 110 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/SM7nELuw",
      "expanded_url" : "http://www.bakadesuyo.com/does-being-tall-mean-youre-more-likely-to-col",
      "display_url" : "bakadesuyo.com/does-being-tal…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141639559342587904",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT doesn't say it helps in college, but it helped getting us here: http://t.co/SM7nELuw via @bakadesuyo",
  "id" : 141639559342587904,
  "created_at" : "Tue Nov 29 22:07:57 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141637513281421312",
  "geo" : {
  },
  "id_str" : "141638628316164096",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr hahah just don't try too hard to scrub the VT off the wall",
  "id" : 141638628316164096,
  "in_reply_to_status_id" : 141637513281421312,
  "created_at" : "Tue Nov 29 22:04:15 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cycling",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141630736133406720",
  "text" : "sprinted after and caught the bus for a nice draft riding back to campus, look to the guy in the car behind: thumbs up from him! #cycling",
  "id" : 141630736133406720,
  "created_at" : "Tue Nov 29 21:32:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141617768234622977",
  "geo" : {
  },
  "id_str" : "141619213193330688",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e even cooler when ya seen it b4. good they dont let me teach hs lol, id be waxing cantor. guess who played bball w him last nite?",
  "id" : 141619213193330688,
  "in_reply_to_status_id" : 141617768234622977,
  "created_at" : "Tue Nov 29 20:47:06 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141617880197378048",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo good luck on that test!",
  "id" : 141617880197378048,
  "created_at" : "Tue Nov 29 20:41:48 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wideeyes",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "disbelief",
      "indices" : [ 97, 107 ]
    }, {
      "text" : "mindbending",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141612946005557248",
  "text" : "ever been in a room full of people seeing cantor's diagonalization for the first time? #wideeyes #disbelief #mindbending",
  "id" : 141612946005557248,
  "created_at" : "Tue Nov 29 20:22:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141601738858835968",
  "geo" : {
  },
  "id_str" : "141610278877003778",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo 29er?",
  "id" : 141610278877003778,
  "in_reply_to_status_id" : 141601738858835968,
  "created_at" : "Tue Nov 29 20:11:36 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141609698624405506",
  "text" : "realizing I had 8min until class 2mi away, asked the group which direction wind was, j.p. with the best answer: [twirls finger] #blacksburg",
  "id" : 141609698624405506,
  "created_at" : "Tue Nov 29 20:09:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 44, 55 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/PFYxxAXt",
      "expanded_url" : "http://www.bakadesuyo.com/can-twitter-trends-help-you-beat-the-stock-ma",
      "display_url" : "bakadesuyo.com/can-twitter-tr…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141559950819344384",
  "text" : "using twitter to beat the stock market? via @bakadesuyo http://t.co/PFYxxAXt",
  "id" : 141559950819344384,
  "created_at" : "Tue Nov 29 16:51:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmonalready",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141522931263078401",
  "text" : "the math ugrad lounge mac desktop is certainly no supercomputer...been chunking since yesterday morning on some MATLAB code #cmonalready",
  "id" : 141522931263078401,
  "created_at" : "Tue Nov 29 14:24:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141522143069474817",
  "text" : "heard from Stanca Chuipa on HIV modeling today at our group meeting, semester end presentations this friday already wow",
  "id" : 141522143069474817,
  "created_at" : "Tue Nov 29 14:21:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141369962030825472",
  "text" : "solid 2.5 hours of basketball with friends from math class and our professor!",
  "id" : 141369962030825472,
  "created_at" : "Tue Nov 29 04:16:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141309448420474881",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C what time you gonna be downtown? I can swing by at 9:30-10!",
  "id" : 141309448420474881,
  "created_at" : "Tue Nov 29 00:16:12 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 11, 21 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 22, 29 ],
      "id_str" : "18177652",
      "id" : 18177652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "throwback",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/Vcvmqypz",
      "expanded_url" : "http://twitpic.com/7lc1fl",
      "display_url" : "twitpic.com/7lc1fl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141304646147903488",
  "text" : "#throwback @vtcycling @BenDUB http://t.co/Vcvmqypz",
  "id" : 141304646147903488,
  "created_at" : "Mon Nov 28 23:57:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 47, 55 ],
      "id_str" : "84075278",
      "id" : 84075278
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 64, 74 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "booyah",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141299289891667968",
  "text" : "analysis HW knocked out #booyah, time for some @Moes_HQ and the @VTCycling meeting!",
  "id" : 141299289891667968,
  "created_at" : "Mon Nov 28 23:35:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "us",
      "indices" : [ 96, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141019876616712192",
  "geo" : {
  },
  "id_str" : "141029795759792130",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons yay! it's really only setting in that we just RAN a marathon...like who does that #us",
  "id" : 141029795759792130,
  "in_reply_to_status_id" : 141019876616712192,
  "created_at" : "Mon Nov 28 05:44:58 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141027710674808832",
  "text" : "it will be interesting to actually be car-less for my last three weeks in blacksburg, for the first time ever (carpooled down)",
  "id" : 141027710674808832,
  "created_at" : "Mon Nov 28 05:36:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 43, 52 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/Q9CRt4sX",
      "expanded_url" : "http://twitpic.com/7kyrcg",
      "display_url" : "twitpic.com/7kyrcg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141019454313205760",
  "text" : "26.2 bumper sticker among the mail, thanks @dmreagan!! http://t.co/Q9CRt4sX",
  "id" : 141019454313205760,
  "created_at" : "Mon Nov 28 05:03:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141017664461094913",
  "text" : "back in the burg, and driving late to beat traffic: huge success. 3 rest stops and made it from the poconos in 7h18m! amazing thxgiving",
  "id" : 141017664461094913,
  "created_at" : "Mon Nov 28 04:56:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140911211956027393",
  "text" : "huge 3 hour mountain bike ride w David on most of the trails in the Preserve, awesome. Headed to tech now!",
  "id" : 140911211956027393,
  "created_at" : "Sun Nov 27 21:53:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trailtime",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "henrystep",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140850332354879488",
  "text" : "#trailtime and attempting the infamous #henrystep",
  "id" : 140850332354879488,
  "created_at" : "Sun Nov 27 17:51:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moretrails",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140645928741777408",
  "text" : "finally retrieved the cell: mtbing the Pocono Preserve and spending the day with David has been awesome! Plan 4 tmrw: #moretrails",
  "id" : 140645928741777408,
  "created_at" : "Sun Nov 27 04:19:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140488966406275072",
  "text" : "mountain biking time!",
  "id" : 140488966406275072,
  "created_at" : "Sat Nov 26 17:55:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140430585398181890",
  "text" : "headed to the Poconos!!",
  "id" : 140430585398181890,
  "created_at" : "Sat Nov 26 14:03:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 23, 39 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/gqZtVhdW",
      "expanded_url" : "http://twitpic.com/7k00mc",
      "display_url" : "twitpic.com/7k00mc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "140430439616753664",
  "text" : "the \"green drink\" that @RumblinStumblin's drinking http://t.co/gqZtVhdW",
  "id" : 140430439616753664,
  "created_at" : "Sat Nov 26 14:03:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140312472061091840",
  "text" : "\"get busy living, or get busy dying\" -Andy Dufrain",
  "id" : 140312472061091840,
  "created_at" : "Sat Nov 26 06:14:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 30, 39 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 40, 51 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shawshankredemption",
      "indices" : [ 0, 20 ]
    }, {
      "text" : "classic",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140311298008293376",
  "text" : "#shawshankredemption #classic @DKnick88 @skholden17",
  "id" : 140311298008293376,
  "created_at" : "Sat Nov 26 06:09:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 20, 31 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "passedoutonmycouch",
      "indices" : [ 0, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/QOxsvV3N",
      "expanded_url" : "http://twitpic.com/7jsj2s",
      "display_url" : "twitpic.com/7jsj2s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "140292583040630785",
  "text" : "#passedoutonmycouch @skholden17 http://t.co/QOxsvV3N",
  "id" : 140292583040630785,
  "created_at" : "Sat Nov 26 04:55:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 15, 26 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 35, 51 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanksgivingbarber",
      "indices" : [ 81, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140244827030827008",
  "text" : "cut my brother @kreagannet, my dad @RumblinStumblin, and my uncle's hair tonight #thanksgivingbarber",
  "id" : 140244827030827008,
  "created_at" : "Sat Nov 26 01:45:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 3, 14 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 46, 57 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sleep",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140244663901753344",
  "text" : "RT @kreagannet finally got my haircut, thanks @andyreagan #sleep early 2nite",
  "id" : 140244663901753344,
  "created_at" : "Sat Nov 26 01:45:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "missedblackfriday",
      "indices" : [ 110, 128 ]
    }, {
      "text" : "NOT",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "140234453317459969",
  "text" : "long run, emergency yeast run to save the vanilla porter, second thanksgiving, and the annual O Brother movie #missedblackfriday #NOT",
  "id" : 140234453317459969,
  "created_at" : "Sat Nov 26 01:04:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139874150423605248",
  "geo" : {
  },
  "id_str" : "139875279404400640",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs turkey??",
  "id" : 139875279404400640,
  "in_reply_to_status_id" : 139874150423605248,
  "created_at" : "Fri Nov 25 01:17:20 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankfulfor",
      "indices" : [ 51, 63 ]
    }, {
      "text" : "gobblegobble",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139788468141305856",
  "text" : "thanksgiving with the family down in Rathbone, NY. #thankfulfor it all. #gobblegobble",
  "id" : 139788468141305856,
  "created_at" : "Thu Nov 24 19:32:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139599652981972993",
  "text" : "fact: the marcellus village tavern is nothing short of a high school reunion",
  "id" : 139599652981972993,
  "created_at" : "Thu Nov 24 07:02:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139576223440441344",
  "geo" : {
  },
  "id_str" : "139597286933139456",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 idk HOW i missed you",
  "id" : 139597286933139456,
  "in_reply_to_status_id" : 139576223440441344,
  "created_at" : "Thu Nov 24 06:52:41 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139589646886772736",
  "geo" : {
  },
  "id_str" : "139597189927288833",
  "in_reply_to_user_id" : 253660652,
  "text" : "@J_Gardner90 that's scary!",
  "id" : 139597189927288833,
  "in_reply_to_status_id" : 139589646886772736,
  "created_at" : "Thu Nov 24 06:52:18 +0000 2011",
  "in_reply_to_screen_name" : "Bugmanjg",
  "in_reply_to_user_id_str" : "253660652",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 64, 71 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 72, 81 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 82, 93 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 119, 134 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139597055147507712",
  "text" : "fun night in downtown Marcellus (never thought I'd say that)... @DZdan1 @DKnick88 @skholden17, and thanks for the ride @ryandelgiudice",
  "id" : 139597055147507712,
  "created_at" : "Thu Nov 24 06:51:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139493668909367298",
  "geo" : {
  },
  "id_str" : "139493937940410369",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 I'll be at the VT cheerin for VT!!",
  "id" : 139493937940410369,
  "in_reply_to_status_id" : 139493668909367298,
  "created_at" : "Thu Nov 24 00:02:01 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139446668004302849",
  "geo" : {
  },
  "id_str" : "139484169163120640",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 not the VT??",
  "id" : 139484169163120640,
  "in_reply_to_status_id" : 139446668004302849,
  "created_at" : "Wed Nov 23 23:23:12 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "fb",
      "indices" : [ 5, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/eORd0uir",
      "expanded_url" : "http://twitpic.com/7ijk52",
      "display_url" : "twitpic.com/7ijk52"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139459953848090624",
  "text" : "#yum #fb http://t.co/eORd0uir",
  "id" : 139459953848090624,
  "created_at" : "Wed Nov 23 21:46:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139445930125574144",
  "text" : "Tully's for lunch, sampled all the taps at Middle Ages Brewing, and home to brew a porter with a growler of support!",
  "id" : 139445930125574144,
  "created_at" : "Wed Nov 23 20:51:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 22, 38 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 42, 53 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldmanstillgotit",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139391122094034944",
  "text" : "dropped to 0-2 in the @RumblinStumblin vs @andyreagan Thanksgiving Table Tennis Tournament (TTTT), perhaps 2 series left #oldmanstillgotit",
  "id" : 139391122094034944,
  "created_at" : "Wed Nov 23 17:13:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139173768747687936",
  "text" : "RT @ashley_martin00: will it puleasee stop raining so I can run outside in the mornin!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "139172597920313347",
    "text" : "will it puleasee stop raining so I can run outside in the mornin!",
    "id" : 139172597920313347,
    "created_at" : "Wed Nov 23 02:45:07 +0000 2011",
    "user" : {
      "name" : "Ashley Martin",
      "screen_name" : "a_martin00",
      "protected" : false,
      "id_str" : "254218062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2977273304/8babb407cc58520331f0aedf6a8fd1b5_normal.jpeg",
      "id" : 254218062,
      "verified" : false
    }
  },
  "id" : 139173768747687936,
  "created_at" : "Wed Nov 23 02:49:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/9d4VAiWF",
      "expanded_url" : "http://twitpic.com/7i22jw",
      "display_url" : "twitpic.com/7i22jw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139122656212557824",
  "text" : "homemade guacamole! #yum http://t.co/9d4VAiWF",
  "id" : 139122656212557824,
  "created_at" : "Tue Nov 22 23:26:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139095039258271744",
  "geo" : {
  },
  "id_str" : "139096987348905984",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 since its 5pm now, add dark to the list lol. guess I should... going now!",
  "id" : 139096987348905984,
  "in_reply_to_status_id" : 139095039258271744,
  "created_at" : "Tue Nov 22 21:44:40 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139075484192489472",
  "text" : "overcast, 37F and no trails = no motivation to run",
  "id" : 139075484192489472,
  "created_at" : "Tue Nov 22 20:19:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 70, 77 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138820619302215681",
  "text" : "roadtrip to Vermont and UVM visit were excellent. always an adventure @sspis1",
  "id" : 138820619302215681,
  "created_at" : "Tue Nov 22 03:26:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 0, 11 ],
      "id_str" : "40995810",
      "id" : 40995810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138699369347162113",
  "geo" : {
  },
  "id_str" : "138819966047756288",
  "in_reply_to_user_id" : 40995810,
  "text" : "@anasemanas or when someone tells you something is unique and your first thought is \"well, assume there were two\"",
  "id" : 138819966047756288,
  "in_reply_to_status_id" : 138699369347162113,
  "created_at" : "Tue Nov 22 03:23:53 +0000 2011",
  "in_reply_to_screen_name" : "anasemanas",
  "in_reply_to_user_id_str" : "40995810",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138762828323618816",
  "geo" : {
  },
  "id_str" : "138819003765366786",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 you're on your own there lol",
  "id" : 138819003765366786,
  "in_reply_to_status_id" : 138762828323618816,
  "created_at" : "Tue Nov 22 03:20:04 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138640944894443520",
  "text" : "Burlington is a super cool town",
  "id" : 138640944894443520,
  "created_at" : "Mon Nov 21 15:32:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "success",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138486517508214784",
  "text" : "tent pitched in the \"pine\" lean to at mount philoh state park #success",
  "id" : 138486517508214784,
  "created_at" : "Mon Nov 21 05:18:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138368753481170944",
  "geo" : {
  },
  "id_str" : "138383681126539264",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons yeah I actually stopped running because my left calf was locking up... :(",
  "id" : 138383681126539264,
  "in_reply_to_status_id" : 138368753481170944,
  "created_at" : "Sun Nov 20 22:30:15 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wow",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "twitterhastakenovermylife",
      "indices" : [ 63, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138364151851515904",
  "text" : "very nearly tweeted a phone number instead of calling it. #wow #twitterhastakenovermylife",
  "id" : 138364151851515904,
  "created_at" : "Sun Nov 20 21:12:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138354087069622274",
  "geo" : {
  },
  "id_str" : "138359171660779520",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons haha feel ya 100%. we should run together sometime after thxgiving break!!",
  "id" : 138359171660779520,
  "in_reply_to_status_id" : 138354087069622274,
  "created_at" : "Sun Nov 20 20:52:51 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imissrunning",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138343593810214912",
  "geo" : {
  },
  "id_str" : "138350666648260609",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons np, yeah it is quite disappointing not being able run yet #imissrunning",
  "id" : 138350666648260609,
  "in_reply_to_status_id" : 138343593810214912,
  "created_at" : "Sun Nov 20 20:19:04 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138337762192535553",
  "geo" : {
  },
  "id_str" : "138342756681658368",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons hang in there, i only made it 3.7 on my first run back!",
  "id" : 138342756681658368,
  "in_reply_to_status_id" : 138337762192535553,
  "created_at" : "Sun Nov 20 19:47:38 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/URZpHEeX",
      "expanded_url" : "http://andyreagan.com/2011/11/20/running/",
      "display_url" : "andyreagan.com/2011/11/20/run…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "138126880300744705",
  "text" : "a thought on running: http://t.co/URZpHEeX",
  "id" : 138126880300744705,
  "created_at" : "Sun Nov 20 05:29:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 42, 58 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 125, 132 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138106879590137856",
  "text" : "lost the inaugural table tennis match via @RumblinStumblin in over-time tonight... however, SUPER EXCITED for Vermont trip w @sspis1!!!",
  "id" : 138106879590137856,
  "created_at" : "Sun Nov 20 04:10:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138051123935330304",
  "text" : "excellent dinner with the whole fam. the eatin is good at home!!",
  "id" : 138051123935330304,
  "created_at" : "Sun Nov 20 00:28:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 16, 25 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137970211801399296",
  "text" : "going running w @dmreagan!",
  "id" : 137970211801399296,
  "created_at" : "Sat Nov 19 19:07:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overaweekon81",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137842723062423552",
  "text" : "made it home! longest drive yet, completing my 13th round trip syr-&gt;bburg #overaweekon81",
  "id" : 137842723062423552,
  "created_at" : "Sat Nov 19 10:40:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnabealongnight",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137725456437874688",
  "text" : "your move next PA #gonnabealongnight",
  "id" : 137725456437874688,
  "created_at" : "Sat Nov 19 02:54:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137684354737508352",
  "geo" : {
  },
  "id_str" : "137708045743566848",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 4am lol traffic was awful",
  "id" : 137708045743566848,
  "in_reply_to_status_id" : 137684354737508352,
  "created_at" : "Sat Nov 19 01:45:31 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Beatty",
      "screen_name" : "PaulBeatty",
      "indices" : [ 6, 17 ],
      "id_str" : "30007041",
      "id" : 30007041
    }, {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 31, 38 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 40, 51 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "babytweet",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/DcS7gS3c",
      "expanded_url" : "http://twitter.com/k8eb8e/status/137703158452453376/photo/1",
      "display_url" : "pic.twitter.com/DcS7gS3c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "137705753296379904",
  "text" : "yayyy @paulbeatty is awesome! \"@k8eb8e: @andyreagan and Paul at dinner #babytweet http://t.co/DcS7gS3c\"",
  "id" : 137705753296379904,
  "created_at" : "Sat Nov 19 01:36:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterrequest",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "thanks",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137670884029763584",
  "text" : "#twitterrequest could everyone slow down and stop crashing into eachother #thanks",
  "id" : 137670884029763584,
  "created_at" : "Fri Nov 18 23:17:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freshmanmove",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137662273626976256",
  "text" : "harrisonburg in 4.5 ...usually 2 lol damn #freshmanmove leaving midday friday of break",
  "id" : 137662273626976256,
  "created_at" : "Fri Nov 18 22:43:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137660361217290240",
  "geo" : {
  },
  "id_str" : "137661111305641985",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet probs tmrw, traffic is killer, im 2.5 hrs behind",
  "id" : 137661111305641985,
  "in_reply_to_status_id" : 137660361217290240,
  "created_at" : "Fri Nov 18 22:39:01 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan_Gillespie",
      "screen_name" : "MeganG",
      "indices" : [ 84, 91 ],
      "id_str" : "16967718",
      "id" : 16967718
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crazy",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "whowouldthunkit",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137660080760954880",
  "text" : "OMG just heard someone scream andy on the highway and its my neighbor from syracuse @megang!! #crazy #whowouldthunkit",
  "id" : 137660080760954880,
  "created_at" : "Fri Nov 18 22:34:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull",
      "screen_name" : "redbull",
      "indices" : [ 7, 15 ],
      "id_str" : "17540485",
      "id" : 17540485
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwish",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "atleastimawake",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137649396220313604",
  "text" : "#iwish @redbull gave my car wings too #atleastimawake",
  "id" : 137649396220313604,
  "created_at" : "Fri Nov 18 21:52:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "terrible",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "stopandgokilledit",
      "indices" : [ 54, 72 ]
    }, {
      "text" : "butstill",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "ratedfor29highway",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137648378292084736",
  "text" : "gas stop num 1, got 30.0MPG on my last tank #terrible #stopandgokilledit #butstill #ratedfor29highway",
  "id" : 137648378292084736,
  "created_at" : "Fri Nov 18 21:48:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "figerscrossed",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137647497723125760",
  "text" : "may have escaped the traffic #figerscrossed, a solid 70 miles in 2.5 hrs of driving",
  "id" : 137647497723125760,
  "created_at" : "Fri Nov 18 21:44:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137630089193078784",
  "text" : "at this current rate i should be home by about monday... (barely kidding)",
  "id" : 137630089193078784,
  "created_at" : "Fri Nov 18 20:35:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137602483177537536",
  "geo" : {
  },
  "id_str" : "137604208743546880",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis *stop and go safely.... haha. thanks!",
  "id" : 137604208743546880,
  "in_reply_to_status_id" : 137602483177537536,
  "created_at" : "Fri Nov 18 18:52:54 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137601230682853377",
  "text" : "on the road home! got a little carried away packing and pretty much moved out. stopped in traffic on the 81 onramp now...",
  "id" : 137601230682853377,
  "created_at" : "Fri Nov 18 18:41:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137589207693660160",
  "geo" : {
  },
  "id_str" : "137598483279523840",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet approx 10.5 hours from right now!",
  "id" : 137598483279523840,
  "in_reply_to_status_id" : 137589207693660160,
  "created_at" : "Fri Nov 18 18:30:09 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137531946757668866",
  "text" : "two classes, lunch, then packing and hittin the old dusty trail home. biscuits in algebra this AM!!",
  "id" : 137531946757668866,
  "created_at" : "Fri Nov 18 14:05:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 81, 93 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137442268863922176",
  "text" : "glad the #hokies hung on for the W, and after cleaning the stadium for 3 hours w @VTTriathlon it's time to crash!!",
  "id" : 137442268863922176,
  "created_at" : "Fri Nov 18 08:09:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsgo",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "hokies",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137361674842808320",
  "text" : "was on ESPN! #letsgo #hokies",
  "id" : 137361674842808320,
  "created_at" : "Fri Nov 18 02:49:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Klassen",
      "screen_name" : "MJKlassen",
      "indices" : [ 3, 13 ],
      "id_str" : "31229008",
      "id" : 31229008
    }, {
      "name" : "pattyc",
      "screen_name" : "pattyc172",
      "indices" : [ 36, 46 ],
      "id_str" : "367460225",
      "id" : 367460225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137333257879552000",
  "text" : "RT @MJKlassen: Thursday night game, @pattyc172 21st bday, darius rucker playing the national anthem, last home game, and thanksgiving br ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pattyc",
        "screen_name" : "pattyc172",
        "indices" : [ 21, 31 ],
        "id_str" : "367460225",
        "id" : 367460225
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "137323139196665856",
    "text" : "Thursday night game, @pattyc172 21st bday, darius rucker playing the national anthem, last home game, and thanksgiving break. So blessed.",
    "id" : 137323139196665856,
    "created_at" : "Fri Nov 18 00:16:02 +0000 2011",
    "user" : {
      "name" : "Michelle Klassen",
      "screen_name" : "MJKlassen",
      "protected" : true,
      "id_str" : "31229008",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1687910702/tp4_normal.jpg",
      "id" : 31229008,
      "verified" : false
    }
  },
  "id" : 137333257879552000,
  "created_at" : "Fri Nov 18 00:56:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 11, 22 ]
    }, {
      "text" : "gametime",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "safetyfirst",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137297746389504000",
  "text" : "snowing on #blacksburg, and its almost #gametime!! patched a flat and installed a tail light on the trike for tail-riding! #safetyfirst",
  "id" : 137297746389504000,
  "created_at" : "Thu Nov 17 22:35:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137258456892706816",
  "geo" : {
  },
  "id_str" : "137271408505008128",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis no sir!! no such thing as bad football weather!",
  "id" : 137271408505008128,
  "in_reply_to_status_id" : 137258456892706816,
  "created_at" : "Thu Nov 17 20:50:28 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull",
      "screen_name" : "redbull",
      "indices" : [ 3, 11 ],
      "id_str" : "17540485",
      "id" : 17540485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137215790352044032",
  "text" : "RT @redbull: If you're bored, you're boring. Try to make the most of your time.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "137213475427598336",
    "text" : "If you're bored, you're boring. Try to make the most of your time.",
    "id" : 137213475427598336,
    "created_at" : "Thu Nov 17 17:00:16 +0000 2011",
    "user" : {
      "name" : "Red Bull",
      "screen_name" : "redbull",
      "protected" : false,
      "id_str" : "17540485",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2035141305/rbsport1_jan09_pant_200_200_twitter_normal.gif",
      "id" : 17540485,
      "verified" : true
    }
  },
  "id" : 137215790352044032,
  "created_at" : "Thu Nov 17 17:09:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinamerritt",
      "screen_name" : "tinainvirginia",
      "indices" : [ 3, 18 ],
      "id_str" : "12600952",
      "id" : 12600952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "Blacksburg",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "137169688986779649",
  "text" : "RT @tinainvirginia: I just passed people tailgating for tonight's game. #awesome #Blacksburg",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "awesome",
        "indices" : [ 52, 60 ]
      }, {
        "text" : "Blacksburg",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "137145817172684802",
    "text" : "I just passed people tailgating for tonight's game. #awesome #Blacksburg",
    "id" : 137145817172684802,
    "created_at" : "Thu Nov 17 12:31:25 +0000 2011",
    "user" : {
      "name" : "tinamerritt",
      "screen_name" : "tinainvirginia",
      "protected" : false,
      "id_str" : "12600952",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1799666433/IMG_3053_normal.jpg",
      "id" : 12600952,
      "verified" : false
    }
  },
  "id" : 137169688986779649,
  "created_at" : "Thu Nov 17 14:06:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136956857871904769",
  "text" : "math project complete! time to race on some rollers, share some faith, and potluck + bonfire later!!",
  "id" : 136956857871904769,
  "created_at" : "Thu Nov 17 00:00:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strange",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "shitfast",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136894654498095104",
  "geo" : {
  },
  "id_str" : "136909235274530816",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy what the hell man, that's 77 miles further than i held that pace, and Jurek dropped? #strange #shitfast",
  "id" : 136909235274530816,
  "in_reply_to_status_id" : 136894654498095104,
  "created_at" : "Wed Nov 16 20:51:19 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 13, 29 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/oxUKTX7f",
      "expanded_url" : "http://www.wrenchscience.com/WSLogic/Mountain/Group.aspx?stylecode=29&buildid=9885016",
      "display_url" : "wrenchscience.com/WSLogic/Mounta…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136664106634723329",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw @JacobnAndersson if I take the job...first purchase: http://t.co/oxUKTX7f",
  "id" : 136664106634723329,
  "created_at" : "Wed Nov 16 04:37:16 +0000 2011",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136649007303888896",
  "geo" : {
  },
  "id_str" : "136649759040618496",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e adding 2hrs to a 10hr drive would be a bit much, so yes definitely that would be awesome!!",
  "id" : 136649759040618496,
  "in_reply_to_status_id" : 136649007303888896,
  "created_at" : "Wed Nov 16 03:40:16 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136641156229496832",
  "geo" : {
  },
  "id_str" : "136648724683304960",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e how far is where you live from 81?",
  "id" : 136648724683304960,
  "in_reply_to_status_id" : 136641156229496832,
  "created_at" : "Wed Nov 16 03:36:09 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http://t.co/2bCCvcP6",
      "expanded_url" : "http://www.onionsportsnetwork.com/video/nascar-coach-reveals-winning-strategy-drive-fast,14154/",
      "display_url" : "onionsportsnetwork.com/video/nascar-c…"
    } ]
  },
  "in_reply_to_status_id_str" : "136578502634905602",
  "geo" : {
  },
  "id_str" : "136645252290322432",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud http://t.co/2bCCvcP6",
  "id" : 136645252290322432,
  "in_reply_to_status_id" : 136578502634905602,
  "created_at" : "Wed Nov 16 03:22:21 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noshavenovember",
      "indices" : [ 16, 32 ]
    }, {
      "text" : "vtmp",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "vtdudeprobs",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136643278106923009",
  "text" : "my beard itches #noshavenovember #vtmp &lt;-- #vtdudeprobs",
  "id" : 136643278106923009,
  "created_at" : "Wed Nov 16 03:14:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136575937780256768",
  "text" : "newman community thanksgiving dinner!",
  "id" : 136575937780256768,
  "created_at" : "Tue Nov 15 22:46:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 3, 13 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/4Z3TZjd5",
      "expanded_url" : "http://www.businessweek.com/lifestyle/virginia-town-is-best-place-in-the-us-to-raise-kids-11152011.html",
      "display_url" : "businessweek.com/lifestyle/virg…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136572546391875585",
  "text" : "RT @NRVLiving: Blacksburg the #1 place in the country to raise kids?  Seems that way http://t.co/4Z3TZjd5",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/4Z3TZjd5",
        "expanded_url" : "http://www.businessweek.com/lifestyle/virginia-town-is-best-place-in-the-us-to-raise-kids-11152011.html",
        "display_url" : "businessweek.com/lifestyle/virg…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "136570567045296128",
    "text" : "Blacksburg the #1 place in the country to raise kids?  Seems that way http://t.co/4Z3TZjd5",
    "id" : 136570567045296128,
    "created_at" : "Tue Nov 15 22:25:35 +0000 2011",
    "user" : {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "protected" : false,
      "id_str" : "9463702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1787766827/Jeremy_normal.jpg",
      "id" : 9463702,
      "verified" : false
    }
  },
  "id" : 136572546391875585,
  "created_at" : "Tue Nov 15 22:33:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "useful",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "toughquestions",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136561775545028608",
  "text" : "thinking abt my detailed 5 year plan - my advisor Dr Laubenbacher is having the grp present this. #useful but #toughquestions",
  "id" : 136561775545028608,
  "created_at" : "Tue Nov 15 21:50:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136552068419825664",
  "geo" : {
  },
  "id_str" : "136553834800611328",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy thanks! how early on Friday? I have class 9-11, was looking to go home after but would totally hit up some trails first!",
  "id" : 136553834800611328,
  "in_reply_to_status_id" : 136552068419825664,
  "created_at" : "Tue Nov 15 21:19:05 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136539311138025472",
  "geo" : {
  },
  "id_str" : "136550284473282560",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs im pretty sure all black people are tall",
  "id" : 136550284473282560,
  "in_reply_to_status_id" : 136539311138025472,
  "created_at" : "Tue Nov 15 21:04:59 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterencouragement",
      "indices" : [ 23, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136543919906373635",
  "geo" : {
  },
  "id_str" : "136549946282344448",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 gym!! #twitterencouragement",
  "id" : 136549946282344448,
  "in_reply_to_status_id" : 136543919906373635,
  "created_at" : "Tue Nov 15 21:03:38 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hustle",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136492550860185600",
  "text" : "got a job offer!! and going on a grad school visit over break #hustle",
  "id" : 136492550860185600,
  "created_at" : "Tue Nov 15 17:15:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136455550090227712",
  "geo" : {
  },
  "id_str" : "136456015687331840",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT its just raining lol, did you ride your bike today?",
  "id" : 136456015687331840,
  "in_reply_to_status_id" : 136455550090227712,
  "created_at" : "Tue Nov 15 14:50:24 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "gonnabehungry",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136451038944296960",
  "text" : "group meeting this morning was good, but i forgot to eat breakfast this morning #whoops #gonnabehungry",
  "id" : 136451038944296960,
  "created_at" : "Tue Nov 15 14:30:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/6EDtdhKn",
      "expanded_url" : "http://www.hcura.org/ncrc/2012/",
      "display_url" : "hcura.org/ncrc/2012/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136314300594798592",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 check this one out too: http://t.co/6EDtdhKn",
  "id" : 136314300594798592,
  "created_at" : "Tue Nov 15 05:27:16 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collegiate Times",
      "screen_name" : "CollegiateTimes",
      "indices" : [ 3, 19 ],
      "id_str" : "45960001",
      "id" : 45960001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/wtamW8Jd",
      "expanded_url" : "http://bit.ly/uAfrTP",
      "display_url" : "bit.ly/uAfrTP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136307317405790208",
  "text" : "RT @CollegiateTimes: The King of the road http://t.co/wtamW8Jd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http://t.co/wtamW8Jd",
        "expanded_url" : "http://bit.ly/uAfrTP",
        "display_url" : "bit.ly/uAfrTP"
      } ]
    },
    "geo" : {
    },
    "id_str" : "136305628737060865",
    "text" : "The King of the road http://t.co/wtamW8Jd",
    "id" : 136305628737060865,
    "created_at" : "Tue Nov 15 04:52:48 +0000 2011",
    "user" : {
      "name" : "Collegiate Times",
      "screen_name" : "CollegiateTimes",
      "protected" : false,
      "id_str" : "45960001",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2559994692/xhtj16ss7b2q5d6rrb99_normal.png",
      "id" : 45960001,
      "verified" : false
    }
  },
  "id" : 136307317405790208,
  "created_at" : "Tue Nov 15 04:59:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 18, 27 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 28, 44 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 69, 78 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136301950487625728",
  "geo" : {
  },
  "id_str" : "136303686740742145",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr hahahah @dmreagan @RumblinStumblin is this true?? (look at @vmhilljr 's last tweet)",
  "id" : 136303686740742145,
  "in_reply_to_status_id" : 136301950487625728,
  "created_at" : "Tue Nov 15 04:45:05 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136300301945802753",
  "geo" : {
  },
  "id_str" : "136301403185479681",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons yeah i hear ya. if i'm still hurtin tomorrow, i might buy a couple bags of ice, you want in lol?",
  "id" : 136301403185479681,
  "in_reply_to_status_id" : 136300301945802753,
  "created_at" : "Tue Nov 15 04:36:01 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 99, 110 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybenextyear",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136292673010147328",
  "geo" : {
  },
  "id_str" : "136300577419313152",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr unfortunately the scores swapped in the last two minutes, and i paid off the booth! (aka @kreagannet ) #maybenextyear",
  "id" : 136300577419313152,
  "in_reply_to_status_id" : 136292673010147328,
  "created_at" : "Tue Nov 15 04:32:44 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136288577058385920",
  "geo" : {
  },
  "id_str" : "136300159796649985",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel sometimes.... i do. lol.",
  "id" : 136300159796649985,
  "in_reply_to_status_id" : 136288577058385920,
  "created_at" : "Tue Nov 15 04:31:05 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/fxLkhNO6",
      "expanded_url" : "http://www.xamuel.com/homeless-by-choice/",
      "display_url" : "xamuel.com/homeless-by-ch…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136299896591486976",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 check this out: http://t.co/fxLkhNO6",
  "id" : 136299896591486976,
  "created_at" : "Tue Nov 15 04:30:02 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136282698313498624",
  "geo" : {
  },
  "id_str" : "136282894179110913",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel really jill?",
  "id" : 136282894179110913,
  "in_reply_to_status_id" : 136282698313498624,
  "created_at" : "Tue Nov 15 03:22:28 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/njh9XgNV",
      "expanded_url" : "http://runningtimes.com/Article.aspx?ArticleID=9911",
      "display_url" : "runningtimes.com/Article.aspx?A…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136282833269428224",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons what you really need is a foam roller: http://t.co/njh9XgNV (or an ice bath)",
  "id" : 136282833269428224,
  "created_at" : "Tue Nov 15 03:22:14 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Weber State NCUR2012",
      "screen_name" : "NCUR2012",
      "indices" : [ 26, 35 ],
      "id_str" : "268489364",
      "id" : 268489364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136205188213125121",
  "geo" : {
  },
  "id_str" : "136275560602140674",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 I just applied to @ncur2012 as well! how do cross a finger?",
  "id" : 136275560602140674,
  "in_reply_to_status_id" : 136205188213125121,
  "created_at" : "Tue Nov 15 02:53:20 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 10, 19 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/ksG9Ywu8",
      "expanded_url" : "http://andyreagan.com/wp-content/uploads/2011/11/FF.png",
      "display_url" : "andyreagan.com/wp-content/upl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136272376852774913",
  "text" : "what does @vmhilljr have to say about his poor performance in fantasy football this week? http://t.co/ksG9Ywu8",
  "id" : 136272376852774913,
  "created_at" : "Tue Nov 15 02:40:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136267537909432323",
  "geo" : {
  },
  "id_str" : "136270067972325376",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving that's awesome! yeah I do appreciate the recommendation so much, and will for sure send more his way",
  "id" : 136270067972325376,
  "in_reply_to_status_id" : 136267537909432323,
  "created_at" : "Tue Nov 15 02:31:30 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136265854429052928",
  "geo" : {
  },
  "id_str" : "136266269166022656",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving yessir! got a new front left hub and it made a world of difference. i won't need earplugs for the drive home :)",
  "id" : 136266269166022656,
  "in_reply_to_status_id" : 136265854429052928,
  "created_at" : "Tue Nov 15 02:16:24 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweetguys",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "itsonnow",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "fb",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136266075976384512",
  "text" : "thought someone had finally stolen my bike, but wait...there it is! halfway up that giant tree! #sweetguys #itsonnow #fb",
  "id" : 136266075976384512,
  "created_at" : "Tue Nov 15 02:15:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/RCa0IpDX",
      "expanded_url" : "http://andyreagan.com/2011/11/14/richmond-marathon/",
      "display_url" : "andyreagan.com/2011/11/14/ric…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136232806819958784",
  "text" : "race report of my first marathon!! http://t.co/RCa0IpDX #fb",
  "id" : 136232806819958784,
  "created_at" : "Tue Nov 15 00:03:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 21, 28 ],
      "id_str" : "15324722",
      "id" : 15324722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136229417121886210",
  "text" : "the support from the @garmin staff was awesome! was able to get what I could out of my corrupted data!!",
  "id" : 136229417121886210,
  "created_at" : "Mon Nov 14 23:49:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136226287202209793",
  "text" : "2 hours well spent and I got my marathon loaded into garmin training center! (connect still won't take it)",
  "id" : 136226287202209793,
  "created_at" : "Mon Nov 14 23:37:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sucks",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136204980645408768",
  "text" : "of the 5 activities on my Garmin, it COMPLETELY LOST MY FIRST MARATHON ahhh #sucks",
  "id" : 136204980645408768,
  "created_at" : "Mon Nov 14 22:12:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136203737957007360",
  "text" : "awesome 15 mile recovery ride to Radford to get my car. Beautiful weather, nice roads, bike is so smooth. The car is SO QUIET now!!",
  "id" : 136203737957007360,
  "created_at" : "Mon Nov 14 22:07:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pumped",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136165552589783041",
  "text" : "just got my tickets for the thursday night game!! #pumped",
  "id" : 136165552589783041,
  "created_at" : "Mon Nov 14 19:36:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136136608821948416",
  "geo" : {
  },
  "id_str" : "136154977818263552",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr thanks! and no thanks haha my team floundered on me!!",
  "id" : 136154977818263552,
  "in_reply_to_status_id" : 136136608821948416,
  "created_at" : "Mon Nov 14 18:54:11 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "indices" : [ 50, 62 ],
      "id_str" : "19368361",
      "id" : 19368361
    }, {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 63, 74 ],
      "id_str" : "16353686",
      "id" : 16353686
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 78, 94 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/T07rQ9J7",
      "expanded_url" : "http://twitpic.com/7e8lr0",
      "display_url" : "twitpic.com/7e8lr0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136154256095977472",
  "text" : "where can I get this technological breakthrough!? @bikesnobnyc @angryasian RT @JacobnAndersson http://t.co/T07rQ9J7",
  "id" : 136154256095977472,
  "created_at" : "Mon Nov 14 18:51:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "postmarathonproblems",
      "indices" : [ 56, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136113614921797632",
  "text" : "needing to use the handicap ramps to walk around campus #postmarathonproblems",
  "id" : 136113614921797632,
  "created_at" : "Mon Nov 14 16:09:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/1tOzQBr9",
      "expanded_url" : "http://twitpic.com/7e1g79",
      "display_url" : "twitpic.com/7e1g79"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135911974218371073",
  "text" : "number wall with the newest addition! check it out: http://t.co/1tOzQBr9",
  "id" : 135911974218371073,
  "created_at" : "Mon Nov 14 02:48:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "score",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135908644205232128",
  "text" : "realized the apt complex i live next to's laundry room is 100ft from my door. after using a laundromat a mile away for 1.5 years... #score",
  "id" : 135908644205232128,
  "created_at" : "Mon Nov 14 02:35:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eastcoasters",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/4elV94aD",
      "expanded_url" : "http://twitpic.com/7dvfle",
      "display_url" : "twitpic.com/7dvfle"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135749262473564160",
  "text" : "cross racing action at #eastcoasters Blacksburg Cyclocross Spectacle! wish I could race! http://t.co/4elV94aD",
  "id" : 135749262473564160,
  "created_at" : "Sun Nov 13 16:02:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 0, 9 ],
      "id_str" : "23640974",
      "id" : 23640974
    }, {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 10, 17 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "Paul Beatty",
      "screen_name" : "PaulBeatty",
      "indices" : [ 42, 53 ],
      "id_str" : "30007041",
      "id" : 30007041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135564398206009344",
  "geo" : {
  },
  "id_str" : "135567635290140672",
  "in_reply_to_user_id" : 23640974,
  "text" : "@jpbeatty @k8eb8e that is sad! what about @paulbeatty though?",
  "id" : 135567635290140672,
  "in_reply_to_status_id" : 135564398206009344,
  "created_at" : "Sun Nov 13 04:00:17 +0000 2011",
  "in_reply_to_screen_name" : "jpbeatty",
  "in_reply_to_user_id_str" : "23640974",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Belgium Brewing",
      "screen_name" : "newbelgium",
      "indices" : [ 40, 51 ],
      "id_str" : "18057459",
      "id" : 18057459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlife",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/ufG8AoSm",
      "expanded_url" : "http://twitpic.com/7dodre",
      "display_url" : "twitpic.com/7dodre"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135560710645219328",
  "text" : "lasagna and a 6-pack of my new favorite @newbelgium brew #goodlife http://t.co/ufG8AoSm",
  "id" : 135560710645219328,
  "created_at" : "Sun Nov 13 03:32:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "indices" : [ 3, 17 ],
      "id_str" : "15637363",
      "id" : 15637363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "runrichmond",
      "indices" : [ 42, 54 ]
    }, {
      "text" : "rva",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135510133332643840",
  "text" : "RT @SportsBackers: Congratulations to all #runrichmond finishers! It was a beautiful day to showcase the beauty #rva has to offer!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "runrichmond",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "rva",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "135498432969326593",
    "text" : "Congratulations to all #runrichmond finishers! It was a beautiful day to showcase the beauty #rva has to offer!",
    "id" : 135498432969326593,
    "created_at" : "Sat Nov 12 23:25:18 +0000 2011",
    "user" : {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "protected" : false,
      "id_str" : "15637363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1261705802/Squirt__logo_2c_normal.jpg",
      "id" : 15637363,
      "verified" : false
    }
  },
  "id" : 135510133332643840,
  "created_at" : "Sun Nov 13 00:11:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Fulton",
      "screen_name" : "BigFluffyFuton",
      "indices" : [ 0, 15 ],
      "id_str" : "260786338",
      "id" : 260786338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135355813945548801",
  "geo" : {
  },
  "id_str" : "135461865902968832",
  "in_reply_to_user_id" : 260786338,
  "text" : "@BigFluffyFuton dude i was so excited to see you out there!!!",
  "id" : 135461865902968832,
  "in_reply_to_status_id" : 135355813945548801,
  "created_at" : "Sat Nov 12 21:00:00 +0000 2011",
  "in_reply_to_screen_name" : "BigFluffyFuton",
  "in_reply_to_user_id_str" : "260786338",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mac Miller",
      "screen_name" : "MacMiller",
      "indices" : [ 3, 13 ],
      "id_str" : "23065354",
      "id" : 23065354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135460849384042496",
  "text" : "RT @MacMiller: my teacher asked me what I wanted to be when I grew up. I said happy. She said I didn't understand the ? I said she didnt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "135327463499771904",
    "text" : "my teacher asked me what I wanted to be when I grew up. I said happy. She said I didn't understand the ? I said she didnt understand life.",
    "id" : 135327463499771904,
    "created_at" : "Sat Nov 12 12:05:56 +0000 2011",
    "user" : {
      "name" : "Mac Miller",
      "screen_name" : "MacMiller",
      "protected" : false,
      "id_str" : "23065354",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3304007054/43294e43055e5bb34dc8e74d3f907173_normal.jpeg",
      "id" : 23065354,
      "verified" : true
    }
  },
  "id" : 135460849384042496,
  "created_at" : "Sat Nov 12 20:55:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135402790867574784",
  "geo" : {
  },
  "id_str" : "135452729563811840",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet thanks so much bro! if i can walk, we'll have to go hawgging when i get home",
  "id" : 135452729563811840,
  "in_reply_to_status_id" : 135402790867574784,
  "created_at" : "Sat Nov 12 20:23:41 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135349117521113088",
  "geo" : {
  },
  "id_str" : "135452383336603648",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 thanks Sarah, twas good!!",
  "id" : 135452383336603648,
  "in_reply_to_status_id" : 135349117521113088,
  "created_at" : "Sat Nov 12 20:22:19 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 0, 9 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135431722568396800",
  "geo" : {
  },
  "id_str" : "135452372666302464",
  "in_reply_to_user_id" : 23640974,
  "text" : "@jpbeatty thanks!!",
  "id" : 135452372666302464,
  "in_reply_to_status_id" : 135431722568396800,
  "created_at" : "Sat Nov 12 20:22:16 +0000 2011",
  "in_reply_to_screen_name" : "jpbeatty",
  "in_reply_to_user_id_str" : "23640974",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debut",
      "indices" : [ 40, 46 ]
    }, {
      "text" : "ouch",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "ouch",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "ouch",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135416207330390017",
  "text" : "finished Richmond Marathon in 3:30:36!! #debut #26.2 #ouch #ouch #ouch",
  "id" : 135416207330390017,
  "created_at" : "Sat Nov 12 17:58:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RICHMONDMARATHON",
      "indices" : [ 57, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135320065838039040",
  "text" : "been at the start for half an hour, race in 1.5 hours!!! #RICHMONDMARATHON",
  "id" : 135320065838039040,
  "created_at" : "Sat Nov 12 11:36:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "indices" : [ 3, 17 ],
      "id_str" : "15637363",
      "id" : 15637363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135294949129326592",
  "text" : "RT @SportsBackers: Rise and shine – it’s time to RUN RICHMOND!!!!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "135288239039852544",
    "text" : "Rise and shine – it’s time to RUN RICHMOND!!!!",
    "id" : 135288239039852544,
    "created_at" : "Sat Nov 12 09:30:04 +0000 2011",
    "user" : {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "protected" : false,
      "id_str" : "15637363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1261705802/Squirt__logo_2c_normal.jpg",
      "id" : 15637363,
      "verified" : false
    }
  },
  "id" : 135294949129326592,
  "created_at" : "Sat Nov 12 09:56:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "5AMwakeup",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "soready",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "RICHMONDMARATHON",
      "indices" : [ 33, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135176447768801280",
  "text" : "bed at 9PM?! #5AMwakeup #soready #RICHMONDMARATHON",
  "id" : 135176447768801280,
  "created_at" : "Sat Nov 12 02:05:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135169266487013376",
  "geo" : {
  },
  "id_str" : "135176173184491520",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy good luck tmrw! ill be startin 15min after ya in Richmond full",
  "id" : 135176173184491520,
  "in_reply_to_status_id" : 135169266487013376,
  "created_at" : "Sat Nov 12 02:04:45 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "registeringearlyftw",
      "indices" : [ 63, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/V7NH5BAj",
      "expanded_url" : "http://twitpic.com/7d7no8",
      "display_url" : "twitpic.com/7d7no8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135132447770816512",
  "text" : "got a ballin number!! this PPU is crazyyy with ppl and vendors #registeringearlyftw http://t.co/V7NH5BAj",
  "id" : 135132447770816512,
  "created_at" : "Fri Nov 11 23:11:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soexcited",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135118067813462018",
  "text" : "almost to packet pick up in Richmond! #soexcited",
  "id" : 135118067813462018,
  "created_at" : "Fri Nov 11 22:13:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 12, 21 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135090716002099201",
  "geo" : {
  },
  "id_str" : "135117658168360960",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 @DKnick88 i dont even remember the shoe box lol guess i needed it",
  "id" : 135117658168360960,
  "in_reply_to_status_id" : 135090716002099201,
  "created_at" : "Fri Nov 11 22:12:14 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 27, 39 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 72, 79 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RICHMONDMARATHON",
      "indices" : [ 53, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/Zul8Pnl1",
      "expanded_url" : "http://twitpic.com/7d5sz4",
      "display_url" : "twitpic.com/7d5sz4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135080848096624641",
  "text" : "everybody's rockin the new @VTTriathlon singlets for #RICHMONDMARATHON (@rkay21 @splagsVT grayson will have them) http://t.co/Zul8Pnl1",
  "id" : 135080848096624641,
  "created_at" : "Fri Nov 11 19:45:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/wW3G8nOJ",
      "expanded_url" : "http://twitpic.com/7d55th",
      "display_url" : "twitpic.com/7d55th"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135062706024751104",
  "text" : "got all the essentials!! http://t.co/wW3G8nOJ",
  "id" : 135062706024751104,
  "created_at" : "Fri Nov 11 18:33:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drivingthecreepervan",
      "indices" : [ 61, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135060267657732096",
  "text" : "final D2 carboloading complete, and passenger van picked up! #drivingthecreepervan",
  "id" : 135060267657732096,
  "created_at" : "Fri Nov 11 18:24:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Seth Greenberg",
      "screen_name" : "headhokie",
      "indices" : [ 16, 26 ],
      "id_str" : "565708797",
      "id" : 565708797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135050628371193856",
  "text" : "awesome hearing @HeadHokie at D2!!",
  "id" : 135050628371193856,
  "created_at" : "Fri Nov 11 17:45:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 0, 14 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135029358678114304",
  "geo" : {
  },
  "id_str" : "135039413662130177",
  "in_reply_to_user_id" : 326870950,
  "text" : "@BlackSheep_VT where can i find a copy on campus??",
  "id" : 135039413662130177,
  "in_reply_to_status_id" : 135029358678114304,
  "created_at" : "Fri Nov 11 17:01:19 +0000 2011",
  "in_reply_to_screen_name" : "BlackSheep_VT",
  "in_reply_to_user_id_str" : "326870950",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 26, 33 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 34, 45 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "lindz",
      "screen_name" : "lindzshark",
      "indices" : [ 46, 57 ],
      "id_str" : "230893616",
      "id" : 230893616
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 58, 69 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135037561235181568",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @DKnick88 @DZdan1 @skholden17 @lindzshark @kreagannet it's official, im coming home for thxgiving!! i better see ALL y'all!",
  "id" : 135037561235181568,
  "created_at" : "Fri Nov 11 16:53:58 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135036964826132480",
  "text" : "gettin me some new tires, sway bar linkage, and wheel bearing for the drive home to NY for thanksgiving!",
  "id" : 135036964826132480,
  "created_at" : "Fri Nov 11 16:51:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 31, 40 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 45, 61 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/WhBmOp4C",
      "expanded_url" : "http://twitpic.com/7d3ur5",
      "display_url" : "twitpic.com/7d3ur5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135029323794104320",
  "text" : "check out the SU cornhole that @dmreagan and @RumblinStumblin made, its looks awesome http://t.co/WhBmOp4C",
  "id" : 135029323794104320,
  "created_at" : "Fri Nov 11 16:21:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madeawishthough",
      "indices" : [ 54, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135028727003353088",
  "text" : "11:11:11 on 11/11/11 passed without any meltdowns lol #madeawishthough",
  "id" : 135028727003353088,
  "created_at" : "Fri Nov 11 16:18:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 30, 40 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodstart",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134997218527674368",
  "text" : "car to the shop (thanks again @NRVLiving) and biscuits in class this morning! #goodstart",
  "id" : 134997218527674368,
  "created_at" : "Fri Nov 11 14:13:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134835535108775936",
  "text" : "missed dinner due to 3.5 exam. the most important dinner of all! eatin a pound of pasta then sleepin, marathon in 1day 10.5 hours!!",
  "id" : 134835535108775936,
  "created_at" : "Fri Nov 11 03:31:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134833936126844928",
  "text" : "SNOW in #blacksburg!! No one else has noticed since theyre watching the game, i bet",
  "id" : 134833936126844928,
  "created_at" : "Fri Nov 11 03:24:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134832737810006016",
  "geo" : {
  },
  "id_str" : "134833649873989632",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 haha chyeah. and thanksgiving...still undecided really lol.",
  "id" : 134833649873989632,
  "in_reply_to_status_id" : 134832737810006016,
  "created_at" : "Fri Nov 11 03:23:41 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134818479822995456",
  "text" : "just finished a 3.5 hour algebra test (during a football game, no less)...conclusion: i am not an algebraist.",
  "id" : 134818479822995456,
  "created_at" : "Fri Nov 11 02:23:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134818293948235776",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw haha that's awesome. thanks man!",
  "id" : 134818293948235776,
  "created_at" : "Fri Nov 11 02:22:40 +0000 2011",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134723338688933888",
  "geo" : {
  },
  "id_str" : "134755362019614720",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @DKnick88 if by annoying they meant very entertaining lol",
  "id" : 134755362019614720,
  "in_reply_to_status_id" : 134723338688933888,
  "created_at" : "Thu Nov 10 22:12:36 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 3, 15 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/hrpoLq5y",
      "expanded_url" : "http://www.youtube.com/watch?v=NsMw10KVVCk",
      "display_url" : "youtube.com/watch?v=NsMw10…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "134754234213220352",
  "text" : "RT @runfasteraw: @andyreagan  http://t.co/hrpoLq5y good luck this weekend",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http://t.co/hrpoLq5y",
        "expanded_url" : "http://www.youtube.com/watch?v=NsMw10KVVCk",
        "display_url" : "youtube.com/watch?v=NsMw10…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "134745449214119937",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan  http://t.co/hrpoLq5y good luck this weekend",
    "id" : 134745449214119937,
    "created_at" : "Thu Nov 10 21:33:13 +0000 2011",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "protected" : true,
      "id_str" : "66689453",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3052598887/8a9227fac821877ebc00df2d12f5f06f_normal.jpeg",
      "id" : 66689453,
      "verified" : false
    }
  },
  "id" : 134754234213220352,
  "created_at" : "Thu Nov 10 22:08:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 3, 12 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RICHMONDMARATHON",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134286095205679104",
  "text" : "RT @Run_Rudy #RICHMONDMARATHON FOUR DAYS",
  "id" : 134286095205679104,
  "created_at" : "Wed Nov 09 15:07:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 21, 30 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134285310803722240",
  "text" : "solid 8am easy run w @Run_Rudy ...so ready, can't stop thinking about Richmond.",
  "id" : 134285310803722240,
  "created_at" : "Wed Nov 09 15:04:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 3, 12 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134070077984215040",
  "text" : "RT @jpbeatty: Linear algebra is actually useful. Who knew?",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "134068774881067008",
    "text" : "Linear algebra is actually useful. Who knew?",
    "id" : 134068774881067008,
    "created_at" : "Wed Nov 09 00:44:21 +0000 2011",
    "user" : {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "protected" : false,
      "id_str" : "23640974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/601624441/john_head_normal.jpg",
      "id" : 23640974,
      "verified" : false
    }
  },
  "id" : 134070077984215040,
  "created_at" : "Wed Nov 09 00:49:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134070026566242304",
  "text" : "going to play pick-up basketball! chyeah!",
  "id" : 134070026566242304,
  "created_at" : "Wed Nov 09 00:49:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canhardlybelieveit",
      "indices" : [ 32, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134063528729509889",
  "text" : "week and half till thanksgiving #canhardlybelieveit. richmond in 3d 12h!!",
  "id" : 134063528729509889,
  "created_at" : "Wed Nov 09 00:23:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 58, 67 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pathetic",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "bringitvern",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134041013382692864",
  "text" : "put up 37 pts in FF last week #pathetic. projected loss 2 @vmhilljr this coming week by 49...line-up change = proj win by 6! #bringitvern",
  "id" : 134041013382692864,
  "created_at" : "Tue Nov 08 22:54:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134023128614576129",
  "text" : "found the key to my bike lock!! what an interesting day of commuting.",
  "id" : 134023128614576129,
  "created_at" : "Tue Nov 08 21:42:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "Dave Bunce",
      "screen_name" : "ISMsaddles",
      "indices" : [ 54, 65 ],
      "id_str" : "18658970",
      "id" : 18658970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/1w1O4mk7",
      "expanded_url" : "http://www.treehugger.com/bikes/why-you-should-get-a-no-nose-seat-when-you-sit-on-a-regular-bike-saddle-youre-sitting-on-your-penis.html",
      "display_url" : "treehugger.com/bikes/why-you-…"
    } ]
  },
  "in_reply_to_status_id_str" : "134019403225378816",
  "geo" : {
  },
  "id_str" : "134022198242455552",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson it's called a \"bi-saddle.\" check out @ISMsaddles. no-nose saddles are pretty popular/might be good: http://t.co/1w1O4mk7",
  "id" : 134022198242455552,
  "in_reply_to_status_id" : 134019403225378816,
  "created_at" : "Tue Nov 08 21:39:16 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "someecards",
      "screen_name" : "someecards",
      "indices" : [ 3, 14 ],
      "id_str" : "14094741",
      "id" : 14094741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/2sMmv11C",
      "expanded_url" : "http://funni.ly/vR6tL0",
      "display_url" : "funni.ly/vR6tL0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "134015800347598849",
  "text" : "RT @someecards: Eyewitness account of Oklahoma earthquake from walking Oklahoma stereotype. http://t.co/2sMmv11C",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/2sMmv11C",
        "expanded_url" : "http://funni.ly/vR6tL0",
        "display_url" : "funni.ly/vR6tL0"
      } ]
    },
    "geo" : {
    },
    "id_str" : "133962238687068161",
    "text" : "Eyewitness account of Oklahoma earthquake from walking Oklahoma stereotype. http://t.co/2sMmv11C",
    "id" : 133962238687068161,
    "created_at" : "Tue Nov 08 17:41:01 +0000 2011",
    "user" : {
      "name" : "someecards",
      "screen_name" : "someecards",
      "protected" : false,
      "id_str" : "14094741",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1693411660/TwitterIcon_normal.jpg",
      "id" : 14094741,
      "verified" : true
    }
  },
  "id" : 134015800347598849,
  "created_at" : "Tue Nov 08 21:13:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133957078321602561",
  "text" : "transcript mailed out! grad school is expensive... $40 app fee, $23 sending GREs (let alone test cost), $15 transcript + $5 mailing",
  "id" : 133957078321602561,
  "created_at" : "Tue Nov 08 17:20:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133906697000464384",
  "text" : "solid 8am group meeting!",
  "id" : 133906697000464384,
  "created_at" : "Tue Nov 08 14:00:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133742166504775681",
  "geo" : {
  },
  "id_str" : "133752193244332033",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs write me some MATLAB code to find all the steady states of a two dimensional non-linear system? k thx :)",
  "id" : 133752193244332033,
  "in_reply_to_status_id" : 133742166504775681,
  "created_at" : "Tue Nov 08 03:46:22 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/iQ6TpD1h",
      "expanded_url" : "http://andyreagan.com/?p=2679",
      "display_url" : "andyreagan.com/?p=2679"
    } ]
  },
  "geo" : {
  },
  "id_str" : "133751279032877056",
  "text" : "visualization of the steady states for a model of two opinions in a pop with varying fixed meme subpop: http://t.co/iQ6TpD1h",
  "id" : 133751279032877056,
  "created_at" : "Tue Nov 08 03:42:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 4, 14 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 46, 62 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133727477003599874",
  "text" : "the @vtcycling meeting was great, congrats to @JacobnAndersson as the new MTB VP! And to Cody as MTB Travel Coordinator.",
  "id" : 133727477003599874,
  "created_at" : "Tue Nov 08 02:08:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 11, 19 ],
      "id_str" : "84075278",
      "id" : 84075278
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 35, 45 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 57, 67 ],
      "id_str" : "45430885",
      "id" : 45430885
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 74, 87 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133715433231630336",
  "text" : "grabbin an @Moes_HQ burrito before @VTCycling meeting! w @bdoyle613, Jan, @williamenium and Tyler!",
  "id" : 133715433231630336,
  "created_at" : "Tue Nov 08 01:20:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133695616965558273",
  "geo" : {
  },
  "id_str" : "133699850448539649",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT nooooooo",
  "id" : 133699850448539649,
  "in_reply_to_status_id" : 133695616965558273,
  "created_at" : "Tue Nov 08 00:18:23 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hopeididntjinxit",
      "indices" : [ 66, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133682574110375936",
  "text" : "early forecast for Saturday (marathon!) is 61 and sunny, boo-yah! #hopeididntjinxit",
  "id" : 133682574110375936,
  "created_at" : "Mon Nov 07 23:09:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 92, 101 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 102, 118 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frommyankles",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133677243594579969",
  "text" : "got a care package from my parents! basketball shoes and world supply of tube socks, thanks @dmreagan @rumblinstumblin #frommyankles",
  "id" : 133677243594579969,
  "created_at" : "Mon Nov 07 22:48:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 25, 37 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133676769155883008",
  "text" : "fun round of disc golf w @runfasteraw and @Tri_Gardner! a tie on the front end. @J_Gardner90 next time!",
  "id" : 133676769155883008,
  "created_at" : "Mon Nov 07 22:46:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133633721671761920",
  "text" : "GRE scores posted!!! checked early just in case, maybe I should've checked even earlier! 86 percentile verbal, 96 quant, 87 writing",
  "id" : 133633721671761920,
  "created_at" : "Mon Nov 07 19:55:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "indices" : [ 3, 17 ],
      "id_str" : "15637363",
      "id" : 15637363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133528619313135616",
  "text" : "RT @SportsBackers: IT'S RACE WEEEEEEEK!!!!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "133514080345538560",
    "text" : "IT'S RACE WEEEEEEEK!!!!",
    "id" : 133514080345538560,
    "created_at" : "Mon Nov 07 12:00:11 +0000 2011",
    "user" : {
      "name" : "SportsBackers",
      "screen_name" : "SportsBackers",
      "protected" : false,
      "id_str" : "15637363",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1261705802/Squirt__logo_2c_normal.jpg",
      "id" : 15637363,
      "verified" : false
    }
  },
  "id" : 133528619313135616,
  "created_at" : "Mon Nov 07 12:57:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bringit",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133393796619714560",
  "text" : "very successful sunday on the books. minus my FF team. two big tests this week, my GRE scores on T, and my first MARATHON in 5D 8hr #bringit",
  "id" : 133393796619714560,
  "created_at" : "Mon Nov 07 04:02:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "miracleshappen",
      "indices" : [ 25, 40 ]
    }, {
      "text" : "success",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133291552452775936",
  "text" : "algebra done before 4pm? #miracleshappen! going disc golfing!! #success",
  "id" : 133291552452775936,
  "created_at" : "Sun Nov 06 21:15:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "133288237547528194",
  "text" : "@Tri_Gardner disc golf, now? +all me 3154815570",
  "id" : 133288237547528194,
  "created_at" : "Sun Nov 06 21:02:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pledge2Pedal",
      "screen_name" : "Pledge2Pedal",
      "indices" : [ 0, 13 ],
      "id_str" : "370447197",
      "id" : 370447197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133263897384853505",
  "geo" : {
  },
  "id_str" : "133268563422220289",
  "in_reply_to_user_id" : 370447197,
  "text" : "@Pledge2Pedal been there, my friend did that. have you heard of the monthly star-bomb in Roanoke?? same thing, from mill mtn star!",
  "id" : 133268563422220289,
  "in_reply_to_status_id" : 133263897384853505,
  "created_at" : "Sun Nov 06 19:44:36 +0000 2011",
  "in_reply_to_screen_name" : "Pledge2Pedal",
  "in_reply_to_user_id_str" : "370447197",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132938025620615168",
  "text" : "@Tri_Gardner I shall indeed!!",
  "id" : 132938025620615168,
  "created_at" : "Sat Nov 05 21:51:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stupidtimechange",
      "indices" : [ 104, 121 ]
    }, {
      "text" : "fb",
      "indices" : [ 122, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132937046904946688",
  "text" : "excellent game of disc golf w Bradner and @splagsVT, nice fall day. last day before the sun sets at 5PM #stupidtimechange #fb",
  "id" : 132937046904946688,
  "created_at" : "Sat Nov 05 21:47:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/kIcPIy8V",
      "expanded_url" : "http://ht.ly/7jYdd",
      "display_url" : "ht.ly/7jYdd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132880440796254208",
  "text" : "RT @bakadesuyo: Do happier people live longer? http://t.co/kIcPIy8V",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http://t.co/kIcPIy8V",
        "expanded_url" : "http://ht.ly/7jYdd",
        "display_url" : "ht.ly/7jYdd"
      } ]
    },
    "geo" : {
    },
    "id_str" : "132849676075548672",
    "text" : "Do happier people live longer? http://t.co/kIcPIy8V",
    "id" : 132849676075548672,
    "created_at" : "Sat Nov 05 16:00:05 +0000 2011",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 132880440796254208,
  "created_at" : "Sat Nov 05 18:02:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 101, 110 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/Zf2PWm7D",
      "expanded_url" : "http://bit.ly/vZrSFI",
      "display_url" : "bit.ly/vZrSFI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132875555958824960",
  "text" : "marshalled the 2mi turnaround for a 5K this AM, after went 4 easy but quick 9 on Poverty w Chrissy + @slpagsVT. garmin: http://t.co/Zf2PWm7D",
  "id" : 132875555958824960,
  "created_at" : "Sat Nov 05 17:42:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neverthoughtthisdaywouldcome",
      "indices" : [ 45, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132551516501450752",
  "text" : "OMGZZZZ google profiles for accounts users!! #neverthoughtthisdaywouldcome",
  "id" : 132551516501450752,
  "created_at" : "Fri Nov 04 20:15:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realanalysis",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132549645133021184",
  "text" : "got a 78 on my #realanalysis exam, chyeah! (yeah im excited 4 that grade. this AM in class, we were just hoping that he wouldnt fail of us!)",
  "id" : 132549645133021184,
  "created_at" : "Fri Nov 04 20:07:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt McKenney",
      "screen_name" : "mattmckenney",
      "indices" : [ 0, 13 ],
      "id_str" : "244222514",
      "id" : 244222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132082730828701696",
  "geo" : {
  },
  "id_str" : "132224654856290304",
  "in_reply_to_user_id" : 244222514,
  "text" : "@mattmckenney don't want to get your pant leg caught in the chain!",
  "id" : 132224654856290304,
  "in_reply_to_status_id" : 132082730828701696,
  "created_at" : "Thu Nov 03 22:36:28 +0000 2011",
  "in_reply_to_screen_name" : "mattmckenney",
  "in_reply_to_user_id_str" : "244222514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amireallyassmartasithinkiam",
      "indices" : [ 72, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132223117367050242",
  "text" : "real analysis exam in half an hour, a lot riding on this one...lets see #amireallyassmartasithinkiam",
  "id" : 132223117367050242,
  "created_at" : "Thu Nov 03 22:30:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 15, 22 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "132216866650329088",
  "text" : "RT @jcreichel: @Kaitia happy birthday!!! &lt;3",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kait",
        "screen_name" : "Kaitia",
        "indices" : [ 0, 7 ],
        "id_str" : "31015715",
        "id" : 31015715
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "132190051126870016",
    "geo" : {
    },
    "id_str" : "132208724961009664",
    "in_reply_to_user_id" : 31015715,
    "text" : "@Kaitia happy birthday!!! &lt;3",
    "id" : 132208724961009664,
    "in_reply_to_status_id" : 132190051126870016,
    "created_at" : "Thu Nov 03 21:33:11 +0000 2011",
    "in_reply_to_screen_name" : "Kaitia",
    "in_reply_to_user_id_str" : "31015715",
    "user" : {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "protected" : true,
      "id_str" : "49206838",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3185934624/9c5e72145e1ebedfc08d1cdf3e9668f0_normal.jpeg",
      "id" : 49206838,
      "verified" : false
    }
  },
  "id" : 132216866650329088,
  "created_at" : "Thu Nov 03 22:05:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Fuller",
      "screen_name" : "AllenJFuller",
      "indices" : [ 3, 16 ],
      "id_str" : "65186354",
      "id" : 65186354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/RYAkGTQG",
      "expanded_url" : "http://twitter.com/AllenJFuller/status/132166322019778560/photo/1",
      "display_url" : "pic.twitter.com/RYAkGTQG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132180889860976640",
  "text" : "RT @AllenJFuller: My level of maturity decreases as I use Siri more - http://t.co/RYAkGTQG",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/AllenJFuller/status/132166322019778560/photo/1",
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/RYAkGTQG",
        "media_url" : "http://pbs.twimg.com/media/AdWMkdOCQAAqRuo.jpg",
        "id_str" : "132166322023972864",
        "id" : 132166322023972864,
        "media_url_https" : "https://pbs.twimg.com/media/AdWMkdOCQAAqRuo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com/RYAkGTQG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "132166322019778560",
    "text" : "My level of maturity decreases as I use Siri more - http://t.co/RYAkGTQG",
    "id" : 132166322019778560,
    "created_at" : "Thu Nov 03 18:44:41 +0000 2011",
    "user" : {
      "name" : "Allen Fuller",
      "screen_name" : "AllenJFuller",
      "protected" : false,
      "id_str" : "65186354",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1575617757/Allen_J_Fuller_III_normal.jpg",
      "id" : 65186354,
      "verified" : false
    }
  },
  "id" : 132180889860976640,
  "created_at" : "Thu Nov 03 19:42:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "forkapple",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "cuptower",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/DMesZ7c3",
      "expanded_url" : "http://twitpic.com/7afk72",
      "display_url" : "twitpic.com/7afk72"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132142677679542272",
  "text" : "almost as cool as #forkapple is the #cuptower http://t.co/DMesZ7c3",
  "id" : 132142677679542272,
  "created_at" : "Thu Nov 03 17:10:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VTGirlProblems",
      "screen_name" : "VTGirlProblems",
      "indices" : [ 0, 15 ],
      "id_str" : "372660710",
      "id" : 372660710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ithoughtaboutit",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132109100883509248",
  "geo" : {
  },
  "id_str" : "132118512666820609",
  "in_reply_to_user_id" : 372660710,
  "text" : "@VTGirlProblems they probs wanted the shoutout, so they unfollow and wait till they see 999 to follow again #ithoughtaboutit",
  "id" : 132118512666820609,
  "in_reply_to_status_id" : 132109100883509248,
  "created_at" : "Thu Nov 03 15:34:42 +0000 2011",
  "in_reply_to_screen_name" : "VTGirlProblems",
  "in_reply_to_user_id_str" : "372660710",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "caughtup",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "neverends",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131949458069008384",
  "text" : "played some hoops and finished up my HW tonight. #caughtup but it #neverends",
  "id" : 131949458069008384,
  "created_at" : "Thu Nov 03 04:22:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131861934143315968",
  "geo" : {
  },
  "id_str" : "131949145115205632",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 sweeet!!",
  "id" : 131949145115205632,
  "in_reply_to_status_id" : 131861934143315968,
  "created_at" : "Thu Nov 03 04:21:42 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bburg",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131841937757057024",
  "text" : "landed in ROA and almost back to the #bburg. pretty awesome views of the mtns coming in",
  "id" : 131841937757057024,
  "created_at" : "Wed Nov 02 21:15:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/KC8dHPxh",
      "expanded_url" : "http://twitpic.com/79x8yp",
      "display_url" : "twitpic.com/79x8yp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131794026608332800",
  "text" : "after haulin my heavy ass bag to the other end of terminal to then realize food is where i was: http://t.co/KC8dHPxh",
  "id" : 131794026608332800,
  "created_at" : "Wed Nov 02 18:05:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squeakycheese",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131525331239698432",
  "geo" : {
  },
  "id_str" : "131531110705397760",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr they just dont know... havent ever had the #squeakycheese",
  "id" : 131531110705397760,
  "in_reply_to_status_id" : 131525331239698432,
  "created_at" : "Wed Nov 02 00:40:35 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reallifeapproaches",
      "indices" : [ 55, 74 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131520992123158529",
  "geo" : {
  },
  "id_str" : "131530625877409792",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis yessir!! came up here for a job interview #reallifeapproaches",
  "id" : 131530625877409792,
  "in_reply_to_status_id" : 131520992123158529,
  "created_at" : "Wed Nov 02 00:38:39 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131524934722785280",
  "text" : "in search of cheese curd and spotted cow ale!",
  "id" : 131524934722785280,
  "created_at" : "Wed Nov 02 00:16:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131519472581361664",
  "text" : "fun little 5mi run around Madison, really pretty city! Managed to run thru campus, down frat row, on a dirt path by the lake, and by capitol",
  "id" : 131519472581361664,
  "created_at" : "Tue Nov 01 23:54:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ftw",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131502634573115392",
  "text" : "time to go get lost in Madison (exploring by running #ftw)",
  "id" : 131502634573115392,
  "created_at" : "Tue Nov 01 22:47:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131492102440882176",
  "text" : "so a total of 3 assessments (tests), 2 one on one interviews, giving a 20min pres, 2 overviews and a campus tour ...that's an interview!",
  "id" : 131492102440882176,
  "created_at" : "Tue Nov 01 22:05:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131244745979727872",
  "geo" : {
  },
  "id_str" : "131400860726079488",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris do it!!",
  "id" : 131400860726079488,
  "in_reply_to_status_id" : 131244745979727872,
  "created_at" : "Tue Nov 01 16:03:01 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 3, 12 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131400500510867456",
  "text" : "RT @vmhilljr: Having no electricity gives me an appreciation of how our ancestors lived. Before cars, for example, how did they recharge ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "131366214294454273",
    "text" : "Having no electricity gives me an appreciation of how our ancestors lived. Before cars, for example, how did they recharge their iPhones?",
    "id" : 131366214294454273,
    "created_at" : "Tue Nov 01 13:45:20 +0000 2011",
    "user" : {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "protected" : false,
      "id_str" : "104673361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1681278155/wally_normal.jpg",
      "id" : 104673361,
      "verified" : false
    }
  },
  "id" : 131400500510867456,
  "created_at" : "Tue Nov 01 16:01:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131400368541282304",
  "text" : "interview is excellent so far, the campus here is amazing!",
  "id" : 131400368541282304,
  "created_at" : "Tue Nov 01 16:01:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]