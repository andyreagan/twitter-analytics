Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 79, 90 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819048667, -73.2029054 ]
  },
  "id_str" : "208382138133917696",
  "text" : "finished moving out of my old place and straight to the TT up Bolton! I thin k @peterdodds got me though",
  "id" : 208382138133917696,
  "created_at" : "Fri Jun 01 02:19:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4793334, -73.2068704 ]
  },
  "id_str" : "208290175732822017",
  "text" : "moving day, known by Burlington's homeless as christmas",
  "id" : 208290175732822017,
  "created_at" : "Thu May 31 20:13:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/208047374252257280/photo/1",
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/xLtRiR48",
      "media_url" : "http://pbs.twimg.com/media/AuMh_A9CMAEITx_.jpg",
      "id_str" : "208047374260645889",
      "id" : 208047374260645889,
      "media_url_https" : "https://pbs.twimg.com/media/AuMh_A9CMAEITx_.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/xLtRiR48"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859447667, -73.20824125 ]
  },
  "id_str" : "208047374252257280",
  "text" : "new and improved bike trailer hitch for the final move tomorrow http://t.co/xLtRiR48",
  "id" : 208047374252257280,
  "created_at" : "Thu May 31 04:08:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 31, 38 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/e16swlnu",
      "expanded_url" : "http://yfrog.com/nvkehpygj",
      "display_url" : "yfrog.com/nvkehpygj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4858084667, -73.20824625 ]
  },
  "id_str" : "208046371897491457",
  "text" : "injuries were somehow avoided \"@sspis1: http://t.co/e16swlnu bad news bears\"",
  "id" : 208046371897491457,
  "created_at" : "Thu May 31 04:04:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 41, 52 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/nYvMBRV9",
      "expanded_url" : "http://twitter.com/sspis1/status/207990930026926081/photo/1",
      "display_url" : "pic.twitter.com/nYvMBRV9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "207991905357791234",
  "text" : "RT @sspis1: Quick hike up Mansfield with @andyreagan http://t.co/nYvMBRV9",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">Twitter MMS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 29, 40 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/sspis1/status/207990930026926081/photo/1",
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/nYvMBRV9",
        "media_url" : "http://pbs.twimg.com/media/AuLuph0CEAANcYu.jpg",
        "id_str" : "207990930031120384",
        "id" : 207990930031120384,
        "media_url_https" : "https://pbs.twimg.com/media/AuLuph0CEAANcYu.jpg",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1952,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/nYvMBRV9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "207990930026926081",
    "text" : "Quick hike up Mansfield with @andyreagan http://t.co/nYvMBRV9",
    "id" : 207990930026926081,
    "created_at" : "Thu May 31 00:24:37 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 207991905357791234,
  "created_at" : "Thu May 31 00:28:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "summittweet",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "4348ft",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "mtmansfield",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.54356375, -72.81462685 ]
  },
  "id_str" : "207924539747868673",
  "text" : "lichen tweet #storylab #summittweet #4348ft #mtmansfield",
  "id" : 207924539747868673,
  "created_at" : "Wed May 30 20:00:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 40, 49 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "207856959238574081",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 come join at the table outside, @dr_pyser and @SuMillie want to meet youuu",
  "id" : 207856959238574081,
  "created_at" : "Wed May 30 15:32:15 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scary",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "207837636054884352",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 test geotag from laptop. twitter thinks I'm in Williston, and google knows I'm on trinity campus #scary",
  "id" : 207837636054884352,
  "created_at" : "Wed May 30 14:15:28 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207477401050025984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859650667, -73.2083971 ]
  },
  "id_str" : "207479117623463938",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan yupp, did half and half last time and that worked",
  "id" : 207479117623463938,
  "in_reply_to_status_id" : 207477401050025984,
  "created_at" : "Tue May 29 14:30:51 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Klassen",
      "screen_name" : "MJKlassen",
      "indices" : [ 0, 10 ],
      "id_str" : "31229008",
      "id" : 31229008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207360977933565953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859631833, -73.20840145 ]
  },
  "id_str" : "207478932868567042",
  "in_reply_to_user_id" : 31229008,
  "text" : "@MJKlassen that looks amazing! quite the cyclist you seem to have become from twitter!",
  "id" : 207478932868567042,
  "in_reply_to_status_id" : 207360977933565953,
  "created_at" : "Tue May 29 14:30:07 +0000 2012",
  "in_reply_to_screen_name" : "MJKlassen",
  "in_reply_to_user_id_str" : "31229008",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/207476740212277248/photo/1",
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/N2630Ktf",
      "media_url" : "http://pbs.twimg.com/media/AuEa_vgCQAAVhPB.jpg",
      "id_str" : "207476740220665856",
      "id" : 207476740220665856,
      "media_url_https" : "https://pbs.twimg.com/media/AuEa_vgCQAAVhPB.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/N2630Ktf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859742167, -73.2083859333 ]
  },
  "id_str" : "207476740212277248",
  "text" : "the 100th loaf (maple whole wheat) is in the bread machine...and I got it this time last year http://t.co/N2630Ktf",
  "id" : 207476740212277248,
  "created_at" : "Tue May 29 14:21:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "indices" : [ 24, 31 ],
      "id_str" : "24074204",
      "id" : 24074204
    }, {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 34, 47 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uvmcycling",
      "indices" : [ 116, 127 ]
    }, {
      "text" : "needrestday",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48603525, -73.20837445 ]
  },
  "id_str" : "207224765642047489",
  "text" : "brisket (other known as @benciv), @dabrownnoise, Forrest and Josh S beat me up today on a sweet 46 miler in the sun #uvmcycling #needrestday",
  "id" : 207224765642047489,
  "created_at" : "Mon May 28 21:40:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kbvcm",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4815888333, -73.2189405 ]
  },
  "id_str" : "206718699518967808",
  "text" : "and they're off #kbvcm",
  "id" : 206718699518967808,
  "created_at" : "Sun May 27 12:09:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/206684357375692800/photo/1",
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/LHSitWQf",
      "media_url" : "http://pbs.twimg.com/media/At5KU_ZCEAA6sne.jpg",
      "id_str" : "206684357379887104",
      "id" : 206684357379887104,
      "media_url_https" : "https://pbs.twimg.com/media/At5KU_ZCEAA6sne.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LHSitWQf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4810832667, -73.2190840167 ]
  },
  "id_str" : "206684357375692800",
  "text" : "awake before the runners today http://t.co/LHSitWQf",
  "id" : 206684357375692800,
  "created_at" : "Sun May 27 09:52:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 8, 16 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/206562205355880448/photo/1",
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/HNY1lU2p",
      "media_url" : "http://pbs.twimg.com/media/At3bOzqCMAE0reZ.jpg",
      "id_str" : "206562205360074753",
      "id" : 206562205360074753,
      "media_url_https" : "https://pbs.twimg.com/media/At3bOzqCMAE0reZ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/HNY1lU2p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4861630167, -73.2083972 ]
  },
  "id_str" : "206562205355880448",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill @Karo1yn this is what speed tastes like? http://t.co/HNY1lU2p",
  "id" : 206562205355880448,
  "created_at" : "Sun May 27 01:47:22 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4861462333, -73.2084263667 ]
  },
  "id_str" : "206561901981872128",
  "text" : "\"when we run we talk about drinking, and when we drink we talk about running\" -Colby",
  "id" : 206561901981872128,
  "created_at" : "Sun May 27 01:46:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859100333, -73.2081924 ]
  },
  "id_str" : "206527411209240576",
  "text" : "has discovered the magical recipe for great runs: huge salad (w beets) followed by a two hour nap. hilly 10k in 44:30 and couldve kept going",
  "id" : 206527411209240576,
  "created_at" : "Sat May 26 23:29:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 4, 15 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/LSDI47F9",
      "expanded_url" : "http://www.9wsyr.com/s/f_dhWkC4LEOsxP21aDTGwQ.cspx#.T8DFk8tFQSg.email",
      "display_url" : "9wsyr.com/s/f_dhWkC4LEOs…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859421167, -73.20825465 ]
  },
  "id_str" : "206370996691804160",
  "text" : "wow @skholden17 awesome game!!! http://t.co/LSDI47F9",
  "id" : 206370996691804160,
  "created_at" : "Sat May 26 13:07:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Greenlaw",
      "screen_name" : "dgreenlaw13",
      "indices" : [ 28, 40 ],
      "id_str" : "269907937",
      "id" : 269907937
    }, {
      "name" : "Jake Warshaw",
      "screen_name" : "jake11248",
      "indices" : [ 41, 51 ],
      "id_str" : "270322204",
      "id" : 270322204
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 52, 59 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nothingbetter",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4858666167, -73.2082903833 ]
  },
  "id_str" : "206199539391139843",
  "text" : "awesome MTB earlier today w @dgreenlaw13 @jake11248 @sspis1, followed up w a burrito and brew #nothingbetter",
  "id" : 206199539391139843,
  "created_at" : "Sat May 26 01:46:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "206108193238171648",
  "text" : "just checked out Hubert D'Autremont's shop in S Burlington and got some great advice to get started framebuilding...couldn't be more excited",
  "id" : 206108193238171648,
  "created_at" : "Fri May 25 19:43:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 1, 13 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Dana Greenlaw",
      "screen_name" : "dgreenlaw13",
      "indices" : [ 32, 44 ],
      "id_str" : "269907937",
      "id" : 269907937
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/205808220554530816/photo/1",
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/2UVaqT1M",
      "media_url" : "http://pbs.twimg.com/media/AtstfHZCEAIx8pR.jpg",
      "id_str" : "205808220558725122",
      "id" : 205808220558725122,
      "media_url_https" : "https://pbs.twimg.com/media/AtstfHZCEAIx8pR.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/2UVaqT1M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4861267833, -73.2082471333 ]
  },
  "id_str" : "205808220554530816",
  "text" : ".@uvm_cycling's chipmunk killer @dgreenlaw13 http://t.co/2UVaqT1M",
  "id" : 205808220554530816,
  "created_at" : "Thu May 24 23:51:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 33, 44 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/E839lXeH",
      "expanded_url" : "http://yfrog.com/oehk2goj",
      "display_url" : "yfrog.com/oehk2goj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205777428470173697",
  "text" : "RT @sspis1: http://t.co/E839lXeH @andyreagan at unicycle practice",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 21, 32 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/E839lXeH",
        "expanded_url" : "http://yfrog.com/oehk2goj",
        "display_url" : "yfrog.com/oehk2goj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205723343486328832",
    "text" : "http://t.co/E839lXeH @andyreagan at unicycle practice",
    "id" : 205723343486328832,
    "created_at" : "Thu May 24 18:14:01 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 205777428470173697,
  "created_at" : "Thu May 24 21:48:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 11, 18 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/SuQx4Uke",
      "expanded_url" : "http://bit.ly/KuG1Cd",
      "display_url" : "bit.ly/KuG1Cd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205760989017288704",
  "text" : "looks like @ttmill is going to have to recover quicker... 7 miles in, on an 82deg scorcher, and back on top of Depot St http://t.co/SuQx4Uke",
  "id" : 205760989017288704,
  "created_at" : "Thu May 24 20:43:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 40, 51 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/TnwK83Zg",
      "expanded_url" : "http://yfrog.com/nw8tdolj",
      "display_url" : "yfrog.com/nw8tdolj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205381673980932097",
  "text" : "RT @sspis1: http://t.co/TnwK83Zg moving @andyreagan nbd",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 28, 39 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/TnwK83Zg",
        "expanded_url" : "http://yfrog.com/nw8tdolj",
        "display_url" : "yfrog.com/nw8tdolj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "205364083967537152",
    "text" : "http://t.co/TnwK83Zg moving @andyreagan nbd",
    "id" : 205364083967537152,
    "created_at" : "Wed May 23 18:26:27 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 205381673980932097,
  "created_at" : "Wed May 23 19:36:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 65, 76 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/ROVwtMBV",
      "expanded_url" : "http://twitter.com/sspis1/status/205160704817377282/photo/1",
      "display_url" : "pic.twitter.com/ROVwtMBV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "205290195208253441",
  "text" : "RT @sspis1: nothing like building a bike trailer at 1am ... only @andyreagan :P http://t.co/ROVwtMBV",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">Twitter MMS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 53, 64 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/sspis1/status/205160704817377282/photo/1",
        "indices" : [ 68, 88 ],
        "url" : "http://t.co/ROVwtMBV",
        "media_url" : "http://pbs.twimg.com/media/AtjgkvUCMAAlN50.jpg",
        "id_str" : "205160704825765888",
        "id" : 205160704825765888,
        "media_url_https" : "https://pbs.twimg.com/media/AtjgkvUCMAAlN50.jpg",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1952,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/ROVwtMBV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "205160704817377282",
    "text" : "nothing like building a bike trailer at 1am ... only @andyreagan :P http://t.co/ROVwtMBV",
    "id" : 205160704817377282,
    "created_at" : "Wed May 23 04:58:19 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 205290195208253441,
  "created_at" : "Wed May 23 13:32:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205281375169953793",
  "geo" : {
  },
  "id_str" : "205290165491613698",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill \"thief\" would imply there was stealing involved. and you can only steal what belongs to someone else...",
  "id" : 205290165491613698,
  "in_reply_to_status_id" : 205281375169953793,
  "created_at" : "Wed May 23 13:32:44 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "indices" : [ 57, 64 ],
      "id_str" : "24074204",
      "id" : 24074204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/5uzcD4Pj",
      "expanded_url" : "http://vimeo.com/19736217",
      "display_url" : "vimeo.com/19736217"
    } ]
  },
  "geo" : {
  },
  "id_str" : "204616234069794816",
  "text" : "cool POV vid of some brazing action http://t.co/5uzcD4Pj @BenCiv",
  "id" : 204616234069794816,
  "created_at" : "Mon May 21 16:54:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204446755201359872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4801215333, -73.21237085 ]
  },
  "id_str" : "204448511729741824",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill congrats on the graduatuon and chyeahhhh unbeatable. PS call me when you run in the AM",
  "id" : 204448511729741824,
  "in_reply_to_status_id" : 204446755201359872,
  "created_at" : "Mon May 21 05:48:18 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 3, 10 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 12, 23 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "204373185901232130",
  "text" : "RT @k8eb8e: @andyreagan honestly, it would have too. I don't think anything tastes worse than how that looks",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "204372675496394752",
    "geo" : {
    },
    "id_str" : "204373034579140610",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan honestly, it would have too. I don't think anything tastes worse than how that looks",
    "id" : 204373034579140610,
    "in_reply_to_status_id" : 204372675496394752,
    "created_at" : "Mon May 21 00:48:23 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "protected" : false,
      "id_str" : "26517690",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/673880411/IMG_0050_normal.JPG",
      "id" : 26517690,
      "verified" : false
    }
  },
  "id" : 204373185901232130,
  "created_at" : "Mon May 21 00:48:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/204372675496394752/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/LWEa4fty",
      "media_url" : "http://pbs.twimg.com/media/AtYT3ZUCQAAHxJu.jpg",
      "id_str" : "204372675500589056",
      "id" : 204372675500589056,
      "media_url_https" : "https://pbs.twimg.com/media/AtYT3ZUCQAAHxJu.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LWEa4fty"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4711739667, -73.1905962667 ]
  },
  "id_str" : "204372675496394752",
  "text" : "better than it looks http://t.co/LWEa4fty",
  "id" : 204372675496394752,
  "created_at" : "Mon May 21 00:46:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/204360940932694016/photo/1",
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/Q5mHEljZ",
      "media_url" : "http://pbs.twimg.com/media/AtYJMWqCAAAxyoY.jpg",
      "id_str" : "204360940936888320",
      "id" : 204360940936888320,
      "media_url_https" : "https://pbs.twimg.com/media/AtYJMWqCAAAxyoY.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Q5mHEljZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4709801333, -73.1906623833 ]
  },
  "id_str" : "204360940932694016",
  "text" : "hairy hot dogs? http://t.co/Q5mHEljZ",
  "id" : 204360940932694016,
  "created_at" : "Mon May 21 00:00:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carolyn mason",
      "screen_name" : "caro1yn",
      "indices" : [ 23, 31 ],
      "id_str" : "18973694",
      "id" : 18973694
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/204300514693881858/photo/1",
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/n0H2Psey",
      "media_url" : "http://pbs.twimg.com/media/AtXSPFYCIAEtutK.jpg",
      "id_str" : "204300514698076161",
      "id" : 204300514698076161,
      "media_url_https" : "https://pbs.twimg.com/media/AtXSPFYCIAEtutK.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/n0H2Psey"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4921369333, -73.2402350667 ]
  },
  "id_str" : "204300514693881858",
  "text" : "north beach is hoppin. @caro1yn such a bad influence http://t.co/n0H2Psey",
  "id" : 204300514693881858,
  "created_at" : "Sun May 20 20:00:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carolyn mason",
      "screen_name" : "caro1yn",
      "indices" : [ 23, 31 ],
      "id_str" : "18973694",
      "id" : 18973694
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/204300403838435328/photo/1",
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/1A0NNHaU",
      "media_url" : "http://pbs.twimg.com/media/AtXSIoaCQAI3O5S.jpg",
      "id_str" : "204300403842629634",
      "id" : 204300403842629634,
      "media_url_https" : "https://pbs.twimg.com/media/AtXSIoaCQAI3O5S.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/1A0NNHaU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4921369333, -73.2402350667 ]
  },
  "id_str" : "204300403838435328",
  "text" : "north beach is hoppin. @caro1yn such a bad influence http://t.co/1A0NNHaU",
  "id" : 204300403838435328,
  "created_at" : "Sun May 20 20:00:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203978968058167296/photo/1",
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/0e3m60BM",
      "media_url" : "http://pbs.twimg.com/media/AtStym0CAAA5q7H.jpg",
      "id_str" : "203978968062361600",
      "id" : 203978968062361600,
      "media_url_https" : "https://pbs.twimg.com/media/AtStym0CAAA5q7H.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/0e3m60BM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4687478667, -73.1780416167 ]
  },
  "id_str" : "203978968058167296",
  "text" : "some of the gorgeous Vermont countryside today: http://t.co/0e3m60BM",
  "id" : 203978968058167296,
  "created_at" : "Sat May 19 22:42:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Greenlaw",
      "screen_name" : "dgreenlaw13",
      "indices" : [ 26, 38 ],
      "id_str" : "269907937",
      "id" : 269907937
    }, {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 39, 52 ],
      "id_str" : "328777340",
      "id" : 328777340
    }, {
      "name" : "Alex Cox",
      "screen_name" : "coxinabox1",
      "indices" : [ 53, 64 ],
      "id_str" : "56529676",
      "id" : 56529676
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 65, 77 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/Vwehp9uV",
      "expanded_url" : "http://bit.ly/LojZE0",
      "display_url" : "bit.ly/LojZE0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "203969454063882241",
  "text" : "awesome group ride today! @dgreenlaw13 @DaBrownNoise @coxinabox1 @UVM_cycling http://t.co/Vwehp9uV",
  "id" : 203969454063882241,
  "created_at" : "Sat May 19 22:04:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 34, 46 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biggroupride",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4686898, -73.1954011333 ]
  },
  "id_str" : "203881692136611841",
  "text" : "time to ride bikes! #biggroupride @UVM_cycling",
  "id" : 203881692136611841,
  "created_at" : "Sat May 19 16:15:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/AMFrzaql",
      "expanded_url" : "http://4sq.com/J3ZjdX",
      "display_url" : "4sq.com/J3ZjdX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4757291361, -73.2139394415 ]
  },
  "id_str" : "203711372608028673",
  "text" : "if you want to wait in longer than is worth spending inside go to... (@ What Ale's You w/ 4 others) http://t.co/AMFrzaql",
  "id" : 203711372608028673,
  "created_at" : "Sat May 19 04:59:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 10, 17 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4860002667, -73.20852645 ]
  },
  "id_str" : "203632706674892800",
  "text" : "signed up @sspis1 and myself for a motorcycle license course later this summer! all on the way to hit up some singletrack, chyeah",
  "id" : 203632706674892800,
  "created_at" : "Fri May 18 23:46:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203569148989681664",
  "geo" : {
  },
  "id_str" : "203572715305709568",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill tempting, but I'm going to try the long ride w the cycling team (no family in town for me!)",
  "id" : 203572715305709568,
  "in_reply_to_status_id" : 203569148989681664,
  "created_at" : "Fri May 18 19:48:12 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/g2OxLb6h",
      "expanded_url" : "http://app.strava.com/activities/8805457",
      "display_url" : "app.strava.com/activities/880…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "203561357684125696",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill congrats on the 20k. our repeats on wednesday were pretty solid times: http://t.co/g2OxLb6h",
  "id" : 203561357684125696,
  "created_at" : "Fri May 18 19:03:04 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203522309712130049/photo/1",
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/ptfyIW8P",
      "media_url" : "http://pbs.twimg.com/media/AtMOdl6CMAEIZRb.jpg",
      "id_str" : "203522309716324353",
      "id" : 203522309716324353,
      "media_url_https" : "https://pbs.twimg.com/media/AtMOdl6CMAEIZRb.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ptfyIW8P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46746775, -73.1813362167 ]
  },
  "id_str" : "203522309712130049",
  "text" : "vermont plates! http://t.co/ptfyIW8P",
  "id" : 203522309712130049,
  "created_at" : "Fri May 18 16:27:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203508146004688896/photo/1",
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/M3iFmXf3",
      "media_url" : "http://pbs.twimg.com/media/AtMBlJ_CAAA-zFw.jpg",
      "id_str" : "203508146008883200",
      "id" : 203508146008883200,
      "media_url_https" : "https://pbs.twimg.com/media/AtMBlJ_CAAA-zFw.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/M3iFmXf3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.483367, -73.1942111333 ]
  },
  "id_str" : "203508146004688896",
  "text" : "reason number 842 why I'm afraid to get my car inspected: my muffler http://t.co/M3iFmXf3",
  "id" : 203508146004688896,
  "created_at" : "Fri May 18 15:31:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203471150645387265",
  "geo" : {
  },
  "id_str" : "203506982655762433",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill you really should. see ya at the pool in a minute!",
  "id" : 203506982655762433,
  "in_reply_to_status_id" : 203471150645387265,
  "created_at" : "Fri May 18 15:27:00 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203506550327877632",
  "text" : "bike to work day #fail: first time I drove to work all year...got halfway here on bike, realized needed car to finally register it at dmv",
  "id" : 203506550327877632,
  "created_at" : "Fri May 18 15:25:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Culture Cycles",
      "screen_name" : "CultureCycles",
      "indices" : [ 0, 14 ],
      "id_str" : "39440392",
      "id" : 39440392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203494248971124736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4789406, -73.2009187 ]
  },
  "id_str" : "203498276190822401",
  "in_reply_to_user_id" : 39440392,
  "text" : "@CultureCycles thanks! yeah its actually really tough to find him online, i'll let him know :P",
  "id" : 203498276190822401,
  "in_reply_to_status_id" : 203494248971124736,
  "created_at" : "Fri May 18 14:52:24 +0000 2012",
  "in_reply_to_screen_name" : "CultureCycles",
  "in_reply_to_user_id_str" : "39440392",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 29, 36 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203492778683015171",
  "text" : "got the summer planned out w @sspis1, going to be some great adventures!",
  "id" : 203492778683015171,
  "created_at" : "Fri May 18 14:30:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Culture Cycles",
      "screen_name" : "CultureCycles",
      "indices" : [ 0, 14 ],
      "id_str" : "39440392",
      "id" : 39440392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203492594947334144",
  "in_reply_to_user_id" : 39440392,
  "text" : "@CultureCycles hey guys, I've got a jig and am building my first frame this summer in #btv, can you help me contact Hubert d'Autremont?",
  "id" : 203492594947334144,
  "created_at" : "Fri May 18 14:29:50 +0000 2012",
  "in_reply_to_screen_name" : "CultureCycles",
  "in_reply_to_user_id_str" : "39440392",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203456128678498305",
  "geo" : {
  },
  "id_str" : "203464106068557824",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill oh mannn, I tried to join but woke up at 7:20. now I'm more glad I didn't actually",
  "id" : 203464106068557824,
  "in_reply_to_status_id" : 203456128678498305,
  "created_at" : "Fri May 18 12:36:37 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4860188667, -73.20847545 ]
  },
  "id_str" : "203303699576135681",
  "text" : "beer, bread, and pasta w Boves sauce is what I call post ride recovery.",
  "id" : 203303699576135681,
  "created_at" : "Fri May 18 01:59:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203243786208423936/photo/1",
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/Ka4ui1Zu",
      "media_url" : "http://pbs.twimg.com/media/AtIRJZACMAA-Cgg.jpg",
      "id_str" : "203243786212618240",
      "id" : 203243786212618240,
      "media_url_https" : "https://pbs.twimg.com/media/AtIRJZACMAA-Cgg.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Ka4ui1Zu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2778907333, -73.21740635 ]
  },
  "id_str" : "203243786208423936",
  "text" : "w Kameron and friend! http://t.co/Ka4ui1Zu",
  "id" : 203243786208423936,
  "created_at" : "Thu May 17 22:01:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203147863952338945",
  "text" : "back to the pool after a 1.5wk hiatus",
  "id" : 203147863952338945,
  "created_at" : "Thu May 17 15:39:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Performance Bicycle",
      "screen_name" : "performance_inc",
      "indices" : [ 3, 19 ],
      "id_str" : "115143004",
      "id" : 115143004
    }, {
      "name" : "USA Pro Challenge",
      "screen_name" : "USAProChallenge",
      "indices" : [ 43, 59 ],
      "id_str" : "175525187",
      "id" : 175525187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BikeMonth",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203144511868780544",
  "text" : "RT @performance_inc: We are! #BikeMonth RT @usaprochallenge: Tomorrow is National Bike to Work Day. Are you going to ride to work? http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA Pro Challenge",
        "screen_name" : "USAProChallenge",
        "indices" : [ 22, 38 ],
        "id_str" : "175525187",
        "id" : 175525187
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BikeMonth",
        "indices" : [ 8, 18 ]
      }, {
        "text" : "USAPRO",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/uZCsMpyH",
        "expanded_url" : "http://ow.ly/aXnID",
        "display_url" : "ow.ly/aXnID"
      } ]
    },
    "geo" : {
    },
    "id_str" : "203126599552483329",
    "text" : "We are! #BikeMonth RT @usaprochallenge: Tomorrow is National Bike to Work Day. Are you going to ride to work? http://t.co/uZCsMpyH #USAPRO",
    "id" : 203126599552483329,
    "created_at" : "Thu May 17 14:15:29 +0000 2012",
    "user" : {
      "name" : "Performance Bicycle",
      "screen_name" : "performancebike",
      "protected" : false,
      "id_str" : "47428569",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2166665868/performance_bicycles_logo_normal.jpg",
      "id" : 47428569,
      "verified" : false
    }
  },
  "id" : 203144511868780544,
  "created_at" : "Thu May 17 15:26:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "203143720713981953",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 hope the drive is going well! really enjoyed your visit.",
  "id" : 203143720713981953,
  "created_at" : "Thu May 17 15:23:31 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203121983158894593/photo/1",
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/aAAkLX4r",
      "media_url" : "http://pbs.twimg.com/media/AtGiXhSCQAA0lzd.jpg",
      "id_str" : "203121983163088896",
      "id" : 203121983163088896,
      "media_url_https" : "https://pbs.twimg.com/media/AtGiXhSCQAA0lzd.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/aAAkLX4r"
    } ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792322, -73.2066187 ]
  },
  "id_str" : "203121983158894593",
  "text" : "uncommon grounds maple scone #yum http://t.co/aAAkLX4r",
  "id" : 203121983158894593,
  "created_at" : "Thu May 17 13:57:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/203117465302081537/photo/1",
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/cQ77HlqW",
      "media_url" : "http://pbs.twimg.com/media/AtGeQi9CIAA4QQ6.jpg",
      "id_str" : "203117465306275840",
      "id" : 203117465306275840,
      "media_url_https" : "https://pbs.twimg.com/media/AtGeQi9CIAA4QQ6.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/cQ77HlqW"
    } ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792322, -73.2066187 ]
  },
  "id_str" : "203117465302081537",
  "text" : "uncommon grounds maple scone #yum http://t.co/cQ77HlqW",
  "id" : 203117465302081537,
  "created_at" : "Thu May 17 13:39:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gross",
      "indices" : [ 9, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202852742643990528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.491525, -73.1904802 ]
  },
  "id_str" : "202869423734927360",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn #gross",
  "id" : 202869423734927360,
  "in_reply_to_status_id" : 202852742643990528,
  "created_at" : "Wed May 16 21:13:34 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/202863186960056323/photo/1",
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/myblduca",
      "media_url" : "http://pbs.twimg.com/media/AtC2_mUCAAE9uSA.jpg",
      "id_str" : "202863186964250625",
      "id" : 202863186964250625,
      "media_url_https" : "https://pbs.twimg.com/media/AtC2_mUCAAE9uSA.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/myblduca"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4712474667, -73.1876313667 ]
  },
  "id_str" : "202863186960056323",
  "text" : "look who's driving http://t.co/myblduca",
  "id" : 202863186960056323,
  "created_at" : "Wed May 16 20:48:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/202845834537218048/photo/1",
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/2rLDd6CX",
      "media_url" : "http://pbs.twimg.com/media/AtCnNjgCMAASBAM.jpg",
      "id_str" : "202845834541412352",
      "id" : 202845834541412352,
      "media_url_https" : "https://pbs.twimg.com/media/AtCnNjgCMAASBAM.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/2rLDd6CX"
    } ],
    "hashtags" : [ {
      "text" : "agreed",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3402168, -72.7516407 ]
  },
  "id_str" : "202845834537218048",
  "text" : "#agreed http://t.co/2rLDd6CX",
  "id" : 202845834537218048,
  "created_at" : "Wed May 16 19:39:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 3, 10 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 38, 49 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/9geuFh15",
      "expanded_url" : "http://twitter.com/rkay21/status/202836531029884929/photo/1",
      "display_url" : "pic.twitter.com/9geuFh15"
    } ]
  },
  "geo" : {
  },
  "id_str" : "202845547575521280",
  "text" : "RT @rkay21: Ben and jerry's tour with @andyreagan http://t.co/9geuFh15",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 26, 37 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/rkay21/status/202836531029884929/photo/1",
        "indices" : [ 38, 58 ],
        "url" : "http://t.co/9geuFh15",
        "media_url" : "http://pbs.twimg.com/media/AtCewBPCQAIh1wK.jpg",
        "id_str" : "202836531034079234",
        "id" : 202836531034079234,
        "media_url_https" : "https://pbs.twimg.com/media/AtCewBPCQAIh1wK.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1456,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com/9geuFh15"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "202836531029884929",
    "text" : "Ben and jerry's tour with @andyreagan http://t.co/9geuFh15",
    "id" : 202836531029884929,
    "created_at" : "Wed May 16 19:02:53 +0000 2012",
    "user" : {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "protected" : false,
      "id_str" : "46970249",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1555179811/IMG_5798_normal.jpeg",
      "id" : 46970249,
      "verified" : false
    }
  },
  "id" : 202845547575521280,
  "created_at" : "Wed May 16 19:38:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 3, 10 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 96, 107 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Catherine Markesich",
      "screen_name" : "cmarkesich",
      "indices" : [ 108, 119 ],
      "id_str" : "61633923",
      "id" : 61633923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "202750354998312960",
  "text" : "RT @ttmill: nothing like some quality Depot reps to start the day off right. thanks for joining @andyreagan @cmarkesich",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 84, 95 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Catherine Markesich",
        "screen_name" : "cmarkesich",
        "indices" : [ 96, 107 ],
        "id_str" : "61633923",
        "id" : 61633923
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "202738632057036802",
    "text" : "nothing like some quality Depot reps to start the day off right. thanks for joining @andyreagan @cmarkesich",
    "id" : 202738632057036802,
    "created_at" : "Wed May 16 12:33:51 +0000 2012",
    "user" : {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "protected" : false,
      "id_str" : "549461514",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2249653724/BIKE3_normal.jpg",
      "id" : 549461514,
      "verified" : false
    }
  },
  "id" : 202750354998312960,
  "created_at" : "Wed May 16 13:20:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 29, 36 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlyfe",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4789406, -73.2009187 ]
  },
  "id_str" : "202750304469524480",
  "text" : "solid 7AM Depot St repeats w @ttmill pushin me! followed up w an \"over hard omlette\" and homemade bread toast #goodlyfe",
  "id" : 202750304469524480,
  "created_at" : "Wed May 16 13:20:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4769690667, -73.2190851 ]
  },
  "id_str" : "202144411411419136",
  "text" : "made it to Burlington, and saw a guy fiddling w his road bike... not even one of his chainring bolts was remotely tightened! He's good now!",
  "id" : 202144411411419136,
  "created_at" : "Mon May 14 21:12:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 39, 50 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 52, 61 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 64, 75 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 95, 104 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 133, 140 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0007277833, -76.14285475 ]
  },
  "id_str" : "202058225258999809",
  "text" : "after an excellent night on the hill w @skholden17, @DKnick88 + @kreagannet, and run this AM w @dmreagan, I'm headed to #btv 2 greet @rkay21",
  "id" : 202058225258999809,
  "created_at" : "Mon May 14 15:30:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201829440106405889/photo/1",
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/Tzg5MMNy",
      "media_url" : "http://pbs.twimg.com/media/As0KznMCIAMHOQ2.jpg",
      "id_str" : "201829440110600195",
      "id" : 201829440110600195,
      "media_url_https" : "https://pbs.twimg.com/media/As0KznMCIAMHOQ2.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Tzg5MMNy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98025285, -76.3049284333 ]
  },
  "id_str" : "201829440106405889",
  "text" : "best part of being home is quite possibly the food! sweet potatoes and speedies http://t.co/Tzg5MMNy",
  "id" : 201829440106405889,
  "created_at" : "Mon May 14 00:21:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 30, 41 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201795637707145216/photo/1",
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/fINg0oHM",
      "media_url" : "http://pbs.twimg.com/media/AszsEDcCAAEz3KD.jpg",
      "id_str" : "201795637711339521",
      "id" : 201795637711339521,
      "media_url_https" : "https://pbs.twimg.com/media/AszsEDcCAAEz3KD.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/fINg0oHM"
    } ],
    "hashtags" : [ {
      "text" : "SULax",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0360014, -76.1349842 ]
  },
  "id_str" : "201795637707145216",
  "text" : "#SULax takes the win 15-5 and @skholden17 was signing autographs! http://t.co/fINg0oHM",
  "id" : 201795637707145216,
  "created_at" : "Sun May 13 22:06:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 13, 24 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SULax",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0357026833, -76.1366934167 ]
  },
  "id_str" : "201788113784274944",
  "text" : "another from @skholden17 and it's not looking good for Dartmouth. 10-4 with 8:50 left #SULax",
  "id" : 201788113784274944,
  "created_at" : "Sun May 13 21:36:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 34, 45 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SULax",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0359665167, -76.1366478833 ]
  },
  "id_str" : "201786556766359554",
  "text" : "three more goals and another from @skholden17 putting SU up 8-4! #SULax",
  "id" : 201786556766359554,
  "created_at" : "Sun May 13 21:30:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 1, 12 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SULax",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0358699833, -76.1369995 ]
  },
  "id_str" : "201781352788537344",
  "text" : ".@skholden17 with another unassisted goal!! 4-3 Cuse. #SULax",
  "id" : 201781352788537344,
  "created_at" : "Sun May 13 21:09:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 19, 30 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SULax",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0360616333, -76.1363792667 ]
  },
  "id_str" : "201776654341783552",
  "text" : "third SU goal from @skholden17! 3-3 at half #SULax",
  "id" : 201776654341783552,
  "created_at" : "Sun May 13 20:51:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 1, 12 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201768336953049090/photo/1",
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/0ogT3vl5",
      "media_url" : "http://pbs.twimg.com/media/AszTO8NCAAAdnBm.jpg",
      "id_str" : "201768336957243392",
      "id" : 201768336957243392,
      "media_url_https" : "https://pbs.twimg.com/media/AszTO8NCAAAdnBm.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/0ogT3vl5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.03585925, -76.1364578167 ]
  },
  "id_str" : "201768336953049090",
  "text" : ".@skholden17 with the ball!! http://t.co/0ogT3vl5",
  "id" : 201768336953049090,
  "created_at" : "Sun May 13 20:18:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/JC6kc5c6",
      "expanded_url" : "http://4sq.com/JSvz5e",
      "display_url" : "4sq.com/JSvz5e"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.985218287, -76.2957918063 ]
  },
  "id_str" : "201706595401478146",
  "text" : "hommme for the day! (@ Marcellus, NY) http://t.co/JC6kc5c6",
  "id" : 201706595401478146,
  "created_at" : "Sun May 13 16:12:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/gk5QfaO1",
      "expanded_url" : "http://twitter.com/DZdan1/status/201675569539186690/photo/1",
      "display_url" : "pic.twitter.com/gk5QfaO1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "201691806629507072",
  "text" : "RT @DZdan1: Otto's trip to Burlington...the next chapter in the life of our mystery ottoman http://t.co/gk5QfaO1",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/DZdan1/status/201675569539186690/photo/1",
        "indices" : [ 80, 100 ],
        "url" : "http://t.co/gk5QfaO1",
        "media_url" : "http://pbs.twimg.com/media/Asx-3KrCAAEeoMC.jpg",
        "id_str" : "201675569547575297",
        "id" : 201675569547575297,
        "media_url_https" : "https://pbs.twimg.com/media/Asx-3KrCAAEeoMC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/gk5QfaO1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "201675569539186690",
    "text" : "Otto's trip to Burlington...the next chapter in the life of our mystery ottoman http://t.co/gk5QfaO1",
    "id" : 201675569539186690,
    "created_at" : "Sun May 13 14:09:38 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 201691806629507072,
  "created_at" : "Sun May 13 15:14:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 52, 61 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201494971025596419",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2097510667, -77.9558983167 ]
  },
  "id_str" : "201497538698813441",
  "in_reply_to_user_id" : 361592148,
  "text" : "@3TriDRHECK I expect a staff at least the height of @Run_Rudy",
  "id" : 201497538698813441,
  "in_reply_to_status_id" : 201494971025596419,
  "created_at" : "Sun May 13 02:22:11 +0000 2012",
  "in_reply_to_screen_name" : "DREK_3",
  "in_reply_to_user_id_str" : "361592148",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201497016621207553/photo/1",
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/a9AmATV8",
      "media_url" : "http://pbs.twimg.com/media/AsvceBOCEAA3fOD.jpg",
      "id_str" : "201497016629596160",
      "id" : 201497016629596160,
      "media_url_https" : "https://pbs.twimg.com/media/AsvceBOCEAA3fOD.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/a9AmATV8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2097864333, -77.9557799167 ]
  },
  "id_str" : "201497016621207553",
  "text" : "my new best friend, I've been honored to carry on the tradition of Otto the Ottoman http://t.co/a9AmATV8",
  "id" : 201497016621207553,
  "created_at" : "Sun May 13 02:20:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201374830921121792/photo/1",
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/47A1S2AR",
      "media_url" : "http://pbs.twimg.com/media/AsttV4ACAAE4VBb.jpg",
      "id_str" : "201374830925316097",
      "id" : 201374830925316097,
      "media_url_https" : "https://pbs.twimg.com/media/AsttV4ACAAE4VBb.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/47A1S2AR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2065265167, -77.9521700333 ]
  },
  "id_str" : "201374830921121792",
  "text" : "walking across the stage! http://t.co/47A1S2AR",
  "id" : 201374830921121792,
  "created_at" : "Sat May 12 18:14:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201364689635119104/photo/1",
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/dQOO4it4",
      "media_url" : "http://pbs.twimg.com/media/AstkHkxCEAE4ACI.jpg",
      "id_str" : "201364689639313409",
      "id" : 201364689639313409,
      "media_url_https" : "https://pbs.twimg.com/media/AstkHkxCEAE4ACI.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/dQOO4it4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2065211667, -77.9522252 ]
  },
  "id_str" : "201364689635119104",
  "text" : "Senator Charles Schumer says \"go for it!\" and now from Dr Stuart Krieger, Brockport class of 73 http://t.co/dQOO4it4",
  "id" : 201364689635119104,
  "created_at" : "Sat May 12 17:34:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 29, 36 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 37, 44 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 45, 58 ],
      "id_str" : "285218603",
      "id" : 285218603
    }, {
      "name" : "Kevin Perry",
      "screen_name" : "Kevin_Perry12",
      "indices" : [ 59, 73 ],
      "id_str" : "374679730",
      "id" : 374679730
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201352829728858112/photo/1",
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/wQ4qEyIf",
      "media_url" : "http://pbs.twimg.com/media/AstZVPLCIAArzYI.jpg",
      "id_str" : "201352829733052416",
      "id" : 201352829733052416,
      "media_url_https" : "https://pbs.twimg.com/media/AstZVPLCIAArzYI.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/wQ4qEyIf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2065824667, -77.9522877833 ]
  },
  "id_str" : "201352829728858112",
  "text" : "and here come the graduates! @sspis1 @DZdan1 @EStoeckeler4 @Kevin_Perry12 http://t.co/wQ4qEyIf",
  "id" : 201352829728858112,
  "created_at" : "Sat May 12 16:47:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/201350388765569024/photo/1",
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/L8S0vDyX",
      "media_url" : "http://pbs.twimg.com/media/AstXHJ4CMAAYCXV.jpg",
      "id_str" : "201350388769763328",
      "id" : 201350388769763328,
      "media_url_https" : "https://pbs.twimg.com/media/AstXHJ4CMAAYCXV.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/L8S0vDyX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2065989333, -77.9522852167 ]
  },
  "id_str" : "201350388765569024",
  "text" : "SUNY Brockport graduation! http://t.co/L8S0vDyX",
  "id" : 201350388765569024,
  "created_at" : "Sat May 12 16:37:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/gvfJkkg1",
      "expanded_url" : "http://4sq.com/IPlzIC",
      "display_url" : "4sq.com/IPlzIC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2159902491, -77.9383948664 ]
  },
  "id_str" : "201181678226509824",
  "text" : "I'm at Barbers Grill And Taproom (Brockport, NY) http://t.co/gvfJkkg1",
  "id" : 201181678226509824,
  "created_at" : "Sat May 12 05:27:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.227071, -77.9246937 ]
  },
  "id_str" : "201179888860925952",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 get your ass to barbers kid",
  "id" : 201179888860925952,
  "created_at" : "Sat May 12 05:19:57 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 126, 140 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786833, -73.2010843 ]
  },
  "id_str" : "201009079408267264",
  "text" : "now at \"Computational Cultural Evolution: A Tale of Two Studies\" by Dan Rockmore from Darmouth College and Sante Fe Institute @uvmcomplexity",
  "id" : 201009079408267264,
  "created_at" : "Fri May 11 18:01:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786833, -73.2010843 ]
  },
  "id_str" : "201007606318366722",
  "text" : "ate lunch w Dan Rockmore then met with Dr Yang and got offered to turn my term project into a thesis w Eric! ballinnn! hard work payin off",
  "id" : 201007606318366722,
  "created_at" : "Fri May 11 17:55:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roguewaves",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "nonlinearPDE",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4786833, -73.2010843 ]
  },
  "id_str" : "200965460613791747",
  "text" : "presentation nailed! #roguewaves #nonlinearPDE done for the semester",
  "id" : 200965460613791747,
  "created_at" : "Fri May 11 15:07:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adventure",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4860014167, -73.2084026 ]
  },
  "id_str" : "200824652275253248",
  "text" : "adding excitement to my life, I need to move out on May 26 but cant move in until June 1, when I should already be en route to VA #adventure",
  "id" : 200824652275253248,
  "created_at" : "Fri May 11 05:48:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 106, 119 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "gradschool",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4990142, -73.2014572 ]
  },
  "id_str" : "200824134190632961",
  "text" : "oh the things I missed... could have been building a bike trailer bar to awe the #storylab and partying w @uvmtriathlon. thats #gradschool",
  "id" : 200824134190632961,
  "created_at" : "Fri May 11 05:46:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/200823456084922369/photo/1",
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/IuwVC2k4",
      "media_url" : "http://pbs.twimg.com/media/Asl33orCEAAkgVq.png",
      "id_str" : "200823456089116672",
      "id" : 200823456089116672,
      "media_url_https" : "https://pbs.twimg.com/media/Asl33orCEAAkgVq.png",
      "sizes" : [ {
        "h" : 634,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/IuwVC2k4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859591, -73.2085028333 ]
  },
  "id_str" : "200823456084922369",
  "text" : "spent from noon-1AM today working on PDE term paper, on rogue waves. a third order wave sol'n 4 your viewing pleasure: http://t.co/IuwVC2k4",
  "id" : 200823456084922369,
  "created_at" : "Fri May 11 05:43:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/200760821272416258/photo/1",
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/3dgOYBnH",
      "media_url" : "http://pbs.twimg.com/media/Ask-5z1CEAAniYm.jpg",
      "id_str" : "200760821280804864",
      "id" : 200760821280804864,
      "media_url_https" : "https://pbs.twimg.com/media/Ask-5z1CEAAniYm.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/3dgOYBnH"
    } ],
    "hashtags" : [ {
      "text" : "noanswersinthebottom",
      "indices" : [ 42, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.479113, -73.2064773 ]
  },
  "id_str" : "200760821272416258",
  "text" : "a goodbye to the last late homework night #noanswersinthebottom? http://t.co/3dgOYBnH",
  "id" : 200760821272416258,
  "created_at" : "Fri May 11 01:34:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Tock",
      "screen_name" : "tick3tock3",
      "indices" : [ 0, 11 ],
      "id_str" : "223308471",
      "id" : 223308471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48594195, -73.2084149 ]
  },
  "id_str" : "200435341163896832",
  "in_reply_to_user_id" : 223308471,
  "text" : "@tick3tock3 happy birthday kiddo!!",
  "id" : 200435341163896832,
  "created_at" : "Thu May 10 04:01:23 +0000 2012",
  "in_reply_to_screen_name" : "tick3tock3",
  "in_reply_to_user_id_str" : "223308471",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48594245, -73.2084515833 ]
  },
  "id_str" : "200434752103260160",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 not fairrr, he could come to vermonnnt. PS I think you tweeted at me from the wrong twitter account earlier :-O",
  "id" : 200434752103260160,
  "created_at" : "Thu May 10 03:59:03 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/200381492323557376/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/57mQjudb",
      "media_url" : "http://pbs.twimg.com/media/Asfl59XCIAAEM_S.jpg",
      "id_str" : "200381492327751680",
      "id" : 200381492327751680,
      "media_url_https" : "https://pbs.twimg.com/media/Asfl59XCIAAEM_S.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/57mQjudb"
    } ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.41220045, -73.20449455 ]
  },
  "id_str" : "200381492323557376",
  "text" : "discovered #storylab http://t.co/57mQjudb",
  "id" : 200381492323557376,
  "created_at" : "Thu May 10 00:27:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 39, 51 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4121155833, -73.2044200333 ]
  },
  "id_str" : "200380012082376705",
  "text" : "the balmer's peak is no myth #storylab @mrfrank5790",
  "id" : 200380012082376705,
  "created_at" : "Thu May 10 00:21:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.41218735, -73.2045751833 ]
  },
  "id_str" : "200355600813658113",
  "text" : "a turn of events at the #storylab bbq, a comedy show from Bill!",
  "id" : 200355600813658113,
  "created_at" : "Wed May 09 22:44:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/200310688135135232/photo/1",
      "indices" : [ 11, 31 ],
      "url" : "http://t.co/LunD76rN",
      "media_url" : "http://pbs.twimg.com/media/AselgnNCQAEFhNR.jpg",
      "id_str" : "200310688139329537",
      "id" : 200310688139329537,
      "media_url_https" : "https://pbs.twimg.com/media/AselgnNCQAEFhNR.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LunD76rN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "200310688135135232",
  "text" : "party time http://t.co/LunD76rN",
  "id" : 200310688135135232,
  "created_at" : "Wed May 09 19:46:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199990229623521282",
  "geo" : {
  },
  "id_str" : "199992466995298304",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill mhmmmmmm",
  "id" : 199992466995298304,
  "in_reply_to_status_id" : 199990229623521282,
  "created_at" : "Tue May 08 22:41:34 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strava",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "199988544071155712",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill yo you've got two separate #strava workouts for the same run, one faster than the other??",
  "id" : 199988544071155712,
  "created_at" : "Tue May 08 22:25:59 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 71, 78 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strava",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/5GhBjHA5",
      "expanded_url" : "http://app.strava.com/runs/8142912",
      "display_url" : "app.strava.com/runs/8142912"
    } ]
  },
  "geo" : {
  },
  "id_str" : "199988401175408641",
  "text" : "short run in the rain, tried to steal the Depot St #strava record from @ttmill but something's fishy w travis's garmin http://t.co/5GhBjHA5",
  "id" : 199988401175408641,
  "created_at" : "Tue May 08 22:25:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48585415, -73.2082245167 ]
  },
  "id_str" : "199934932833939457",
  "text" : "has now eaten 15 pounds of carrots this year...but I still hate the taste plain. personal experiment failing",
  "id" : 199934932833939457,
  "created_at" : "Tue May 08 18:52:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "199676391711719424",
  "text" : "\"if aliens saw people wake up grudgingly every morning to a beeping alarm clock, they might wonder who is the master and who is the tool\"",
  "id" : 199676391711719424,
  "created_at" : "Tue May 08 01:45:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 14, 28 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/BIoN48uq",
      "expanded_url" : "http://farmerandfarmer.org/medicine/index.html",
      "display_url" : "farmerandfarmer.org/medicine/index…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "199675215649849344",
  "text" : "great read MT @ChrisDanforth Jonathan Harris ask whether software or humanity drives evolution these days: http://t.co/BIoN48uq",
  "id" : 199675215649849344,
  "created_at" : "Tue May 08 01:40:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199656338190643202",
  "geo" : {
  },
  "id_str" : "199674499854110720",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 you look old w that beard!!",
  "id" : 199674499854110720,
  "in_reply_to_status_id" : 199656338190643202,
  "created_at" : "Tue May 08 01:38:05 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 17, 24 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 25, 38 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/199255367677509632/photo/1",
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/JcBvbxjV",
      "media_url" : "http://pbs.twimg.com/media/AsPls4JCAAAhxRC.jpg",
      "id_str" : "199255367681703936",
      "id" : 199255367681703936,
      "media_url_https" : "https://pbs.twimg.com/media/AsPls4JCAAAhxRC.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/JcBvbxjV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4861256333, -73.2084227167 ]
  },
  "id_str" : "199255367677509632",
  "text" : "excellent ride w @ttmill @dabrownnoise Emily, Chris W, Mike R, and Andrew C! http://t.co/JcBvbxjV",
  "id" : 199255367677509632,
  "created_at" : "Sun May 06 21:52:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199253771061178368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4861391833, -73.20856845 ]
  },
  "id_str" : "199254785617170433",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill indeed you do sir. get that sh*t on strava and tweet it out so I can RT that biz. PS can you email me the data file?",
  "id" : 199254785617170433,
  "in_reply_to_status_id" : 199253771061178368,
  "created_at" : "Sun May 06 21:50:17 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199148669059088384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859490833, -73.20837025 ]
  },
  "id_str" : "199159014964207618",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill how about...first one to the top of app gap gets to keep the medal?",
  "id" : 199159014964207618,
  "in_reply_to_status_id" : 199148669059088384,
  "created_at" : "Sun May 06 15:29:44 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48605245, -73.20833395 ]
  },
  "id_str" : "199145512664956928",
  "in_reply_to_user_id" : 16174144,
  "text" : "@peterdodds I saw your time from the half yesterday, awesome run! I'm thinking good thing I didnt sign up, I woulda been eating your dust!!",
  "id" : 199145512664956928,
  "created_at" : "Sun May 06 14:36:04 +0000 2012",
  "in_reply_to_screen_name" : "peterdodds",
  "in_reply_to_user_id_str" : "16174144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 10, 19 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Fleet Feet Sports",
      "screen_name" : "FleetFeetSYR",
      "indices" : [ 42, 55 ],
      "id_str" : "21203615",
      "id" : 21203615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MountainGoatRun",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/zi5d3gMu",
      "expanded_url" : "http://ow.ly/i/BOAK",
      "display_url" : "ow.ly/i/BOAK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4860531333, -73.2082758667 ]
  },
  "id_str" : "199143960051056641",
  "text" : "good luck @dmreagan! (if youre running!) \"@FleetFeetSYR: http://t.co/zi5d3gMu Let the race begin! #MountainGoatRun\"",
  "id" : 199143960051056641,
  "created_at" : "Sun May 06 14:29:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859022333, -73.2083516833 ]
  },
  "id_str" : "199143552779960320",
  "text" : "getting amped for my first shot at climbing the App Gap today! huge breakfast and polishing my ride",
  "id" : 199143552779960320,
  "created_at" : "Sun May 06 14:28:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Davis",
      "screen_name" : "gforceben",
      "indices" : [ 0, 10 ],
      "id_str" : "25156787",
      "id" : 25156787
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 35, 47 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198929918103527424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4711643, -73.1906475333 ]
  },
  "id_str" : "198939251520442370",
  "in_reply_to_user_id" : 25156787,
  "text" : "@gforceben thanks for the stream!! @UVM_cycling peeps at home were watching!",
  "id" : 198939251520442370,
  "in_reply_to_status_id" : 198929918103527424,
  "created_at" : "Sun May 06 00:56:28 +0000 2012",
  "in_reply_to_screen_name" : "gforceben",
  "in_reply_to_user_id_str" : "25156787",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198938755497865216/photo/1",
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/6AEDwDue",
      "media_url" : "http://pbs.twimg.com/media/AsLFvn3CMAAYri_.jpg",
      "id_str" : "198938755502059520",
      "id" : 198938755502059520,
      "media_url_https" : "https://pbs.twimg.com/media/AsLFvn3CMAAYri_.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/6AEDwDue"
    } ],
    "hashtags" : [ {
      "text" : "classic",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.471161, -73.19065715 ]
  },
  "id_str" : "198938755497865216",
  "text" : "#classic http://t.co/6AEDwDue",
  "id" : 198938755497865216,
  "created_at" : "Sun May 06 00:54:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198869240407793664/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/BGaFlbI8",
      "media_url" : "http://pbs.twimg.com/media/AsKGhT-CIAA2nJn.jpg",
      "id_str" : "198869240411987968",
      "id" : 198869240411987968,
      "media_url_https" : "https://pbs.twimg.com/media/AsKGhT-CIAA2nJn.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/BGaFlbI8"
    } ],
    "hashtags" : [ {
      "text" : "cincodemayo",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4711244167, -73.1907829333 ]
  },
  "id_str" : "198869240407793664",
  "text" : "perfect #cincodemayo http://t.co/BGaFlbI8",
  "id" : 198869240407793664,
  "created_at" : "Sat May 05 20:18:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48598145, -73.2083972 ]
  },
  "id_str" : "198848043573985280",
  "text" : "at this rate, someday I'm going to try catch someone running that is way too fast and blow up",
  "id" : 198848043573985280,
  "created_at" : "Sat May 05 18:54:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859563167, -73.2084067 ]
  },
  "id_str" : "198636762313146368",
  "text" : "well that was it for the previously failed to send tweets, there were more but all the pictures were wrong...strange",
  "id" : 198636762313146368,
  "created_at" : "Sat May 05 04:54:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 68, 75 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198634539147460608/photo/1",
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/ytLrkecz",
      "media_url" : "http://pbs.twimg.com/media/AsGxD5qCAAA2mpf.jpg",
      "id_str" : "198634539155849216",
      "id" : 198634539155849216,
      "media_url_https" : "https://pbs.twimg.com/media/AsGxD5qCAAA2mpf.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ytLrkecz"
    } ],
    "hashtags" : [ {
      "text" : "sendingoldfailedtouploadtweets",
      "indices" : [ 0, 31 ]
    }, {
      "text" : "eggsinabasket",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859618167, -73.2084090167 ]
  },
  "id_str" : "198634539147460608",
  "text" : "#sendingoldfailedtouploadtweets 5th day in a row for #eggsinabasket @sspis1 http://t.co/ytLrkecz",
  "id" : 198634539147460608,
  "created_at" : "Sat May 05 04:45:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859707667, -73.2084195167 ]
  },
  "id_str" : "198633054993002497",
  "text" : "just notched 5K tweets! also since it's an obscure hour...about to unload the drafts folder. here comes some randomness",
  "id" : 198633054993002497,
  "created_at" : "Sat May 05 04:39:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 21, 28 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859669, -73.20842335 ]
  },
  "id_str" : "198632473108815874",
  "text" : "chill night hangin w @ttmill and some brews...seriously lacking a front porch for another month though",
  "id" : 198632473108815874,
  "created_at" : "Sat May 05 04:37:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 83, 97 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4860334167, -73.2084786333 ]
  },
  "id_str" : "198560460591730688",
  "text" : "plan \"learning to swim fast\" is going swimmingly, as was my first 1.5 miles in the @brooksrunning Pure Flows!",
  "id" : 198560460591730688,
  "created_at" : "Fri May 04 23:51:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howamericafails",
      "indices" : [ 13, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198557311416012800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4911404, -73.1891118 ]
  },
  "id_str" : "198559939797594112",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw #howamericafails",
  "id" : 198559939797594112,
  "in_reply_to_status_id" : 198557311416012800,
  "created_at" : "Fri May 04 23:49:13 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198522653135486976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4911404, -73.1891118 ]
  },
  "id_str" : "198559458304069632",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn sweet! thats 18.5 miles further than I ran today... shelburne half tomorrow?",
  "id" : 198559458304069632,
  "in_reply_to_status_id" : 198522653135486976,
  "created_at" : "Fri May 04 23:47:18 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198474803831779328/photo/1",
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/X9v1Z93I",
      "media_url" : "http://pbs.twimg.com/media/AsEfyFOCMAAn0Dp.jpg",
      "id_str" : "198474803835973632",
      "id" : 198474803835973632,
      "media_url_https" : "https://pbs.twimg.com/media/AsEfyFOCMAAn0Dp.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/X9v1Z93I"
    } ],
    "hashtags" : [ {
      "text" : "OpenFOAM",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4849107, -73.1950773 ]
  },
  "id_str" : "198474803831779328",
  "text" : "#OpenFOAM master status http://t.co/X9v1Z93I",
  "id" : 198474803831779328,
  "created_at" : "Fri May 04 18:10:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/BWKqfQxO",
      "expanded_url" : "http://a5.sphotos.ak.fbcdn.net/hphotos-ak-ash3/528596_917179273224_307758_37892340_1120488307_n.jpg",
      "display_url" : "a5.sphotos.ak.fbcdn.net/hphotos-ak-ash…"
    } ]
  },
  "in_reply_to_status_id_str" : "198283387184754688",
  "geo" : {
  },
  "id_str" : "198408151693926400",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo mullet. inspiration: http://t.co/BWKqfQxO",
  "id" : 198408151693926400,
  "in_reply_to_status_id" : 198283387184754688,
  "created_at" : "Fri May 04 13:46:04 +0000 2012",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198407623647838209",
  "text" : "is *now* officially a math grad at UVM: for Prof Foote to hand back my homework, I got my own mailbox!",
  "id" : 198407623647838209,
  "created_at" : "Fri May 04 13:43:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.478681, -73.2010428 ]
  },
  "id_str" : "198263134060937217",
  "text" : "the moment I hit send to email my last homework, a minute before the midnight deadline, it starts raining. and I'm at the office, can't win!",
  "id" : 198263134060937217,
  "created_at" : "Fri May 04 04:09:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 43, 52 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTV",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/A15GomSO",
      "expanded_url" : "http://bit.ly/KtsbvU",
      "display_url" : "bit.ly/KtsbvU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198145587416268801",
  "text" : "the great depths of the internet beware RT @dr_pyser burlington cats. just crying out for some lol captions. #BTV http://t.co/A15GomSO",
  "id" : 198145587416268801,
  "created_at" : "Thu May 03 20:22:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "indices" : [ 3, 16 ],
      "id_str" : "490982935",
      "id" : 490982935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198144772739842048",
  "text" : "RT @AlanHungover: Internet Explorer: The best browser for downloading another browser.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "198140412949569536",
    "text" : "Internet Explorer: The best browser for downloading another browser.",
    "id" : 198140412949569536,
    "created_at" : "Thu May 03 20:02:10 +0000 2012",
    "user" : {
      "name" : "Alan Garner",
      "screen_name" : "AlanHungover",
      "protected" : false,
      "id_str" : "490982935",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1825288290/gifsmall_normal.gif",
      "id" : 490982935,
      "verified" : false
    }
  },
  "id" : 198144772739842048,
  "created_at" : "Thu May 03 20:19:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198119371518906368/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/ly772iDI",
      "media_url" : "http://pbs.twimg.com/media/Ar_chMrCEAI_Spv.png",
      "id_str" : "198119371523100674",
      "id" : 198119371523100674,
      "media_url_https" : "https://pbs.twimg.com/media/Ar_chMrCEAI_Spv.png",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 462
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 462
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 462
      } ],
      "display_url" : "pic.twitter.com/ly772iDI"
    } ],
    "hashtags" : [ {
      "text" : "openFOAM",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198119371518906368",
  "text" : ".@dr_pyser and I have created the VORTEX OF AWESOME #openFOAM http://t.co/ly772iDI",
  "id" : 198119371518906368,
  "created_at" : "Thu May 03 18:38:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198103478554472449/photo/1",
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/viWRLejE",
      "media_url" : "http://pbs.twimg.com/media/Ar_OEGyCMAE5X5g.png",
      "id_str" : "198103478562861057",
      "id" : 198103478562861057,
      "media_url_https" : "https://pbs.twimg.com/media/Ar_OEGyCMAE5X5g.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/viWRLejE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198103478554472449",
  "text" : "aerodynamic simulation of a motorbike, now just to make this a fully faired recumbent bicycle... http://t.co/viWRLejE",
  "id" : 198103478554472449,
  "created_at" : "Thu May 03 17:35:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MOOTS",
      "screen_name" : "MOOTSCYCLES",
      "indices" : [ 33, 45 ],
      "id_str" : "71604171",
      "id" : 71604171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/3s47eksl",
      "expanded_url" : "http://moots.com/afternoon-ti/moots-demos-head-east/",
      "display_url" : "moots.com/afternoon-ti/m…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "198072605331292160",
  "text" : "if you're in Syr I'm jealous! MT @MOOTSCYCLES Demo Thursday with Syracuse Bicycle: Hope to see you there! http://t.co/3s47eksl",
  "id" : 198072605331292160,
  "created_at" : "Thu May 03 15:32:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198058399605342208",
  "text" : "beware of the bermuta triangle of particles...check your mesh quality controls twice",
  "id" : 198058399605342208,
  "created_at" : "Thu May 03 14:36:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/198057905533104129/photo/1",
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/qkf4Gvmo",
      "media_url" : "http://pbs.twimg.com/media/Ar-knaCCMAAmX-h.png",
      "id_str" : "198057905537298432",
      "id" : 198057905537298432,
      "media_url_https" : "https://pbs.twimg.com/media/Ar-knaCCMAAmX-h.png",
      "sizes" : [ {
        "h" : 302,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/qkf4Gvmo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "198057905533104129",
  "text" : "snappyHexMesh on a motorbike...I know that's you're to see on twitter http://t.co/qkf4Gvmo",
  "id" : 198057905533104129,
  "created_at" : "Thu May 03 14:34:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 0, 10 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197908858545512449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4790537, -73.206517 ]
  },
  "id_str" : "197925999025995776",
  "in_reply_to_user_id" : 528928681,
  "text" : "@jcusick13 you were indeed!!",
  "id" : 197925999025995776,
  "in_reply_to_status_id" : 197908858545512449,
  "created_at" : "Thu May 03 05:50:10 +0000 2012",
  "in_reply_to_screen_name" : "jcusick13",
  "in_reply_to_user_id_str" : "528928681",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4790537, -73.206517 ]
  },
  "id_str" : "197924821856817153",
  "text" : "NBR success. what a crazy night, and an awesome school. where else?",
  "id" : 197924821856817153,
  "created_at" : "Thu May 03 05:45:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197870859434737665/photo/1",
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/4Tw4MMtC",
      "media_url" : "http://pbs.twimg.com/media/Ar76f5BCQAEcmfT.png",
      "id_str" : "197870859438931969",
      "id" : 197870859438931969,
      "media_url_https" : "https://pbs.twimg.com/media/Ar76f5BCQAEcmfT.png",
      "sizes" : [ {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 1114
      } ],
      "display_url" : "pic.twitter.com/4Tw4MMtC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197870859434737665",
  "text" : "\"hey Andy what do you do in your complex analysis hw\" \"oh, just draw pictures\" http://t.co/4Tw4MMtC",
  "id" : 197870859434737665,
  "created_at" : "Thu May 03 02:11:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 13, 20 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 42, 54 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collnats",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "197791091163013121",
  "text" : "great ride w @ttmill, and safe travels to @UVM_cycling heading the #collnats",
  "id" : 197791091163013121,
  "created_at" : "Wed May 02 20:54:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 32, 39 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197745943293079552",
  "text" : "bike ride time!! been too long. @ttmill",
  "id" : 197745943293079552,
  "created_at" : "Wed May 02 17:54:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197467297823207424",
  "geo" : {
  },
  "id_str" : "197683106159927297",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr that's grossss",
  "id" : 197683106159927297,
  "in_reply_to_status_id" : 197467297823207424,
  "created_at" : "Wed May 02 13:44:59 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197464215534043137",
  "geo" : {
  },
  "id_str" : "197682999108706304",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr that would give away our disguise of normal clothes!",
  "id" : 197682999108706304,
  "in_reply_to_status_id" : 197464215534043137,
  "created_at" : "Wed May 02 13:44:34 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197682632291651588",
  "text" : "last complex analysis class :(",
  "id" : 197682632291651588,
  "created_at" : "Wed May 02 13:43:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M&M",
      "screen_name" : "MandyMarquardt",
      "indices" : [ 0, 15 ],
      "id_str" : "191883583",
      "id" : 191883583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/1HYeqqLt",
      "expanded_url" : "http://www.velominati.com/the-rules/",
      "display_url" : "velominati.com/the-rules/"
    } ]
  },
  "in_reply_to_status_id_str" : "197428281543376896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4910653, -73.2231756 ]
  },
  "id_str" : "197534151757402113",
  "in_reply_to_user_id" : 191883583,
  "text" : "@MandyMarquardt I'd like to refer you to rule 26 #justsayin http://t.co/1HYeqqLt",
  "id" : 197534151757402113,
  "in_reply_to_status_id" : 197428281543376896,
  "created_at" : "Wed May 02 03:53:06 +0000 2012",
  "in_reply_to_screen_name" : "MandyMarquardt",
  "in_reply_to_user_id_str" : "191883583",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 10, 21 ],
      "id_str" : "355569678",
      "id" : 355569678
    }, {
      "name" : "UVMtv",
      "screen_name" : "UVMtv",
      "indices" : [ 27, 33 ],
      "id_str" : "14330309",
      "id" : 14330309
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197532993009614849/photo/1",
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/j3SqGJcp",
      "media_url" : "http://pbs.twimg.com/media/Ar3HNegCAAECQVj.jpg",
      "id_str" : "197532993013809153",
      "id" : 197532993013809153,
      "media_url_https" : "https://pbs.twimg.com/media/Ar3HNegCAAECQVj.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/j3SqGJcp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "197532993009614849",
  "text" : "thanks to @erik_ryden (and @uvmtv) our freezer &gt; your freezer http://t.co/j3SqGJcp",
  "id" : 197532993009614849,
  "created_at" : "Wed May 02 03:48:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197532719054462977/photo/1",
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/zQLJDCmC",
      "media_url" : "http://pbs.twimg.com/media/Ar3G9h9CIAAPWKs.jpg",
      "id_str" : "197532719062851584",
      "id" : 197532719062851584,
      "media_url_https" : "https://pbs.twimg.com/media/Ar3G9h9CIAAPWKs.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/zQLJDCmC"
    } ],
    "hashtags" : [ {
      "text" : "sogood",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "197532719054462977",
  "text" : "since last june, I've made 88 loaves of bread (&gt;2/wk) and finished 1lb of yeast! #sogood http://t.co/zQLJDCmC",
  "id" : 197532719054462977,
  "created_at" : "Wed May 02 03:47:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "197531995780296704",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 looking good!",
  "id" : 197531995780296704,
  "created_at" : "Wed May 02 03:44:32 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 15, 26 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "加藤　かおる",
      "screen_name" : "sumadesu",
      "indices" : [ 87, 96 ],
      "id_str" : "171245284",
      "id" : 171245284
    }, {
      "name" : "Marie Frank",
      "screen_name" : "mmfrank",
      "indices" : [ 97, 105 ],
      "id_str" : "27631374",
      "id" : 27631374
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197481982068920320/photo/1",
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/rqv9yVhN",
      "media_url" : "http://pbs.twimg.com/media/Ar2Y0P8CEAAn5Ov.jpg",
      "id_str" : "197481982073114624",
      "id" : 197481982073114624,
      "media_url_https" : "https://pbs.twimg.com/media/Ar2Y0P8CEAAn5Ov.jpg",
      "sizes" : [ {
        "h" : 1296,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com/rqv9yVhN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4707741, -73.2102542 ]
  },
  "id_str" : "197481982068920320",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth @peterdodds you guys should join math trivia night, you'd fit right in! @sumadesu @mmfrank http://t.co/rqv9yVhN",
  "id" : 197481982068920320,
  "created_at" : "Wed May 02 00:25:49 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teammathgrad",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4707741, -73.2102542 ]
  },
  "id_str" : "197462817069207553",
  "text" : "#teammathgrad needs a new trivia team name... any math innuendos tweeps?",
  "id" : 197462817069207553,
  "created_at" : "Tue May 01 23:09:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanksups",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4707741, -73.2102542 ]
  },
  "id_str" : "197462528903745537",
  "text" : "bike finally arrived! icing on the $140 shipping...a $10 recieving charge #thanksups",
  "id" : 197462528903745537,
  "created_at" : "Tue May 01 23:08:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197358454459998208/photo/1",
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/cqoy6A6V",
      "media_url" : "http://pbs.twimg.com/media/Ar0od_vCIAEy5lB.png",
      "id_str" : "197358454464192513",
      "id" : 197358454464192513,
      "media_url_https" : "https://pbs.twimg.com/media/Ar0od_vCIAEy5lB.png",
      "sizes" : [ {
        "h" : 299,
        "resize" : "fit",
        "w" : 669
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 669
      } ],
      "display_url" : "pic.twitter.com/cqoy6A6V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197358454459998208",
  "text" : "here's a cooler looking one. flow from the left inlet, looking at magnitude of flow vector http://t.co/cqoy6A6V",
  "id" : 197358454459998208,
  "created_at" : "Tue May 01 16:14:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/197357478957166594/photo/1",
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/aSjFtDR0",
      "media_url" : "http://pbs.twimg.com/media/Ar0nlNtCMAE0OLP.png",
      "id_str" : "197357478961360897",
      "id" : 197357478961360897,
      "media_url_https" : "https://pbs.twimg.com/media/Ar0nlNtCMAE0OLP.png",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com/aSjFtDR0"
    } ],
    "hashtags" : [ {
      "text" : "OpenFOAM",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197357478957166594",
  "text" : "the second fluid flow example #OpenFOAM http://t.co/aSjFtDR0",
  "id" : 197357478957166594,
  "created_at" : "Tue May 01 16:11:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "197342734053425152",
  "text" : "administration at UVM trying to replace the naked bike ride with \"Activities Designed to Make Your Evening Fun!\" ...which will I attend?!?",
  "id" : 197342734053425152,
  "created_at" : "Tue May 01 15:12:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/5FpGQNn8",
      "expanded_url" : "http://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=0CDMQFjAA&url=http%3A%2F%2Fwww.openfoam.com%2F&ei=AOGfT6e7J8mY6AGD8syVAg&usg=AFQjCNEWtNQsnHMEtKoOpS-IY-G02B3nlA",
      "display_url" : "google.com/url?sa=t&rct=j…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "197312345297534977",
  "text" : "car moved back from garage from parking ban, breakfast made, and now learning OpenFOAM! http://t.co/5FpGQNn8",
  "id" : 197312345297534977,
  "created_at" : "Tue May 01 13:11:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]