Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86640729811714048",
  "text" : "although my 14 mile trail run nearly killed me today, I just signed up for the RIchmond Marathon on Nov 12th!!",
  "id" : 86640729811714048,
  "created_at" : "Fri Jul 01 03:42:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86602359521804288",
  "text" : "ouchy ouch ouch, my legs",
  "id" : 86602359521804288,
  "created_at" : "Fri Jul 01 01:09:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86558311108984832",
  "text" : "going for a long run! 14.5 miles on poverty creek trail hopefully",
  "id" : 86558311108984832,
  "created_at" : "Thu Jun 30 22:14:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "86547701201768448",
  "text" : "pre long run meal, so glad FFA is gone (@ Dietrick Dining Center) http://4sq.com/m7zAts",
  "id" : 86547701201768448,
  "created_at" : "Thu Jun 30 21:32:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86461659958353920",
  "text" : "why can't biologists figure out how IRP1 and IRP2 react to oxidative stress? different labs completely contradict eachother",
  "id" : 86461659958353920,
  "created_at" : "Thu Jun 30 15:50:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86256149917204482",
  "text" : "had an awesome (fast) 8mi run to Cburg for Coldstone! Close to 7min/mile the whole way, but the Garmin didn't transfer for the 1st time",
  "id" : 86256149917204482,
  "created_at" : "Thu Jun 30 02:14:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wednesday Worlds",
      "screen_name" : "wednesdayworlds",
      "indices" : [ 16, 32 ],
      "id_str" : "161035957",
      "id" : 161035957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86208289003675648",
  "text" : "No shifter = no @wednesdayworlds, but running to Cburg yes",
  "id" : 86208289003675648,
  "created_at" : "Wed Jun 29 23:03:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86126750676959232",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr \"i can't shove my fist in your childhood dreams\"",
  "id" : 86126750676959232,
  "created_at" : "Wed Jun 29 17:39:52 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85832336683450369",
  "geo" : {
  },
  "id_str" : "85835161987579905",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff sweet, thx!",
  "id" : 85835161987579905,
  "in_reply_to_status_id" : 85832336683450369,
  "created_at" : "Tue Jun 28 22:21:12 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85834598688362496",
  "text" : "got to best buy and had forgotten my gift card I went there to spend. Had that thing since last christmas haha its gonna live on",
  "id" : 85834598688362496,
  "created_at" : "Tue Jun 28 22:18:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85820319226544128",
  "text" : "lost that race to about 1000 of the FFA... so came home.",
  "id" : 85820319226544128,
  "created_at" : "Tue Jun 28 21:22:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 54, 63 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85812013774798848",
  "text" : "has to race 4000 future farmers of america to dinner, @jdbrunnr looks like you're not eatin",
  "id" : 85812013774798848,
  "created_at" : "Tue Jun 28 20:49:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 63, 72 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tauday",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85757653288108033",
  "text" : "\"unless i'm at the beach, i'd rather have two pi's than a tau\" @jdbrunnr #tauday",
  "id" : 85757653288108033,
  "created_at" : "Tue Jun 28 17:13:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 62, 71 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tauday",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85757574430998528",
  "text" : "\"unless i'm at the beach, i'd rather have to pi's than a tau\" @jdbrunnr #tauday",
  "id" : 85757574430998528,
  "created_at" : "Tue Jun 28 17:12:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85695731683430400",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff any idea if the blueberry picking is still going on?",
  "id" : 85695731683430400,
  "created_at" : "Tue Jun 28 13:07:09 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 3, 14 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85535115966562304",
  "text" : "RT @iamtedking: Which reminds me of this. http://youtu.be/bzE-IMaegzQ  Which is still as excellent as ever!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "85459551381504001",
    "text" : "Which reminds me of this. http://youtu.be/bzE-IMaegzQ  Which is still as excellent as ever!",
    "id" : 85459551381504001,
    "created_at" : "Mon Jun 27 21:28:39 +0000 2011",
    "user" : {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "protected" : false,
      "id_str" : "23695888",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2244513395/IMAG0190-1_normal.jpg",
      "id" : 23695888,
      "verified" : false
    }
  },
  "id" : 85535115966562304,
  "created_at" : "Tue Jun 28 02:28:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85533938130485248",
  "text" : "and 4 days left to register for Richmond Marathon on Nov 12th before the price goes up, who else is doing it?! #fb",
  "id" : 85533938130485248,
  "created_at" : "Tue Jun 28 02:24:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 134, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85533418393313280",
  "text" : "results for the Triadventure Summer Sprint are up, 5th best bike leg! with a really fast 5k (not walking) I could've been 3rd overall #fb",
  "id" : 85533418393313280,
  "created_at" : "Tue Jun 28 02:22:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85532735157968897",
  "text" : "excellent 6mi tempo-ish run w Laurel, and PB-jelly-brownie-salsa burritos after :) ...off day tmrw! #fb",
  "id" : 85532735157968897,
  "created_at" : "Tue Jun 28 02:19:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85505829016580096",
  "text" : "what's up with the 400000 future farmers of america kids staying at tech?",
  "id" : 85505829016580096,
  "created_at" : "Tue Jun 28 00:32:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85504070101630976",
  "text" : "awesome swim/crawl and ropeswing at the river, now time to run! #fb",
  "id" : 85504070101630976,
  "created_at" : "Tue Jun 28 00:25:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85448356993839104",
  "geo" : {
  },
  "id_str" : "85449913680408577",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff it's the BrewDo, not the Fork and Cork",
  "id" : 85449913680408577,
  "in_reply_to_status_id" : 85448356993839104,
  "created_at" : "Mon Jun 27 20:50:21 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85368700059922432",
  "text" : "wants to see results from the Tri yesterday...c'mon SetUp! and the Richmond Marathon is in 19.5 wks, I would start training in 1.5",
  "id" : 85368700059922432,
  "created_at" : "Mon Jun 27 15:27:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85123594165829632",
  "text" : "super fun 22mi ride on my fixed gear with Chrissy, Edie, Bradner, and Chad! Legs are officially retired for the day. #fb",
  "id" : 85123594165829632,
  "created_at" : "Sun Jun 26 23:13:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85089716743049216",
  "text" : "there was a bird flying around upstairs at home!! i put on gloves and caught him and let him be free",
  "id" : 85089716743049216,
  "created_at" : "Sun Jun 26 20:59:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 17, 29 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85083181560246274",
  "text" : "good short nap w @ShayDubb615, goin on a fun bike ride w Chrissy and friends soon",
  "id" : 85083181560246274,
  "created_at" : "Sun Jun 26 20:33:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85035068157988864",
  "geo" : {
  },
  "id_str" : "85082991289843712",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet impressive brah. i'd been up for four hours and finished a triathlon by 8:10AM :-P",
  "id" : 85082991289843712,
  "in_reply_to_status_id" : 85035068157988864,
  "created_at" : "Sun Jun 26 20:32:20 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 32, 39 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 85, 98 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "85009123204276226",
  "text" : "on way home got gatorade i owed @rkay21 and steak seasoning for cooking venison from @laurentappan! already enough activity for a whole day",
  "id" : 85009123204276226,
  "created_at" : "Sun Jun 26 15:38:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 16, 28 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http://t.co/R3pLGpf",
      "expanded_url" : "http://twitpic.com/5h7dbe",
      "display_url" : "twitpic.com/5h7dbe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84989819255652352",
  "text" : "got 2nd place!! @VTTriathlon domination of collegiate http://t.co/R3pLGpf",
  "id" : 84989819255652352,
  "created_at" : "Sun Jun 26 14:22:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84975214819164160",
  "text" : "triathlon was awesome! felt really really slow, but got 13th overall and 2nd in my age group maybe",
  "id" : 84975214819164160,
  "created_at" : "Sun Jun 26 13:24:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http://t.co/jcd9hCH",
      "expanded_url" : "http://twitpic.com/5h4gef",
      "display_url" : "twitpic.com/5h4gef"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84930197454983168",
  "text" : "Here we go! http://t.co/jcd9hCH",
  "id" : 84930197454983168,
  "created_at" : "Sun Jun 26 10:25:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84906939422748672",
  "text" : "its 5AM and I've been up for 45 minutes... why is this Tri so earlyyy",
  "id" : 84906939422748672,
  "created_at" : "Sun Jun 26 08:52:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heregoesnothing",
      "indices" : [ 68, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84753767232323584",
  "text" : "done with packet pickup, got some cobalt drill bits on the way home #heregoesnothing",
  "id" : 84753767232323584,
  "created_at" : "Sat Jun 25 22:44:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 30, 42 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http://t.co/vuFAhq3",
      "expanded_url" : "http://twitpic.com/5grsh5",
      "display_url" : "twitpic.com/5grsh5"
    }, {
      "indices" : [ 85, 104 ],
      "url" : "http://t.co/poLAUTJ",
      "expanded_url" : "http://twitpic.com/5grsi8",
      "display_url" : "twitpic.com/5grsi8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84690446021963777",
  "text" : "setting up for the Triathlon! @LeeRMatthis check out the bottles http://t.co/vuFAhq3 http://t.co/poLAUTJ",
  "id" : 84690446021963777,
  "created_at" : "Sat Jun 25 18:32:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 3, 15 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "NextThreeDays.com",
      "screen_name" : "Next3Days",
      "indices" : [ 18, 28 ],
      "id_str" : "37722313",
      "id" : 37722313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http://t.co/Xu6Ljv2",
      "expanded_url" : "http://bit.ly/laDoOd",
      "display_url" : "bit.ly/laDoOd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84677249554583552",
  "text" : "RT @LeeRMatthis: “@Next3Days: Triathlon Tomorrow - Triadventure Summer Sprint - Christiansburg Aquatic Center - http://t.co/Xu6Ljv2”. Wo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NextThreeDays.com",
        "screen_name" : "Next3Days",
        "indices" : [ 1, 11 ],
        "id_str" : "37722313",
        "id" : 37722313
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 114 ],
        "url" : "http://t.co/Xu6Ljv2",
        "expanded_url" : "http://bit.ly/laDoOd",
        "display_url" : "bit.ly/laDoOd"
      } ]
    },
    "geo" : {
    },
    "id_str" : "84675688707260417",
    "text" : "“@Next3Days: Triathlon Tomorrow - Triadventure Summer Sprint - Christiansburg Aquatic Center - http://t.co/Xu6Ljv2”. WoooooooHoooooo",
    "id" : 84675688707260417,
    "created_at" : "Sat Jun 25 17:33:52 +0000 2011",
    "user" : {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "protected" : false,
      "id_str" : "70417462",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1402226998/image_normal.jpg",
      "id" : 70417462,
      "verified" : false
    }
  },
  "id" : 84677249554583552,
  "created_at" : "Sat Jun 25 17:40:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84677163604905985",
  "text" : "couldn't get a pedal off the bike im borrowing, and neither could East Coasters or Christian, uh oh. Drilling it out or using a dif bike...",
  "id" : 84677163604905985,
  "created_at" : "Sat Jun 25 17:39:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84428660064526336",
  "geo" : {
  },
  "id_str" : "84437304684453888",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr you're coming to my house later right?",
  "id" : 84437304684453888,
  "in_reply_to_status_id" : 84428660064526336,
  "created_at" : "Sat Jun 25 01:46:36 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2342, -80.4198 ]
  },
  "id_str" : "84427834608726017",
  "text" : "jumbo texas margaritas! (@ El Rodeo) http://4sq.com/k3BibJ",
  "id" : 84427834608726017,
  "created_at" : "Sat Jun 25 01:08:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Students",
      "screen_name" : "googlestudents",
      "indices" : [ 0, 15 ],
      "id_str" : "30315557",
      "id" : 30315557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askagoogler",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84318960337698816",
  "in_reply_to_user_id" : 30315557,
  "text" : "@googlestudents Does google hire mathematics majors with only some programming experience? #askagoogler",
  "id" : 84318960337698816,
  "created_at" : "Fri Jun 24 17:56:21 +0000 2011",
  "in_reply_to_screen_name" : "googlestudents",
  "in_reply_to_user_id_str" : "30315557",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 80, 92 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84271061738323968",
  "text" : "114 seconds on minesweeper expert, huzzah! now i don't have to play again until @ShayDubb615 beats that, which will be never...",
  "id" : 84271061738323968,
  "created_at" : "Fri Jun 24 14:46:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 67, 76 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84063152295264256",
  "text" : "headed to Mary Kate's to finally get my car registration stickers! @dmreagan when I get back!",
  "id" : 84063152295264256,
  "created_at" : "Fri Jun 24 00:59:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84042985578307584",
  "geo" : {
  },
  "id_str" : "84046797500194816",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan haha guess so. Im not home yet, ill let you know when I am to Skype",
  "id" : 84046797500194816,
  "in_reply_to_status_id" : 84042985578307584,
  "created_at" : "Thu Jun 23 23:54:52 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84024646718066688",
  "geo" : {
  },
  "id_str" : "84046267759595520",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo cool thanks, I've had to warranty one before, this time the teeth on the gear in the shifter stripped... good luck Saturday!!",
  "id" : 84046267759595520,
  "in_reply_to_status_id" : 84024646718066688,
  "created_at" : "Thu Jun 23 23:52:46 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http://t.co/z9bsCbQ",
      "expanded_url" : "http://twitpic.com/5fusi9",
      "display_url" : "twitpic.com/5fusi9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84045763096739840",
  "text" : "it didn't upload the pic, here's the bike: http://t.co/z9bsCbQ",
  "id" : 84045763096739840,
  "created_at" : "Thu Jun 23 23:50:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 9, 21 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "upgrade",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84042016564064256",
  "text" : "tri team @VTTriathlon's team bike #upgrade",
  "id" : 84042016564064256,
  "created_at" : "Thu Jun 23 23:35:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 75, 88 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84035539229081600",
  "text" : "and I get homemade applesauce and venison for bringing it back too! Thanks @laurentappan!! Now headed to tri team house to check out bikes",
  "id" : 84035539229081600,
  "created_at" : "Thu Jun 23 23:10:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 32, 45 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http://t.co/B2hHzZI",
      "expanded_url" : "http://twitpic.com/5fu18w",
      "display_url" : "twitpic.com/5fu18w"
    }, {
      "indices" : [ 118, 137 ],
      "url" : "http://t.co/a2B28sX",
      "expanded_url" : "http://twitpic.com/5fuak2",
      "display_url" : "twitpic.com/5fuak2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "84035352238628864",
  "text" : "Goin to take the tandem back to @laurentappan, might've tried to keep it but she had fixie ransom http://t.co/B2hHzZI http://t.co/a2B28sX",
  "id" : 84035352238628864,
  "created_at" : "Thu Jun 23 23:09:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84027153720680449",
  "text" : "only worry is getting a bike or shifter for Sunday's Tri. Also happened to run into Anne T who's putting it on my way home too, im excited!",
  "id" : 84027153720680449,
  "created_at" : "Thu Jun 23 22:36:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "84023823644626944",
  "text" : "just went to East Coasters, and my shifter is totally f'ed. They're gonna call SRAM tmrw, hopefully a warranty issue",
  "id" : 84023823644626944,
  "created_at" : "Thu Jun 23 22:23:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "84013113204146176",
  "text" : "still never get tired of d2 (@ Dietrick Dining Center) http://4sq.com/lUDYbV",
  "id" : 84013113204146176,
  "created_at" : "Thu Jun 23 21:41:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 9, 23 ],
      "id_str" : "154139533",
      "id" : 154139533
    }, {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 70, 81 ],
      "id_str" : "18855629",
      "id" : 18855629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadnats",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83965756995403777",
  "text" : "congrats @rickygargiulo and Grayson, 27th and 62nd (17th cat 2) today @usacycling U23 #roadnats!!",
  "id" : 83965756995403777,
  "created_at" : "Thu Jun 23 18:32:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83912066720739328",
  "geo" : {
  },
  "id_str" : "83913008283258880",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 the heat \"index\" is for wimps",
  "id" : 83913008283258880,
  "in_reply_to_status_id" : 83912066720739328,
  "created_at" : "Thu Jun 23 15:03:14 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chyeah",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83711728055103489",
  "text" : "looks like I got a spot for the 3Sports triathlon in Richmond this July #chyeah",
  "id" : 83711728055103489,
  "created_at" : "Thu Jun 23 01:43:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83710466253266944",
  "geo" : {
  },
  "id_str" : "83710850027892736",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD it sure was, thanks!",
  "id" : 83710850027892736,
  "in_reply_to_status_id" : 83710466253266944,
  "created_at" : "Thu Jun 23 01:39:56 +0000 2011",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83710580397064192",
  "text" : "thinks my shifter on my road bike is broken, rut roh I gotta get that fixed before sunday",
  "id" : 83710580397064192,
  "created_at" : "Thu Jun 23 01:38:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 53, 62 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83705430966153216",
  "text" : "Wednesday worlds was awesome, finished second behind @aJohnnyD! after suffering on his wheel all the way back blacksburg rd",
  "id" : 83705430966153216,
  "created_at" : "Thu Jun 23 01:18:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 3, 15 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christiansburg",
      "indices" : [ 40, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83341186672246785",
  "text" : "RT @LeeRMatthis: Looking forward to the #Christiansburg Triathlon this weekend!!!  Gonna redline it from the gun!!!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Christiansburg",
        "indices" : [ 23, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "83334917097930754",
    "text" : "Looking forward to the #Christiansburg Triathlon this weekend!!!  Gonna redline it from the gun!!!",
    "id" : 83334917097930754,
    "created_at" : "Wed Jun 22 00:46:07 +0000 2011",
    "user" : {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "protected" : false,
      "id_str" : "70417462",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1402226998/image_normal.jpg",
      "id" : 70417462,
      "verified" : false
    }
  },
  "id" : 83341186672246785,
  "created_at" : "Wed Jun 22 01:11:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83338863707291649",
  "geo" : {
  },
  "id_str" : "83341048969052160",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice jealousss",
  "id" : 83341048969052160,
  "in_reply_to_status_id" : 83338863707291649,
  "created_at" : "Wed Jun 22 01:10:29 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http://t.co/0ndNjOa",
      "expanded_url" : "http://bit.ly/iHfqTd",
      "display_url" : "bit.ly/iHfqTd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "83336580227538944",
  "text" : "dipped 10min early from work to go swim @ the river! it was sweet, plus some ropeswing action. Garmin Connect - Details: http://t.co/0ndNjOa",
  "id" : 83336580227538944,
  "created_at" : "Wed Jun 22 00:52:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "83224366594277376",
  "text" : "forgot my bag and had to walk all the way back #fail (@ Dietrick Dining Center) http://4sq.com/lci5xP",
  "id" : 83224366594277376,
  "created_at" : "Tue Jun 21 17:26:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http://t.co/z3KqI5N",
      "expanded_url" : "http://www.youtube.com/watch?v=DiUdtxe2YnU",
      "display_url" : "youtube.com/watch?v=DiUdtx…"
    } ]
  },
  "in_reply_to_status_id_str" : "83199624239779840",
  "geo" : {
  },
  "id_str" : "83200438400335872",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet http://t.co/z3KqI5N",
  "id" : 83200438400335872,
  "in_reply_to_status_id" : 83199624239779840,
  "created_at" : "Tue Jun 21 15:51:44 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 13, 22 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http://t.co/R0lcTT2",
      "expanded_url" : "http://twitpic.com/5es3pn",
      "display_url" : "twitpic.com/5es3pn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "83194578827620352",
  "text" : "the network! @jdbrunnr http://t.co/R0lcTT2",
  "id" : 83194578827620352,
  "created_at" : "Tue Jun 21 15:28:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "83155088339763200",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet damn that was close, almost lost a $400 hand cart",
  "id" : 83155088339763200,
  "created_at" : "Tue Jun 21 12:51:32 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 29, 36 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "life",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82961437168902144",
  "text" : "chillin and drinkin a beer w @jbice0 on a beautiful blacksburg evening #life",
  "id" : 82961437168902144,
  "created_at" : "Tue Jun 21 00:02:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "こうすけ",
      "screen_name" : "kmyuh",
      "indices" : [ 0, 6 ],
      "id_str" : "573873054",
      "id" : 573873054
    }, {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 71, 80 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82912931657945088",
  "geo" : {
  },
  "id_str" : "82918770435309568",
  "in_reply_to_user_id" : 29261982,
  "text" : "@kmyuh just had to look up what blast meant lol, learned somethin new. @jdbrunnr is on twatter too!",
  "id" : 82918770435309568,
  "in_reply_to_status_id" : 82912931657945088,
  "created_at" : "Mon Jun 20 21:12:30 +0000 2011",
  "in_reply_to_screen_name" : "uh_my_uh_kay",
  "in_reply_to_user_id_str" : "29261982",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82820964626345984",
  "text" : "presentation this morning went well...now trying to finalize the regulations in our network is hard though, the biology not conclusive",
  "id" : 82820964626345984,
  "created_at" : "Mon Jun 20 14:43:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hugeimprovement",
      "indices" : [ 41, 57 ]
    }, {
      "text" : "thisplaceisgettingcivilized",
      "indices" : [ 58, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82616791838371840",
  "text" : "just redid the kitchen and built a table #hugeimprovement #thisplaceisgettingcivilized",
  "id" : 82616791838371840,
  "created_at" : "Mon Jun 20 01:12:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chipotle",
      "screen_name" : "ChipotleTweets",
      "indices" : [ 38, 53 ],
      "id_str" : "141341662",
      "id" : 141341662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/PVyov5g",
      "expanded_url" : "http://bit.ly/m8iAb5",
      "display_url" : "bit.ly/m8iAb5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "82530011374043136",
  "text" : "Awesome ride!! showered and headed to @chipotletweets! Bradshaw Loop by andyreagan on Garmin Connect: http://t.co/PVyov5g",
  "id" : 82530011374043136,
  "created_at" : "Sun Jun 19 19:27:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.378785, -80.110148 ]
  },
  "id_str" : "82502183479812096",
  "text" : "fillin up water bottles (@ Home Place Restaurant) http://4sq.com/kLuXxZ",
  "id" : 82502183479812096,
  "created_at" : "Sun Jun 19 17:37:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http://t.co/cdQVK7w",
      "expanded_url" : "http://twitpic.com/5dwxv2",
      "display_url" : "twitpic.com/5dwxv2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "82497513701126144",
  "text" : "in the middle of a beautiful ride w Chrissy, Edie, and Jaber! #fb http://t.co/cdQVK7w",
  "id" : 82497513701126144,
  "created_at" : "Sun Jun 19 17:18:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82466389306257409",
  "text" : "heading out for a long road ride!",
  "id" : 82466389306257409,
  "created_at" : "Sun Jun 19 15:14:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82273007497773056",
  "text" : "3rd place in my age group = medal! Wearing it and drinking on the beach at cabo!",
  "id" : 82273007497773056,
  "created_at" : "Sun Jun 19 02:26:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "fb",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82257718588608512",
  "text" : "5k in 18:43! Time to head to downtown #blacksburg! #fb",
  "id" : 82257718588608512,
  "created_at" : "Sun Jun 19 01:25:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82165050600718336",
  "text" : "headin downtown to sign up for solstice festival!! so many activities! (signing up for the downtown sundown 5k)",
  "id" : 82165050600718336,
  "created_at" : "Sat Jun 18 19:17:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 0, 12 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82129044916801536",
  "in_reply_to_user_id" : 53501576,
  "text" : "@ShayDubb615 hope you're feelin better after the nap!",
  "id" : 82129044916801536,
  "created_at" : "Sat Jun 18 16:54:24 +0000 2011",
  "in_reply_to_screen_name" : "ShayDubb615",
  "in_reply_to_user_id_str" : "53501576",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "productivedayalready",
      "indices" : [ 13, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.233589, -80.418047 ]
  },
  "id_str" : "82128727164723200",
  "text" : "laundry done #productivedayalready (@ EZ Way Laundromat) http://4sq.com/jyt0Zt",
  "id" : 82128727164723200,
  "created_at" : "Sat Jun 18 16:53:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81347155306102784",
  "geo" : {
  },
  "id_str" : "82119886209417217",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson raced once, but really just loving summer here. Been running a lot actually, 5k tonight and a tri next weekend",
  "id" : 82119886209417217,
  "in_reply_to_status_id" : 81347155306102784,
  "created_at" : "Sat Jun 18 16:18:01 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "82118736252907520",
  "text" : "took down the lofted couch today...sad. although not as awesome, the living room is eight times bigger",
  "id" : 82118736252907520,
  "created_at" : "Sat Jun 18 16:13:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http://t.co/D3PIhOj",
      "expanded_url" : "http://bit.ly/kRvBbq",
      "display_url" : "bit.ly/kRvBbq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "81876286817054720",
  "text" : "16-12-8-4 Track Workout at 5:41, 5:49, 5:27, 4:23 pace! http://t.co/D3PIhOj",
  "id" : 81876286817054720,
  "created_at" : "Sat Jun 18 00:10:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 54, 66 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81856217546375168",
  "text" : "good day at research today, now goin to get stuff for @ShayDubb615's bday!",
  "id" : 81856217546375168,
  "created_at" : "Fri Jun 17 22:50:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81724314168201216",
  "text" : "the literature on the effects of oxidative stress are so contradictory...uh",
  "id" : 81724314168201216,
  "created_at" : "Fri Jun 17 14:06:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81390668848709632",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan PM, lol",
  "id" : 81390668848709632,
  "created_at" : "Thu Jun 16 16:00:22 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81390591233101826",
  "text" : "\"the water is deceptively shallow\" does that mean to you that it's deep, or shallow?",
  "id" : 81390591233101826,
  "created_at" : "Thu Jun 16 16:00:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81351359965835264",
  "geo" : {
  },
  "id_str" : "81356968861761536",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr i knoww...",
  "id" : 81356968861761536,
  "in_reply_to_status_id" : 81351359965835264,
  "created_at" : "Thu Jun 16 13:46:27 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "81346614408642560",
  "text" : "I think they're gonna name an omlette after me http://4sq.com/kN6VIe",
  "id" : 81346614408642560,
  "created_at" : "Thu Jun 16 13:05:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81190889246048257",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan skype tomorrow at 630?",
  "id" : 81190889246048257,
  "created_at" : "Thu Jun 16 02:46:31 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81154752213295104",
  "geo" : {
  },
  "id_str" : "81182644259389440",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e will do, hang in there!",
  "id" : 81182644259389440,
  "in_reply_to_status_id" : 81154752213295104,
  "created_at" : "Thu Jun 16 02:13:45 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81162072494309376",
  "geo" : {
  },
  "id_str" : "81182092704231425",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson sick!! congrats dude that's awesome",
  "id" : 81182092704231425,
  "in_reply_to_status_id" : 81162072494309376,
  "created_at" : "Thu Jun 16 02:11:33 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81163244433195008",
  "geo" : {
  },
  "id_str" : "81181988291219456",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan how about I take the quantitative for you and you take the other part for me",
  "id" : 81181988291219456,
  "in_reply_to_status_id" : 81163244433195008,
  "created_at" : "Thu Jun 16 02:11:08 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81172444169240576",
  "geo" : {
  },
  "id_str" : "81181802273837056",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice droid dooooesssss",
  "id" : 81181802273837056,
  "in_reply_to_status_id" : 81172444169240576,
  "created_at" : "Thu Jun 16 02:10:24 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 20, 29 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/0SUpUpn",
      "expanded_url" : "http://bit.ly/k3zU5E",
      "display_url" : "bit.ly/k3zU5E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "81181314228813824",
  "text" : "awesome tempo run w @jdbrunnr and Laurel, put in three 6 minute miles and felt great. garmin: http://t.co/0SUpUpn",
  "id" : 81181314228813824,
  "created_at" : "Thu Jun 16 02:08:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 17, 26 ],
      "id_str" : "25850390",
      "id" : 25850390
    }, {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 28, 40 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81147248066560000",
  "text" : "goin for a run w @jdbrunnr. @ShayDubb615 they didn't have the movie",
  "id" : 81147248066560000,
  "created_at" : "Wed Jun 15 23:53:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81091435784454145",
  "text" : "just went to a really interesting presentation about presenting and interviewing with techniques from theater",
  "id" : 81091435784454145,
  "created_at" : "Wed Jun 15 20:11:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "81017188777082880",
  "text" : "the goal is to be an arrow, not a leaf",
  "id" : 81017188777082880,
  "created_at" : "Wed Jun 15 15:16:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 4, 13 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 85, 97 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80977632514154496",
  "text" : "\"Do @facebook employees get in trouble for being on facebook when they're at work?\" -@ShayDubb615 good question",
  "id" : 80977632514154496,
  "created_at" : "Wed Jun 15 12:39:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nocomplaints",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "80974118396235776",
  "text" : "yup #nocomplaints (@ Dietrick Dining Center) [pic]: http://4sq.com/k2pIFn",
  "id" : 80974118396235776,
  "created_at" : "Wed Jun 15 12:25:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Dublin",
      "screen_name" : "ShayDubb615",
      "indices" : [ 15, 27 ],
      "id_str" : "53501576",
      "id" : 53501576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80863091574849536",
  "text" : "Happy birthday @ShayDubb615!",
  "id" : 80863091574849536,
  "created_at" : "Wed Jun 15 05:03:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 47, 56 ],
      "id_str" : "25850390",
      "id" : 25850390
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 57, 64 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 127, 139 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http://t.co/ZPGu9sA",
      "expanded_url" : "http://bit.ly/k0a0LT",
      "display_url" : "bit.ly/k0a0LT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "80818823317561344",
  "text" : "perfect cool weather for an easy sundown run w @jdbrunnr @rkay21, garmin data: http://t.co/ZPGu9sA. arches felt great thanks 2 @leermatthis",
  "id" : 80818823317561344,
  "created_at" : "Wed Jun 15 02:08:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80815078429048832",
  "geo" : {
  },
  "id_str" : "80816687443742721",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 hahah remember that time I was meeting you there after a bike ride during HS? Good times",
  "id" : 80816687443742721,
  "in_reply_to_status_id" : 80815078429048832,
  "created_at" : "Wed Jun 15 01:59:34 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Seth Greenberg",
      "screen_name" : "headhokie",
      "indices" : [ 7, 17 ],
      "id_str" : "565708797",
      "id" : 565708797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80816434845982720",
  "text" : "Nice! \"@HeadHokie: Even saw Boeheim smile.\"",
  "id" : 80816434845982720,
  "created_at" : "Wed Jun 15 01:58:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80784170292477952",
  "geo" : {
  },
  "id_str" : "80805194811707392",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff yeah I thought I got the date wrong...but apparently didn't",
  "id" : 80805194811707392,
  "in_reply_to_status_id" : 80784170292477952,
  "created_at" : "Wed Jun 15 01:13:54 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80775134264303616",
  "text" : "Mixed up the dates, whoops. Looking at Tri's for later this summer to comp maybe...",
  "id" : 80775134264303616,
  "created_at" : "Tue Jun 14 23:14:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80771048764751872",
  "text" : "goin to listen to music at market square park then running!",
  "id" : 80771048764751872,
  "created_at" : "Tue Jun 14 22:58:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 86, 95 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "80747491636682752",
  "text" : "on the summer camp rush: \"I had to wait in line for a drink, can you believe that!?\" -@jdbrunnr http://4sq.com/lFublg",
  "id" : 80747491636682752,
  "created_at" : "Tue Jun 14 21:24:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 110, 126 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80741244745158657",
  "text" : "and on a site note, i think i'm on the email list for a zumba flash mob! i better start practicing. thanks to @BlacksburgStuff for the tip",
  "id" : 80741244745158657,
  "created_at" : "Tue Jun 14 20:59:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80740984429875200",
  "text" : "Reinhard likes our model too! now the real work sorta begins, extending the model to 729 entries... but not before dinner!",
  "id" : 80740984429875200,
  "created_at" : "Tue Jun 14 20:58:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 72, 81 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80731053962174464",
  "text" : "the model works even better than before!! after many heated arguments w @jdbrunnr abt the effects of ferritin on intracellular iron, that is",
  "id" : 80731053962174464,
  "created_at" : "Tue Jun 14 20:19:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "80681205896445952",
  "text" : "Om nom nom (@ Dietrick Dining Center) [pic]: http://4sq.com/jeVO1i",
  "id" : 80681205896445952,
  "created_at" : "Tue Jun 14 17:01:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80654374581444609",
  "geo" : {
  },
  "id_str" : "80656107118407680",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving sounds fun to me!",
  "id" : 80656107118407680,
  "in_reply_to_status_id" : 80654374581444609,
  "created_at" : "Tue Jun 14 15:21:29 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 3, 19 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blacksburg",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80656061736042496",
  "text" : "RT @BlacksburgStuff: 7PM Market Square Jam in #Blacksburg!  Bring your chairs and come enjoy/join in with old timey, blues, folk, blue g ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blacksburg",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80654169979109376",
    "text" : "7PM Market Square Jam in #Blacksburg!  Bring your chairs and come enjoy/join in with old timey, blues, folk, blue grass music downtown. 6/14",
    "id" : 80654169979109376,
    "created_at" : "Tue Jun 14 15:13:47 +0000 2011",
    "user" : {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "protected" : false,
      "id_str" : "226946313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1354924918/Downtown_Blacksburg_from_top_of_crane_normal.jpg",
      "id" : 226946313,
      "verified" : false
    }
  },
  "id" : 80656061736042496,
  "created_at" : "Tue Jun 14 15:21:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minesweeper",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80636604976336897",
  "text" : "presentation went well this AM, gettin back at it (reading about Heme, HO1, ALAS1 protiens) after a game of #minesweeper",
  "id" : 80636604976336897,
  "created_at" : "Tue Jun 14 14:03:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Tock",
      "screen_name" : "tick3tock3",
      "indices" : [ 0, 11 ],
      "id_str" : "223308471",
      "id" : 223308471
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twittercelebrity",
      "indices" : [ 43, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80622610249039872",
  "geo" : {
  },
  "id_str" : "80635900895305728",
  "in_reply_to_user_id" : 223308471,
  "text" : "@tick3tock3 40 more and you'll close to me #twittercelebrity",
  "id" : 80635900895305728,
  "in_reply_to_status_id" : 80622610249039872,
  "created_at" : "Tue Jun 14 14:01:11 +0000 2011",
  "in_reply_to_screen_name" : "tick3tock3",
  "in_reply_to_user_id_str" : "223308471",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 3, 10 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cutestbabyever",
      "indices" : [ 25, 40 ]
    }, {
      "text" : "lookslikedaddy",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/blW6v5P",
      "expanded_url" : "http://twitter.com/k8eb8e/status/80634058132033536/photo/1",
      "display_url" : "pic.twitter.com/blW6v5P"
    } ]
  },
  "geo" : {
  },
  "id_str" : "80635622351577088",
  "text" : "RT @k8eb8e: Baby Paul!!! #cutestbabyever #lookslikedaddy http://t.co/blW6v5P",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/k8eb8e/status/80634058132033536/photo/1",
        "indices" : [ 45, 64 ],
        "url" : "http://t.co/blW6v5P",
        "media_url" : "http://pbs.twimg.com/media/AR54P6fCEAEUZmN.jpg",
        "id_str" : "80634058132033537",
        "id" : 80634058132033537,
        "media_url_https" : "https://pbs.twimg.com/media/AR54P6fCEAEUZmN.jpg",
        "sizes" : [ {
          "h" : 1028,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1028,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/blW6v5P"
      } ],
      "hashtags" : [ {
        "text" : "cutestbabyever",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "lookslikedaddy",
        "indices" : [ 29, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "80634058132033536",
    "text" : "Baby Paul!!! #cutestbabyever #lookslikedaddy http://t.co/blW6v5P",
    "id" : 80634058132033536,
    "created_at" : "Tue Jun 14 13:53:52 +0000 2011",
    "user" : {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "protected" : false,
      "id_str" : "26517690",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/673880411/IMG_0050_normal.JPG",
      "id" : 26517690,
      "verified" : false
    }
  },
  "id" : 80635622351577088,
  "created_at" : "Tue Jun 14 14:00:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80475488237273088",
  "geo" : {
  },
  "id_str" : "80594246888980480",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis going for a run tonight, will let you know!",
  "id" : 80594246888980480,
  "in_reply_to_status_id" : 80475488237273088,
  "created_at" : "Tue Jun 14 11:15:40 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80478692668751872",
  "geo" : {
  },
  "id_str" : "80593497392037888",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e ahhhh im so happy for you!! Congratulations!!!",
  "id" : 80593497392037888,
  "in_reply_to_status_id" : 80478692668751872,
  "created_at" : "Tue Jun 14 11:12:41 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http://t.co/yc7Pr6J",
      "expanded_url" : "http://twitpic.com/5b9hvz",
      "display_url" : "twitpic.com/5b9hvz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "80454754177794048",
  "text" : "perfection: http://t.co/yc7Pr6J",
  "id" : 80454754177794048,
  "created_at" : "Tue Jun 14 02:01:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80436712345583617",
  "text" : "awesome ride, lots of tempo and stopping to watch the sun set back in town",
  "id" : 80436712345583617,
  "created_at" : "Tue Jun 14 00:49:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80403892227145728",
  "text" : "bike ride w Chrissy, Jaber and his friend John!",
  "id" : 80403892227145728,
  "created_at" : "Mon Jun 13 22:39:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RecycleNRV",
      "screen_name" : "RecycleNRV",
      "indices" : [ 0, 11 ],
      "id_str" : "18010412",
      "id" : 18010412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80379144751419393",
  "geo" : {
  },
  "id_str" : "80402846310342656",
  "in_reply_to_user_id" : 18010412,
  "text" : "@RecycleNRV haha no worriess, a quick answer: andyreagan.com/?p=2323",
  "id" : 80402846310342656,
  "in_reply_to_status_id" : 80379144751419393,
  "created_at" : "Mon Jun 13 22:35:07 +0000 2011",
  "in_reply_to_screen_name" : "RecycleNRV",
  "in_reply_to_user_id_str" : "18010412",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80389745510850560",
  "geo" : {
  },
  "id_str" : "80395184646524929",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 much needed",
  "id" : 80395184646524929,
  "in_reply_to_status_id" : 80389745510850560,
  "created_at" : "Mon Jun 13 22:04:40 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoying",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "80395014554927104",
  "text" : "these high school sports camps crowding d2 are #annoying, but I did teach a kid how to make a cone! http://4sq.com/mIZoDv",
  "id" : 80395014554927104,
  "created_at" : "Mon Jun 13 22:03:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 0, 11 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http://t.co/RywQAnq",
      "expanded_url" : "http://andyreagan.com/?p=2323",
      "display_url" : "andyreagan.com/?p=2323"
    } ]
  },
  "in_reply_to_status_id_str" : "80378850156101632",
  "geo" : {
  },
  "id_str" : "80384060496691200",
  "in_reply_to_user_id" : 55931868,
  "text" : "@andyreagan haha no worriess, a quick answer: http://t.co/RywQAnq",
  "id" : 80384060496691200,
  "in_reply_to_status_id" : 80378850156101632,
  "created_at" : "Mon Jun 13 21:20:28 +0000 2011",
  "in_reply_to_screen_name" : "andyreagan",
  "in_reply_to_user_id_str" : "55931868",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RecycleNRV",
      "screen_name" : "RecycleNRV",
      "indices" : [ 0, 11 ],
      "id_str" : "18010412",
      "id" : 18010412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80377826305519616",
  "geo" : {
  },
  "id_str" : "80378850156101632",
  "in_reply_to_user_id" : 18010412,
  "text" : "@RecycleNRV Available? Sure. Required? No.",
  "id" : 80378850156101632,
  "in_reply_to_status_id" : 80377826305519616,
  "created_at" : "Mon Jun 13 20:59:45 +0000 2011",
  "in_reply_to_screen_name" : "RecycleNRV",
  "in_reply_to_user_id_str" : "18010412",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 60, 67 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80378638809313280",
  "text" : "and in other good news, DROID had just run of batteries and @rkay21 wont have to worry abt getting the water turned off, finally paid it",
  "id" : 80378638809313280,
  "created_at" : "Mon Jun 13 20:58:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 34, 43 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cluboilcans",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http://t.co/AYQVueT",
      "expanded_url" : "http://twitpic.com/5b662c",
      "display_url" : "twitpic.com/5b662c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "80378201498599424",
  "text" : "can tabs in the mail #cluboilcans @jdbrunnr http://t.co/AYQVueT",
  "id" : 80378201498599424,
  "created_at" : "Mon Jun 13 20:57:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 14, 26 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80377098132398080",
  "text" : "and thanks to @LeeRMatthis for looking at my bruised arches, just an overuse strain it appears #phew",
  "id" : 80377098132398080,
  "created_at" : "Mon Jun 13 20:52:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80376884730413057",
  "text" : "doesn't think it's right that it is a requirement to have trash service living in #blacksburg...",
  "id" : 80376884730413057,
  "created_at" : "Mon Jun 13 20:51:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 83, 95 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80351458905694211",
  "text" : "droid is dead... hopefully the batteries just ran out fast randomly? headed to see @LeeRMatthis!",
  "id" : 80351458905694211,
  "created_at" : "Mon Jun 13 19:10:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80349555392126976",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff just started following you yesterday and can't think how many events i missed b4! ..we'll see if this flash mob is for real",
  "id" : 80349555392126976,
  "created_at" : "Mon Jun 13 19:03:21 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80349127971577856",
  "text" : "did work and got the model to work!! but in the process tossed Reinhard's algorithm out the window... we'll see what he thinks abt that tmrw",
  "id" : 80349127971577856,
  "created_at" : "Mon Jun 13 19:01:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80310983557517312",
  "geo" : {
  },
  "id_str" : "80348442043494401",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 hahahah",
  "id" : 80348442043494401,
  "in_reply_to_status_id" : 80310983557517312,
  "created_at" : "Mon Jun 13 18:58:56 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80289696202227712",
  "geo" : {
  },
  "id_str" : "80295825942650880",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yay!",
  "id" : 80295825942650880,
  "in_reply_to_status_id" : 80289696202227712,
  "created_at" : "Mon Jun 13 15:29:51 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80097008551079938",
  "text" : "trip to Lowe's w Alex to build sawhorses (and a temporary kitchen table) failed (closed) ...but headed to be early tonight, I need sleeep",
  "id" : 80097008551079938,
  "created_at" : "Mon Jun 13 02:19:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "80005966497714177",
  "text" : "solid workout, just beat the rainstorm...but my feet kill :(",
  "id" : 80005966497714177,
  "created_at" : "Sun Jun 12 20:18:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2341, -80.4091 ]
  },
  "id_str" : "79977828388573185",
  "text" : "home and goin for a brick workout! (@ International Bicycle Barracks) http://4sq.com/iCeuAj",
  "id" : 79977828388573185,
  "created_at" : "Sun Jun 12 18:26:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "79968763344195584",
  "text" : "will I ever get tired of d2? Nope. (@ Dietrick Dining Center) http://4sq.com/kFelrC",
  "id" : 79968763344195584,
  "created_at" : "Sun Jun 12 17:50:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79912122015940608",
  "geo" : {
  },
  "id_str" : "79948600989327360",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 what no!?",
  "id" : 79948600989327360,
  "in_reply_to_status_id" : 79912122015940608,
  "created_at" : "Sun Jun 12 16:30:06 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 35, 50 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79760895311491072",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @DKnick88 I trough @ryandelgiudice overrr the most",
  "id" : 79760895311491072,
  "created_at" : "Sun Jun 12 04:04:13 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.229835, -80.416032 ]
  },
  "id_str" : "79741766038859776",
  "text" : "Boogiebergggggg (@ River Mill) http://4sq.com/l2e0za",
  "id" : 79741766038859776,
  "created_at" : "Sun Jun 12 02:48:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 3, 19 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79726860577144832",
  "text" : "RT @BlacksburgStuff: 10PM Boogieburg Presents... \"RE:FILL\" @ The Rivermill (212 Draper Rd. NW, Blacksburg, VA) FREE! 21+",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "79691032303902721",
    "text" : "10PM Boogieburg Presents... \"RE:FILL\" @ The Rivermill (212 Draper Rd. NW, Blacksburg, VA) FREE! 21+",
    "id" : 79691032303902721,
    "created_at" : "Sat Jun 11 23:26:37 +0000 2011",
    "user" : {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "protected" : false,
      "id_str" : "226946313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1354924918/Downtown_Blacksburg_from_top_of_crane_normal.jpg",
      "id" : 226946313,
      "verified" : false
    }
  },
  "id" : 79726860577144832,
  "created_at" : "Sun Jun 12 01:48:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.230636, -80.41503 ]
  },
  "id_str" : "79726406971572224",
  "text" : "Edie's bday! (@ Sharkey's Wing & Rib Joint) http://4sq.com/jcRcSS",
  "id" : 79726406971572224,
  "created_at" : "Sun Jun 12 01:47:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2314, -80.4154 ]
  },
  "id_str" : "79716234832257024",
  "text" : "had some delicious chicken from grillmaster Alex and Elliot, downtown now! (@ Hokie House) http://4sq.com/jP5UR6",
  "id" : 79716234832257024,
  "created_at" : "Sun Jun 12 01:06:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79661785199804416",
  "text" : "just SAW lightning hit, WOW it was loud. Xbox flashing the ring of death",
  "id" : 79661785199804416,
  "created_at" : "Sat Jun 11 21:30:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 46, 55 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oilcanclub",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http://t.co/9nrKvJn",
      "expanded_url" : "http://bit.ly/mBUWs",
      "display_url" : "bit.ly/mBUWs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "79638684865003520",
  "text" : "sending in my fosters tabs now! #oilcanclub w @jdbrunnr. today's short ride on Garmin Connect: http://t.co/9nrKvJn",
  "id" : 79638684865003520,
  "created_at" : "Sat Jun 11 19:58:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndsay McKeever",
      "screen_name" : "LyndsayMck",
      "indices" : [ 59, 70 ],
      "id_str" : "34336023",
      "id" : 34336023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79625470802538496",
  "text" : "bottom of old farm looking sweet, and got in a good ride w @LyndsayMck",
  "id" : 79625470802538496,
  "created_at" : "Sat Jun 11 19:06:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79615250625863682",
  "geo" : {
  },
  "id_str" : "79625342117093376",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr sick!",
  "id" : 79625342117093376,
  "in_reply_to_status_id" : 79615250625863682,
  "created_at" : "Sat Jun 11 19:05:35 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GardenFreshBeats",
      "screen_name" : "GardenFreshBeat",
      "indices" : [ 0, 16 ],
      "id_str" : "308157623",
      "id" : 308157623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79625057655193600",
  "geo" : {
  },
  "id_str" : "79625294612410368",
  "in_reply_to_user_id" : 308157623,
  "text" : "@GardenFreshBeat worse if its the guy spotting you...especially squats too",
  "id" : 79625294612410368,
  "in_reply_to_status_id" : 79625057655193600,
  "created_at" : "Sat Jun 11 19:05:24 +0000 2011",
  "in_reply_to_screen_name" : "GardenFreshBeat",
  "in_reply_to_user_id_str" : "308157623",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79554523466706944",
  "text" : "headed to do some trail work",
  "id" : 79554523466706944,
  "created_at" : "Sat Jun 11 14:24:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 25, 34 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79391385077297152",
  "text" : "oil can club complete, w @jdbrunnr",
  "id" : 79391385077297152,
  "created_at" : "Sat Jun 11 03:35:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 26, 39 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2288, -80.4131 ]
  },
  "id_str" : "79362794528579585",
  "text" : "blackened mahi mahi, yup (@laurentappan jealous?) (@ Cabo Fish Taco w/ 2 others) http://4sq.com/kmYJTZ",
  "id" : 79362794528579585,
  "created_at" : "Sat Jun 11 01:42:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http://t.co/HzZtW3b",
      "expanded_url" : "http://bit.ly/iGn6Sz",
      "display_url" : "bit.ly/iGn6Sz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "79356238214856704",
  "text" : "beautiful afternoon ride, foggy valleys and a mountain top sunset! new chain+cassette r sweet: Garmin Connect Details: http://t.co/HzZtW3b",
  "id" : 79356238214856704,
  "created_at" : "Sat Jun 11 01:16:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http://t.co/JCwZ0Sr",
      "expanded_url" : "http://twitpic.com/59qlhr",
      "display_url" : "twitpic.com/59qlhr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "79318942199451648",
  "text" : "pic of the bike rack: http://t.co/JCwZ0Sr",
  "id" : 79318942199451648,
  "created_at" : "Fri Jun 10 22:48:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2341, -80.4091 ]
  },
  "id_str" : "79318551416152064",
  "text" : "home, headed for a run or ride prob. can't go for three days w.o! check out our new rack: http://4sq.com/iMWZkh",
  "id" : 79318551416152064,
  "created_at" : "Fri Jun 10 22:46:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "79297210721902592",
  "text" : "did a ton of work today researching, it sorta worked. Back for dinner (@ Dietrick Dining Center) http://4sq.com/mrpVFK",
  "id" : 79297210721902592,
  "created_at" : "Fri Jun 10 21:21:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "79216459972231168",
  "text" : "183 meals left this summer! Lunch (@ Dietrick Dining Center) http://4sq.com/j92QiR",
  "id" : 79216459972231168,
  "created_at" : "Fri Jun 10 16:00:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79178746220912640",
  "geo" : {
  },
  "id_str" : "79182943280574464",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr last night I picked up to two oil cans while at Kroger, they were only 2.19!",
  "id" : 79182943280574464,
  "in_reply_to_status_id" : 79178746220912640,
  "created_at" : "Fri Jun 10 13:47:39 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "79175858287411200",
  "text" : "d2 omlette ftw, and another day of research begins",
  "id" : 79175858287411200,
  "created_at" : "Fri Jun 10 13:19:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77918071867719680",
  "text" : "awesome day: got errands done, dinner, bike ride, and 9mi run thru foxridge, across lane stadium, and across the floor of cassell!",
  "id" : 77918071867719680,
  "created_at" : "Tue Jun 07 02:01:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Lamo",
      "screen_name" : "6",
      "indices" : [ 91, 93 ],
      "id_str" : "662693",
      "id" : 662693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77812731356528640",
  "text" : "presentation went well this morning! hopin my shoes come today 2 run after work.watch this @6:20: http://www.youtube.com/watch?v=9RsCzfckU2Q",
  "id" : 77812731356528640,
  "created_at" : "Mon Jun 06 19:02:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77192597822644224",
  "geo" : {
  },
  "id_str" : "77494685811216387",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr double yes!",
  "id" : 77494685811216387,
  "in_reply_to_status_id" : 77192597822644224,
  "created_at" : "Sun Jun 05 21:59:07 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77490095288102913",
  "text" : "in Lexington. Incredibly beautiful and awesome ride, 90 miles, 8500ft climbing, and one calorie short of 10000 burned",
  "id" : 77490095288102913,
  "created_at" : "Sun Jun 05 21:40:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/q1Afe4H",
      "expanded_url" : "http://twitpic.com/57dtvu",
      "display_url" : "twitpic.com/57dtvu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "77379067929825281",
  "text" : "At the cookie lady, june curry's, bike house! Incredible http://t.co/q1Afe4H",
  "id" : 77379067929825281,
  "created_at" : "Sun Jun 05 14:19:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77108300117852160",
  "text" : "In charlottesville!!",
  "id" : 77108300117852160,
  "created_at" : "Sat Jun 04 20:23:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "george cummins",
      "screen_name" : "lonefalcon",
      "indices" : [ 0, 11 ],
      "id_str" : "35940635",
      "id" : 35940635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77015576920326144",
  "geo" : {
  },
  "id_str" : "77100208453992448",
  "in_reply_to_user_id" : 35940635,
  "text" : "@lonefalcon yooo that was me waving erratically coming down the blue ridge parkway!!",
  "id" : 77100208453992448,
  "in_reply_to_status_id" : 77015576920326144,
  "created_at" : "Sat Jun 04 19:51:36 +0000 2011",
  "in_reply_to_screen_name" : "lonefalcon",
  "in_reply_to_user_id_str" : "35940635",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "77028069461864450",
  "text" : "11 miles in, 5mi ascent conquered, and im on the blue ridge parkway!",
  "id" : 77028069461864450,
  "created_at" : "Sat Jun 04 15:04:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 16, 26 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76971209983660032",
  "text" : "up to go ride w @bikebuild tomorrow! driving to lexington now, then biking to cville!!",
  "id" : 76971209983660032,
  "created_at" : "Sat Jun 04 11:19:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76815392676388864",
  "geo" : {
  },
  "id_str" : "76971042203115520",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy same!",
  "id" : 76971042203115520,
  "in_reply_to_status_id" : 76815392676388864,
  "created_at" : "Sat Jun 04 11:18:21 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 99, 107 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http://t.co/ZpE1k0b",
      "expanded_url" : "http://connect.garmin.com/activity/89764698?sms_ss=twitter&at_xt=4de85ae46dd9a9da,0",
      "display_url" : "connect.garmin.com/activity/89764…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "76497228457459714",
  "text" : "Huck Run w Jim, John, and Leslie by andyreagan at Garmin Connect - Details http://t.co/ZpE1k0b via @AddThis",
  "id" : 76497228457459714,
  "created_at" : "Fri Jun 03 03:55:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76303275565137921",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr update your twitter brah",
  "id" : 76303275565137921,
  "created_at" : "Thu Jun 02 15:04:53 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76302955342602240",
  "text" : "great day of researching so far @vbiatvt, time for lunch!?",
  "id" : 76302955342602240,
  "created_at" : "Thu Jun 02 15:03:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http://t.co/ry9EfJa",
      "expanded_url" : "http://connect.garmin.com/activity/89520535?sms_ss=twitter&at_xt=4de6e78a69516c53,0",
      "display_url" : "connect.garmin.com/activity/89520…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "76098414131154945",
  "text" : "Wednesday Worlds by andyreagan on Garmin Connect - Check it out: http://t.co/ry9EfJa",
  "id" : 76098414131154945,
  "created_at" : "Thu Jun 02 01:30:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wednesday Worlds",
      "screen_name" : "wednesdayworlds",
      "indices" : [ 7, 23 ],
      "id_str" : "161035957",
      "id" : 161035957
    }, {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 71, 80 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76073983904194560",
  "text" : "Fourth @wednesdayworlds!! Felt great, attacked on the way out, and saw @aJohnnyD finish! Fresh bread waiting at the house for me #yum",
  "id" : 76073983904194560,
  "created_at" : "Wed Jun 01 23:53:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wednesday Worlds",
      "screen_name" : "wednesdayworlds",
      "indices" : [ 58, 74 ],
      "id_str" : "161035957",
      "id" : 161035957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "76042977855799296",
  "text" : "Long, but good first day of research at @vbiatvt. Goin to @wednesdayworlds, and fresh bread will be done when I finish!",
  "id" : 76042977855799296,
  "created_at" : "Wed Jun 01 21:50:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75910229463801856",
  "text" : "At the inn and conference center for the first day of the REU",
  "id" : 75910229463801856,
  "created_at" : "Wed Jun 01 13:03:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 70, 77 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "75798347826466816",
  "text" : "Long night of picking ppl up at the airport and such, thanks a lot to @jbice0 for the company and flying expertise",
  "id" : 75798347826466816,
  "created_at" : "Wed Jun 01 05:38:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]