Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 99, 108 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53660705806753792",
  "text" : "passing arrays of structures by constant reference to user-defined functions...makin my head hurt! @dmreagan don't know how you do it",
  "id" : 53660705806753792,
  "created_at" : "Fri Apr 01 03:31:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53641102653267968",
  "text" : "just found out I didn't get into the C2B2 REU in Colorado...two applications that I waited months for came within hrs of eachother, weird",
  "id" : 53641102653267968,
  "created_at" : "Fri Apr 01 02:13:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53616471326195713",
  "text" : "39deg and raining....don't think all 1000 \"attending\" the naked run are going to show",
  "id" : 53616471326195713,
  "created_at" : "Fri Apr 01 00:35:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53607565837340672",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan yup!! we'll def have the ride the tandem to work sometime lol. and what are you doing saturday night?!",
  "id" : 53607565837340672,
  "created_at" : "Fri Apr 01 00:00:14 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53607373058740225",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @DKnick88 thanks guys!",
  "id" : 53607373058740225,
  "created_at" : "Thu Mar 31 23:59:28 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 12, 19 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53600106477387776",
  "geo" : {
  },
  "id_str" : "53607148319555584",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet @DZdan1 a trip to Blacksburg this summer is definitely in order!",
  "id" : 53607148319555584,
  "in_reply_to_status_id" : 53600106477387776,
  "created_at" : "Thu Mar 31 23:58:34 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53600551614676992",
  "geo" : {
  },
  "id_str" : "53607045575884803",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e after 21 years, I'm still in denial",
  "id" : 53607045575884803,
  "in_reply_to_status_id" : 53600551614676992,
  "created_at" : "Thu Mar 31 23:58:10 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 30, 39 ],
      "id_str" : "195438525",
      "id" : 195438525
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 64, 74 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304689, -80.4151305 ]
  },
  "id_str" : "53605893937446912",
  "text" : "just got a burrito to support @cafezulu biking XC this summer w @bikebuild!! (@ Moe's Southwest Grill) http://4sq.com/gKHEas",
  "id" : 53605893937446912,
  "created_at" : "Thu Mar 31 23:53:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatguy",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53599722639867904",
  "text" : "just pointed out a mistake in the professors c++ code in his ppt in a 300 person lecture...damnit I've become #thatguy",
  "id" : 53599722639867904,
  "created_at" : "Thu Mar 31 23:29:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53561482373378048",
  "text" : "has been doing research at the VBI for like 6 hours straight now too, back to class again!",
  "id" : 53561482373378048,
  "created_at" : "Thu Mar 31 20:57:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53559442872082432",
  "geo" : {
  },
  "id_str" : "53561296007860224",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 well stop forgetting so i can see what you're up to these days!",
  "id" : 53561296007860224,
  "in_reply_to_status_id" : 53559442872082432,
  "created_at" : "Thu Mar 31 20:56:22 +0000 2011",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 40, 49 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 50, 66 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 67, 74 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 75, 84 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 85, 100 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 101, 112 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53561111206830080",
  "text" : "GOT MY RESEARCH POSITION THIS SUMMER!!! @dmreagan @RumblinStumblin @DZdan1 @DKnick88 @ryandelgiudice @kreagannet",
  "id" : 53561111206830080,
  "created_at" : "Thu Mar 31 20:55:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53324207525871616",
  "text" : "has been defeated by number theory. headin home to sleep",
  "id" : 53324207525871616,
  "created_at" : "Thu Mar 31 05:14:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 1, 8 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "53185523967197185",
  "text" : ".@DZdan1 http://andyreagan.com/2011/03/29/on-glasses/",
  "id" : 53185523967197185,
  "created_at" : "Wed Mar 30 20:03:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "53122599621890048",
  "text" : "has gotta get my mayorship back, I got lazy! (@ McBryde Hall w/ 2 others) http://4sq.com/fw2o7i",
  "id" : 53122599621890048,
  "created_at" : "Wed Mar 30 15:53:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53098389956595712",
  "geo" : {
  },
  "id_str" : "53105283538485251",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 because there are two pieces (a pair) of glass (glasses, plural) in each \"pair of glasses\"",
  "id" : 53105283538485251,
  "in_reply_to_status_id" : 53098389956595712,
  "created_at" : "Wed Mar 30 14:44:20 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 74, 84 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 102, 114 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52883233582485504",
  "text" : "the weather went 25 in AM -&gt; 60!! so I went for a super awesome ride w @vtcycling! hangin out till @VTTriathlon meeting, no homebrew 2nite",
  "id" : 52883233582485504,
  "created_at" : "Wed Mar 30 00:02:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52839994812940288",
  "text" : "talked to Reinhard, should know about this summer by the END OF THIS WEEK",
  "id" : 52839994812940288,
  "created_at" : "Tue Mar 29 21:10:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52815495694516224",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium yo, we need to decide now. spandex classic, is it happening? check your email",
  "id" : 52815495694516224,
  "created_at" : "Tue Mar 29 19:32:50 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "52761337733988352",
  "text" : "quiz and hw done! D2 after class, more hw, research meeting, then maybe a training ride (or class) (@ McBryde Hall) http://4sq.com/gH29NR",
  "id" : 52761337733988352,
  "created_at" : "Tue Mar 29 15:57:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52726058012782592",
  "text" : "numerical integration quiz and homework due at 11...it never ends",
  "id" : 52726058012782592,
  "created_at" : "Tue Mar 29 13:37:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52707605419798528",
  "geo" : {
  },
  "id_str" : "52725853150384128",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 get it!",
  "id" : 52725853150384128,
  "in_reply_to_status_id" : 52707605419798528,
  "created_at" : "Tue Mar 29 13:36:37 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 72, 82 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52500323662696448",
  "text" : "awesome bike ride, headin to Moes in a few for John G's bday before the @vtcycling meeting!",
  "id" : 52500323662696448,
  "created_at" : "Mon Mar 28 22:40:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52336832037404672",
  "text" : "what happened to spring...30deg and snowing?!",
  "id" : 52336832037404672,
  "created_at" : "Mon Mar 28 11:50:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52190114062942209",
  "text" : "is goin to bed early tonight, up early tmrw. long week of hw coming up, then it'll be april already jeez...",
  "id" : 52190114062942209,
  "created_at" : "Mon Mar 28 02:07:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 57, 67 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52119282779308032",
  "text" : "is home pretty early from an awesome weekend of racing!! @vtcycling kicked some arse",
  "id" : 52119282779308032,
  "created_at" : "Sun Mar 27 21:26:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52119108333993984",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice sorry to hear abt the knee man, heal up!",
  "id" : 52119108333993984,
  "created_at" : "Sun Mar 27 21:25:38 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 53, 63 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51484182207135744",
  "text" : "5 hours to sleep then up to drive down and race with @vtcycling!",
  "id" : 51484182207135744,
  "created_at" : "Sat Mar 26 03:22:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51297750372978688",
  "text" : "finished my HW...just in time! speedin to class",
  "id" : 51297750372978688,
  "created_at" : "Fri Mar 25 15:01:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51257433636601857",
  "text" : "at the VBI early to finish up HW, then class and done for the week!",
  "id" : 51257433636601857,
  "created_at" : "Fri Mar 25 12:21:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51102237287649280",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan forget who carried you to the car haha? like old times... did you feel okay today?",
  "id" : 51102237287649280,
  "created_at" : "Fri Mar 25 02:04:57 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51067521272528896",
  "geo" : {
  },
  "id_str" : "51096681000869888",
  "in_reply_to_user_id" : 70474456,
  "text" : "@bpolson89 one is meant to be buttoned by a right handed person while wearing it, the other to be buttoned by someone else!",
  "id" : 51096681000869888,
  "in_reply_to_status_id" : 51067521272528896,
  "created_at" : "Fri Mar 25 01:42:52 +0000 2011",
  "in_reply_to_screen_name" : "britty_kitty89",
  "in_reply_to_user_id_str" : "70474456",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 86, 96 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51062203234783232",
  "text" : "is feelin good and just got on the trainer for my second ride in 3 weeks! Then pk's w @vtcycling at 8",
  "id" : 51062203234783232,
  "created_at" : "Thu Mar 24 23:25:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 41, 54 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50801562724999168",
  "text" : "and cheers to a very \"successful\" end RT @laurentappan hpy 21at to me a",
  "id" : 50801562724999168,
  "created_at" : "Thu Mar 24 06:10:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 6, 19 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50740545714270208",
  "text" : "21!!! @laurentappan downtown http://twitpic.com/4cmet8",
  "id" : 50740545714270208,
  "created_at" : "Thu Mar 24 02:07:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50625290027810816",
  "geo" : {
  },
  "id_str" : "50647664005627904",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 did you say snow? there were girls layin out to tan here when I was on campus",
  "id" : 50647664005627904,
  "in_reply_to_status_id" : 50625290027810816,
  "created_at" : "Wed Mar 23 19:58:38 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "50588228868247552",
  "text" : "classss. advanced calc hw this week is really hard, so is number theory...damn (@ McBryde Hall) http://4sq.com/fD7kqe",
  "id" : 50588228868247552,
  "created_at" : "Wed Mar 23 16:02:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50326779948314624",
  "text" : "RT @VTCycling: next years new officers voted in last night! read more: new post on http://www.cycling.org.vt.edu",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "50326732678504449",
    "text" : "next years new officers voted in last night! read more: new post on http://www.cycling.org.vt.edu",
    "id" : 50326732678504449,
    "created_at" : "Tue Mar 22 22:43:22 +0000 2011",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 50326779948314624,
  "created_at" : "Tue Mar 22 22:43:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50316151619715072",
  "geo" : {
  },
  "id_str" : "50321159790669825",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice congrats!!",
  "id" : 50321159790669825,
  "in_reply_to_status_id" : 50316151619715072,
  "created_at" : "Tue Mar 22 22:21:14 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50220653210648576",
  "geo" : {
  },
  "id_str" : "50252173862387712",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie dude that's sweet! I wanna learn!",
  "id" : 50252173862387712,
  "in_reply_to_status_id" : 50220653210648576,
  "created_at" : "Tue Mar 22 17:47:06 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50033982758326273",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium it's $3150 to take the 2-week frame building class from UBI....pricey man",
  "id" : 50033982758326273,
  "created_at" : "Tue Mar 22 03:20:05 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50032524432392192",
  "text" : "trying to set up an account required to make an appointment at schiffert, impossible. going there tomorrow morning anyway, bastards",
  "id" : 50032524432392192,
  "created_at" : "Tue Mar 22 03:14:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 59, 69 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "50027443897106432",
  "text" : "got elected to do be co-fundraising officer next year with @VTCycling. and had a super fun time chillin with ppl at Moes after.",
  "id" : 50027443897106432,
  "created_at" : "Tue Mar 22 02:54:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49968580808278016",
  "text" : "Just saw a sedan with 38+ inch chrome wheels...only fear of getting shot kept me from just laughing at this rediculous looking thing",
  "id" : 49968580808278016,
  "created_at" : "Mon Mar 21 23:00:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wimps",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49962592273313792",
  "text" : "the sidewalks are literally filled with runners...where did they all come from? where were they when it was 40 degrees out? #wimps",
  "id" : 49962592273313792,
  "created_at" : "Mon Mar 21 22:36:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49962173857923073",
  "text" : "also had a great conversation with Dr. Adjerid today abt grad school (director the Graduate School, and accelerated ugrad/masters prgm)",
  "id" : 49962173857923073,
  "created_at" : "Mon Mar 21 22:34:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49961598575575040",
  "text" : "someone ask me if 72 degrees in Blacksburg right now. bc it is. and I forgot key today, just had to break into my own house...scarily easy",
  "id" : 49961598575575040,
  "created_at" : "Mon Mar 21 22:32:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49961218311593984",
  "text" : "also found out today that offers for my summer REU \"will be going out soon, we had a huge number of applicants\" not bad, but not great news",
  "id" : 49961218311593984,
  "created_at" : "Mon Mar 21 22:30:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Ekoniak",
      "screen_name" : "me3head",
      "indices" : [ 0, 8 ],
      "id_str" : "20575038",
      "id" : 20575038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49905544009482240",
  "geo" : {
  },
  "id_str" : "49960403542876160",
  "in_reply_to_user_id" : 20575038,
  "text" : "@me3head oh its on!",
  "id" : 49960403542876160,
  "in_reply_to_status_id" : 49905544009482240,
  "created_at" : "Mon Mar 21 22:27:43 +0000 2011",
  "in_reply_to_screen_name" : "me3head",
  "in_reply_to_user_id_str" : "20575038",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49955585516503040",
  "text" : "finished up my numerical analysis project for good! accidentally skipped lunch though, dinner time!!",
  "id" : 49955585516503040,
  "created_at" : "Mon Mar 21 22:08:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49843028810141699",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet if ur going to brew, you should read section one of this and youll know what ur doin: http://www.howtobrew.com/intro.html",
  "id" : 49843028810141699,
  "created_at" : "Mon Mar 21 14:41:18 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49679789610635264",
  "geo" : {
  },
  "id_str" : "49831741220859904",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 it is blue? then yes lol",
  "id" : 49831741220859904,
  "in_reply_to_status_id" : 49679789610635264,
  "created_at" : "Mon Mar 21 13:56:27 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49515806840717312",
  "text" : "Overtime!!",
  "id" : 49515806840717312,
  "created_at" : "Sun Mar 20 17:01:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2228619568, -80.4193693399 ]
  },
  "id_str" : "49491650426318848",
  "text" : "at the Tech bball game, we're up 15-11. We better beat this team (@ Cassell Coliseum w/ 17 others) http://4sq.com/hOXIIb",
  "id" : 49491650426318848,
  "created_at" : "Sun Mar 20 15:25:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49305894902697984",
  "text" : "is hittin the sack with anti-coughing device in hand. which is a water bottle. maybe watching some tech hoops, then mtb'ing tomorrow!",
  "id" : 49305894902697984,
  "created_at" : "Sun Mar 20 03:06:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49273443799142400",
  "geo" : {
  },
  "id_str" : "49275897899008000",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 sick! this explains a lot, i had a few emails where ppl said PS look at the moon tonight, i was very confused lol",
  "id" : 49275897899008000,
  "in_reply_to_status_id" : 49273443799142400,
  "created_at" : "Sun Mar 20 01:07:44 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49245614801817601",
  "geo" : {
  },
  "id_str" : "49275500593557504",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice http://www.youtube.com/watch?v=oGt4DOl411o",
  "id" : 49275500593557504,
  "in_reply_to_status_id" : 49245614801817601,
  "created_at" : "Sun Mar 20 01:06:09 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49243789432324096",
  "text" : "is done doing work! time to eat. got a heck of a lot done today, though I would like to be racing on a speedway right now...",
  "id" : 49243789432324096,
  "created_at" : "Sat Mar 19 23:00:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OnionInternet",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49153296715362304",
  "text" : "RT @TheOnion: Entire Facebook Staff Laughs As Man Tightens Privacy Settings http://onion.com/bzOA8z #OnionInternet",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OnionInternet",
        "indices" : [ 86, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "49151915807866880",
    "text" : "Entire Facebook Staff Laughs As Man Tightens Privacy Settings http://onion.com/bzOA8z #OnionInternet",
    "id" : 49151915807866880,
    "created_at" : "Sat Mar 19 16:55:04 +0000 2011",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1683182196/onion_logo_03_L_normal.png",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 49153296715362304,
  "created_at" : "Sat Mar 19 17:00:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49151806630141952",
  "text" : "going over to VBI to do homework...awesome day outside",
  "id" : 49151806630141952,
  "created_at" : "Sat Mar 19 16:54:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49151592657723392",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan i'm feeling much better, like 95% now. i drank a lot of water and that really helped",
  "id" : 49151592657723392,
  "created_at" : "Sat Mar 19 16:53:47 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "49133046766645248",
  "text" : "didn't go to app state today...was coughing all night and got no sleep, decided my body needed sleep and not racing. just woke up",
  "id" : 49133046766645248,
  "created_at" : "Sat Mar 19 15:40:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48936554235838464",
  "text" : "alarm for 4:30am...ouch",
  "id" : 48936554235838464,
  "created_at" : "Sat Mar 19 02:39:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Frahm",
      "screen_name" : "thebikebar",
      "indices" : [ 0, 11 ],
      "id_str" : "121821964",
      "id" : 121821964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48909566158708736",
  "geo" : {
  },
  "id_str" : "48936275222339585",
  "in_reply_to_user_id" : 121821964,
  "text" : "@thebikebar those fenders look awesome man! post instructions somewhere",
  "id" : 48936275222339585,
  "in_reply_to_status_id" : 48909566158708736,
  "created_at" : "Sat Mar 19 02:38:11 +0000 2011",
  "in_reply_to_screen_name" : "thebikebar",
  "in_reply_to_user_id_str" : "121821964",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48929593138225152",
  "text" : "got some help from Tyler and my road bike is all tuned up, ready to race tomorrow.  whether my body will be ready...another story",
  "id" : 48929593138225152,
  "created_at" : "Sat Mar 19 02:11:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 0, 10 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48771922439307264",
  "geo" : {
  },
  "id_str" : "48873010005950464",
  "in_reply_to_user_id" : 73786966,
  "text" : "@SH13LDS21 only 72 in Virginia...",
  "id" : 48873010005950464,
  "in_reply_to_status_id" : 48771922439307264,
  "created_at" : "Fri Mar 18 22:26:48 +0000 2011",
  "in_reply_to_screen_name" : "SH13LDS21",
  "in_reply_to_user_id_str" : "73786966",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48872400544215040",
  "text" : "new rim for dave's commuter, hub to build the neglected rim onto both on their way via east coasters",
  "id" : 48872400544215040,
  "created_at" : "Fri Mar 18 22:24:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48861904344580096",
  "text" : "is a popsicle monster. taking a break from HW (for the first time today) to go mend a bike wheel situation i created",
  "id" : 48861904344580096,
  "created_at" : "Fri Mar 18 21:42:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48590755031285761",
  "geo" : {
  },
  "id_str" : "48592067349319680",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice true, true. suppose im nieve my man",
  "id" : 48592067349319680,
  "in_reply_to_status_id" : 48590755031285761,
  "created_at" : "Fri Mar 18 03:50:26 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48590094818476032",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice nah man whats a world w.o trust",
  "id" : 48590094818476032,
  "created_at" : "Fri Mar 18 03:42:36 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "r*becca",
      "screen_name" : "brownshu",
      "indices" : [ 0, 9 ],
      "id_str" : "12543092",
      "id" : 12543092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48562920740753409",
  "geo" : {
  },
  "id_str" : "48588038628065280",
  "in_reply_to_user_id" : 12543092,
  "text" : "@brownshu I hope that you are alright!!",
  "id" : 48588038628065280,
  "in_reply_to_status_id" : 48562920740753409,
  "created_at" : "Fri Mar 18 03:34:25 +0000 2011",
  "in_reply_to_screen_name" : "brownshu",
  "in_reply_to_user_id_str" : "12543092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Henning",
      "screen_name" : "cahenning",
      "indices" : [ 0, 10 ],
      "id_str" : "26317651",
      "id" : 26317651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48587417430667264",
  "geo" : {
  },
  "id_str" : "48587843341254656",
  "in_reply_to_user_id" : 26317651,
  "text" : "@cahenning be careful, you gonna ride all the way to the west coast again!!",
  "id" : 48587843341254656,
  "in_reply_to_status_id" : 48587417430667264,
  "created_at" : "Fri Mar 18 03:33:39 +0000 2011",
  "in_reply_to_screen_name" : "cahenning",
  "in_reply_to_user_id_str" : "26317651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 8, 17 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48515185324998656",
  "geo" : {
  },
  "id_str" : "48587594077978624",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @DKnick88 hope you guys are causin come troublllle tonight too!!",
  "id" : 48587594077978624,
  "in_reply_to_status_id" : 48515185324998656,
  "created_at" : "Fri Mar 18 03:32:39 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48585816506773504",
  "geo" : {
  },
  "id_str" : "48587292675293184",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie next week sometime we need to hang out, and you can drink some of the beer that we brewed together!",
  "id" : 48587292675293184,
  "in_reply_to_status_id" : 48585816506773504,
  "created_at" : "Fri Mar 18 03:31:27 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48586453592195072",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan i met two girls who graduated from york hs a year earlier than you too haha",
  "id" : 48586453592195072,
  "created_at" : "Fri Mar 18 03:28:07 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 28, 37 ],
      "id_str" : "195438525",
      "id" : 195438525
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 54, 64 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48586249438629888",
  "text" : "had an awesome time helping @cafeZulu raise money for @bikebuild, spinning on rollers downtown!!",
  "id" : 48586249438629888,
  "created_at" : "Fri Mar 18 03:27:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48495517637947392",
  "text" : "riding bikes in 65 degrees and sunny &gt; C++ class. st patricks get together at our house tonight, dave's cooking corn beef + cabbage!",
  "id" : 48495517637947392,
  "created_at" : "Thu Mar 17 21:26:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 3, 14 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48441417030320128",
  "text" : "RT @kreagannet Crazy nice outside. Happy st patricks day.",
  "id" : 48441417030320128,
  "created_at" : "Thu Mar 17 17:51:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 41, 50 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48382709554352129",
  "text" : "got my cycling shoes in the mail, thanks @dmreagan",
  "id" : 48382709554352129,
  "created_at" : "Thu Mar 17 13:58:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48377840986636288",
  "text" : "feeling 1000 times better today than i did yesterday",
  "id" : 48377840986636288,
  "created_at" : "Thu Mar 17 13:39:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "48108784207405056",
  "text" : "has had one of the strangest days of my life so far",
  "id" : 48108784207405056,
  "created_at" : "Wed Mar 16 19:50:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47886391077642240",
  "text" : "has given up on my C++ program at 1am. dr barnette has to have something wrong in his code... ready for another long day tomorrow!",
  "id" : 47886391077642240,
  "created_at" : "Wed Mar 16 05:06:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47745005732904960",
  "text" : "time to present to our research group. hopefully good news about this summer!",
  "id" : 47745005732904960,
  "created_at" : "Tue Mar 15 19:44:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47716181586620417",
  "geo" : {
  },
  "id_str" : "47716522696781824",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e haha sure it'll toughen em up. test went really well, but sooo much work still ughhh you know the life",
  "id" : 47716522696781824,
  "in_reply_to_status_id" : 47716181586620417,
  "created_at" : "Tue Mar 15 17:51:20 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47675483705458688",
  "geo" : {
  },
  "id_str" : "47715899259621376",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e make them play dodgeball. then start throwing wrenches and shout \"If you can dodge a ball, you can dodge a wrench!!\"",
  "id" : 47715899259621376,
  "in_reply_to_status_id" : 47675483705458688,
  "created_at" : "Tue Mar 15 17:48:51 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47669478586191872",
  "text" : "has been studying for numerical methods midterm all morning, feeling really good about it. exam in 15",
  "id" : 47669478586191872,
  "created_at" : "Tue Mar 15 14:44:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47500527331852289",
  "text" : "just tried to do hw, now to get some sleep for a real big day tmrw. Midterm at 11, presentation at 4. Not a minute to waste",
  "id" : 47500527331852289,
  "created_at" : "Tue Mar 15 03:33:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndsay McKeever",
      "screen_name" : "LyndsayMck",
      "indices" : [ 83, 94 ],
      "id_str" : "34336023",
      "id" : 34336023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47475394957422593",
  "text" : "meeting was lots of fun, rode the trike to take water bottles and pick up clothes. @LyndsayMck I got ur clothing! let me kno if u want ship",
  "id" : 47475394957422593,
  "created_at" : "Tue Mar 15 01:53:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47441227150397441",
  "text" : "stir fried sausage veggies and potatoes for dinner, magic hat #9 to drink... yeah!! Cycling meeting now",
  "id" : 47441227150397441,
  "created_at" : "Mon Mar 14 23:37:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    }, {
      "name" : "Virginia Tech SGA",
      "screen_name" : "vtsga",
      "indices" : [ 61, 67 ],
      "id_str" : "17863253",
      "id" : 17863253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47340256579686400",
  "geo" : {
  },
  "id_str" : "47349760864161792",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 nice!! let's go to the basketball game on Wednesday, @vtsga says it's free.",
  "id" : 47349760864161792,
  "in_reply_to_status_id" : 47340256579686400,
  "created_at" : "Mon Mar 14 17:33:57 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dick Vitale",
      "screen_name" : "DickieV",
      "indices" : [ 3, 11 ],
      "id_str" : "78183672",
      "id" : 78183672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47347089277067264",
  "text" : "RT @DickieV: I could not sleep thinking about the kids of Colorado & Virginia Tech - received a bad deal -  time to move on to best 3 we ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "47277421610799104",
    "text" : "I could not sleep thinking about the kids of Colorado & Virginia Tech - received a bad deal -  time to move on to best 3 weeeks in sports!",
    "id" : 47277421610799104,
    "created_at" : "Mon Mar 14 12:46:30 +0000 2011",
    "user" : {
      "name" : "Dick Vitale",
      "screen_name" : "DickieV",
      "protected" : false,
      "id_str" : "78183672",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/483161586/DV_Profile_normal.gif",
      "id" : 78183672,
      "verified" : true
    }
  },
  "id" : 47347089277067264,
  "created_at" : "Mon Mar 14 17:23:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "47322346591227904",
  "text" : "class now, then going over my presentation that I worked all morning on with Shernita (@ McBryde Hall w/ 2 others) http://4sq.com/esOJey",
  "id" : 47322346591227904,
  "created_at" : "Mon Mar 14 15:45:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47110567583952896",
  "text" : "cracked a sam adams latitude 48 ipa to unpack, and daves grillin sausage! goin to bed asap",
  "id" : 47110567583952896,
  "created_at" : "Mon Mar 14 01:43:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "47100356638945280",
  "text" : "Ah, blacksburg....",
  "id" : 47100356638945280,
  "created_at" : "Mon Mar 14 01:02:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 27, 42 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46988546778738688",
  "text" : "on my solo groove now from @ryandelgiudice's",
  "id" : 46988546778738688,
  "created_at" : "Sun Mar 13 17:38:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46944941779333120",
  "text" : "Driver change!",
  "id" : 46944941779333120,
  "created_at" : "Sun Mar 13 14:45:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46925424239980544",
  "text" : "gettin a late start, gonna be a long day...thanks daylight savings time!!",
  "id" : 46925424239980544,
  "created_at" : "Sun Mar 13 13:27:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46827896869892098",
  "text" : "is aimin for 5hrs of sleep before a very long day of driving bak to bburg tmrw",
  "id" : 46827896869892098,
  "created_at" : "Sun Mar 13 07:00:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46650985577320448",
  "geo" : {
  },
  "id_str" : "46709611465682944",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis I bleed green!",
  "id" : 46709611465682944,
  "in_reply_to_status_id" : 46650985577320448,
  "created_at" : "Sat Mar 12 23:10:13 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46649019711229952",
  "text" : "Rode down to the parade! http://twitpic.com/48uo6v",
  "id" : 46649019711229952,
  "created_at" : "Sat Mar 12 19:09:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46500208678404096",
  "text" : "nvm, the #hokies won!! my tv froze right after fs hit that shot and I just turned it off, whoops! Time to beat duke again....",
  "id" : 46500208678404096,
  "created_at" : "Sat Mar 12 09:18:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 102, 115 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "su",
      "indices" : [ 45, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46495932522577921",
  "text" : "really tough losses for both the #hokies and #su...damn. st pattys day parade tmrw to make it better! @laurentappan we did! :)",
  "id" : 46495932522577921,
  "created_at" : "Sat Mar 12 09:01:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46349985490550784",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan we just finished the canned green beans you gave us forever ago lol",
  "id" : 46349985490550784,
  "created_at" : "Fri Mar 11 23:21:12 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46323479615774720",
  "text" : "back home, had a great time in Buffalo. homeworkkkkkk",
  "id" : 46323479615774720,
  "created_at" : "Fri Mar 11 21:35:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46258052940304384",
  "text" : "on the way to Brockport for late brunch and then back to syr",
  "id" : 46258052940304384,
  "created_at" : "Fri Mar 11 17:15:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.949967, -78.8272188 ]
  },
  "id_str" : "46082470759768064",
  "text" : "I'm at The Steer Restaurant & Saloon (3151 Main Street, Highgate Ave., Buffalo) http://4sq.com/er7Pjr",
  "id" : 46082470759768064,
  "created_at" : "Fri Mar 11 05:38:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 20, 27 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gaycommentofthenight",
      "indices" : [ 38, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46068904430280704",
  "text" : "\"every single thing @dzdan1 has said\" #gaycommentofthenight",
  "id" : 46068904430280704,
  "created_at" : "Fri Mar 11 04:44:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 34, 49 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 50, 57 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 58, 67 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "46068466997923841",
  "text" : "good win #hokies! goin outtt with @ryandelgiudice @DZdan1 @DKnick88",
  "id" : 46068466997923841,
  "created_at" : "Fri Mar 11 04:42:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45908408464969728",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 we're on our way!",
  "id" : 45908408464969728,
  "created_at" : "Thu Mar 10 18:06:32 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45328343637299200",
  "text" : "Just watched 180 south...another movie that makes you want to be a dirty hippie and \"just live life, man\"",
  "id" : 45328343637299200,
  "created_at" : "Wed Mar 09 03:41:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45327938740166657",
  "text" : "booo NY http://twitpic.com/47o1fr",
  "id" : 45327938740166657,
  "created_at" : "Wed Mar 09 03:39:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "45250904533909504",
  "text" : "can't believe how much snow there is in CNY! still glad to be home",
  "id" : 45250904533909504,
  "created_at" : "Tue Mar 08 22:33:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.980236, -76.305137 ]
  },
  "id_str" : "45201967525543936",
  "text" : "Home! (@ Reagan Stronghold) http://4sq.com/g87sC7",
  "id" : 45201967525543936,
  "created_at" : "Tue Mar 08 19:19:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 39, 54 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44908698589593601",
  "text" : "closin in on two hours from el casa de @ryandelgiudice!",
  "id" : 44908698589593601,
  "created_at" : "Mon Mar 07 23:54:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 16, 31 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 32, 41 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 42, 49 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 50, 61 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 62, 78 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 83, 92 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44841398981242881",
  "text" : "Oh yeah, to see @ryandelgiudice @DKnick88 @DZdan1 @kreagannet @RumblinStumblin and @dmreagan!! excited for this week!!",
  "id" : 44841398981242881,
  "created_at" : "Mon Mar 07 19:26:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44840906532204545",
  "text" : "50 and sunny in bburg, why am I driving north right now and not going for a ride?",
  "id" : 44840906532204545,
  "created_at" : "Mon Mar 07 19:24:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44818442884358144",
  "text" : "Ipa going into secondary, yum!! http://twitpic.com/477201",
  "id" : 44818442884358144,
  "created_at" : "Mon Mar 07 17:55:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44818335170441216",
  "text" : "Bottled raison d'etre http://twitpic.com/4771un",
  "id" : 44818335170441216,
  "created_at" : "Mon Mar 07 17:54:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44809780484775936",
  "text" : "is starting bottling now, then racking my beer. dang bottling is a lot of work.",
  "id" : 44809780484775936,
  "created_at" : "Mon Mar 07 17:20:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 0, 10 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44802162382999553",
  "geo" : {
  },
  "id_str" : "44809610217005056",
  "in_reply_to_user_id" : 73786966,
  "text" : "@SH13LDS21 yessir",
  "id" : 44809610217005056,
  "in_reply_to_status_id" : 44802162382999553,
  "created_at" : "Mon Mar 07 17:20:18 +0000 2011",
  "in_reply_to_screen_name" : "SH13LDS21",
  "in_reply_to_user_id_str" : "73786966",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44780329940156416",
  "text" : "is goin to get my oil changed...ill do it myself next time (the oil i got aint goin bad)",
  "id" : 44780329940156416,
  "created_at" : "Mon Mar 07 15:23:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 3, 18 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44762110063939584",
  "text" : "RT @ryandelgiudice: Heading back to Philly...back home to Syracuse tmrw!",
  "retweeted_status" : {
    "source" : "<a href=\"http://ubersocial.com\" rel=\"nofollow\">UberSocial Pro for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "44726477421424640",
    "text" : "Heading back to Philly...back home to Syracuse tmrw!",
    "id" : 44726477421424640,
    "created_at" : "Mon Mar 07 11:49:57 +0000 2011",
    "user" : {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "protected" : true,
      "id_str" : "44471444",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1264948750/DSC00020_normal.jpg",
      "id" : 44471444,
      "verified" : false
    }
  },
  "id" : 44762110063939584,
  "created_at" : "Mon Mar 07 14:11:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44576280225652736",
  "text" : "back at the house in #blacksburg, drinkin a celebration beer and unpacking. hung up my clothes from today and they're dripping all over...",
  "id" : 44576280225652736,
  "created_at" : "Mon Mar 07 01:53:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44512919513350144",
  "text" : "super super awesome weekend of racing. led most of the rr, had a ton of fun with the team, and raced strong in two criteriums today!",
  "id" : 44512919513350144,
  "created_at" : "Sun Mar 06 21:41:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "44388424072957952",
  "text" : "had an awesome day yesterday racing on the front and then chillin with the team. Slippery crit in an hour!",
  "id" : 44388424072957952,
  "created_at" : "Sun Mar 06 13:26:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43820537486639105",
  "text" : "just had a fun dinner with my research group, packing in 5min for the weekend then hittin the road with Andy Dub!",
  "id" : 43820537486639105,
  "created_at" : "Fri Mar 04 23:50:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43765821243277312",
  "geo" : {
  },
  "id_str" : "43798442790756352",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice sweeet!!!!",
  "id" : 43798442790756352,
  "in_reply_to_status_id" : 43765821243277312,
  "created_at" : "Fri Mar 04 22:22:17 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43554401696227328",
  "text" : "overall, an epic day. bed now, yoga and hw in the AM",
  "id" : 43554401696227328,
  "created_at" : "Fri Mar 04 06:12:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43527422787858432",
  "geo" : {
  },
  "id_str" : "43528008077807616",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie where was this??",
  "id" : 43528008077807616,
  "in_reply_to_status_id" : 43527422787858432,
  "created_at" : "Fri Mar 04 04:27:40 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 61, 68 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43429417174835200",
  "text" : "had a really fun time learning to ride a horse today! Thanks @rkay21! Class (ugh) and then hw...maybe a movie tonight?",
  "id" : 43429417174835200,
  "created_at" : "Thu Mar 03 21:55:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "43341739771183104",
  "text" : "and got a 95 on my numerical analysis project, yeah!! Plus a new record, my house to in class in 4min! http://4sq.com/gPj3aP",
  "id" : 43341739771183104,
  "created_at" : "Thu Mar 03 16:07:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43340822644670464",
  "text" : "Beautiful early morning ride and photoshoot, pretty cool having parparazzi...Justin and I felt like pros! 3 days hard training...legs hurt",
  "id" : 43340822644670464,
  "created_at" : "Thu Mar 03 16:03:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43276616834621440",
  "text" : "7am ride! Chelsea coming to follow in the car and take pictures for a photojournalism project, should b fun!",
  "id" : 43276616834621440,
  "created_at" : "Thu Mar 03 11:48:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43155165901107200",
  "text" : "just put the super cool Park Tool BO-2 to use! sierra nevada glissade, thanks Bradner. goin to bed after, long and exciting day tmrw",
  "id" : 43155165901107200,
  "created_at" : "Thu Mar 03 03:46:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 63, 75 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43154170437582849",
  "text" : "todays corrections: the winning DFH beer was a JOINT effort of @MechE_Hokie and I!! and abt 1/2 adv  calc turned their hw in at the end...",
  "id" : 43154170437582849,
  "created_at" : "Thu Mar 03 03:42:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43140970962890753",
  "geo" : {
  },
  "id_str" : "43153619100512256",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie my bad!!!!",
  "id" : 43153619100512256,
  "in_reply_to_status_id" : 43140970962890753,
  "created_at" : "Thu Mar 03 03:39:59 +0000 2011",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 42, 57 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43153221686001665",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin just talked to @ryandelgiudice, I'll be home Wed or Thurs for the second half of spring break at the shortest!",
  "id" : 43153221686001665,
  "created_at" : "Thu Mar 03 03:38:24 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43140109465436160",
  "geo" : {
  },
  "id_str" : "43140630045655040",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice answer your phone brah",
  "id" : 43140630045655040,
  "in_reply_to_status_id" : 43140109465436160,
  "created_at" : "Thu Mar 03 02:48:22 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43140561238114304",
  "text" : "got 3rd place in the competition!! won a bottle of DFH \"Old Ale\" and a DFH hat!",
  "id" : 43140561238114304,
  "created_at" : "Thu Mar 03 02:48:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43080339144458240",
  "text" : "Renewed my registration quick, it ran out yesterday whoops. Now gonna win some DFH vintage!!",
  "id" : 43080339144458240,
  "created_at" : "Wed Mar 02 22:48:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 99, 108 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43077517560647680",
  "text" : "just got back from a beautiful, super super hard ride with a lot of the team. eatin some delicious @dmreagan cookies then homebrew contest!",
  "id" : 43077517560647680,
  "created_at" : "Wed Mar 02 22:37:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 0, 10 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43041475386294272",
  "geo" : {
  },
  "id_str" : "43077072809242625",
  "in_reply_to_user_id" : 73786966,
  "text" : "@SH13LDS21 mmmm good smell",
  "id" : 43077072809242625,
  "in_reply_to_status_id" : 43041475386294272,
  "created_at" : "Wed Mar 02 22:35:49 +0000 2011",
  "in_reply_to_screen_name" : "SH13LDS21",
  "in_reply_to_user_id_str" : "73786966",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeopleForBikes.org",
      "screen_name" : "peopleforbikes",
      "indices" : [ 30, 45 ],
      "id_str" : "93892158",
      "id" : 93892158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43033758873567232",
  "text" : "got some super cool swag from @peopleforbikes today!! Wearin the socks riding now, bottle opener... maybe after! http://twitpic.com/45f963",
  "id" : 43033758873567232,
  "created_at" : "Wed Mar 02 19:43:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 57, 67 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43031563763597312",
  "text" : "GORGEOUS day out!! So warm, and sunny. Goin for a ride w @vtcycling @ 3 http://twitpic.com/45f6pr",
  "id" : 43031563763597312,
  "created_at" : "Wed Mar 02 19:34:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "43030654602067968",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin the \"lefty\" http://twitpic.com/45f5kz",
  "id" : 43030654602067968,
  "created_at" : "Wed Mar 02 19:31:22 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "42992247028977665",
  "text" : "typed my adv calc hw and handing in today, the only person in the class doing either...whuddup (due date extended 2 fri)",
  "id" : 42992247028977665,
  "created_at" : "Wed Mar 02 16:58:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42970863313764352",
  "geo" : {
  },
  "id_str" : "42978809024221184",
  "in_reply_to_user_id" : 33612141,
  "text" : "@jade_lemmerman everything is urgent, prioritize by what's important",
  "id" : 42978809024221184,
  "in_reply_to_status_id" : 42970863313764352,
  "created_at" : "Wed Mar 02 16:05:21 +0000 2011",
  "in_reply_to_screen_name" : "jadelemmerman",
  "in_reply_to_user_id_str" : "33612141",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42770008291540992",
  "geo" : {
  },
  "id_str" : "42971984354754560",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis Cecil is definitely looking to sell his powermeter.  I may also not want mine anymore. Porque?",
  "id" : 42971984354754560,
  "in_reply_to_status_id" : 42770008291540992,
  "created_at" : "Wed Mar 02 15:38:14 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42803080135311360",
  "text" : "the officiating was awful...really hurt us at the worst time...but still an overall poor shooting game by the #hokies. Exhausted...bed",
  "id" : 42803080135311360,
  "created_at" : "Wed Mar 02 04:27:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "42634969885052928",
  "text" : "Mmmmm fooooood (@ Dietrick Dining Center) http://4sq.com/e2liKr",
  "id" : 42634969885052928,
  "created_at" : "Tue Mar 01 17:19:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42628213469478912",
  "text" : "awesome ride this morning with Justin C and Zach M, the grass in Catawba valley is turning green! Headed to d2 for lunch",
  "id" : 42628213469478912,
  "created_at" : "Tue Mar 01 16:52:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42561286432768000",
  "text" : "Long ride!",
  "id" : 42561286432768000,
  "created_at" : "Tue Mar 01 12:26:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]