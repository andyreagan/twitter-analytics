Grailbird.data.tweets_2009_09 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4516462461",
  "text" : "is bedtime! Breakfast tomorrow, classes, then a meeting with bike co-op, potluck at DH's, and running galileo movie night!",
  "id" : 4516462461,
  "created_at" : "Thu Oct 01 03:49:23 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4511675960",
  "geo" : {
  },
  "id_str" : "4513187026",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet lauren and I are jealous of the hot tub lol we decided. Crazy weekend coming uo!",
  "id" : 4513187026,
  "in_reply_to_status_id" : 4511675960,
  "created_at" : "Thu Oct 01 01:30:19 +0000 2009",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4497974149",
  "geo" : {
  },
  "id_str" : "4503195495",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 you're at Clarkson, that's why lol. Not that it's any better in VA lol",
  "id" : 4503195495,
  "in_reply_to_status_id" : 4497974149,
  "created_at" : "Wed Sep 30 18:07:37 +0000 2009",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4497833072",
  "text" : "and I got an 82 on the ochem exam...pretty happy with that, bc I screwed up. I got the hang of it now...i'll do better next time",
  "id" : 4497833072,
  "created_at" : "Wed Sep 30 14:13:22 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 10, 21 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4497816055",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @kreagannet it's been cold and suuuper windy here for days, I'm finally seeing a little sunshine today...",
  "id" : 4497816055,
  "created_at" : "Wed Sep 30 14:12:32 +0000 2009",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4496774007",
  "text" : "Is doin work! A lot to do...",
  "id" : 4496774007,
  "created_at" : "Wed Sep 30 13:21:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4488252116",
  "text" : "also just finished \"A Pedaling Revolution: How Cyclists Are Changing American Cities\" by Jeff Mapes...maybe that's why.",
  "id" : 4488252116,
  "created_at" : "Wed Sep 30 03:11:55 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4488236970",
  "text" : "needs something new. I'm tired of our car culture.  It's dangerous, unhealthy, dissatisfying, and bad for the environment.",
  "id" : 4488236970,
  "created_at" : "Wed Sep 30 03:11:12 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4474072102",
  "text" : "is doin work today. Gotta finish orgo HW tonight...",
  "id" : 4474072102,
  "created_at" : "Tue Sep 29 16:43:04 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4461186077",
  "text" : "And they're delicious lol thanks mom! I'm pretty torn abt what to do this weekend...either Polyface farm or dominating mtb vs and at WVU",
  "id" : 4461186077,
  "created_at" : "Tue Sep 29 03:13:57 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4459809229",
  "geo" : {
  },
  "id_str" : "4461149030",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet impressive... I spent all night doing cycling order spreadsheets and meeting with the team/officers. Finished pb cookie bag #3",
  "id" : 4461149030,
  "in_reply_to_status_id" : 4459809229,
  "created_at" : "Tue Sep 29 03:12:18 +0000 2009",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4451597147",
  "text" : "squeezed in a bike ride...my left crank fell off twice!!",
  "id" : 4451597147,
  "created_at" : "Mon Sep 28 20:19:18 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 4, 15 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4449342989",
  "text" : "and @kreagannet I did a 3x8 of decline bench with 35lb and 40lb dumbells at the end, is that ok lol?",
  "id" : 4449342989,
  "created_at" : "Mon Sep 28 18:37:19 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4449326010",
  "text" : "has done everything but ride before physics....got a little over an hour to ride, not enough time :(",
  "id" : 4449326010,
  "created_at" : "Mon Sep 28 18:36:34 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4444500579",
  "text" : "5 hours to kill before class, and I need to eat, lift, ride, do the physics HW, and work on the cycling clothing spreadsheet...",
  "id" : 4444500579,
  "created_at" : "Mon Sep 28 15:05:57 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4441454302",
  "text" : "Hates how the ochem prof treates us like idiots during class saying how atoms are happy or unhappy or \"want\" something..but gives hard tests",
  "id" : 4441454302,
  "created_at" : "Mon Sep 28 12:29:41 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4420017743",
  "text" : "Got the phone back, d2 brunch down, and is going sailing!!",
  "id" : 4420017743,
  "created_at" : "Sun Sep 27 16:37:02 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4412608515",
  "text" : "is still phoneless...and had a great night rollerskating haha!",
  "id" : 4412608515,
  "created_at" : "Sun Sep 27 07:17:33 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4404902854",
  "text" : "'s phone is still at Dan Freeman's house, along with fixie...hence the lack of tweets. Sweet game today, despite the weather, skating 2nite!",
  "id" : 4404902854,
  "created_at" : "Sat Sep 26 23:46:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4376977371",
  "geo" : {
  },
  "id_str" : "4394447146",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice agreed.",
  "id" : 4394447146,
  "in_reply_to_status_id" : 4376977371,
  "created_at" : "Sat Sep 26 14:42:55 +0000 2009",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4394438946",
  "text" : "got in a great ride yesterday, some new sunglasses, and is ready for some fooootballl today!",
  "id" : 4394438946,
  "created_at" : "Sat Sep 26 14:42:27 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4371073708",
  "text" : "Va tech waffle!! What other college has that lol. Look at this spread lol http://pic.gd/787cee",
  "id" : 4371073708,
  "created_at" : "Fri Sep 25 15:47:13 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4369038690",
  "text" : "is signed up for intramural table tennis, and I'm totally bringin home the slam dunk contest in the spring!",
  "id" : 4369038690,
  "created_at" : "Fri Sep 25 14:13:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4367905185",
  "text" : "is not so sure about that ochem exam....don't think it went so well :/ and its raining and nasty outside :/",
  "id" : 4367905185,
  "created_at" : "Fri Sep 25 13:16:24 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yourlame",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4359519981",
  "text" : "#yourlame if you're in college and don't know the difference between your and you're, please.",
  "id" : 4359519981,
  "created_at" : "Fri Sep 25 03:13:59 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4358048202",
  "text" : "ran the table tennis table at Galileo, 3-0 baby. Organic practice test tonight and then bed for the 8AM exam tomorrow!",
  "id" : 4358048202,
  "created_at" : "Fri Sep 25 02:06:59 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4352762634",
  "text" : "just studied a little bit for ochem, but not taking the test tonight!!",
  "id" : 4352762634,
  "created_at" : "Thu Sep 24 22:08:45 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 28, 39 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4347911688",
  "text" : "goin to work out!! Doin the @kreagannet workout again!",
  "id" : 4347911688,
  "created_at" : "Thu Sep 24 18:16:37 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4345709292",
  "text" : "Found my bike lock! It was sitting in the back of ES, probably exactly where I left it two days ago haha.",
  "id" : 4345709292,
  "created_at" : "Thu Sep 24 16:39:02 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4343281383",
  "text" : "Dominated my physical chemistry test, 100 anyone?",
  "id" : 4343281383,
  "created_at" : "Thu Sep 24 14:54:01 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4330535329",
  "text" : "feels pretty good about the physical chemistry test tomorrow morning... and about a bike co-op on campus!!",
  "id" : 4330535329,
  "created_at" : "Thu Sep 24 01:19:53 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4325580863",
  "text" : "Got a good interval bike ride in today, too much goin on tonight! And a test tmrw and friday morning...I need to be studyin jeez.",
  "id" : 4325580863,
  "created_at" : "Wed Sep 23 21:25:36 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4313817437",
  "text" : "8AM ochem wooo! Test friday at 8AM sweet! I can take it Thurs night if I want...",
  "id" : 4313817437,
  "created_at" : "Wed Sep 23 12:08:27 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4304791243",
  "text" : "Tirrred. Gotta finish the ochem hw tonight...",
  "id" : 4304791243,
  "created_at" : "Wed Sep 23 01:55:57 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 4, 15 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4300876446",
  "text" : "did @kreagannet's workout today, gettin ripped! and I did a hill climb bike ride, gettin in shape!",
  "id" : 4300876446,
  "created_at" : "Tue Sep 22 23:05:25 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4164395601",
  "text" : "lee hall just lost power for two hours crazy!!",
  "id" : 4164395601,
  "created_at" : "Tue Sep 22 03:51:28 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4162454720",
  "text" : "@kreagennet WOW that's sick!! I weighed in at 176 today and benched 135lbs twice yesterday max lol. check your email!",
  "id" : 4162454720,
  "created_at" : "Tue Sep 22 02:22:07 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4148171432",
  "text" : "got a 88 on my physics test, better than expected! Finished the HW already today too. Can I fit a bike ride in??",
  "id" : 4148171432,
  "created_at" : "Mon Sep 21 15:20:30 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4146641772",
  "text" : "Its official: 198.6 (weight of me + fixie) - 176.1 (just me, with shoes and jeans lol) = 22.5 pounds, the weight of my steel frame fixie!",
  "id" : 4146641772,
  "created_at" : "Mon Sep 21 14:01:15 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4145664765",
  "text" : "Hopefully my physics TA is helpful today...I got HW to finish and then maybe riding but the weather suckkks.",
  "id" : 4145664765,
  "created_at" : "Mon Sep 21 13:02:58 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4131295408",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet obv we're seen the seinfeld, but i never made the connection to do it when I come home! like for thanksgiving i might have room",
  "id" : 4131295408,
  "created_at" : "Sun Sep 20 21:02:14 +0000 2009",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4106520414",
  "text" : "Just devised a brilliant plan, to get home for thanksgiving for free: fill my car with cans which have no value in VA, and 5 cents in NY...",
  "id" : 4106520414,
  "created_at" : "Sat Sep 19 17:45:55 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4102765760",
  "text" : "doesn't want to sell concessions at the game, but it may be better than watching it on TV...so I might do it.",
  "id" : 4102765760,
  "created_at" : "Sat Sep 19 14:17:41 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4097363659",
  "text" : "Bedtime! Sooo tired. Big game against Nebraska tmrw!!",
  "id" : 4097363659,
  "created_at" : "Sat Sep 19 05:46:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4090575417",
  "text" : "Just finished my physics test, and already missed three questions....",
  "id" : 4090575417,
  "created_at" : "Fri Sep 18 23:18:16 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4077602689",
  "text" : "Is in 8AM ochem still waking up...I thought ochem was supposed to be harder than gen chem?? Not looking forward to physics test tonight...",
  "id" : 4077602689,
  "created_at" : "Fri Sep 18 12:33:54 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4064926938",
  "text" : "Is at the clean energy rally woo!!",
  "id" : 4064926938,
  "created_at" : "Thu Sep 17 22:32:45 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4056455634",
  "geo" : {
  },
  "id_str" : "4058179578",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice well yes of course lol. I just set up bikeblacksburg.org, check it out! Finishing class then dinner with Lauren tonight :)",
  "id" : 4058179578,
  "in_reply_to_status_id" : 4056455634,
  "created_at" : "Thu Sep 17 17:03:26 +0000 2009",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4054543386",
  "text" : "D2 breakfast was better than expected...there's a quiz at the end of this pchem class, we'll see how that goes...",
  "id" : 4054543386,
  "created_at" : "Thu Sep 17 14:07:14 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4034391895",
  "text" : "Hahaha best bumper sticker ever http://mypict.me/EYVv",
  "id" : 4034391895,
  "created_at" : "Wed Sep 16 17:58:55 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4032141529",
  "text" : "send out the clothing order this morning, already ran into a problem, and it's just crazy with emails (and it's working now too)!",
  "id" : 4032141529,
  "created_at" : "Wed Sep 16 16:11:17 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4021688433",
  "text" : "And I'm now the owner of bikeblacksburg.org, the future home for the bike co-op and bike share programs...cool stuff happening with those",
  "id" : 4021688433,
  "created_at" : "Wed Sep 16 03:39:08 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4021647156",
  "text" : "Bed early for 8AM ochem again, at least I still understand it lol. (Unlike pchem, just looked at the HW, insane)",
  "id" : 4021647156,
  "created_at" : "Wed Sep 16 03:36:51 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4018991373",
  "text" : "is done with physics hw, organic hw, and painting my fixie now! free time what? oh wait, got the bike toaster to finish haha",
  "id" : 4018991373,
  "created_at" : "Wed Sep 16 01:30:37 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4010401830",
  "text" : "Painting complete! http://mypict.me/Ehfm",
  "id" : 4010401830,
  "created_at" : "Tue Sep 15 18:44:54 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4007430114",
  "text" : "Mmm philly cheesesteak haha. ES class then stuff, ES HW, more ES class, and lots of Organic HW.",
  "id" : 4007430114,
  "created_at" : "Tue Sep 15 16:15:36 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 43, 54 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4005433535",
  "text" : "Almost done with physical chemistry...then @kreagannet I'm gonna mail that stuff today!",
  "id" : 4005433535,
  "created_at" : "Tue Sep 15 14:32:58 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 41, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3985458539",
  "text" : "Someone stole my xbox faceplate...sweet. #FB",
  "id" : 3985458539,
  "created_at" : "Mon Sep 14 18:27:02 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3983024653",
  "text" : "Spent 3 hours this morning on physics and is almost done...time for lunch and trying to get the cycling order pushed out.",
  "id" : 3983024653,
  "created_at" : "Mon Sep 14 16:20:20 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3958173027",
  "geo" : {
  },
  "id_str" : "3960536303",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia haha that's just an old frame that I've been working on...I sanded down, primed and painted it and I'm building it up as a commuter!",
  "id" : 3960536303,
  "in_reply_to_status_id" : 3958173027,
  "created_at" : "Sun Sep 13 19:44:14 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3948830133",
  "geo" : {
  },
  "id_str" : "3953811148",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia haha Christmas time what??",
  "id" : 3953811148,
  "in_reply_to_status_id" : 3948830133,
  "created_at" : "Sun Sep 13 12:40:00 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3944054954",
  "text" : "Is a fan of cornhole",
  "id" : 3944054954,
  "created_at" : "Sat Sep 12 23:50:49 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3942557006",
  "text" : "Red and shiny...love it. This picture does absolutely no justice http://mypict.me/CiUz",
  "id" : 3942557006,
  "created_at" : "Sat Sep 12 22:23:01 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3941703924",
  "text" : "Goin to meet ppl after the game...then workin on the fixie and possibly looking for my oaks",
  "id" : 3941703924,
  "created_at" : "Sat Sep 12 21:32:50 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3937833903",
  "text" : "Hell yeahhh http://mypict.me/CaMa",
  "id" : 3937833903,
  "created_at" : "Sat Sep 12 17:51:06 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3936188563",
  "text" : "Is at the Tech football game!!",
  "id" : 3936188563,
  "created_at" : "Sat Sep 12 16:20:01 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3887324065",
  "text" : "Walked to class this morning for the first time, and it sucks haha I know why I bike. (Dave borrowed my bike lock so I couldn't)",
  "id" : 3887324065,
  "created_at" : "Thu Sep 10 13:40:52 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3885675685",
  "geo" : {
  },
  "id_str" : "3886814303",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia I'm almost three weeks in, suck it up lol. I just hope I got half of my physical chemistry hw right...then d2 lunch!",
  "id" : 3886814303,
  "in_reply_to_status_id" : 3885675685,
  "created_at" : "Thu Sep 10 13:09:32 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3881433902",
  "text" : "Is in bed...pchem early, damn that hw was hard. Applied for my passport today haha so I got somethin done",
  "id" : 3881433902,
  "created_at" : "Thu Sep 10 05:04:03 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3873501150",
  "text" : "Is doin HW tonight...",
  "id" : 3873501150,
  "created_at" : "Wed Sep 09 22:40:56 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3856490384",
  "text" : "Survived a busy night and drafted a halfway decent team in the process I think. Organic chemistry at 8AM can't wait!",
  "id" : 3856490384,
  "created_at" : "Wed Sep 09 03:57:44 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3833453020",
  "geo" : {
  },
  "id_str" : "3839086813",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet good luck on your first day! I might go get breakfast before my 9:30 physical chemistry...too early to think, so who knows.",
  "id" : 3839086813,
  "in_reply_to_status_id" : 3833453020,
  "created_at" : "Tue Sep 08 12:25:48 +0000 2009",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3832566783",
  "text" : "is goin to deets! Tomorrow night has too many things going on...its like my schedule is bipolar or somethin lol.",
  "id" : 3832566783,
  "created_at" : "Tue Sep 08 03:08:50 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3819198398",
  "text" : "had two classes this morning and is free till 4!",
  "id" : 3819198398,
  "created_at" : "Mon Sep 07 14:35:35 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3809421102",
  "text" : "just dominated physics 2. Pics of the MTB race this weekend: http://picasaweb.google.com/vtcycling",
  "id" : 3809421102,
  "created_at" : "Mon Sep 07 01:31:43 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3807645268",
  "text" : "doin HW...maybe watching a movie later, borrowed Shawshank Redemption and its supposed to be really good.",
  "id" : 3807645268,
  "created_at" : "Sun Sep 06 23:43:37 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3803951795",
  "text" : "Is beaten from the MTB race...crashed like 5 times the course was rediculous, but I finished well somehow! Now its D2, work, mass...pass out",
  "id" : 3803951795,
  "created_at" : "Sun Sep 06 19:53:19 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3782145773",
  "geo" : {
  },
  "id_str" : "3792736307",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia hope you had fun riding! Come to VA and u could ride every day lol were having our home mountain bike race this weekend its sweet!",
  "id" : 3792736307,
  "in_reply_to_status_id" : 3782145773,
  "created_at" : "Sun Sep 06 04:18:35 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3792675264",
  "text" : "Just updated the blog check it out lol blog.andyreagan.com! More MTB racing in the AM!!",
  "id" : 3792675264,
  "created_at" : "Sun Sep 06 04:14:29 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 40, 51 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 88, 95 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3760948647",
  "text" : "is doin laundry in new hall west lol... @kreagannet tell me more about this system! and @kaitia I'm great haha! crazy busy and I love it!",
  "id" : 3760948647,
  "created_at" : "Fri Sep 04 17:16:07 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3755890449",
  "geo" : {
  },
  "id_str" : "3757791241",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia glad to hear! How are things in NY?",
  "id" : 3757791241,
  "in_reply_to_status_id" : 3755890449,
  "created_at" : "Fri Sep 04 14:33:48 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3755876472",
  "text" : "Just ran for an hour before my 8AM class, fun fridays!",
  "id" : 3755876472,
  "created_at" : "Fri Sep 04 12:40:26 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3747512994",
  "text" : "Is whipped from swim practice and I have an 8AM...goin to bed.",
  "id" : 3747512994,
  "created_at" : "Fri Sep 04 01:54:19 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3737260388",
  "text" : "Hungrrry...haven't eaten yet today! And were talking about food in ES!!",
  "id" : 3737260388,
  "created_at" : "Thu Sep 03 16:55:15 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3734196385",
  "text" : "Likes (and understands) physical chemistry so far! We have a quiz now :-O. And D2 after?",
  "id" : 3734196385,
  "created_at" : "Thu Sep 03 14:14:23 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3728413347",
  "text" : "Is going to bed...just watched Into The Wild and I really excited for this next summer!",
  "id" : 3728413347,
  "created_at" : "Thu Sep 03 05:52:29 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3720064495",
  "geo" : {
  },
  "id_str" : "3720427117",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 excellent. I just came one piece shy of eating a whole free pizza but they ran out (I'm still hungry lol). How's the tundra?",
  "id" : 3720427117,
  "in_reply_to_status_id" : 3720064495,
  "created_at" : "Wed Sep 02 22:26:20 +0000 2009",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3719045459",
  "text" : "Doesn't particularly want to go to club officer training...not even for free food.",
  "id" : 3719045459,
  "created_at" : "Wed Sep 02 21:14:00 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3715811312",
  "text" : "Just read almost half of a book!",
  "id" : 3715811312,
  "created_at" : "Wed Sep 02 18:16:13 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3714186287",
  "text" : "How many times can I say? Best food in the nation. Best food in the nation. Best food in the nation. Best food in the nation. Best food in t",
  "id" : 3714186287,
  "created_at" : "Wed Sep 02 16:38:14 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 6, 15 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 16, 27 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 28, 43 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3710907864",
  "text" : "c'mon @dmreagan @kreagannet @ryandelgiudice! I wanna see some tweets lol!",
  "id" : 3710907864,
  "created_at" : "Wed Sep 02 13:15:51 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3710342852",
  "text" : "Is lovin 8AM ochem lol....and passed 5000 miles on my bike this morning on the way here!!",
  "id" : 3710342852,
  "created_at" : "Wed Sep 02 12:35:41 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3704765736",
  "text" : "On the whole, good day :)",
  "id" : 3704765736,
  "created_at" : "Wed Sep 02 04:13:07 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3693904921",
  "text" : "is waitin for his next class... good day so far :)",
  "id" : 3693904921,
  "created_at" : "Tue Sep 01 18:37:01 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]