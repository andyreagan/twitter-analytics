Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 34, 41 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/K8uh5Oh0",
      "expanded_url" : "http://www.youtube.com/watch?v=HpY3ggKAPIE",
      "display_url" : "youtube.com/watch?v=HpY3gg…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "197070945620475904",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice @DKnick88 too bad @DZdan1 woudn't understand http://t.co/K8uh5Oh0",
  "id" : 197070945620475904,
  "created_at" : "Mon Apr 30 21:12:29 +0000 2012",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weak",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/yAotEBkO",
      "expanded_url" : "http://peakraces.peak.com/deathrace/",
      "display_url" : "peakraces.peak.com/deathrace/"
    } ]
  },
  "in_reply_to_status_id_str" : "197021774267949057",
  "geo" : {
  },
  "id_str" : "197026418406850560",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 #weak \"NO fire, NO barbed wire and NO electric shocks!\" how about \"DEATH RACE\": http://t.co/yAotEBkO",
  "id" : 197026418406850560,
  "in_reply_to_status_id" : 197021774267949057,
  "created_at" : "Mon Apr 30 18:15:33 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196774708795019264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4788444, -73.2007923 ]
  },
  "id_str" : "196799977249447938",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill siiiiick!! can I ride it can I ride it??",
  "id" : 196799977249447938,
  "in_reply_to_status_id" : 196774708795019264,
  "created_at" : "Mon Apr 30 03:15:45 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 19, 33 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "196396372633731072",
  "text" : "congratulations to @ChrisDanforth on receiving tenure!!",
  "id" : 196396372633731072,
  "created_at" : "Sun Apr 29 00:31:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "196392529216815106",
  "text" : "finished the second season of Mad Men today...now to finish real analysis for the semester!",
  "id" : 196392529216815106,
  "created_at" : "Sun Apr 29 00:16:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boss",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/PGevDoHT",
      "expanded_url" : "http://www.adkultracycling.com/adk540/",
      "display_url" : "adkultracycling.com/adk540/"
    } ]
  },
  "in_reply_to_status_id_str" : "195968425149988865",
  "geo" : {
  },
  "id_str" : "195972570225459201",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD like a #boss! I'm thinking about racing this fall: http://t.co/PGevDoHT to qualify a team for RAAM, win it next year??",
  "id" : 195972570225459201,
  "in_reply_to_status_id" : 195968425149988865,
  "created_at" : "Fri Apr 27 20:27:56 +0000 2012",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/195962972076638208/photo/1",
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/0jTfvMNZ",
      "media_url" : "http://pbs.twimg.com/media/ArgzSOxCAAA3YH9.jpg",
      "id_str" : "195962972085026816",
      "id" : 195962972085026816,
      "media_url_https" : "https://pbs.twimg.com/media/ArgzSOxCAAA3YH9.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/0jTfvMNZ"
    } ],
    "hashtags" : [ {
      "text" : "wedontmessaround",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "195962972076638208",
  "text" : "digital scoreboard for the farrell hall foos bowl tourney! #wedontmessaround http://t.co/0jTfvMNZ",
  "id" : 195962972076638208,
  "created_at" : "Fri Apr 27 19:49:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195939198266650626",
  "text" : "almost 4 month check in: cycled 1074 miles and driven 2378 miles, not bad!",
  "id" : 195939198266650626,
  "created_at" : "Fri Apr 27 18:15:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 3, 17 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/cTccJcJr",
      "expanded_url" : "http://is.gd/afSBtN",
      "display_url" : "is.gd/afSBtN"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195897344041025537",
  "text" : "RT @ChrisKingBuzz: Our friends in the UK  sharing knowledge How Things Work: The Freehub Body - Dirt\nhttp://t.co/cTccJcJr",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http://t.co/cTccJcJr",
        "expanded_url" : "http://is.gd/afSBtN",
        "display_url" : "is.gd/afSBtN"
      } ]
    },
    "geo" : {
    },
    "id_str" : "195894891186888705",
    "text" : "Our friends in the UK  sharing knowledge How Things Work: The Freehub Body - Dirt\nhttp://t.co/cTccJcJr",
    "id" : 195894891186888705,
    "created_at" : "Fri Apr 27 15:19:16 +0000 2012",
    "user" : {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "protected" : false,
      "id_str" : "113114946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3184873192/e60b1eaffb311509c692e46648cd2b64_normal.jpeg",
      "id" : 113114946,
      "verified" : false
    }
  },
  "id" : 195897344041025537,
  "created_at" : "Fri Apr 27 15:29:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195893857475493890",
  "text" : "only 7 classes left this semester...where did it go?",
  "id" : 195893857475493890,
  "created_at" : "Fri Apr 27 15:15:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/195642111478079488/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/xgRkc9kN",
      "media_url" : "http://pbs.twimg.com/media/ArcPdr3CIAE9nXP.jpg",
      "id_str" : "195642111478079489",
      "id" : 195642111478079489,
      "media_url_https" : "https://pbs.twimg.com/media/ArcPdr3CIAE9nXP.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/xgRkc9kN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4980936, -73.2004885 ]
  },
  "id_str" : "195642111478079488",
  "text" : "droid forgot the pic http://t.co/xgRkc9kN",
  "id" : 195642111478079488,
  "created_at" : "Thu Apr 26 22:34:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832506333, -73.1937380333 ]
  },
  "id_str" : "195641148285530112",
  "text" : "right, so the limit as h goes to 0....",
  "id" : 195641148285530112,
  "created_at" : "Thu Apr 26 22:30:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCN12",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "195640591546204162",
  "text" : "shoulders still sore from #USATCN12... going for a swim to hopefully loosen up! wish I had my bicycle back though",
  "id" : 195640591546204162,
  "created_at" : "Thu Apr 26 22:28:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KBVCM2012",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/0aquy5IP",
      "expanded_url" : "http://zerotoboston.com/category/smart-alec-marathon-posters/",
      "display_url" : "zerotoboston.com/category/smart…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "195376043530522624",
  "text" : "excellent ideas for the Burlington marathon (no, not running it!) #KBVCM2012 http://t.co/0aquy5IP",
  "id" : 195376043530522624,
  "created_at" : "Thu Apr 26 04:57:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Pattison",
      "screen_name" : "espattison",
      "indices" : [ 0, 11 ],
      "id_str" : "549445630",
      "id" : 549445630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195371668267466752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4859356167, -73.2083552333 ]
  },
  "id_str" : "195372040356761600",
  "in_reply_to_user_id" : 549445630,
  "text" : "@espattison so close...well that's exciting!! I will be holding the \"this parade sucks\" sign :P",
  "id" : 195372040356761600,
  "in_reply_to_status_id" : 195371668267466752,
  "created_at" : "Thu Apr 26 04:41:38 +0000 2012",
  "in_reply_to_screen_name" : "espattison",
  "in_reply_to_user_id_str" : "549445630",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Pattison",
      "screen_name" : "espattison",
      "indices" : [ 0, 11 ],
      "id_str" : "549445630",
      "id" : 549445630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KBVCM2012",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195362629026463744",
  "geo" : {
  },
  "id_str" : "195371342114201600",
  "in_reply_to_user_id" : 549445630,
  "text" : "@espattison can I ask what #KBVCM2012 is? best guess: k... burlington vermont city marathon?",
  "id" : 195371342114201600,
  "in_reply_to_status_id" : 195362629026463744,
  "created_at" : "Thu Apr 26 04:38:52 +0000 2012",
  "in_reply_to_screen_name" : "espattison",
  "in_reply_to_user_id_str" : "549445630",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4858105833, -73.208542 ]
  },
  "id_str" : "195316775565533185",
  "text" : "running store is 5.5 miles away...so it's only right to run there for a new pair! excellent light run",
  "id" : 195316775565533185,
  "created_at" : "Thu Apr 26 01:02:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194966000289058816",
  "text" : "that feeling of safety you get when cops cars surround the house across the street, spotlights going",
  "id" : 194966000289058816,
  "created_at" : "Wed Apr 25 01:48:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194587708058910721",
  "text" : "so this is what getting burnt out on analysis feels like....",
  "id" : 194587708058910721,
  "created_at" : "Tue Apr 24 00:44:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194414075713830912",
  "text" : "oh yeah, class. but only 1.5 weeks left!",
  "id" : 194414075713830912,
  "created_at" : "Mon Apr 23 13:15:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/Kp43KFkG",
      "expanded_url" : "http://bit.ly/JEtmca",
      "display_url" : "bit.ly/JEtmca"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194137687391862784",
  "text" : "a closer look at the rookie mistake of triathlon...averaged 185bpm (95% of max HR) for 30min swim http://t.co/Kp43KFkG",
  "id" : 194137687391862784,
  "created_at" : "Sun Apr 22 18:56:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/jv2pAkXE",
      "expanded_url" : "http://4sq.com/HTFSFm",
      "display_url" : "4sq.com/HTFSFm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8530437018, -77.0423126221 ]
  },
  "id_str" : "194120962260742144",
  "text" : "almost backkk (@ Ronald Reagan Washington National Airport (DCA) w/ 59 others) http://t.co/jv2pAkXE",
  "id" : 194120962260742144,
  "created_at" : "Sun Apr 22 17:50:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194073313226657792",
  "text" : "during the race, swore I wouldn't do another tri until I could swim a 1:00 100m. killing myself in a tiny wetsuit was rough",
  "id" : 194073313226657792,
  "created_at" : "Sun Apr 22 14:40:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/LeNAq0VB",
      "expanded_url" : "http://en.wikipedia.org/wiki/Birmingham-Shuttlesworth_International_Airport",
      "display_url" : "en.wikipedia.org/wiki/Birmingha…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194073053058174976",
  "text" : "@axetickle it's BHM, but this one: http://t.co/LeNAq0VB I was in for the weekend for a triathlon",
  "id" : 194073053058174976,
  "created_at" : "Sun Apr 22 14:39:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCN12",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/PEtlPCfq",
      "expanded_url" : "http://www.pigmantri.com/jmsracing/results12/usatcollegiate12b.html",
      "display_url" : "pigmantri.com/jmsracing/resu…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "194072798178721792",
  "text" : "full results for #USATCN12 are up: (probably have been) http://t.co/PEtlPCfq",
  "id" : 194072798178721792,
  "created_at" : "Sun Apr 22 14:38:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194072547782963200",
  "text" : "@axetickle yuppp.",
  "id" : 194072547782963200,
  "created_at" : "Sun Apr 22 14:37:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTV",
      "indices" : [ 50, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "194068180543602689",
  "text" : "chillin in the Birmingham airport, be back in the #BTV by 5!",
  "id" : 194068180543602689,
  "created_at" : "Sun Apr 22 14:20:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194065351552671744",
  "geo" : {
  },
  "id_str" : "194067629181386752",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 crush!!",
  "id" : 194067629181386752,
  "in_reply_to_status_id" : 194065351552671744,
  "created_at" : "Sun Apr 22 14:18:23 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193929438839308288",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris hope the drive is going well!!!",
  "id" : 193929438839308288,
  "created_at" : "Sun Apr 22 05:09:15 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dirtymullet",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193929051998650368",
  "text" : "guy at bar came up to me and told me that I have the best mullet he's ever seen, and just wanted to congratulate #dirtymullet",
  "id" : 193929051998650368,
  "created_at" : "Sun Apr 22 05:07:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193925158552080386",
  "text" : "phone is still dead. sometimes life would be simpler without it... people would have to keep plans!",
  "id" : 193925158552080386,
  "created_at" : "Sun Apr 22 04:52:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193925012753887232",
  "text" : "back at the hotel! after some post race recovery, watching the relay race, napping in the park and hitting up the bars!",
  "id" : 193925012753887232,
  "created_at" : "Sun Apr 22 04:51:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 0, 12 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 13, 24 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193849620714102784",
  "in_reply_to_user_id" : 47645908,
  "text" : "@VTTriathlon @andyreagan Andy, we wont be at the pizza place by 7:30. get in touch if you can/care?",
  "id" : 193849620714102784,
  "created_at" : "Sat Apr 21 23:52:05 +0000 2012",
  "in_reply_to_screen_name" : "VTTriathlon",
  "in_reply_to_user_id_str" : "47645908",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCN12",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2099059167, -87.5693496667 ]
  },
  "id_str" : "193781910835695616",
  "text" : "is alive and kicking after a tough race! rookie mistake pushed way too hard on swim, finished 2:40ish #USATCN12",
  "id" : 193781910835695616,
  "created_at" : "Sat Apr 21 19:23:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193649923168800768",
  "geo" : {
  },
  "id_str" : "193668558104952832",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser thanks!!",
  "id" : 193668558104952832,
  "in_reply_to_status_id" : 193649923168800768,
  "created_at" : "Sat Apr 21 11:52:37 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193668492820623360",
  "text" : "got the wetsuit that I forgot at the hotel, ready to race!!",
  "id" : 193668492820623360,
  "created_at" : "Sat Apr 21 11:52:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVMTriathlon",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "USATCN12",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193668431403429889",
  "text" : "RT @UVMTriathlon: GO CATS GO!!! The big day is finally here! #UVMTriathlon  #USATCN12",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UVMTriathlon",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "USATCN12",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "193661766734069760",
    "text" : "GO CATS GO!!! The big day is finally here! #UVMTriathlon  #USATCN12",
    "id" : 193661766734069760,
    "created_at" : "Sat Apr 21 11:25:37 +0000 2012",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 193668431403429889,
  "created_at" : "Sat Apr 21 11:52:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.20992705, -87.56905075 ]
  },
  "id_str" : "193644054079209473",
  "text" : "raceday!! number on, putting bikes in transistion!",
  "id" : 193644054079209473,
  "created_at" : "Sat Apr 21 10:15:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/193477920335990784/photo/1",
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/6NdpWDHq",
      "media_url" : "http://pbs.twimg.com/media/Aq9fJLnCEAIa3Cv.jpg",
      "id_str" : "193477920340185090",
      "id" : 193477920340185090,
      "media_url_https" : "https://pbs.twimg.com/media/Aq9fJLnCEAIa3Cv.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/6NdpWDHq"
    } ],
    "hashtags" : [ {
      "text" : "USATCN12",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2100699667, -87.56642665 ]
  },
  "id_str" : "193477920335990784",
  "text" : "the #USATCN12 pasta dinner was a cornacopia of awesome outfits http://t.co/6NdpWDHq",
  "id" : 193477920335990784,
  "created_at" : "Fri Apr 20 23:15:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 3, 13 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2100655167, -87.5664150167 ]
  },
  "id_str" : "193477528919359488",
  "text" : "RT @WyattLoud @andyreagan's mullet is even more majestic in person",
  "id" : 193477528919359488,
  "created_at" : "Fri Apr 20 23:13:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 3, 13 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "carboload",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "USATCN12",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/v54BEExq",
      "expanded_url" : "http://twitpic.com/9c4msl",
      "display_url" : "twitpic.com/9c4msl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2110329833, -87.5655600833 ]
  },
  "id_str" : "193477292222193665",
  "text" : "RT @WyattLoud #carboload #USATCN12 http://t.co/v54BEExq",
  "id" : 193477292222193665,
  "created_at" : "Fri Apr 20 23:12:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2063166, -87.5678845 ]
  },
  "id_str" : "193379289356447746",
  "text" : "registered for the race! Watch out for number 1087!",
  "id" : 193379289356447746,
  "created_at" : "Fri Apr 20 16:43:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATNC12",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "193358318205542400",
  "text" : "bike assembled and loaded up. headed to pick up packet and pre ride the course!! #USATNC12",
  "id" : 193358318205542400,
  "created_at" : "Fri Apr 20 15:19:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2370871, -87.5641853 ]
  },
  "id_str" : "193169561393168384",
  "text" : "the bike survived shipping with only a bent shifter and two plastic wheel cover screws broken, not bad!",
  "id" : 193169561393168384,
  "created_at" : "Fri Apr 20 02:49:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 1, 14 ],
      "id_str" : "14630047",
      "id" : 14630047
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 21, 33 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 38, 51 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "USATCN12",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.2313034667, -87.5357686333 ]
  },
  "id_str" : "193119484339421184",
  "text" : ".@usatriathlon teams @VTTriathlon and @uvmtriathlon getting social! Dinner at Olive Garden for 34 #awesome #USATCN12",
  "id" : 193119484339421184,
  "created_at" : "Thu Apr 19 23:30:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/YQzjCae3",
      "expanded_url" : "http://www.ncbi.nlm.nih.gov/pubmed/22450589",
      "display_url" : "ncbi.nlm.nih.gov/pubmed/22450589"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193104666492534784",
  "text" : "elite runners (Geb) lose 10% of body weight during world record marathon efforts (think of losing 10% of yours) http://t.co/YQzjCae3",
  "id" : 193104666492534784,
  "created_at" : "Thu Apr 19 22:31:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 15, 28 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/2B8Ai516",
      "expanded_url" : "http://bit.ly/IYzFvb",
      "display_url" : "bit.ly/IYzFvb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "193103532461801472",
  "text" : "Shakeout run w @uvmtriathlon ( by andyreagan at Garmin Connect - Details: http://t.co/2B8Ai516 )",
  "id" : 193103532461801472,
  "created_at" : "Thu Apr 19 22:27:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 51, 64 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 67, 79 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.24106455, -87.5774151 ]
  },
  "id_str" : "193048995180974081",
  "text" : "making dinner reservations for THIRTY FOUR people! @uvmtriathlon + @VTTriathlon!",
  "id" : 193048995180974081,
  "created_at" : "Thu Apr 19 18:50:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/WHY4Kcty",
      "expanded_url" : "http://goo.gl/tl5PS",
      "display_url" : "goo.gl/tl5PS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192994619934519296",
  "text" : "RT @bakadesuyo: What do very happy people all have in common? http://t.co/WHY4Kcty",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http://t.co/WHY4Kcty",
        "expanded_url" : "http://goo.gl/tl5PS",
        "display_url" : "goo.gl/tl5PS"
      } ]
    },
    "geo" : {
    },
    "id_str" : "192975917377785856",
    "text" : "What do very happy people all have in common? http://t.co/WHY4Kcty",
    "id" : 192975917377785856,
    "created_at" : "Thu Apr 19 14:00:18 +0000 2012",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 192994619934519296,
  "created_at" : "Thu Apr 19 15:14:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/RB9lkGv6",
      "expanded_url" : "http://4sq.com/HPFeYa",
      "display_url" : "4sq.com/HPFeYa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.5614231975, -86.7526817322 ]
  },
  "id_str" : "192989591647698945",
  "text" : "landed! (@ Birmingham-Shuttlesworth International Airport (BHM) w/ 6 others) http://t.co/RB9lkGv6",
  "id" : 192989591647698945,
  "created_at" : "Thu Apr 19 14:54:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/nX4V5xLy",
      "expanded_url" : "http://4sq.com/J76JjZ",
      "display_url" : "4sq.com/J76JjZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8530437018, -77.0423126221 ]
  },
  "id_str" : "192934759691857920",
  "text" : "begin sprint to next flight! (@ Ronald Reagan Washington National Airport (DCA) w/ 62 others) http://t.co/nX4V5xLy",
  "id" : 192934759691857920,
  "created_at" : "Thu Apr 19 11:16:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 21, 34 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/07Tz4VDN",
      "expanded_url" : "http://4sq.com/HSkzmO",
      "display_url" : "4sq.com/HSkzmO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4691404687, -73.1549537061 ]
  },
  "id_str" : "192912119694503938",
  "text" : "headed to ALABAMAAAA @uvmtriathlon (@ Burlington International Airport (BTV) w/ 2 others) http://t.co/07Tz4VDN",
  "id" : 192912119694503938,
  "created_at" : "Thu Apr 19 09:46:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192782051513085952",
  "geo" : {
  },
  "id_str" : "192782604867616768",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis ha, thanks!!",
  "id" : 192782604867616768,
  "in_reply_to_status_id" : 192782051513085952,
  "created_at" : "Thu Apr 19 01:12:09 +0000 2012",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 57, 64 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192782485132804096",
  "text" : "betting whether I'll wear it for the flight tomorrow? if @ttmill ups the bet to 4 balance bars...he's gonna lose 'em",
  "id" : 192782485132804096,
  "created_at" : "Thu Apr 19 01:11:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 21, 34 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/192780358129954817/photo/1",
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/9Rl2ccA3",
      "media_url" : "http://pbs.twimg.com/media/Aqzktt5CMAIsuaH.jpg",
      "id_str" : "192780358134149122",
      "id" : 192780358134149122,
      "media_url_https" : "https://pbs.twimg.com/media/Aqzktt5CMAIsuaH.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/9Rl2ccA3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192780358129954817",
  "text" : "its gettin serious w @uvmtriathlon skinsuit, but the only one I could borrow was a small. warning graphic content http://t.co/9Rl2ccA3",
  "id" : 192780358129954817,
  "created_at" : "Thu Apr 19 01:03:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192777421173432320",
  "text" : "the dream kept alive by forfeit, team No Game This Week moves on! still got a good game of 4v4 in",
  "id" : 192777421173432320,
  "created_at" : "Thu Apr 19 00:51:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IHVPA",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/s72ZhSui",
      "expanded_url" : "http://bit.ly/J4aRRA",
      "display_url" : "bit.ly/J4aRRA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "192725293281193984",
  "text" : "has done the maths, and is going to break 100mph on a tandem bike. #IHVPA get ready http://t.co/s72ZhSui",
  "id" : 192725293281193984,
  "created_at" : "Wed Apr 18 21:24:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/192423532662226944/photo/1",
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/WhdmtXAp",
      "media_url" : "http://pbs.twimg.com/media/AqugLvcCAAMGsv9.jpg",
      "id_str" : "192423532666421251",
      "id" : 192423532666421251,
      "media_url_https" : "https://pbs.twimg.com/media/AqugLvcCAAMGsv9.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/WhdmtXAp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192423532662226944",
  "text" : "fun, eventful ride w Kam and Paul. A flat a broken chain but we survived for maple Cree-me's at the end! http://t.co/WhdmtXAp",
  "id" : 192423532662226944,
  "created_at" : "Wed Apr 18 01:25:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 0, 13 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192061610452459521",
  "geo" : {
  },
  "id_str" : "192088241485254656",
  "in_reply_to_user_id" : 328777340,
  "text" : "@DaBrownNoise finally learning some Vermont ways... but I like how \"getting a creamie\" could be taken so many ways",
  "id" : 192088241485254656,
  "in_reply_to_status_id" : 192061610452459521,
  "created_at" : "Tue Apr 17 03:13:00 +0000 2012",
  "in_reply_to_screen_name" : "DaBrownNoise",
  "in_reply_to_user_id_str" : "328777340",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192060520302526464",
  "text" : "the Burlington Bay's Maple Creamie is amazing...maple soft serve on a waffle cone for 2.50 next to water!!",
  "id" : 192060520302526464,
  "created_at" : "Tue Apr 17 01:22:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192058482407645184",
  "geo" : {
  },
  "id_str" : "192060264848433152",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw I plan on keeping it for as long as I can! hoping it gives me magical cycling mullet power",
  "id" : 192060264848433152,
  "in_reply_to_status_id" : 192058482407645184,
  "created_at" : "Tue Apr 17 01:21:50 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192035368017723392",
  "geo" : {
  },
  "id_str" : "192059300993175552",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e don't worry you won't have to see me like this :P BTW I'll be in nova on June 1-2 for a friend's wedding!",
  "id" : 192059300993175552,
  "in_reply_to_status_id" : 192035368017723392,
  "created_at" : "Tue Apr 17 01:18:00 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192059099775639552",
  "text" : "@axetickle thanks! really should've rocked this for the conference...",
  "id" : 192059099775639552,
  "created_at" : "Tue Apr 17 01:17:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 61, 74 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192039375993962497",
  "geo" : {
  },
  "id_str" : "192058887069904896",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia you DEF wouldn't recognize me in the street now! the @uvmtriathlon team is all doing them for our race this weekend",
  "id" : 192058887069904896,
  "in_reply_to_status_id" : 192039375993962497,
  "created_at" : "Tue Apr 17 01:16:21 +0000 2012",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 10, 25 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192050342362488832",
  "geo" : {
  },
  "id_str" : "192057759183798273",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @ryandelgiudice I've even got jorts, and candy to offer the kids from my creepy passenger van",
  "id" : 192057759183798273,
  "in_reply_to_status_id" : 192050342362488832,
  "created_at" : "Tue Apr 17 01:11:52 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/192029589189562368/photo/1",
      "indices" : [ 11, 31 ],
      "url" : "http://t.co/70WM3SPP",
      "media_url" : "http://pbs.twimg.com/media/Aqo55NpCEAA2l5g.jpg",
      "id_str" : "192029589193756672",
      "id" : 192029589193756672,
      "media_url_https" : "https://pbs.twimg.com/media/Aqo55NpCEAA2l5g.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/70WM3SPP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192029589189562368",
  "text" : "and after: http://t.co/70WM3SPP",
  "id" : 192029589189562368,
  "created_at" : "Mon Apr 16 23:19:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/192029084342169601/photo/1",
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/ZyZmzeHm",
      "media_url" : "http://pbs.twimg.com/media/Aqo5b08CMAEeQHa.jpg",
      "id_str" : "192029084346363905",
      "id" : 192029084346363905,
      "media_url_https" : "https://pbs.twimg.com/media/Aqo5b08CMAEeQHa.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ZyZmzeHm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "192029084342169601",
  "text" : "okay followers, you gotta see this. before: http://t.co/ZyZmzeHm",
  "id" : 192029084342169601,
  "created_at" : "Mon Apr 16 23:17:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "champs",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "lifegoals",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191998016775929856",
  "text" : "gives me even more respect for those who crushed the boston marathon today! forgot what the heat was like. #champs #lifegoals",
  "id" : 191998016775929856,
  "created_at" : "Mon Apr 16 21:14:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatisthismoponmyhead",
      "indices" : [ 104, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191996432339836928",
  "text" : "long hair? go for a run in the 80deg w sun beating down... that'll make you think twice about fixing it #whatisthismoponmyhead",
  "id" : 191996432339836928,
  "created_at" : "Mon Apr 16 21:08:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191730887270998017",
  "text" : "is getting really excited for the summer already. riding w bike and build, wedding, three wk canoe trip, and framebuilding on the agenda!",
  "id" : 191730887270998017,
  "created_at" : "Mon Apr 16 03:33:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191708272322027522",
  "geo" : {
  },
  "id_str" : "191708646911115264",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan skype?",
  "id" : 191708646911115264,
  "in_reply_to_status_id" : 191708272322027522,
  "created_at" : "Mon Apr 16 02:04:37 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191705086454538241",
  "geo" : {
  },
  "id_str" : "191708105657159680",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan you still up?",
  "id" : 191708105657159680,
  "in_reply_to_status_id" : 191705086454538241,
  "created_at" : "Mon Apr 16 02:02:28 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191704834213281792",
  "text" : "team No Game This Week advances to second round of playoffs with a strong defensive showing!",
  "id" : 191704834213281792,
  "created_at" : "Mon Apr 16 01:49:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191636348879380480",
  "text" : "can't complain about a long day of homework when I'm home to a big salad, fresh bread, and good beer on tap!",
  "id" : 191636348879380480,
  "created_at" : "Sun Apr 15 21:17:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 3, 14 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/ZK7MELR6",
      "expanded_url" : "http://bit.ly/HGLHbE",
      "display_url" : "bit.ly/HGLHbE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "191518329318547456",
  "text" : "RT @peterdodds: Computational Story Lab team photo/coverage by UVM: http://t.co/ZK7MELR6",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/ZK7MELR6",
        "expanded_url" : "http://bit.ly/HGLHbE",
        "display_url" : "bit.ly/HGLHbE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "190910512664555520",
    "text" : "Computational Story Lab team photo/coverage by UVM: http://t.co/ZK7MELR6",
    "id" : 190910512664555520,
    "created_at" : "Fri Apr 13 21:13:07 +0000 2012",
    "user" : {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "protected" : false,
      "id_str" : "16174144",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/294761101/IMG_7808_small_normal.JPG",
      "id" : 16174144,
      "verified" : false
    }
  },
  "id" : 191518329318547456,
  "created_at" : "Sun Apr 15 13:28:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 91, 98 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfectday",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "191329404922761218",
  "text" : "long mountain bike ride in Old Forge followed up with beer and ice cream. #perfectday with @sspis1",
  "id" : 191329404922761218,
  "created_at" : "Sun Apr 15 00:57:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190946750721302529",
  "text" : "good mountain bike ride, and going out for a run after, stopped and fixed a kid's bike instead of running...what a good guy",
  "id" : 190946750721302529,
  "created_at" : "Fri Apr 13 23:37:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 41, 48 ],
      "id_str" : "765548",
      "id" : 765548
    }, {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 63, 77 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/190862713776381952/photo/1",
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/dZBKHY8Q",
      "media_url" : "http://pbs.twimg.com/media/AqYUoIACIAAOF0G.jpg",
      "id_str" : "190862713784770560",
      "id" : 190862713784770560,
      "media_url_https" : "https://pbs.twimg.com/media/AqYUoIACIAAOF0G.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/dZBKHY8Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190862713776381952",
  "text" : "\"Understanding the World in Realtime\" by @hmason, presented by @uvmcomplexity http://t.co/dZBKHY8Q",
  "id" : 190862713776381952,
  "created_at" : "Fri Apr 13 18:03:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 85, 92 ],
      "id_str" : "765548",
      "id" : 765548
    }, {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 126, 140 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/DB3seA6T",
      "expanded_url" : "http://bitly.com",
      "display_url" : "bitly.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190846392762253313",
  "text" : "learned that there are some exciting things going on http://t.co/DB3seA6T at lunch w @hmason! excited to see her talk today w @uvmcomplexity",
  "id" : 190846392762253313,
  "created_at" : "Fri Apr 13 16:58:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Peter Lista",
      "screen_name" : "peterlista",
      "indices" : [ 8, 19 ],
      "id_str" : "21274226",
      "id" : 21274226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/8rLTXYrJ",
      "expanded_url" : "http://onehappybird.com/",
      "display_url" : "onehappybird.com"
    } ]
  },
  "in_reply_to_status_id_str" : "190659471620587520",
  "geo" : {
  },
  "id_str" : "190816901331554304",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @peterlista you guys should check out http://t.co/8rLTXYrJ, my group posts much of what we do on there!",
  "id" : 190816901331554304,
  "in_reply_to_status_id" : 190659471620587520,
  "created_at" : "Fri Apr 13 15:01:09 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190540717662281728",
  "text" : "here's to hoping that the magical bike riding powers of jorts and a mustache transfer to my take home analysis test",
  "id" : 190540717662281728,
  "created_at" : "Thu Apr 12 20:43:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 49, 60 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/pUDpwLKX",
      "expanded_url" : "http://bit.ly/Hxv6mY",
      "display_url" : "bit.ly/Hxv6mY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190528357035806721",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving good thing you're so good looking: MT @bakadesuyo Does the attractiveness of your agent affect the sale? http://t.co/pUDpwLKX",
  "id" : 190528357035806721,
  "created_at" : "Thu Apr 12 19:54:34 +0000 2012",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190527409605443584",
  "text" : "@axetickle sort-of. compact aluminum road frame, but w forward seatpost, aerobars and a disc wheel",
  "id" : 190527409605443584,
  "created_at" : "Thu Apr 12 19:50:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "playinitsafe",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190525668847661056",
  "text" : "bike shipped to VA, box only weighed 33lbs, and it's gonna get there two days early #playinitsafe",
  "id" : 190525668847661056,
  "created_at" : "Thu Apr 12 19:43:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190434798144200705",
  "text" : "my one class today has been moved to tomorrow....studying all day!",
  "id" : 190434798144200705,
  "created_at" : "Thu Apr 12 13:42:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/OF4xw5n2",
      "expanded_url" : "http://nyti.ms/IGrG4f",
      "display_url" : "nyti.ms/IGrG4f"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190280102259597313",
  "text" : "great news if it happens: \"Antibiotics for Livestock Will Require Prescription, F.D.A. Says\" http://t.co/OF4xw5n2",
  "id" : 190280102259597313,
  "created_at" : "Thu Apr 12 03:28:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 14, 21 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 78, 85 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlife",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190214421778415616",
  "text" : "a bike ride w @sspis1 and then drinking wine on the roof in the sun w her and @DZdan1, followed by homemade bean burritos #goodlife",
  "id" : 190214421778415616,
  "created_at" : "Wed Apr 11 23:07:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/e0s6d7oz",
      "expanded_url" : "http://lmgtfy.com/?q=uvm+matlab+download",
      "display_url" : "lmgtfy.com/?q=uvm+matlab+…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "190123736618381313",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie http://t.co/e0s6d7oz",
  "id" : 190123736618381313,
  "created_at" : "Wed Apr 11 17:06:45 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "190122815704412161",
  "text" : "you can't beat the machines",
  "id" : 190122815704412161,
  "created_at" : "Wed Apr 11 17:03:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 18, 31 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/189880171686400000/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/F3Be9ag3",
      "media_url" : "http://pbs.twimg.com/media/AqKXApeCEAEztSH.jpg",
      "id_str" : "189880171690594305",
      "id" : 189880171690594305,
      "media_url_https" : "https://pbs.twimg.com/media/AqKXApeCEAEztSH.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/F3Be9ag3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189880171686400000",
  "text" : "disc wheel ready! @uvmtriathlon http://t.co/F3Be9ag3",
  "id" : 189880171686400000,
  "created_at" : "Wed Apr 11 00:58:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189783528811134976",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan check yous email",
  "id" : 189783528811134976,
  "created_at" : "Tue Apr 10 18:34:53 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189746791246331904",
  "geo" : {
  },
  "id_str" : "189747466982268929",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy sounds like he failed at finding the right group",
  "id" : 189747466982268929,
  "in_reply_to_status_id" : 189746791246331904,
  "created_at" : "Tue Apr 10 16:11:36 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189591046974488577",
  "geo" : {
  },
  "id_str" : "189591653089165312",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy a degree?",
  "id" : 189591653089165312,
  "in_reply_to_status_id" : 189591046974488577,
  "created_at" : "Tue Apr 10 05:52:27 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189581519021543424",
  "geo" : {
  },
  "id_str" : "189584307671666688",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 think...cold and rainy bike ride. hiking shoes. scissors. warm gloves. ballpoint pen. MAPP torch. sunscreen. 10-gallon hat.",
  "id" : 189584307671666688,
  "in_reply_to_status_id" : 189581519021543424,
  "created_at" : "Tue Apr 10 05:23:15 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Buckley",
      "screen_name" : "mmbuckley",
      "indices" : [ 0, 10 ],
      "id_str" : "33749249",
      "id" : 33749249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189546485581484032",
  "in_reply_to_user_id" : 33749249,
  "text" : "@mmbuckley thanks for the chocolates!!",
  "id" : 189546485581484032,
  "created_at" : "Tue Apr 10 02:52:58 +0000 2012",
  "in_reply_to_screen_name" : "mmbuckley",
  "in_reply_to_user_id_str" : "33749249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complaintweet",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189513328127778816",
  "text" : "\"sent from my iPhone/iPad\" is not an excuse for bad grammar #complaintweet",
  "id" : 189513328127778816,
  "created_at" : "Tue Apr 10 00:41:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 5, 16 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Syracuse University",
      "screen_name" : "SyracuseU",
      "indices" : [ 32, 42 ],
      "id_str" : "125688706",
      "id" : 125688706
    }, {
      "name" : "Syracuse Athletics",
      "screen_name" : "Cuse",
      "indices" : [ 67, 72 ],
      "id_str" : "17879492",
      "id" : 17879492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beatdown",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189511838617182211",
  "text" : "nice @skholden17!! #beatdown MT @SyracuseU: Congratulations to the @CUSE Women's Lacrosse team for defeating #10 Dartmouth 22-4! Now 9-2.",
  "id" : 189511838617182211,
  "created_at" : "Tue Apr 10 00:35:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 10, 20 ],
      "id_str" : "14666918",
      "id" : 14666918
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 34, 43 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 44, 54 ],
      "id_str" : "14666918",
      "id" : 14666918
    }, {
      "name" : "andy ragan",
      "screen_name" : "andyragan",
      "indices" : [ 86, 96 ],
      "id_str" : "944995890",
      "id" : 944995890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterprotip",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189390071978409985",
  "geo" : {
  },
  "id_str" : "189390571146715136",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser @axetickle like this MT @dr_pyser @axetickle modified tweet - coz I deleted @andyragan's second sentence for space. #twitterprotip",
  "id" : 189390571146715136,
  "in_reply_to_status_id" : 189390071978409985,
  "created_at" : "Mon Apr 09 16:33:25 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 11, 20 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189390103595061249",
  "text" : "@axetickle @dr_pyser it means \"modified tweet.\" ie an RT but he added stuff",
  "id" : 189390103595061249,
  "created_at" : "Mon Apr 09 16:31:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189383760507191296",
  "text" : "will an aluminum bike frame loose stiffness over years of hard riding? internets have mixed reviews",
  "id" : 189383760507191296,
  "created_at" : "Mon Apr 09 16:06:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189219155419987969",
  "text" : "so much #math",
  "id" : 189219155419987969,
  "created_at" : "Mon Apr 09 05:12:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/TnwRlWqw",
      "expanded_url" : "http://bit.ly/IdDcSv",
      "display_url" : "bit.ly/IdDcSv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "189181049476087810",
  "text" : "dang today's crit looks fast online: avg speed over 25mph (some laps 28+) and I hit 37mph in my sprint http://t.co/TnwRlWqw",
  "id" : 189181049476087810,
  "created_at" : "Mon Apr 09 02:40:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 23, 35 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vermont",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/FTxohqqP",
      "expanded_url" : "http://twitter.com/UVM_cycling/status/189135610827649024/photo/1",
      "display_url" : "pic.twitter.com/FTxohqqP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "189164251301167104",
  "text" : "a much better picture \"@UVM_cycling: Chasing the sunset after a great weekend racing bikes. #Vermont http://t.co/FTxohqqP\"",
  "id" : 189164251301167104,
  "created_at" : "Mon Apr 09 01:34:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "indices" : [ 3, 10 ],
      "id_str" : "394388191",
      "id" : 394388191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "vt",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189163876154228736",
  "text" : "RT @UVMBUG: How about that sunset tonight? #btv #vt",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "btv",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "vt",
        "indices" : [ 36, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "189147905729380352",
    "text" : "How about that sunset tonight? #btv #vt",
    "id" : 189147905729380352,
    "created_at" : "Mon Apr 09 00:29:09 +0000 2012",
    "user" : {
      "name" : "BUG Bikes",
      "screen_name" : "UVMBUG",
      "protected" : false,
      "id_str" : "394388191",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1597116048/bug_normal.jpg",
      "id" : 394388191,
      "verified" : false
    }
  },
  "id" : 189163876154228736,
  "created_at" : "Mon Apr 09 01:32:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/189133468507189248/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/SoFAZgeR",
      "media_url" : "http://pbs.twimg.com/media/Ap_v4zXCMAE1O6O.jpg",
      "id_str" : "189133468511383553",
      "id" : 189133468511383553,
      "media_url_https" : "https://pbs.twimg.com/media/Ap_v4zXCMAE1O6O.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/SoFAZgeR"
    } ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189133468507189248",
  "text" : "brilliant orange and pink sunset coming into #btv http://t.co/SoFAZgeR",
  "id" : 189133468507189248,
  "created_at" : "Sun Apr 08 23:31:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "189087721543831553",
  "text" : "crit was fun, and we're on the way back to Burlington now",
  "id" : 189087721543831553,
  "created_at" : "Sun Apr 08 20:30:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Ben Civiletti",
      "screen_name" : "BenCiv",
      "indices" : [ 59, 66 ],
      "id_str" : "24074204",
      "id" : 24074204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VICTORY",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188994756511141888",
  "text" : "RT @UVM_cycling: Men's C runs train on the race setting up @BenCiv for #VICTORY",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Civiletti",
        "screen_name" : "BenCiv",
        "indices" : [ 42, 49 ],
        "id_str" : "24074204",
        "id" : 24074204
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VICTORY",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "188989647572041728",
    "text" : "Men's C runs train on the race setting up @BenCiv for #VICTORY",
    "id" : 188989647572041728,
    "created_at" : "Sun Apr 08 14:00:17 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 188994756511141888,
  "created_at" : "Sun Apr 08 14:20:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parisroubaix",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188936984977346560",
  "text" : "NOOO twitter, one glance and I've seen too much about #parisroubaix",
  "id" : 188936984977346560,
  "created_at" : "Sun Apr 08 10:31:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188935923394818050",
  "text" : "wake up this song this AM was Rihanna's S/M.... not as good",
  "id" : 188935923394818050,
  "created_at" : "Sun Apr 08 10:26:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 0, 12 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realitalianpizza",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188780692484784128",
  "text" : "@OGfromtheOB it was excellent! thanks for recommendation! #realitalianpizza",
  "id" : 188780692484784128,
  "created_at" : "Sun Apr 08 00:09:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188774694797836288",
  "text" : "we have a different stomach for brownies",
  "id" : 188774694797836288,
  "created_at" : "Sat Apr 07 23:46:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 23, 35 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/188770253151547393/photo/1",
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/FjTMQEli",
      "media_url" : "http://pbs.twimg.com/media/Ap6li4uCMAAgQBu.jpg",
      "id_str" : "188770253155741696",
      "id" : 188770253155741696,
      "media_url_https" : "https://pbs.twimg.com/media/Ap6li4uCMAAgQBu.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/FjTMQEli"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188770253151547393",
  "text" : "we're chowing down for @bikingbiebs http://t.co/FjTMQEli",
  "id" : 188770253151547393,
  "created_at" : "Sat Apr 07 23:28:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 49, 61 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/fv8iTtEV",
      "expanded_url" : "http://4sq.com/HwozfH",
      "display_url" : "4sq.com/HwozfH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.30306043, -72.91714829 ]
  },
  "id_str" : "188762698660581379",
  "text" : "correction, we're going to \"the spot\" (right one @ogfromtheob?) (@ Frank Pepe - The Spot) http://t.co/fv8iTtEV",
  "id" : 188762698660581379,
  "created_at" : "Sat Apr 07 22:58:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Crowley",
      "screen_name" : "chriscrowley",
      "indices" : [ 34, 47 ],
      "id_str" : "15096946",
      "id" : 15096946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/z0ctXoYn",
      "expanded_url" : "http://4sq.com/IdNc21",
      "display_url" : "4sq.com/IdNc21"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.302902, -72.916985 ]
  },
  "id_str" : "188757338667233280",
  "text" : "gonna be worth the weight I hear! @chriscrowley (@ Frank Pepe Pizzeria Napoletana w/ 4 others) http://t.co/z0ctXoYn",
  "id" : 188757338667233280,
  "created_at" : "Sat Apr 07 22:37:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188753078093225984",
  "text" : "races went alright for me, and as a team UVM took a win in C's and all rubber side down! B's are quite a bit faster, or 2 wks off hurt!",
  "id" : 188753078093225984,
  "created_at" : "Sat Apr 07 22:20:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/188672425465098240/photo/1",
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/yWuC57ZR",
      "media_url" : "http://pbs.twimg.com/media/Ap5MkkMCMAEo8xx.jpg",
      "id_str" : "188672425469292545",
      "id" : 188672425469292545,
      "media_url_https" : "https://pbs.twimg.com/media/Ap5MkkMCMAEo8xx.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/yWuC57ZR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188672425465098240",
  "text" : ".@uvmcycling takes 1-3-5-6 in Men's C circuit. pic of D's staged: http://t.co/yWuC57ZR",
  "id" : 188672425465098240,
  "created_at" : "Sat Apr 07 16:59:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/KXm7fDxZ",
      "expanded_url" : "http://4sq.com/HS8bor",
      "display_url" : "4sq.com/HS8bor"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.321229, -72.918123 ]
  },
  "id_str" : "188580534534930434",
  "text" : "ITT kicks off in a few hours (@ New Haven, CT) http://t.co/KXm7fDxZ",
  "id" : 188580534534930434,
  "created_at" : "Sat Apr 07 10:54:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188571471667412992",
  "text" : "who gets up at 6AM on Saturdays? collegiate bike racers!",
  "id" : 188571471667412992,
  "created_at" : "Sat Apr 07 10:18:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/YWzM6dp5",
      "expanded_url" : "http://4sq.com/HfRORt",
      "display_url" : "4sq.com/HfRORt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.4186288167, -72.904107 ]
  },
  "id_str" : "188464732964007936",
  "text" : "arrived. not nearly as bad as google reviews asserts. sleeping on the thermie just in case (@ Days Inn Hamden) http://t.co/YWzM6dp5",
  "id" : 188464732964007936,
  "created_at" : "Sat Apr 07 03:14:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/ztBzQr9S",
      "expanded_url" : "http://collegiatecycling.org/eccc/wiki/uploads/Calendar/2012-Yale.pdf",
      "display_url" : "collegiatecycling.org/eccc/wiki/uplo…"
    } ]
  },
  "in_reply_to_status_id_str" : "188437157331996673",
  "geo" : {
  },
  "id_str" : "188456102604709888",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr yeah, New Haven! I'm racing bikes there today and tomorrow!! http://t.co/ztBzQr9S On the four foot rim??",
  "id" : 188456102604709888,
  "in_reply_to_status_id" : 188437157331996673,
  "created_at" : "Sat Apr 07 02:40:10 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188433222168875008",
  "geo" : {
  },
  "id_str" : "188434963971059712",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr oh sweet. how much further to New Hartford?",
  "id" : 188434963971059712,
  "in_reply_to_status_id" : 188433222168875008,
  "created_at" : "Sat Apr 07 01:16:11 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/Sto1dJle",
      "expanded_url" : "http://4sq.com/I9jdZ3",
      "display_url" : "4sq.com/I9jdZ3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.093509466, -72.5852108002 ]
  },
  "id_str" : "188433073682124802",
  "text" : "wish I could go in! just driving by (@ Naismith Basketball Hall of Fame) http://t.co/Sto1dJle",
  "id" : 188433073682124802,
  "created_at" : "Sat Apr 07 01:08:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "counting",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/IrFFXNry",
      "expanded_url" : "http://4sq.com/HthI6B",
      "display_url" : "4sq.com/HthI6B"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.88294839, -72.557393 ]
  },
  "id_str" : "188412971037372416",
  "text" : "6 of us walk in, guy behind the counter alerts the staff 4 or 5 people here #counting (@ Wendy's) http://t.co/IrFFXNry",
  "id" : 188412971037372416,
  "created_at" : "Fri Apr 06 23:48:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/Ch31L8DI",
      "expanded_url" : "http://4sq.com/HQYwOI",
      "display_url" : "4sq.com/HQYwOI"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8849343631, -72.5570749509 ]
  },
  "id_str" : "188411393890983936",
  "text" : "I'm at Brattleboro, Vt http://t.co/Ch31L8DI",
  "id" : 188411393890983936,
  "created_at" : "Fri Apr 06 23:42:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 28, 40 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188395948781744128",
  "text" : "en route to New Haven, CT w @UVM_cycling and crew!",
  "id" : 188395948781744128,
  "created_at" : "Fri Apr 06 22:41:09 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 3, 16 ],
      "id_str" : "328777340",
      "id" : 328777340
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 28, 40 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188353403808792576",
  "text" : "RT @DaBrownNoise: Must win. @UVM_cycling",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UVM Cycling",
        "screen_name" : "UVM_cycling",
        "indices" : [ 10, 22 ],
        "id_str" : "75351547",
        "id" : 75351547
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "188311878370471937",
    "text" : "Must win. @UVM_cycling",
    "id" : 188311878370471937,
    "created_at" : "Fri Apr 06 17:07:05 +0000 2012",
    "user" : {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "protected" : false,
      "id_str" : "328777340",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2180329574/bike12_normal.jpg",
      "id" : 328777340,
      "verified" : false
    }
  },
  "id" : 188353403808792576,
  "created_at" : "Fri Apr 06 19:52:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188348313710505984",
  "text" : "picked up my wheel from Skirack...spinning rougher than when I brought it in, they didnt even use CK lube. just going to do it right myself",
  "id" : 188348313710505984,
  "created_at" : "Fri Apr 06 19:31:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/UR2wlVae",
      "expanded_url" : "http://4sq.com/HjtQYZ",
      "display_url" : "4sq.com/HjtQYZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4777334287, -73.1983043723 ]
  },
  "id_str" : "188257980066709504",
  "text" : "back on the grind (class) (@ UVM Lafayette Hall) http://t.co/UR2wlVae",
  "id" : 188257980066709504,
  "created_at" : "Fri Apr 06 13:32:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 17, 27 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/cEfQkrRK",
      "expanded_url" : "http://4sq.com/HmdigE",
      "display_url" : "4sq.com/HmdigE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4769250568, -73.2129664291 ]
  },
  "id_str" : "188130110333911041",
  "text" : "chillin w my man @crispy__c! (@ The Whiskey Room @ Ri Ra) http://t.co/cEfQkrRK",
  "id" : 188130110333911041,
  "created_at" : "Fri Apr 06 05:04:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188081435347910656",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C i'll be in #btv in an hour! want to meet up at a bar? let me know which, my phone will be off for the flight",
  "id" : 188081435347910656,
  "created_at" : "Fri Apr 06 01:51:23 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188081160776192000",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e bummed I didn't get to see ya!",
  "id" : 188081160776192000,
  "created_at" : "Fri Apr 06 01:50:17 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188075910363222017",
  "text" : "our pilot has a \"jimmy buffet for president\" sticker on his baggage. feeling marginally less safe",
  "id" : 188075910363222017,
  "created_at" : "Fri Apr 06 01:29:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chyeah",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188074367522045952",
  "geo" : {
  },
  "id_str" : "188075703324000256",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 vermonttttttttt #chyeah",
  "id" : 188075703324000256,
  "in_reply_to_status_id" : 188074367522045952,
  "created_at" : "Fri Apr 06 01:28:36 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ12",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188056611581997056",
  "text" : "RT @dr_pyser: on my way home from #SIAMUQ12. chillin at national airport in washington, just across the river from the washington monument.",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SIAMUQ12",
        "indices" : [ 20, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "188056070596468736",
    "text" : "on my way home from #SIAMUQ12. chillin at national airport in washington, just across the river from the washington monument.",
    "id" : 188056070596468736,
    "created_at" : "Fri Apr 06 00:10:35 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 188056611581997056,
  "created_at" : "Fri Apr 06 00:12:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweetviews",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "usairways",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188047431370424320",
  "text" : "pro tip: sit on RT side leaving RDU (heading N) and RT side coming into DCA (from S), but L for the sunset! #sweetviews #usairways",
  "id" : 188047431370424320,
  "created_at" : "Thu Apr 05 23:36:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "188044813294256129",
  "text" : "\"no parking in DC these days\" -the pilot, we're on a plane here?",
  "id" : 188044813294256129,
  "created_at" : "Thu Apr 05 23:25:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classytweet",
      "indices" : [ 12, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188017718061047808",
  "geo" : {
  },
  "id_str" : "188029819387260928",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet #classytweet",
  "id" : 188029819387260928,
  "in_reply_to_status_id" : 188017718061047808,
  "created_at" : "Thu Apr 05 22:26:17 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/XVoCLBtB",
      "expanded_url" : "http://4sq.com/Hq35Ai",
      "display_url" : "4sq.com/Hq35Ai"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.8766716953, -78.7930440903 ]
  },
  "id_str" : "187994479679111170",
  "text" : "saying goodbye to the south, for now (@ Raleigh-Durham International Airport (RDU) w/ 34 others) http://t.co/XVoCLBtB",
  "id" : 187994479679111170,
  "created_at" : "Thu Apr 05 20:05:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187979886923755520",
  "geo" : {
  },
  "id_str" : "187987805866172416",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie better yet, a test for graduation. alumni that can't unsubscribe made me the saddest",
  "id" : 187987805866172416,
  "in_reply_to_status_id" : 187979886923755520,
  "created_at" : "Thu Apr 05 19:39:20 +0000 2012",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187967251083825152",
  "text" : "@axetickle now??",
  "id" : 187967251083825152,
  "created_at" : "Thu Apr 05 18:17:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/n4XMttBB",
      "expanded_url" : "http://4sq.com/HNiRVb",
      "display_url" : "4sq.com/HNiRVb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7773443422, -78.6367839575 ]
  },
  "id_str" : "187954555336654848",
  "text" : "lunch w the Nardinster! (@ Tír na nÓg) http://t.co/n4XMttBB",
  "id" : 187954555336654848,
  "created_at" : "Thu Apr 05 17:27:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imokaywiththat",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187891782225379328",
  "geo" : {
  },
  "id_str" : "187899947176312833",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser this can only mean I will soon be super strong and dating natalie portman #imokaywiththat",
  "id" : 187899947176312833,
  "in_reply_to_status_id" : 187891782225379328,
  "created_at" : "Thu Apr 05 13:50:13 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/187890231469543425/photo/1",
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/IAxc0g3b",
      "media_url" : "http://pbs.twimg.com/media/ApuFK4fCEAIh-T2.jpg",
      "id_str" : "187890231473737730",
      "id" : 187890231473737730,
      "media_url_https" : "https://pbs.twimg.com/media/ApuFK4fCEAIh-T2.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/IAxc0g3b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187890231469543425",
  "text" : "guy at starbucks convinced I look like Thor. and not a bad breakfast to boot http://t.co/IAxc0g3b",
  "id" : 187890231469543425,
  "created_at" : "Thu Apr 05 13:11:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siamuq12",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187876825467322369",
  "text" : "#siamuq12 Mark Berliner from Ohio State on \"Statistical Approaches to Combining Models and Observations\"",
  "id" : 187876825467322369,
  "created_at" : "Thu Apr 05 12:18:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brassmonkey",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187724473963778048",
  "geo" : {
  },
  "id_str" : "187769106081132544",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy looks like some #brassmonkey in the making!",
  "id" : 187769106081132544,
  "in_reply_to_status_id" : 187724473963778048,
  "created_at" : "Thu Apr 05 05:10:18 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 0, 12 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "Matthew Buckley",
      "screen_name" : "mmbuckley",
      "indices" : [ 13, 23 ],
      "id_str" : "33749249",
      "id" : 33749249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187768818242826240",
  "in_reply_to_user_id" : 276236513,
  "text" : "@bikingbiebs @mmbuckley my thoughts are with you guys!!",
  "id" : 187768818242826240,
  "created_at" : "Thu Apr 05 05:09:09 +0000 2012",
  "in_reply_to_screen_name" : "bikingbiebs",
  "in_reply_to_user_id_str" : "276236513",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boss",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187759477381005313",
  "geo" : {
  },
  "id_str" : "187768184831614977",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 #boss",
  "id" : 187768184831614977,
  "in_reply_to_status_id" : 187759477381005313,
  "created_at" : "Thu Apr 05 05:06:38 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/187767975158358016/photo/1",
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/RDJu453R",
      "media_url" : "http://pbs.twimg.com/media/ApsV-oPCIAEHCmJ.jpg",
      "id_str" : "187767975162552321",
      "id" : 187767975162552321,
      "media_url_https" : "https://pbs.twimg.com/media/ApsV-oPCIAEHCmJ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/RDJu453R"
    } ],
    "hashtags" : [ {
      "text" : "cookout",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "amazed",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "endofstory",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187767975158358016",
  "text" : "John's friends were *convinced* I wouldnt fit in a medium size #cookout tee, they were then #amazed. #endofstory http://t.co/RDJu453R",
  "id" : 187767975158358016,
  "created_at" : "Thu Apr 05 05:05:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "northcarolina",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187761550252183552",
  "text" : "bars beers and cookout #northcarolina",
  "id" : 187761550252183552,
  "created_at" : "Thu Apr 05 04:40:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontstop",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "believing",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187716667315453952",
  "text" : "UVM's kareoke dream team signed up #dontstop #believing",
  "id" : 187716667315453952,
  "created_at" : "Thu Apr 05 01:41:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 27, 38 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/187706247099858944/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/DNMOoP4L",
      "media_url" : "http://pbs.twimg.com/media/Aprd1lTCQAIk2A4.jpg",
      "id_str" : "187706247104053250",
      "id" : 187706247104053250,
      "media_url_https" : "https://pbs.twimg.com/media/Aprd1lTCQAIk2A4.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/DNMOoP4L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187706247099858944",
  "text" : "name this movie! (picture) @kreagannet http://t.co/DNMOoP4L",
  "id" : 187706247099858944,
  "created_at" : "Thu Apr 05 01:00:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187704178477506560",
  "geo" : {
  },
  "id_str" : "187706222819028992",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yay!!",
  "id" : 187706222819028992,
  "in_reply_to_status_id" : 187704178477506560,
  "created_at" : "Thu Apr 05 01:00:25 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/G0AIpxqH",
      "expanded_url" : "http://www.youtube.com/watch?v=47D9-U8hn5I",
      "display_url" : "youtube.com/watch?v=47D9-U…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187702930856624128",
  "text" : "if you haven't seen kitten mittens...do the right thing http://t.co/G0AIpxqH",
  "id" : 187702930856624128,
  "created_at" : "Thu Apr 05 00:47:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Chung",
      "screen_name" : "jamiechung",
      "indices" : [ 0, 11 ],
      "id_str" : "9361892",
      "id" : 9361892
    }, {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 22, 29 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187688717387968512",
  "geo" : {
  },
  "id_str" : "187698171378540544",
  "in_reply_to_user_id" : 9361892,
  "text" : "@jamiechung check out @square",
  "id" : 187698171378540544,
  "in_reply_to_status_id" : 187688717387968512,
  "created_at" : "Thu Apr 05 00:28:25 +0000 2012",
  "in_reply_to_screen_name" : "jamiechung",
  "in_reply_to_user_id_str" : "9361892",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kidding",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "trivia",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187698047143256064",
  "text" : "please unfollow if you don't know this one: which tv show featured an ad for \"kitten mittens\"? )#kidding #trivia",
  "id" : 187698047143256064,
  "created_at" : "Thu Apr 05 00:27:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187695776447733761",
  "text" : "team \"The Well Hung Jury\" hanging in contention in Joel Lane's trivia night!",
  "id" : 187695776447733761,
  "created_at" : "Thu Apr 05 00:18:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Johnston",
      "screen_name" : "admakj",
      "indices" : [ 3, 10 ],
      "id_str" : "391103954",
      "id" : 391103954
    }, {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 28, 37 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/TgXGbKya",
      "expanded_url" : "http://wny.cc/HIsLZv",
      "display_url" : "wny.cc/HIsLZv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187630063557156864",
  "text" : "RT @admakj: Mesmerizing. RT @Radiolab: Absolutely cannot stop staring at this real-time wind map: http://t.co/TgXGbKya",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radiolab",
        "screen_name" : "Radiolab",
        "indices" : [ 16, 25 ],
        "id_str" : "28583197",
        "id" : 28583197
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/TgXGbKya",
        "expanded_url" : "http://wny.cc/HIsLZv",
        "display_url" : "wny.cc/HIsLZv"
      } ]
    },
    "geo" : {
    },
    "id_str" : "187628914439495680",
    "text" : "Mesmerizing. RT @Radiolab: Absolutely cannot stop staring at this real-time wind map: http://t.co/TgXGbKya",
    "id" : 187628914439495680,
    "created_at" : "Wed Apr 04 19:53:13 +0000 2012",
    "user" : {
      "name" : "Adam Johnston",
      "screen_name" : "admakj",
      "protected" : false,
      "id_str" : "391103954",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2785566215/9533b828c70d323fdc9f0f553a9cb305_normal.jpeg",
      "id" : 391103954,
      "verified" : false
    }
  },
  "id" : 187630063557156864,
  "created_at" : "Wed Apr 04 19:57:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 0, 13 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187623349525020673",
  "geo" : {
  },
  "id_str" : "187625196008652800",
  "in_reply_to_user_id" : 14193991,
  "text" : "@plaidavenger thanks! a good choice, so you can fine tune the global climate models predicting our doom",
  "id" : 187625196008652800,
  "in_reply_to_status_id" : 187623349525020673,
  "created_at" : "Wed Apr 04 19:38:27 +0000 2012",
  "in_reply_to_screen_name" : "plaidavenger",
  "in_reply_to_user_id_str" : "14193991",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187578628471652353",
  "geo" : {
  },
  "id_str" : "187623741998632962",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 excellent! did you ever see my solution?",
  "id" : 187623741998632962,
  "in_reply_to_status_id" : 187578628471652353,
  "created_at" : "Wed Apr 04 19:32:40 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187581614656733186",
  "geo" : {
  },
  "id_str" : "187623672348016642",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 ahhh autocorrect? or just a typo! gosh how are you, we haven't talked in week!!!!!",
  "id" : 187623672348016642,
  "in_reply_to_status_id" : 187581614656733186,
  "created_at" : "Wed Apr 04 19:32:24 +0000 2012",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Johnston",
      "screen_name" : "admakj",
      "indices" : [ 0, 7 ],
      "id_str" : "391103954",
      "id" : 391103954
    }, {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 8, 21 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/Dbcg6aPm",
      "expanded_url" : "http://bit.ly/HurxSw",
      "display_url" : "bit.ly/HurxSw"
    } ]
  },
  "in_reply_to_status_id_str" : "187622098267672577",
  "geo" : {
  },
  "id_str" : "187622465860681728",
  "in_reply_to_user_id" : 391103954,
  "text" : "@admakj @plaidavenger and perhaps integration more than just being a \"user\" is also key: http://t.co/Dbcg6aPm",
  "id" : 187622465860681728,
  "in_reply_to_status_id" : 187622098267672577,
  "created_at" : "Wed Apr 04 19:27:36 +0000 2012",
  "in_reply_to_screen_name" : "admakj",
  "in_reply_to_user_id_str" : "391103954",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/Dbcg6aPm",
      "expanded_url" : "http://bit.ly/HurxSw",
      "display_url" : "bit.ly/HurxSw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187620077598818304",
  "text" : "\"We will be breeding generations of hamsters for the glittering wheels of cages built by Mark Zuckerberg and his kind.\" http://t.co/Dbcg6aPm",
  "id" : 187620077598818304,
  "created_at" : "Wed Apr 04 19:18:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187618398098833408",
  "text" : "that awkward moment where your phone switched contact's numbers and you've been planning dinner with THE WRONG PERSON",
  "id" : 187618398098833408,
  "created_at" : "Wed Apr 04 19:11:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 3, 17 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187612774736728065",
  "text" : "RT @uvmcomplexity: \"Financial black swans driven by ultrafast machine ecology\" by Neil Johnson and company, reading group Weds April 11, ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/GMaK1Nt0",
        "expanded_url" : "http://bit.ly/x50YIe",
        "display_url" : "bit.ly/x50YIe"
      } ]
    },
    "geo" : {
    },
    "id_str" : "187612188985405442",
    "text" : "\"Financial black swans driven by ultrafast machine ecology\" by Neil Johnson and company, reading group Weds April 11, http://t.co/GMaK1Nt0",
    "id" : 187612188985405442,
    "created_at" : "Wed Apr 04 18:46:46 +0000 2012",
    "user" : {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "protected" : false,
      "id_str" : "368379922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529859022/CSC_logo_symbol_normal.png",
      "id" : 368379922,
      "verified" : false
    }
  },
  "id" : 187612774736728065,
  "created_at" : "Wed Apr 04 18:49:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187612649998127104",
  "text" : "some math talks are like short bike races. everybody gets dropped by the end",
  "id" : 187612649998127104,
  "created_at" : "Wed Apr 04 18:48:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlord",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187591675361755138",
  "text" : "trying to catch up on HW, meanwhile my inbox hits 50 messages #goodlord good thing I know my gmail keyboard shortcuts",
  "id" : 187591675361755138,
  "created_at" : "Wed Apr 04 17:25:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siamuq12",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187565750586843136",
  "text" : "super informative talk from Paul Constantine of Standford on building reduced order models #siamuq12",
  "id" : 187565750586843136,
  "created_at" : "Wed Apr 04 15:42:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Young",
      "screen_name" : "ScottHYoung",
      "indices" : [ 0, 12 ],
      "id_str" : "32410914",
      "id" : 32410914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187413972545310722",
  "geo" : {
  },
  "id_str" : "187418083076472832",
  "in_reply_to_user_id" : 32410914,
  "text" : "@ScottHYoung and perhaps this is why education is so vital to everything: learned openmindedness",
  "id" : 187418083076472832,
  "in_reply_to_status_id" : 187413972545310722,
  "created_at" : "Wed Apr 04 05:55:27 +0000 2012",
  "in_reply_to_screen_name" : "ScottHYoung",
  "in_reply_to_user_id_str" : "32410914",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187368405119152128",
  "text" : "and just ran the bball court @ NCSU w Mark! Skills are back, throwin down with ease after a solid 7mi run today??",
  "id" : 187368405119152128,
  "created_at" : "Wed Apr 04 02:38:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187368140957696000",
  "text" : "Mark's friends paid my way to the front a 300 person line to get a free Ben and Jerry's cone!!! Free cone day salvaged!",
  "id" : 187368140957696000,
  "created_at" : "Wed Apr 04 02:37:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7938729, -78.6874489833 ]
  },
  "id_str" : "187312309834756097",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser cone day lives!!! 5000 Hillsborough!!",
  "id" : 187312309834756097,
  "created_at" : "Tue Apr 03 22:55:09 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classy",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187306075517747200",
  "text" : "creeping on the outdoor fitness class, guy who's done his fair share of bicep curls let's me know this is why he goes to the gym #classy",
  "id" : 187306075517747200,
  "created_at" : "Tue Apr 03 22:30:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 0, 12 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187302491380125696",
  "text" : "@OGfromtheOB \"fattism\" still okay! personally, I have as little tolerance for obesity as I do for ignorance",
  "id" : 187302491380125696,
  "created_at" : "Tue Apr 03 22:16:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharingmiserymakesitbetter",
      "indices" : [ 61, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187277300126060545",
  "geo" : {
  },
  "id_str" : "187281553288732672",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I also hear tomorrow is free burrito day at Boloco #sharingmiserymakesitbetter",
  "id" : 187281553288732672,
  "in_reply_to_status_id" : 187277300126060545,
  "created_at" : "Tue Apr 03 20:52:56 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 78, 97 ]
    }, {
      "text" : "vermonterproblems",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187281390394540033",
  "text" : "RT @dr_pyser: Free cone day at Ben and Jerry's and I'm at a conference in NC. #firstworldproblems #vermonterproblems",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstworldproblems",
        "indices" : [ 64, 83 ]
      }, {
        "text" : "vermonterproblems",
        "indices" : [ 84, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "187277300126060545",
    "text" : "Free cone day at Ben and Jerry's and I'm at a conference in NC. #firstworldproblems #vermonterproblems",
    "id" : 187277300126060545,
    "created_at" : "Tue Apr 03 20:36:02 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 187281390394540033,
  "created_at" : "Tue Apr 03 20:52:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NISS SAMSI",
      "screen_name" : "NISSSAMSI",
      "indices" : [ 0, 10 ],
      "id_str" : "11050032",
      "id" : 11050032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187278867092873217",
  "geo" : {
  },
  "id_str" : "187281278037532672",
  "in_reply_to_user_id" : 11050032,
  "text" : "@NISSSAMSI Understandable, slightly. I came from upstate NY to do my undergrad at Va Tech, but I learned... :P",
  "id" : 187281278037532672,
  "in_reply_to_status_id" : 187278867092873217,
  "created_at" : "Tue Apr 03 20:51:50 +0000 2012",
  "in_reply_to_screen_name" : "NISSSAMSI",
  "in_reply_to_user_id_str" : "11050032",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oops",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187276856456773632",
  "text" : "bag of assorted nuts was 1020 calories #oops",
  "id" : 187276856456773632,
  "created_at" : "Tue Apr 03 20:34:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siamuq12",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187272407692746752",
  "text" : "worst part of the #siamuq12 so far: poured myself tea, because we're in NC so I didn't think twice. almost spewed it out, unsweetened?!?",
  "id" : 187272407692746752,
  "created_at" : "Tue Apr 03 20:16:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187263322004004864",
  "geo" : {
  },
  "id_str" : "187271656954269696",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr congratulations Jim!!",
  "id" : 187271656954269696,
  "in_reply_to_status_id" : 187263322004004864,
  "created_at" : "Tue Apr 03 20:13:37 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 86, 94 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/LI5xTehC",
      "expanded_url" : "http://bit.ly/HOKJcP",
      "display_url" : "bit.ly/HOKJcP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "187230829020323841",
  "text" : "went on a great run during the conference lunch break today! http://t.co/LI5xTehC via @AddThis",
  "id" : 187230829020323841,
  "created_at" : "Tue Apr 03 17:31:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "187204821017829377",
  "text" : "instead of doing mile repeats, I'll attempt to avoid the parked cars today",
  "id" : 187204821017829377,
  "created_at" : "Tue Apr 03 15:48:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/UwU8xuh9",
      "expanded_url" : "http://en.wikipedia.org/wiki/Parkinson%27s_Law_of_Triviality/wiki/Parkinson%27s_Law_of_Triviality",
      "display_url" : "en.wikipedia.org/wiki/Parkinson…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186999559766020096",
  "text" : "came across the term \"bikeshedding\" and upon finding it's meaning, think it describes politics well http://t.co/UwU8xuh9",
  "id" : 186999559766020096,
  "created_at" : "Tue Apr 03 02:12:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/YPYZoT64",
      "expanded_url" : "http://4sq.com/HatwaG",
      "display_url" : "4sq.com/HatwaG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7759593277, -78.6447302809 ]
  },
  "id_str" : "186958823318241280",
  "text" : "\"can we have a whole pig? just one\" (@ The Pit) http://t.co/YPYZoT64",
  "id" : 186958823318241280,
  "created_at" : "Mon Apr 02 23:30:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Pajonk",
      "screen_name" : "opajonk",
      "indices" : [ 0, 8 ],
      "id_str" : "107506503",
      "id" : 107506503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186951051205820418",
  "in_reply_to_user_id" : 107506503,
  "text" : "@opajonk hey Oliver! I spoke to you after your talk, sorry for not introducing myself!",
  "id" : 186951051205820418,
  "created_at" : "Mon Apr 02 22:59:38 +0000 2012",
  "in_reply_to_screen_name" : "opajonk",
  "in_reply_to_user_id_str" : "107506503",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186949291963723776",
  "geo" : {
  },
  "id_str" : "186950820514902016",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C word, I'll be getting into town midnight-ish thursday night, and potentially leaving town 4pm friday. so we gotta meet up thurs!",
  "id" : 186950820514902016,
  "in_reply_to_status_id" : 186949291963723776,
  "created_at" : "Mon Apr 02 22:58:43 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186949076787539968",
  "text" : "brain fried. harsh intro to poly chaos. laying down before dinner! not sure if I'll be able to summon energy to do homework later jeez",
  "id" : 186949076787539968,
  "created_at" : "Mon Apr 02 22:51:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ12",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186911472931188736",
  "text" : "up now a mini-tutorial: \"UQ - Foundations and capabilities for model based simulations\" should be good! #SIAMUQ12",
  "id" : 186911472931188736,
  "created_at" : "Mon Apr 02 20:22:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mindexploding",
      "indices" : [ 90, 104 ]
    }, {
      "text" : "SIAMUQ12",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186910547688701954",
  "text" : "monte carlo, collocation, polynomial chaos, stochastic galekin, bayesian inverse problems #mindexploding #SIAMUQ12",
  "id" : 186910547688701954,
  "created_at" : "Mon Apr 02 20:18:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 3, 14 ],
      "id_str" : "16353686",
      "id" : 16353686
    }, {
      "name" : "ROTOR",
      "screen_name" : "ROTOR_bike",
      "indices" : [ 68, 79 ],
      "id_str" : "96997747",
      "id" : 96997747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/h8DmGvpH",
      "expanded_url" : "http://www.rotorbike.com/tryQ/evidence/SSCIvol06no01paper04.pdf",
      "display_url" : "rotorbike.com/tryQ/evidence/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186909663185485825",
  "text" : "RT @angryasian: Interesting and supposedly independent new study on @rotor_bike Q-rings: http://t.co/h8DmGvpH I already like them but th ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ROTOR",
        "screen_name" : "ROTOR_bike",
        "indices" : [ 52, 63 ],
        "id_str" : "96997747",
        "id" : 96997747
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http://t.co/h8DmGvpH",
        "expanded_url" : "http://www.rotorbike.com/tryQ/evidence/SSCIvol06no01paper04.pdf",
        "display_url" : "rotorbike.com/tryQ/evidence/…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "186898515849510912",
    "text" : "Interesting and supposedly independent new study on @rotor_bike Q-rings: http://t.co/h8DmGvpH I already like them but this is intriguing.",
    "id" : 186898515849510912,
    "created_at" : "Mon Apr 02 19:30:53 +0000 2012",
    "user" : {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "protected" : false,
      "id_str" : "16353686",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/904017577/105073547_normal.jpg",
      "id" : 16353686,
      "verified" : false
    }
  },
  "id" : 186909663185485825,
  "created_at" : "Mon Apr 02 20:15:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186866164528451586",
  "text" : "city running mile repeats fail, banged my hip on a parked car mirror #ouch",
  "id" : 186866164528451586,
  "created_at" : "Mon Apr 02 17:22:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186841492298530818",
  "text" : "lunch = chance to run",
  "id" : 186841492298530818,
  "created_at" : "Mon Apr 02 15:44:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ12",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186832886945689600",
  "text" : "\"UQ is a \"heroic quest\" in mathematics\" -Colin Fox #SIAMUQ12",
  "id" : 186832886945689600,
  "created_at" : "Mon Apr 02 15:10:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "convenient",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/NrfVxW1j",
      "expanded_url" : "http://4sq.com/HBAwkI",
      "display_url" : "4sq.com/HBAwkI"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7737037056, -78.640088439 ]
  },
  "id_str" : "186820790812020736",
  "text" : "could spend the entire week indoors, staying in same hotel as conference! #convenient (@ Raleigh Marriott City Center) http://t.co/NrfVxW1j",
  "id" : 186820790812020736,
  "created_at" : "Mon Apr 02 14:22:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ2012",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186816844110376960",
  "text" : "\"Bayesian Nonparametric Approach to Inverse Problems\" from Andrew Stuart, MCMC is useful (last talk knocked it!) #SIAMUQ2012",
  "id" : 186816844110376960,
  "created_at" : "Mon Apr 02 14:06:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SIAMUQ2012",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186796659290808321",
  "text" : "meeting goes till 6:30PM, had to go for the coffee #SIAMUQ2012",
  "id" : 186796659290808321,
  "created_at" : "Mon Apr 02 12:46:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/186575902103175168/photo/1",
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/J5SPO2YN",
      "media_url" : "http://pbs.twimg.com/media/ApbZy2DCAAIQ5bU.jpg",
      "id_str" : "186575902107369474",
      "id" : 186575902107369474,
      "media_url_https" : "https://pbs.twimg.com/media/ApbZy2DCAAIQ5bU.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/J5SPO2YN"
    } ],
    "hashtags" : [ {
      "text" : "SIAMUQ2012",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "186575902103175168",
  "text" : "a great start to #SIAMUQ2012 http://t.co/J5SPO2YN",
  "id" : 186575902103175168,
  "created_at" : "Sun Apr 01 22:08:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/YotHJF27",
      "expanded_url" : "http://yfrog.com/odfafcxzj",
      "display_url" : "yfrog.com/odfafcxzj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "186528678958739456",
  "text" : "today's wheels! http://t.co/YotHJF27",
  "id" : 186528678958739456,
  "created_at" : "Sun Apr 01 19:01:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]