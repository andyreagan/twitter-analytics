Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 86, 93 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/K61K8zZy",
      "expanded_url" : "http://www.youtube.com/watch?v=uE-1RPDqJAY",
      "display_url" : "youtube.com/watch?v=uE-1RP…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "297182505029750784",
  "text" : "the things people put on the internet: to lord of the rings fans http://t.co/K61K8zZy @ttmill",
  "id" : 297182505029750784,
  "created_at" : "Fri Feb 01 03:20:05 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 3, 14 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297144763155628032",
  "text" : "RT @peterdodds: impenguinate (vb): to complicate a situation by adding many penguins; resolvable by disimpenguination. #springpocs2013",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "springpocs2013",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "297138249388937216",
    "text" : "impenguinate (vb): to complicate a situation by adding many penguins; resolvable by disimpenguination. #springpocs2013",
    "id" : 297138249388937216,
    "created_at" : "Fri Feb 01 00:24:13 +0000 2013",
    "user" : {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "protected" : false,
      "id_str" : "16174144",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/294761101/IMG_7808_small_normal.JPG",
      "id" : 16174144,
      "verified" : false
    }
  },
  "id" : 297144763155628032,
  "created_at" : "Fri Feb 01 00:50:06 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297030676140679169",
  "text" : "the elephants in the room have been discovered #springpocs2013",
  "id" : 297030676140679169,
  "created_at" : "Thu Jan 31 17:16:46 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 15, 27 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "hugeday",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "297019073219407872",
  "text" : "congratulation @SumaNMNDesu on your self-promotion to Director of Language Acquisitions! #storylab #hugeday",
  "id" : 297019073219407872,
  "created_at" : "Thu Jan 31 16:30:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 9, 22 ],
      "id_str" : "14630047",
      "id" : 14630047
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 83, 96 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "starttraining",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/nlfgWFqR",
      "expanded_url" : "http://connect.garmin.com/course/2796773#.UQqXRFt7Brk.twitter",
      "display_url" : "connect.garmin.com/course/2796773…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "297014030218960896",
  "text" : "a map of @usatriathlon collegiate nats bike course, with elevation! #starttraining @uvmtriathlon http://t.co/nlfgWFqR",
  "id" : 297014030218960896,
  "created_at" : "Thu Jan 31 16:10:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296710066126589952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820992, -73.2030892 ]
  },
  "id_str" : "296754549773963264",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill come get it!!",
  "id" : 296754549773963264,
  "in_reply_to_status_id" : 296710066126589952,
  "created_at" : "Wed Jan 30 22:59:32 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burritojam",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "runvibes",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/EODW5cbL",
      "expanded_url" : "http://twitpic.com/bzm2xr",
      "display_url" : "twitpic.com/bzm2xr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820874, -73.2030266 ]
  },
  "id_str" : "296754489904463872",
  "text" : "january running in shorts and a tshirt! burrito and beer recovery #burritojam #runvibes http://t.co/EODW5cbL",
  "id" : 296754489904463872,
  "created_at" : "Wed Jan 30 22:59:18 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/aUrsyMQE",
      "expanded_url" : "http://twitpic.com/bzjfdx",
      "display_url" : "twitpic.com/bzjfdx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4831788, -73.1934083 ]
  },
  "id_str" : "296640335164092416",
  "text" : "do boys and girls think alike? you tell me: #storylab http://t.co/aUrsyMQE",
  "id" : 296640335164092416,
  "created_at" : "Wed Jan 30 15:25:41 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/89K01FR3",
      "expanded_url" : "http://www.theonion.com/articles/62yearold-with-gun-only-one-standing-between-natio,30984/",
      "display_url" : "theonion.com/articles/62yea…"
    } ]
  },
  "in_reply_to_status_id_str" : "296288262748790785",
  "geo" : {
  },
  "id_str" : "296313101161213953",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn http://t.co/89K01FR3",
  "id" : 296313101161213953,
  "in_reply_to_status_id" : 296288262748790785,
  "created_at" : "Tue Jan 29 17:45:23 +0000 2013",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vermont",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "btv",
      "indices" : [ 40, 44 ]
    }, {
      "text" : "storylab",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "296312394152550400",
  "text" : "XC skiing before, and to class #vermont #btv #storylab",
  "id" : 296312394152550400,
  "created_at" : "Tue Jan 29 17:42:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "296312180075294720",
  "text" : "\"the search for terrestrial intelligence should perhaps come first\" #springpocs2013",
  "id" : 296312180075294720,
  "created_at" : "Tue Jan 29 17:41:43 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 44, 51 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "295365667585134593",
  "text" : "looking over my shoulder while programming, @sspis1 read my comment lines and thinks codings easy \"% check back here every once in awhile..\"",
  "id" : 295365667585134593,
  "created_at" : "Sun Jan 27 03:00:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 3, 14 ],
      "id_str" : "23695888",
      "id" : 23695888
    }, {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 54, 67 ],
      "id_str" : "17900130",
      "id" : 17900130
    }, {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 81, 92 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "295325161392062464",
  "text" : "RT @iamtedking: That one took a long time to write RT @BicyclingMag: Latest from @IamTedKing: The best-kept secret in pro cycling is...  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bicycling Magazine",
        "screen_name" : "BicyclingMag",
        "indices" : [ 38, 51 ],
        "id_str" : "17900130",
        "id" : 17900130
      }, {
        "name" : "Ted King",
        "screen_name" : "iamtedking",
        "indices" : [ 65, 76 ],
        "id_str" : "23695888",
        "id" : 23695888
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/0Q9vxSNJ",
        "expanded_url" : "http://ow.ly/h8gln",
        "display_url" : "ow.ly/h8gln"
      } ]
    },
    "geo" : {
    },
    "id_str" : "294968476009893890",
    "text" : "That one took a long time to write RT @BicyclingMag: Latest from @IamTedKing: The best-kept secret in pro cycling is... http://t.co/0Q9vxSNJ",
    "id" : 294968476009893890,
    "created_at" : "Sat Jan 26 00:42:19 +0000 2013",
    "user" : {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "protected" : false,
      "id_str" : "23695888",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2244513395/IMAG0190-1_normal.jpg",
      "id" : 23695888,
      "verified" : false
    }
  },
  "id" : 295325161392062464,
  "created_at" : "Sun Jan 27 00:19:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http://t.co/mmy2wMpB",
      "expanded_url" : "http://twitpic.com/by8nf1",
      "display_url" : "twitpic.com/by8nf1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820255, -73.2030357 ]
  },
  "id_str" : "294962873183121410",
  "text" : "after http://t.co/mmy2wMpB",
  "id" : 294962873183121410,
  "created_at" : "Sat Jan 26 00:20:03 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294907061203005440",
  "geo" : {
  },
  "id_str" : "294958805337403393",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill gross",
  "id" : 294958805337403393,
  "in_reply_to_status_id" : 294907061203005440,
  "created_at" : "Sat Jan 26 00:03:53 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/xW1ZKl0q",
      "expanded_url" : "http://twitpic.com/by8jyy",
      "display_url" : "twitpic.com/by8jyy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294958773339033601",
  "text" : "naan flatbread, before: http://t.co/xW1ZKl0q",
  "id" : 294958773339033601,
  "created_at" : "Sat Jan 26 00:03:46 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brooking",
      "screen_name" : "btvjim",
      "indices" : [ 0, 7 ],
      "id_str" : "476054791",
      "id" : 476054791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294930265602682880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822669, -73.20320002 ]
  },
  "id_str" : "294938855394668546",
  "in_reply_to_user_id" : 476054791,
  "text" : "@btvjim barleywines have been known to steal the unprepared's lunch money",
  "id" : 294938855394668546,
  "in_reply_to_status_id" : 294930265602682880,
  "created_at" : "Fri Jan 25 22:44:37 +0000 2013",
  "in_reply_to_screen_name" : "btvjim",
  "in_reply_to_user_id_str" : "476054791",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mylittlecupcake",
      "indices" : [ 4, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/V5r6UDNP",
      "expanded_url" : "http://twitpic.com/by62ci",
      "display_url" : "twitpic.com/by62ci"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.483155, -73.193375 ]
  },
  "id_str" : "294850081847382017",
  "text" : "yum #mylittlecupcake http://t.co/V5r6UDNP",
  "id" : 294850081847382017,
  "created_at" : "Fri Jan 25 16:51:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/bXl3tTZf",
      "expanded_url" : "http://twitpic.com/bxy23v",
      "display_url" : "twitpic.com/bxy23v"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4682145, -73.1766977 ]
  },
  "id_str" : "294561365530644480",
  "text" : "the official drink of graduate school http://t.co/bXl3tTZf",
  "id" : 294561365530644480,
  "created_at" : "Thu Jan 24 21:44:36 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 1, 12 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "294491068395835392",
  "text" : ".@peterdodds are you from new zealand?",
  "id" : 294491068395835392,
  "created_at" : "Thu Jan 24 17:05:16 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henry",
      "screen_name" : "D_AHenry",
      "indices" : [ 0, 9 ],
      "id_str" : "1116151178",
      "id" : 1116151178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "294437230183866370",
  "in_reply_to_user_id" : 1116151178,
  "text" : "@D_AHenry welcome to twitter! never thought this day would come",
  "id" : 294437230183866370,
  "created_at" : "Thu Jan 24 13:31:20 +0000 2013",
  "in_reply_to_screen_name" : "D_AHenry",
  "in_reply_to_user_id_str" : "1116151178",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 0, 8 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "294259225205551104",
  "in_reply_to_user_id" : 811907299,
  "text" : "@linzvee i don't have your email somehow, shoot me a msg andy at andyreagan dot com",
  "id" : 294259225205551104,
  "created_at" : "Thu Jan 24 01:44:01 +0000 2013",
  "in_reply_to_screen_name" : "linzvee",
  "in_reply_to_user_id_str" : "811907299",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 27, 40 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 47, 57 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4697635, -73.1943294 ]
  },
  "id_str" : "294238692690780160",
  "text" : "good quick track workout w @UVMTriathlon coach @conneryVT!",
  "id" : 294238692690780160,
  "created_at" : "Thu Jan 24 00:22:25 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Wolfers",
      "screen_name" : "justinwolfers",
      "indices" : [ 50, 64 ],
      "id_str" : "327577091",
      "id" : 327577091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/HiClp7VM",
      "expanded_url" : "http://n.pr/ZDMmUV",
      "display_url" : "n.pr/ZDMmUV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "294113585582448641",
  "text" : "w more than work-related, might be office job! MT @justinwolfers Deadliest jobs in America: Fisherman, logger and pilot http://t.co/HiClp7VM",
  "id" : 294113585582448641,
  "created_at" : "Wed Jan 23 16:05:17 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/294090338312785920/photo/1",
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/IKtqJdBg",
      "media_url" : "http://pbs.twimg.com/media/BBTRmsNCEAA_O_5.jpg",
      "id_str" : "294090338316980224",
      "id" : 294090338316980224,
      "media_url_https" : "https://pbs.twimg.com/media/BBTRmsNCEAA_O_5.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 1544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/IKtqJdBg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "294090338312785920",
  "text" : "how to get to class when it's -5 out: http://t.co/IKtqJdBg",
  "id" : 294090338312785920,
  "created_at" : "Wed Jan 23 14:32:55 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chaoticsink",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/NK9Cmc1m",
      "expanded_url" : "http://twitpic.com/bxhjqr",
      "display_url" : "twitpic.com/bxhjqr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819742, -73.20299192 ]
  },
  "id_str" : "293930944593793024",
  "text" : "unfortunately my faucet doesnt have fine enough control to exhibit period doubling #chaoticsink http://t.co/NK9Cmc1m",
  "id" : 293930944593793024,
  "created_at" : "Wed Jan 23 03:59:32 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 37, 44 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crafty",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/TBo2WKdb",
      "expanded_url" : "http://twitpic.com/bxhheg",
      "display_url" : "twitpic.com/bxhheg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821007, -73.2030031 ]
  },
  "id_str" : "293928216899510272",
  "text" : "homemade spice rack, anyone? #crafty @sspis1 http://t.co/TBo2WKdb",
  "id" : 293928216899510272,
  "created_at" : "Wed Jan 23 03:48:42 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/YkjdfZzm",
      "expanded_url" : "http://www.nytimes.com/2007/01/28/magazine/28nutritionism.t.html?_r=0",
      "display_url" : "nytimes.com/2007/01/28/mag…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "293787759989112832",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin good stuff: http://t.co/YkjdfZzm",
  "id" : 293787759989112832,
  "created_at" : "Tue Jan 22 18:30:34 +0000 2013",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "293765590047420416",
  "text" : "RT @SumaNMNDesu: \" A lot of connections between combinatorics, probability, and insanity...but its the first two we should worry about\"  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doddsism",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "293762719620931584",
    "text" : "\" A lot of connections between combinatorics, probability, and insanity...but its the first two we should worry about\" #doddsism",
    "id" : 293762719620931584,
    "created_at" : "Tue Jan 22 16:51:04 +0000 2013",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 293765590047420416,
  "created_at" : "Tue Jan 22 17:02:29 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vermontwinterprobz",
      "indices" : [ 83, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/trqvFeyu",
      "expanded_url" : "http://www.youtube.com/watch?v=Y6qR_1eEOH4",
      "display_url" : "youtube.com/watch?v=Y6qR_1…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "293758318441279488",
  "text" : "valid excuses to be late to class: it's so cold that you freehub body freezes open #vermontwinterprobz http://t.co/trqvFeyu",
  "id" : 293758318441279488,
  "created_at" : "Tue Jan 22 16:33:35 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 53, 67 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4792496, -73.1980228 ]
  },
  "id_str" : "293748202706980864",
  "text" : "\"polynomial wiggleness: polynomials like to wiggle\" -@ChrisDanforth",
  "id" : 293748202706980864,
  "created_at" : "Tue Jan 22 15:53:23 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 27, 39 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 40, 47 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trappfamilylodge",
      "indices" : [ 62, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/clGXzk6L",
      "expanded_url" : "http://twitpic.com/bx7qkn",
      "display_url" : "twitpic.com/bx7qkn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "293531065631506432",
  "text" : "the cabin at trapp lodge w @mrfrank5790 @sspis1 and Catherine #trappfamilylodge http://t.co/clGXzk6L",
  "id" : 293531065631506432,
  "created_at" : "Tue Jan 22 01:30:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/jcuy6GaU",
      "expanded_url" : "http://twitpic.com/bx7qft",
      "display_url" : "twitpic.com/bx7qft"
    } ]
  },
  "geo" : {
  },
  "id_str" : "293530889118429186",
  "text" : "the little engine that could [deliver beer] http://t.co/jcuy6GaU",
  "id" : 293530889118429186,
  "created_at" : "Tue Jan 22 01:29:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 42, 49 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ready",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/gdLHCcS8",
      "expanded_url" : "http://twitpic.com/bdja0h",
      "display_url" : "twitpic.com/bdja0h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "293530842700075008",
  "text" : "all I need is a green man suit now #ready @sspis1 http://t.co/gdLHCcS8",
  "id" : 293530842700075008,
  "created_at" : "Tue Jan 22 01:29:41 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482105, -73.2029948 ]
  },
  "id_str" : "293530794381692928",
  "text" : "unloading the tweets that didnt send now, including today at Trapp Lodge!",
  "id" : 293530794381692928,
  "created_at" : "Tue Jan 22 01:29:29 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293134211781640192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.466289, -73.20011381 ]
  },
  "id_str" : "293179271487320066",
  "in_reply_to_user_id" : 16174144,
  "text" : "@peterdodds graupel translates to real suffering on the road bike #ouch",
  "id" : 293179271487320066,
  "in_reply_to_status_id" : 293134211781640192,
  "created_at" : "Mon Jan 21 02:12:39 +0000 2013",
  "in_reply_to_screen_name" : "peterdodds",
  "in_reply_to_user_id_str" : "16174144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 77, 84 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "gopro",
      "indices" : [ 46, 52 ]
    }, {
      "text" : "vermont",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "sledtheeast",
      "indices" : [ 62, 74 ]
    }, {
      "text" : "fb",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/V3NpQGOo",
      "expanded_url" : "http://vimeo.com/m/57814353",
      "display_url" : "vimeo.com/m/57814353"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46625996, -73.19992238 ]
  },
  "id_str" : "293178484518424576",
  "text" : "extreme sledding: camel's hump style #awesome #gopro #vermont #sledtheeast w @sspis1 http://t.co/V3NpQGOo #fb",
  "id" : 293178484518424576,
  "created_at" : "Mon Jan 21 02:09:32 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292778212616974337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821715, -73.2029538 ]
  },
  "id_str" : "292778608357957632",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e ah yes!!",
  "id" : 292778608357957632,
  "in_reply_to_status_id" : 292778212616974337,
  "created_at" : "Sat Jan 19 23:40:34 +0000 2013",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 11, 19 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Pat Kemple",
      "screen_name" : "pkemp33",
      "indices" : [ 20, 28 ],
      "id_str" : "103102170",
      "id" : 103102170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292776477408260097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821049, -73.2029934 ]
  },
  "id_str" : "292777094847537152",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT @Karo1yn @pkemp33 I'm in!!",
  "id" : 292777094847537152,
  "in_reply_to_status_id" : 292776477408260097,
  "created_at" : "Sat Jan 19 23:34:33 +0000 2013",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821798, -73.2029528 ]
  },
  "id_str" : "292776120452014080",
  "text" : "the first bite is always the best. it's all downhill from there. am I right?",
  "id" : 292776120452014080,
  "created_at" : "Sat Jan 19 23:30:41 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292770117673177088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820984, -73.2030061 ]
  },
  "id_str" : "292774452142415872",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT oh no, but I think I'm going to try to find a weekly race or something. sunny hollow has one, right?",
  "id" : 292774452142415872,
  "in_reply_to_status_id" : 292770117673177088,
  "created_at" : "Sat Jan 19 23:24:03 +0000 2013",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292754038322253824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821366, -73.2029587 ]
  },
  "id_str" : "292769308906508288",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT I raced the TdSuck, it was first time on those funny things!",
  "id" : 292769308906508288,
  "in_reply_to_status_id" : 292754038322253824,
  "created_at" : "Sat Jan 19 23:03:37 +0000 2013",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stowe",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.50487047, -72.76295815 ]
  },
  "id_str" : "292724075766370305",
  "text" : "xc skiing is a blast #stowe",
  "id" : 292724075766370305,
  "created_at" : "Sat Jan 19 20:03:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stowe",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48187403, -72.72735029 ]
  },
  "id_str" : "292662399276814338",
  "text" : "#stowe",
  "id" : 292662399276814338,
  "created_at" : "Sat Jan 19 15:58:48 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292345675176345600",
  "geo" : {
  },
  "id_str" : "292360041590312960",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill ouch man, ouch",
  "id" : 292360041590312960,
  "in_reply_to_status_id" : 292345675176345600,
  "created_at" : "Fri Jan 18 19:57:20 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 0, 11 ],
      "id_str" : "606793907",
      "id" : 606793907
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 16, 23 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821567, -73.202954 ]
  },
  "id_str" : "292086037914738689",
  "in_reply_to_user_id" : 606793907,
  "text" : "@withane271 fyi @sspis1 's phone took a swim today, Oona dropped it in a pond (I just happened to be holding her, not related)",
  "id" : 292086037914738689,
  "created_at" : "Fri Jan 18 01:48:32 +0000 2013",
  "in_reply_to_screen_name" : "withane271",
  "in_reply_to_user_id_str" : "606793907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 34, 42 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 43, 53 ],
      "id_str" : "528928681",
      "id" : 528928681
    }, {
      "name" : "Alisa McGowan",
      "screen_name" : "AMCG913",
      "indices" : [ 54, 62 ],
      "id_str" : "351965147",
      "id" : 351965147
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 63, 70 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/ksQ3KsMr",
      "expanded_url" : "http://twitpic.com/bw3c0r",
      "display_url" : "twitpic.com/bw3c0r"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48192905, -73.20324411 ]
  },
  "id_str" : "292085663505997824",
  "text" : "the blinding light of 22 candles! @Karo1yn @jcusick13 @AMCG913 @sspis1 http://t.co/ksQ3KsMr",
  "id" : 292085663505997824,
  "created_at" : "Fri Jan 18 01:47:03 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 30, 37 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatsfordinner",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/6J0gugAH",
      "expanded_url" : "http://twitpic.com/bw2xdw",
      "display_url" : "twitpic.com/bw2xdw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820995, -73.2029901 ]
  },
  "id_str" : "292066461558652928",
  "text" : "rolled eggplant thingies from @sspis1 #whatsfordinner http://t.co/6J0gugAH",
  "id" : 292066461558652928,
  "created_at" : "Fri Jan 18 00:30:45 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 18, 26 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/TBPGXsJR",
      "expanded_url" : "http://twitpic.com/bw2vkb",
      "display_url" : "twitpic.com/bw2vkb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821002, -73.2029859 ]
  },
  "id_str" : "292063923518193665",
  "text" : "happy birthday to @Karo1yn http://t.co/TBPGXsJR",
  "id" : 292063923518193665,
  "created_at" : "Fri Jan 18 00:20:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 3, 11 ],
      "id_str" : "300735398",
      "id" : 300735398
    }, {
      "name" : "Lena Groeger",
      "screen_name" : "lenagroeger",
      "indices" : [ 95, 107 ],
      "id_str" : "55247508",
      "id" : 55247508
    }, {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 108, 119 ],
      "id_str" : "14606079",
      "id" : 14606079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/MK9Kdtoj",
      "expanded_url" : "http://projects.propublica.org/guns/",
      "display_url" : "projects.propublica.org/guns/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "291992639971139584",
  "text" : "RT @aatishb: Where Congress stands on guns. http://t.co/MK9Kdtoj Really great visualization by @lenagroeger @propublica",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lena Groeger",
        "screen_name" : "lenagroeger",
        "indices" : [ 82, 94 ],
        "id_str" : "55247508",
        "id" : 55247508
      }, {
        "name" : "ProPublica",
        "screen_name" : "ProPublica",
        "indices" : [ 95, 106 ],
        "id_str" : "14606079",
        "id" : 14606079
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http://t.co/MK9Kdtoj",
        "expanded_url" : "http://projects.propublica.org/guns/",
        "display_url" : "projects.propublica.org/guns/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "291991198376263682",
    "text" : "Where Congress stands on guns. http://t.co/MK9Kdtoj Really great visualization by @lenagroeger @propublica",
    "id" : 291991198376263682,
    "created_at" : "Thu Jan 17 19:31:41 +0000 2013",
    "user" : {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "protected" : false,
      "id_str" : "300735398",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004047290/1fb4826dac2a09c3431bf19a21c0d669_normal.jpeg",
      "id" : 300735398,
      "verified" : false
    }
  },
  "id" : 291992639971139584,
  "created_at" : "Thu Jan 17 19:37:24 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 3, 12 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "291377296047222785",
  "text" : "RT @vmhilljr: @andyreagan So what is your contribution? Besides taking pictures and tweeting, I mean. Never mind, I think I know.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "291376095314464768",
    "geo" : {
    },
    "id_str" : "291376467575730176",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan So what is your contribution? Besides taking pictures and tweeting, I mean. Never mind, I think I know.",
    "id" : 291376467575730176,
    "in_reply_to_status_id" : 291376095314464768,
    "created_at" : "Wed Jan 16 02:48:58 +0000 2013",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "protected" : false,
      "id_str" : "104673361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1681278155/wally_normal.jpg",
      "id" : 104673361,
      "verified" : false
    }
  },
  "id" : 291377296047222785,
  "created_at" : "Wed Jan 16 02:52:15 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 50, 57 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/EeK4lYxt",
      "expanded_url" : "http://twitpic.com/bvl1sz",
      "display_url" : "twitpic.com/bvl1sz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820024, -73.20309965 ]
  },
  "id_str" : "291376095314464768",
  "text" : "pan frying homemade vegan black bean burgers that @sspis1 made #yum (she's also doing the frying) http://t.co/EeK4lYxt",
  "id" : 291376095314464768,
  "created_at" : "Wed Jan 16 02:47:29 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenJerrysVT",
      "screen_name" : "BenJerrysVT",
      "indices" : [ 14, 26 ],
      "id_str" : "303916863",
      "id" : 303916863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/J5xnIYBP",
      "expanded_url" : "http://twitpic.com/bvku78",
      "display_url" : "twitpic.com/bvku78"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4472082, -73.1207304 ]
  },
  "id_str" : "291366840955985920",
  "text" : "his and hers, @BenJerrysVT style http://t.co/J5xnIYBP",
  "id" : 291366840955985920,
  "created_at" : "Wed Jan 16 02:10:42 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 94, 103 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/G5MGJNka",
      "expanded_url" : "http://twitpic.com/bvkt69",
      "display_url" : "twitpic.com/bvkt69"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.44572431, -73.11403836 ]
  },
  "id_str" : "291365377752064000",
  "text" : "I'll be lookin fly (and more importantly not rolling an ankle) special thanks to the vern guy @vmhilljr http://t.co/G5MGJNka",
  "id" : 291365377752064000,
  "created_at" : "Wed Jan 16 02:04:54 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821004, -73.2029801 ]
  },
  "id_str" : "291351257325654016",
  "text" : "I actually kinda enjoy night running these days, the quietness of the bike path along the black water is unbeatable",
  "id" : 291351257325654016,
  "created_at" : "Wed Jan 16 01:08:47 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/IyhBrb2R",
      "expanded_url" : "http://nixle.com/register/",
      "display_url" : "nixle.com/register/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "291326709326823425",
  "text" : "#btv-ers: you can sign up for text message alerts of parking bans http://t.co/IyhBrb2R",
  "id" : 291326709326823425,
  "created_at" : "Tue Jan 15 23:31:14 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291284372613644288",
  "geo" : {
  },
  "id_str" : "291314231914164224",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan yeah can you send me the .tcx?",
  "id" : 291314231914164224,
  "in_reply_to_status_id" : 291284372613644288,
  "created_at" : "Tue Jan 15 22:41:39 +0000 2013",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 111 ],
      "url" : "https://t.co/IFqDX70b",
      "expanded_url" : "https://github.com/edu",
      "display_url" : "github.com/edu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "291312773990858753",
  "text" : "Student programmers! You can get a free Github micro account, which normally costs $8/mo! https://t.co/IFqDX70b",
  "id" : 291312773990858753,
  "created_at" : "Tue Jan 15 22:35:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291011086218575872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821061, -73.2029808 ]
  },
  "id_str" : "291012094730579968",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr spot on, sir",
  "id" : 291012094730579968,
  "in_reply_to_status_id" : 291011086218575872,
  "created_at" : "Tue Jan 15 02:41:04 +0000 2013",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 29, 36 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 37, 45 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Brie Timm",
      "screen_name" : "KaluYala_BrieT",
      "indices" : [ 46, 61 ],
      "id_str" : "304504811",
      "id" : 304504811
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 62, 71 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 73, 80 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 82, 93 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821319, -73.2029887 ]
  },
  "id_str" : "291010320875524097",
  "text" : "you can say that again, ahem @sspis1 @Karo1yn @KaluYala_BrieT @dmreagan \"@ttmill: @andyreagan A person is never too old for legos\"",
  "id" : 291010320875524097,
  "created_at" : "Tue Jan 15 02:34:01 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itsfull",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/cO3ircdt",
      "expanded_url" : "http://twitpic.com/bvbrmj",
      "display_url" : "twitpic.com/bvbrmj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482106, -73.2029809 ]
  },
  "id_str" : "291009967379578881",
  "text" : "lego needs to spec their trainset with more horsepower anyway #itsfull http://t.co/cO3ircdt",
  "id" : 291009967379578881,
  "created_at" : "Tue Jan 15 02:32:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821041, -73.2029686 ]
  },
  "id_str" : "291009495860137984",
  "text" : "the lego train set had to be put away... \"its like we live with a 10 year old boy\" -my roommates",
  "id" : 291009495860137984,
  "created_at" : "Tue Jan 15 02:30:45 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 48, 58 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/K5GBexPD",
      "expanded_url" : "http://twitpic.com/bvbqzl",
      "display_url" : "twitpic.com/bvbqzl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821027, -73.2030037 ]
  },
  "id_str" : "291009209611460609",
  "text" : "smugglers notch scotch (ale) courtesy of my boy @Crispy__C http://t.co/K5GBexPD",
  "id" : 291009209611460609,
  "created_at" : "Tue Jan 15 02:29:36 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 9, 18 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Utica Boilermaker",
      "screen_name" : "Boilermaker15K",
      "indices" : [ 20, 35 ],
      "id_str" : "26848907",
      "id" : 26848907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boilermaker15k",
      "indices" : [ 57, 72 ]
    }, {
      "text" : "running",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "runchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821494, -73.2029774 ]
  },
  "id_str" : "291006733894160385",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn @dmreagan \"@Boilermaker15K: The 15k is sold out #boilermaker15k #running #runchat\"",
  "id" : 291006733894160385,
  "created_at" : "Tue Jan 15 02:19:46 +0000 2013",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/g1PxmgjF",
      "expanded_url" : "http://twitpic.com/buz8uy",
      "display_url" : "twitpic.com/buz8uy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4939749, -73.1970255 ]
  },
  "id_str" : "290602141796671488",
  "text" : "the little engine that could [deliver beer] http://t.co/g1PxmgjF",
  "id" : 290602141796671488,
  "created_at" : "Sun Jan 13 23:32:04 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/6QPlNwxy",
      "expanded_url" : "http://twitpic.com/buylfh",
      "display_url" : "twitpic.com/buylfh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.39317561, -72.97254913 ]
  },
  "id_str" : "290570541843230720",
  "text" : "the roads are muddy in VT... looks like my shoes were just out there at cross nats http://t.co/6QPlNwxy",
  "id" : 290570541843230720,
  "created_at" : "Sun Jan 13 21:26:30 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290533108204306432",
  "text" : "smooth drive back to #btv, headed for a bike ride outdoors!",
  "id" : 290533108204306432,
  "created_at" : "Sun Jan 13 18:57:45 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 50, 57 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4pack",
      "indices" : [ 31, 37 ]
    }, {
      "text" : "belgianstyle",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "saison",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/mOnrIqov",
      "expanded_url" : "http://twitpic.com/buqm8y",
      "display_url" : "twitpic.com/buqm8y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.93310901, -76.55458733 ]
  },
  "id_str" : "290316685997662209",
  "text" : "Ommegang brews some fine ales, #4pack courtesy of @DZdan1 #belgianstyle #saison http://t.co/mOnrIqov",
  "id" : 290316685997662209,
  "created_at" : "Sun Jan 13 04:37:46 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 75, 86 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290272055092473857",
  "text" : "RT @DZdan1: \"I could prob fit in your gf's shirt too...if...you had a gf.\"-@andyreagan",
  "id" : 290272055092473857,
  "created_at" : "Sun Jan 13 01:40:25 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 20, 32 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "champion",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "ironwoman",
      "indices" : [ 97, 107 ]
    }, {
      "text" : "fb",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290267750377586690",
  "text" : "Chrissy Esposito of @VTTriathlon just finished the Bone Island Ironman in 12.5 hours!! #champion #ironwoman #fb",
  "id" : 290267750377586690,
  "created_at" : "Sun Jan 13 01:23:19 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 42, 54 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 110, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290173593978032128",
  "text" : "correction: waiting online for Chrissy of @VTTriathlon to get off the bike in her first *ironman*! go faster! #fb (and onto the marathon)",
  "id" : 290173593978032128,
  "created_at" : "Sat Jan 12 19:09:10 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 30, 42 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "290173414667337729",
  "text" : "waiting online for Chrissy of @VTTriathlon to get off the bike in her first marathon! go faster! #fb",
  "id" : 290173414667337729,
  "created_at" : "Sat Jan 12 19:08:27 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 52, 61 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/pcyroc31",
      "expanded_url" : "http://twitpic.com/bun2oa",
      "display_url" : "twitpic.com/bun2oa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9802334, -76.3052431 ]
  },
  "id_str" : "290173107350695938",
  "text" : "january CNY run in shorts and a t? just happened, w @dmreagan http://t.co/pcyroc31",
  "id" : 290173107350695938,
  "created_at" : "Sat Jan 12 19:07:14 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/EXluzcXZ",
      "expanded_url" : "http://twitpic.com/bucrwo",
      "display_url" : "twitpic.com/bucrwo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9802336, -76.3052433 ]
  },
  "id_str" : "289814262677913600",
  "text" : "holy guacamole http://t.co/EXluzcXZ",
  "id" : 289814262677913600,
  "created_at" : "Fri Jan 11 19:21:19 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/iGcoKm4U",
      "expanded_url" : "http://twitpic.com/bu5kvm",
      "display_url" : "twitpic.com/bu5kvm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0469846, -76.2275509 ]
  },
  "id_str" : "289554384700964865",
  "text" : "the aisle of POISON http://t.co/iGcoKm4U",
  "id" : 289554384700964865,
  "created_at" : "Fri Jan 11 02:08:39 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289458161117696000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98015949, -76.30517206 ]
  },
  "id_str" : "289469502054338561",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill I meant do you want to ride together lol, I'm over in marcellus",
  "id" : 289469502054338561,
  "in_reply_to_status_id" : 289458161117696000,
  "created_at" : "Thu Jan 10 20:31:22 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/15SZRgkX",
      "expanded_url" : "http://arxiv.org/abs/1301.1937",
      "display_url" : "arxiv.org/abs/1301.1937"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0434766, -76.1434902 ]
  },
  "id_str" : "289405895560003584",
  "text" : "how could i not read \"The 3 stooges of vector calculus and their impersonators: A viewers guide to the classic episode\" http://t.co/15SZRgkX",
  "id" : 289405895560003584,
  "created_at" : "Thu Jan 10 16:18:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289391158671601664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0435442, -76.1435124 ]
  },
  "id_str" : "289392230660182017",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill bike ride sunday morning, perhaps??",
  "id" : 289392230660182017,
  "in_reply_to_status_id" : 289391158671601664,
  "created_at" : "Thu Jan 10 15:24:19 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289383592965066752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0435316, -76.1435013 ]
  },
  "id_str" : "289391993711362048",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 you should share yours! spread the love of kids learning chemistry",
  "id" : 289391993711362048,
  "in_reply_to_status_id" : 289383592965066752,
  "created_at" : "Thu Jan 10 15:23:22 +0000 2013",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 71, 78 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.42138052, -73.21235568 ]
  },
  "id_str" : "289152269344182272",
  "text" : "awesome fun today hiking camels hump and extreme sledding down it with @sspis1 today!! gopro video coming up later",
  "id" : 289152269344182272,
  "created_at" : "Wed Jan 09 23:30:47 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin D. Bloom",
      "screen_name" : "benjamindbloom",
      "indices" : [ 0, 15 ],
      "id_str" : "83238957",
      "id" : 83238957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288819464265412609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821377, -73.2029714 ]
  },
  "id_str" : "288821225235554305",
  "in_reply_to_user_id" : 83238957,
  "text" : "@benjamindbloom so you could always export the sildeshow as a movie, then re-import that movie and adjust the speed. wish I had my mac w me",
  "id" : 288821225235554305,
  "in_reply_to_status_id" : 288819464265412609,
  "created_at" : "Wed Jan 09 01:35:20 +0000 2013",
  "in_reply_to_screen_name" : "benjamindbloom",
  "in_reply_to_user_id_str" : "83238957",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin D. Bloom",
      "screen_name" : "benjamindbloom",
      "indices" : [ 0, 15 ],
      "id_str" : "83238957",
      "id" : 83238957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288815146279772163",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48197153, -73.20282069 ]
  },
  "id_str" : "288819053085212672",
  "in_reply_to_user_id" : 83238957,
  "text" : "@benjamindbloom well iMovie 6 has a time lapse built in I think. and for the slideshow method, just use .04sec each (or less) for higher fps",
  "id" : 288819053085212672,
  "in_reply_to_status_id" : 288815146279772163,
  "created_at" : "Wed Jan 09 01:26:42 +0000 2013",
  "in_reply_to_screen_name" : "benjamindbloom",
  "in_reply_to_user_id_str" : "83238957",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelingfit",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "goodrunvibes",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482103, -73.2029993 ]
  },
  "id_str" : "288807657844899840",
  "text" : "easy 40min run and I got 5.5 miles in #feelingfit #goodrunvibes",
  "id" : 288807657844899840,
  "created_at" : "Wed Jan 09 00:41:26 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin D. Bloom",
      "screen_name" : "benjamindbloom",
      "indices" : [ 0, 15 ],
      "id_str" : "83238957",
      "id" : 83238957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288805398520139777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820939, -73.202993 ]
  },
  "id_str" : "288807151344951298",
  "in_reply_to_user_id" : 83238957,
  "text" : "@benjamindbloom iMovie can do it. make a slideshow and show each photo for .1sec (for 10fps)",
  "id" : 288807151344951298,
  "in_reply_to_status_id" : 288805398520139777,
  "created_at" : "Wed Jan 09 00:39:25 +0000 2013",
  "in_reply_to_screen_name" : "benjamindbloom",
  "in_reply_to_user_id_str" : "83238957",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 56, 72 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/M9kdV7AA",
      "expanded_url" : "http://twitpic.com/btm0gl",
      "display_url" : "twitpic.com/btm0gl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821028, -73.2029849 ]
  },
  "id_str" : "288760394665844737",
  "text" : "extra long bits being put to use hanging blinds, thanks @RumblinStumblin. maybe now the sun wont wake me at 5am http://t.co/M9kdV7AA",
  "id" : 288760394665844737,
  "created_at" : "Tue Jan 08 21:33:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 20, 27 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 125, 136 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cherrysprite",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/tm0ZEhRx",
      "expanded_url" : "http://yfrog.com/mmu95bbj",
      "display_url" : "yfrog.com/mmu95bbj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821427, -73.2029669 ]
  },
  "id_str" : "288750592166334467",
  "text" : "grape motor oil!?! \"@sspis1: http://t.co/tm0ZEhRx someone is having too much fun at the new moes soda machine #cherrysprite! @andyreagan\"",
  "id" : 288750592166334467,
  "created_at" : "Tue Jan 08 20:54:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "borderingonmasochism",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821022, -73.2029755 ]
  },
  "id_str" : "288750368161140736",
  "text" : "me to roommate: feel free to use this roller. him: thanks,but the foam roller is just too soft after using my pvc pipe #borderingonmasochism",
  "id" : 288750368161140736,
  "created_at" : "Tue Jan 08 20:53:47 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288486407444525056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48224025, -73.20307319 ]
  },
  "id_str" : "288491094197547009",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e are they on the 17 day diet? ive seen the board!",
  "id" : 288491094197547009,
  "in_reply_to_status_id" : 288486407444525056,
  "created_at" : "Tue Jan 08 03:43:31 +0000 2013",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288473182816571392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48216472, -73.20318063 ]
  },
  "id_str" : "288473593594122240",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr rumor has it that I'll be bringing a few growlers home too!",
  "id" : 288473593594122240,
  "in_reply_to_status_id" : 288473182816571392,
  "created_at" : "Tue Jan 08 02:33:58 +0000 2013",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288472951907565569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48217171, -73.20316768 ]
  },
  "id_str" : "288473102218838016",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr homebrew was served, in chilled glasses",
  "id" : 288473102218838016,
  "in_reply_to_status_id" : 288472951907565569,
  "created_at" : "Tue Jan 08 02:32:01 +0000 2013",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 21, 28 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suckingup",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/rjcoNbU1",
      "expanded_url" : "http://twitpic.com/btegx3",
      "display_url" : "twitpic.com/btegx3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48209116, -73.20304765 ]
  },
  "id_str" : "288472818163802112",
  "text" : "candlelit dinner for @sspis1 when she got home from work #suckingup http://t.co/rjcoNbU1",
  "id" : 288472818163802112,
  "created_at" : "Tue Jan 08 02:30:54 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 60, 67 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821028, -73.2029761 ]
  },
  "id_str" : "288454892887080960",
  "text" : "\"all I could smell when I ran this week was glazed donuts\" -@sspis1 ...welcome to the #btv",
  "id" : 288454892887080960,
  "created_at" : "Tue Jan 08 01:19:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820949, -73.2029963 ]
  },
  "id_str" : "288435209605636098",
  "text" : "domestic athleticism: cooking food on all four burners",
  "id" : 288435209605636098,
  "created_at" : "Tue Jan 08 00:01:27 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 43, 50 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madscience",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/yEB3ZV5g",
      "expanded_url" : "http://twitpic.com/btd73n",
      "display_url" : "twitpic.com/btd73n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820991, -73.2029515 ]
  },
  "id_str" : "288413107183837184",
  "text" : "in today's mail: test tubes #madscience cc @sspis1 http://t.co/yEB3ZV5g",
  "id" : 288413107183837184,
  "created_at" : "Mon Jan 07 22:33:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recovery",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/dsA9Ecdy",
      "expanded_url" : "http://twitpic.com/bt31b2",
      "display_url" : "twitpic.com/bt31b2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821024, -73.2029751 ]
  },
  "id_str" : "288023615084056576",
  "text" : "#recovery http://t.co/dsA9Ecdy",
  "id" : 288023615084056576,
  "created_at" : "Sun Jan 06 20:45:55 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/JoTywmbG",
      "expanded_url" : "http://twitpic.com/bt2ybm",
      "display_url" : "twitpic.com/bt2ybm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48168095, -73.20321603 ]
  },
  "id_str" : "288019739249356803",
  "text" : "going for a snowshoe run? here's how to get to the powder: http://t.co/JoTywmbG",
  "id" : 288019739249356803,
  "created_at" : "Sun Jan 06 20:30:31 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 13, 21 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterlessroommate",
      "indices" : [ 99, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48213063, -73.2034047 ]
  },
  "id_str" : "287768202082136064",
  "text" : "a sad truth \"@Karo1yn: \"I think we've gotten all of the boys we live with hooked to gossip girl.\" -#twitterlessroommate YES.\"",
  "id" : 287768202082136064,
  "created_at" : "Sun Jan 06 03:51:00 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 1, 15 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/EcEQwu6U",
      "expanded_url" : "http://twitpic.com/bsjs1s",
      "display_url" : "twitpic.com/bsjs1s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4857053, -73.2021573 ]
  },
  "id_str" : "287382279972614144",
  "text" : ".@ChrisDanforth looks like Mr Jake Williams has caught up! http://t.co/EcEQwu6U",
  "id" : 287382279972614144,
  "created_at" : "Sat Jan 05 02:17:29 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287359567627681792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4856023, -73.2022545 ]
  },
  "id_str" : "287361651026579456",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 killing it!! nice job",
  "id" : 287361651026579456,
  "in_reply_to_status_id" : 287359567627681792,
  "created_at" : "Sat Jan 05 00:55:31 +0000 2013",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821033, -73.202981 ]
  },
  "id_str" : "287291547035267073",
  "text" : "note to self (and others): regardless of how warm 31deg feels at first, bring gloves running.",
  "id" : 287291547035267073,
  "created_at" : "Fri Jan 04 20:16:57 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 31, 41 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowshoerunning",
      "indices" : [ 9, 25 ]
    }, {
      "text" : "btv",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/XFejuWC5",
      "expanded_url" : "http://twitpic.com/bsguce",
      "display_url" : "twitpic.com/bsguce"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482093, -73.2029991 ]
  },
  "id_str" : "287253774484008960",
  "text" : "its time #snowshoerunning #btv @jcusick13 http://t.co/XFejuWC5",
  "id" : 287253774484008960,
  "created_at" : "Fri Jan 04 17:46:51 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48203398, -73.2034925 ]
  },
  "id_str" : "287030881682616320",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill yo do you ever want that green gary fischer you left in the garage?",
  "id" : 287030881682616320,
  "created_at" : "Fri Jan 04 03:01:09 +0000 2013",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 80, 89 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/sKm8LKH8",
      "expanded_url" : "http://instagr.am/p/UB_-zzOEhk/",
      "display_url" : "instagr.am/p/UB_-zzOEhk/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821184, -73.2029691 ]
  },
  "id_str" : "286901107639336961",
  "text" : "i started working on the winter running beard too, its darn necessary up here! \"@RBSherfy: #1-month-BEARD http://t.co/sKm8LKH8\"",
  "id" : 286901107639336961,
  "created_at" : "Thu Jan 03 18:25:29 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286900043456327680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48237183, -73.20300367 ]
  },
  "id_str" : "286900738670608384",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy very solid!",
  "id" : 286900738670608384,
  "in_reply_to_status_id" : 286900043456327680,
  "created_at" : "Thu Jan 03 18:24:01 +0000 2013",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 1, 13 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "training",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/zwxcc1vE",
      "expanded_url" : "http://twitpic.com/bs6tlg",
      "display_url" : "twitpic.com/bs6tlg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48239369, -73.20291816 ]
  },
  "id_str" : "286900691451133952",
  "text" : ".@mrfrank5790 spotted at the pool! #training http://t.co/zwxcc1vE",
  "id" : 286900691451133952,
  "created_at" : "Thu Jan 03 18:23:49 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 5, 14 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "familypranks",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "THEdeer",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "gotme",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/rnhRWHBA",
      "expanded_url" : "http://twitpic.com/bs5rcw",
      "display_url" : "twitpic.com/bs5rcw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48171828, -73.20270963 ]
  },
  "id_str" : "286864529122553857",
  "text" : "yes, @dmreagan, the disc golf bag was guilty of transporting the family deer as well #familypranks #THEdeer #gotme http://t.co/rnhRWHBA",
  "id" : 286864529122553857,
  "created_at" : "Thu Jan 03 16:00:08 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 37, 44 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/OhWvuoyU",
      "expanded_url" : "http://twitpic.com/bs5lsa",
      "display_url" : "twitpic.com/bs5lsa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48185615, -73.20297674 ]
  },
  "id_str" : "286860058594250754",
  "text" : "diggin my new disc golf bag,  thanks @DZdan1 http://t.co/OhWvuoyU",
  "id" : 286860058594250754,
  "created_at" : "Thu Jan 03 15:42:22 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286595501271416832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482132, -73.2029726 ]
  },
  "id_str" : "286603105838178304",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 what a bunch of animals!",
  "id" : 286603105838178304,
  "in_reply_to_status_id" : 286595501271416832,
  "created_at" : "Wed Jan 02 22:41:19 +0000 2013",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "goodtobeback",
      "indices" : [ 5, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821023, -73.2029882 ]
  },
  "id_str" : "286330738729705472",
  "text" : "#btv #goodtobeback",
  "id" : 286330738729705472,
  "created_at" : "Wed Jan 02 04:39:02 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterforlife",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.99373886, -76.2268602 ]
  },
  "id_str" : "286227127328722944",
  "text" : "I don't just make gas stops, I make gas and social media stops #twitterforlife",
  "id" : 286227127328722944,
  "created_at" : "Tue Jan 01 21:47:19 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.98909609, -76.24988487 ]
  },
  "id_str" : "286226799002808321",
  "text" : "getting a late start back to the #btv, it's been a great break!",
  "id" : 286226799002808321,
  "created_at" : "Tue Jan 01 21:46:01 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 27, 34 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 35, 44 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/TUli5UQd",
      "expanded_url" : "http://twitpic.com/brla63",
      "display_url" : "twitpic.com/brla63"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9835281, -76.3359157 ]
  },
  "id_str" : "286176307501473792",
  "text" : "COOLEST. KEYRACK. EVER. cc @sspis1 @dmreagan http://t.co/TUli5UQd",
  "id" : 286176307501473792,
  "created_at" : "Tue Jan 01 18:25:23 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/qarl0V0s",
      "expanded_url" : "http://twitpic.com/brl4td",
      "display_url" : "twitpic.com/brl4td"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9803865, -76.30521373 ]
  },
  "id_str" : "286170486755434496",
  "text" : "my two great loves: legos and power tools, wrongly combined http://t.co/qarl0V0s",
  "id" : 286170486755434496,
  "created_at" : "Tue Jan 01 18:02:15 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newyear",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/IlvvqCNU",
      "expanded_url" : "http://twitpic.com/brl4jm",
      "display_url" : "twitpic.com/brl4jm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9835281, -76.3359157 ]
  },
  "id_str" : "286170180592226304",
  "text" : "my girlfriend and my mom are busy playing legos together #newyear http://t.co/IlvvqCNU",
  "id" : 286170180592226304,
  "created_at" : "Tue Jan 01 18:01:02 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]