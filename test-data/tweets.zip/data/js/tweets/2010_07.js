Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 51, 63 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 68, 77 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.886046, -123.95919 ]
  },
  "id_str" : "20032861124",
  "text" : "Picnic and celebrating at a park in Cannon! Thanks @leermatthis and @vmhilljr!",
  "id" : 20032861124,
  "created_at" : "Sun Aug 01 01:49:21 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.886046, -123.95919 ]
  },
  "id_str" : "20024991638",
  "text" : "Canon beach!!! Poppin champagne http://twitpic.com/2ahr7x",
  "id" : 20024991638,
  "created_at" : "Sat Jul 31 23:28:21 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 55, 65 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.902142, -123.959404 ]
  },
  "id_str" : "20017695699",
  "text" : "Can see the Pacific Ocean!! Waitin for the rest of the @bikebuild team to go into town and jump in! #fb",
  "id" : 20017695699,
  "created_at" : "Sat Jul 31 20:58:47 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.793941, -123.457156 ]
  },
  "id_str" : "20008815962",
  "text" : "Summit of the coastal range! 30 miles to go http://twitpic.com/2af4dd",
  "id" : 20008815962,
  "created_at" : "Sat Jul 31 18:02:22 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.866008, -123.174926 ]
  },
  "id_str" : "20000625141",
  "text" : "52 miles away from biking across the country! Headed to Cannon Beach today!! #FB",
  "id" : 20000625141,
  "created_at" : "Sat Jul 31 15:53:18 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 67, 76 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19947794887",
  "text" : "In vernonia! So close!! Hill day, time for a nap in the hammock... @dmreagan hope the flight is going well",
  "id" : 19947794887,
  "created_at" : "Fri Jul 30 23:32:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19858827957",
  "text" : "Building in portland today! http://twitpic.com/29qmo6",
  "id" : 19858827957,
  "created_at" : "Thu Jul 29 22:11:11 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19759878592",
  "text" : "Mt hood! Almost to portland! http://twitpic.com/29ho8f",
  "id" : 19759878592,
  "created_at" : "Wed Jul 28 18:08:40 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19715210836",
  "text" : "is going to bed, 3 more days of biking to the Coast! Tomorrow we'll be sorta in Portland!!",
  "id" : 19715210836,
  "created_at" : "Wed Jul 28 04:52:07 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.99979845, -120.21462885 ]
  },
  "id_str" : "19603786846",
  "text" : "made it through the heat, 97F now, and over the 10 mile climb, Butte Creek Pass, to Fossil, OR!! Only four more days of riding!",
  "id" : 19603786846,
  "created_at" : "Mon Jul 26 21:34:10 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19580791032",
  "text" : "Had a great bday yesterday and I'm on the way to Fossil, OR!",
  "id" : 19580791032,
  "created_at" : "Mon Jul 26 15:13:59 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19517530204",
  "text" : "0/2 getting carded on my birthday lol! Chillin by the river in town now http://twitpic.com/28nblc",
  "id" : 19517530204,
  "created_at" : "Sun Jul 25 19:50:39 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19337082345",
  "text" : "is headed to Unity, OR (pop. 100, we're camping) and PST! And a new post on http://andyreagan.com!",
  "id" : 19337082345,
  "created_at" : "Fri Jul 23 13:00:04 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19278160816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.763449, -117.120248 ]
  },
  "id_str" : "19279454113",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr haha maybe soon...I'm trying to get lost but there aren't many roads out here",
  "id" : 19279454113,
  "in_reply_to_status_id" : 19278160816,
  "created_at" : "Thu Jul 22 19:51:20 +0000 2010",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 45, 54 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.763449, -117.120248 ]
  },
  "id_str" : "19274092310",
  "text" : "is in OREGON!! Pacific time zone too! Thanks @rbsherfy!",
  "id" : 19274092310,
  "created_at" : "Thu Jul 22 18:17:55 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18947345274",
  "geo" : {
  },
  "id_str" : "19105559714",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy dude, two questions. 1) where did you get that stars and bars tape, i cant find it lol and 2) which 50mm lens do you have",
  "id" : 19105559714,
  "in_reply_to_status_id" : 18947345274,
  "created_at" : "Wed Jul 21 21:09:23 +0000 2010",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 0, 13 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19103285871",
  "geo" : {
  },
  "id_str" : "19105451408",
  "in_reply_to_user_id" : 18204345,
  "text" : "@blogblogblog and one for andy, right?",
  "id" : 19105451408,
  "in_reply_to_status_id" : 19103285871,
  "created_at" : "Wed Jul 21 21:07:30 +0000 2010",
  "in_reply_to_screen_name" : "blogblogblog",
  "in_reply_to_user_id_str" : "18204345",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "indices" : [ 3, 9 ],
      "id_str" : "30967859",
      "id" : 30967859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "19087938442",
  "text" : "RT @bsim9: The Lord is close to the brokenhearted and saves those who are crushed in spirit. CUS &lt;3 P2S",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "19087339080",
    "text" : "The Lord is close to the brokenhearted and saves those who are crushed in spirit. CUS &lt;3 P2S",
    "id" : 19087339080,
    "created_at" : "Wed Jul 21 16:06:13 +0000 2010",
    "user" : {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "protected" : false,
      "id_str" : "30967859",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/136469345/Me_kicking_normal.jpg",
      "id" : 30967859,
      "verified" : false
    }
  },
  "id" : 19087938442,
  "created_at" : "Wed Jul 21 16:15:03 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18970007348",
  "text" : "so I'll be riding in the van tomorrow for not waiting for the group today, bummer...",
  "id" : 18970007348,
  "created_at" : "Tue Jul 20 05:09:11 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18945443735",
  "text" : "post about today on http://andyreagan.com! No pictures yet though, maybe later haha",
  "id" : 18945443735,
  "created_at" : "Mon Jul 19 21:44:34 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18939145495",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan no cell service at all here though...but they do have computers. maybe I can skype call your phone?",
  "id" : 18939145495,
  "created_at" : "Mon Jul 19 19:38:51 +0000 2010",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18939101688",
  "text" : "made it 91 miles solo to Idaho City, Idaho. Missed both lunches, so 2 water bottles and 3 clif bars to make it over the mtn + thru the heat!",
  "id" : 18939101688,
  "created_at" : "Mon Jul 19 19:38:00 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 95, 108 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18886598855",
  "text" : "had the greatest day biking today, bundled up in my hammock beneath the sawtooth mtns waitin 4 @laurentappan to call then sleeping!",
  "id" : 18886598855,
  "created_at" : "Mon Jul 19 03:34:52 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 53, 62 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 63, 79 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18665163387",
  "text" : "and I got mail (and important email for once) today! @dmreagan @rumblinstumblin thanks!! and check your email!",
  "id" : 18665163387,
  "created_at" : "Fri Jul 16 06:27:46 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18660931069",
  "text" : "had a great but long workday today, follow by an excellent grill-out at the pastors house and a ride back in his MINT 1965 mustang!",
  "id" : 18660931069,
  "created_at" : "Fri Jul 16 05:05:30 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18391401933",
  "text" : "made it to Jackson, Wyoming today. Chillin on a back porch below the Teton mtns next to green rolling pasture, incredibly beautiful... #fb",
  "id" : 18391401933,
  "created_at" : "Mon Jul 12 23:41:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18083211027",
  "text" : "bike cleaned, clothes washed, great homemade mexican dinner, and after the affordable housing presentation I'm going to bed! Big climb tmrw",
  "id" : 18083211027,
  "created_at" : "Fri Jul 09 02:24:42 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 19, 32 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 37, 46 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18069800580",
  "text" : "just got mail from @laurentappan and @dmreagan! Fudge, a CD, post card, clif bars, a letter, bike seat and the DEER :)",
  "id" : 18069800580,
  "created_at" : "Thu Jul 08 23:08:52 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "18050830213",
  "text" : "is 55 miles into the ride through the desert at Dinosaur Colorado, its beautiful, the desert. Only a few miles to the Utah state line!",
  "id" : 18050830213,
  "created_at" : "Thu Jul 08 17:32:23 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 76, 89 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17991456617",
  "text" : "new post on http://andyreagan.com but no cell service in Maybell, CO, sorry @laurentappan!",
  "id" : 17991456617,
  "created_at" : "Wed Jul 07 23:59:39 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17962884982",
  "text" : "Is halfway to Maybell CO, population 370 haha, blew a tire but got it fixed, averaged over 20mph to lunch!",
  "id" : 17962884982,
  "created_at" : "Wed Jul 07 16:49:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17929605093",
  "text" : "new post on http://andyreagan.com! Straight from the new phone!",
  "id" : 17929605093,
  "created_at" : "Wed Jul 07 06:38:24 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 62, 75 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17923566381",
  "text" : "The hot springs were greatttt, but out of cell coverage sorry @laurentappan... just cleaned out my voicemail! Packing then bed",
  "id" : 17923566381,
  "created_at" : "Wed Jul 07 04:40:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17904244586",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @rumblinstumblin I just shipped some stuff home, should be there in a week or so! Just stuff I didn't need anymore/didn't fit",
  "id" : 17904244586,
  "created_at" : "Tue Jul 06 23:30:14 +0000 2010",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17904173029",
  "text" : "Mountain biking on a kona 29er from orange peel today was incredible.  Great trails, weather, views...everything. I love colorado!!",
  "id" : 17904173029,
  "created_at" : "Tue Jul 06 23:29:01 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17879769782",
  "text" : "got french toast for breakfast (yum!) and now going to rent mtb's for the day!",
  "id" : 17879769782,
  "created_at" : "Tue Jul 06 16:37:51 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17811520860",
  "text" : "got to steamboat springs and got a new phone!! Lovin the Droid so far!",
  "id" : 17811520860,
  "created_at" : "Mon Jul 05 19:16:56 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17642248715",
  "text" : "packing up for Trail Ridge Road today, it's COLD outside! Probably won't have internet/cell for the next two nights...",
  "id" : 17642248715,
  "created_at" : "Sat Jul 03 11:30:49 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17628066391",
  "text" : "The ride today was EPIC, blog post coming and tomorrow we head over Trail Ridge Road!",
  "id" : 17628066391,
  "created_at" : "Sat Jul 03 05:27:19 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17628042925",
  "text" : "just got internet at our host tonight in the mountains above Estes Park! No cell service haha, I should get my new phone 7/5",
  "id" : 17628042925,
  "created_at" : "Sat Jul 03 05:26:51 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 70, 83 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "17529851050",
  "text" : "had a great build day today in Boulder, showered and got to chat with @laurentappan on FB :)  ...dinner time now!!",
  "id" : 17529851050,
  "created_at" : "Thu Jul 01 23:57:53 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]