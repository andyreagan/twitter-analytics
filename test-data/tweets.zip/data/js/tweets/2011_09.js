Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119962645196578817",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet check out my latest retweet",
  "id" : 119962645196578817,
  "created_at" : "Sat Oct 01 02:31:38 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119961612458278913",
  "text" : "RT @bakadesuyo: How little sleep can you get away with? http://ht.ly/6EhtG",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "119909451418443776",
    "text" : "How little sleep can you get away with? http://ht.ly/6EhtG",
    "id" : 119909451418443776,
    "created_at" : "Fri Sep 30 23:00:15 +0000 2011",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 119961612458278913,
  "created_at" : "Sat Oct 01 02:27:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 47, 59 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119955242845618177",
  "text" : "awesome get together at David Henry's tonight. @MechE_Hokie sure does make a mean mac n cheese!",
  "id" : 119955242845618177,
  "created_at" : "Sat Oct 01 02:02:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119779758971174912",
  "text" : "got an 80 on real analysis test, the ironic part is that if i left more problems blank, wouldve got a 90",
  "id" : 119779758971174912,
  "created_at" : "Fri Sep 30 14:24:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Morrison",
      "screen_name" : "jpmor06",
      "indices" : [ 15, 23 ],
      "id_str" : "178447765",
      "id" : 178447765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/Nvnk0WwH",
      "expanded_url" : "http://bit.ly/pNtLnt",
      "display_url" : "bit.ly/pNtLnt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119750097973161984",
  "text" : "a fun friday w @jpmor06 and some of the legends of bakers dozen! http://t.co/Nvnk0WwH",
  "id" : 119750097973161984,
  "created_at" : "Fri Sep 30 12:27:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realanalysis",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/s8GdSais",
      "expanded_url" : "http://twitpic.com/6sjgo9",
      "display_url" : "twitpic.com/6sjgo9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119542744522821632",
  "text" : "bring it on #realanalysis http://t.co/s8GdSais",
  "id" : 119542744522821632,
  "created_at" : "Thu Sep 29 22:43:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 20, 33 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119507501032030208",
  "geo" : {
  },
  "id_str" : "119514390000177152",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT 43 days!! @laurentappan do you till have the tandem here?",
  "id" : 119514390000177152,
  "in_reply_to_status_id" : 119507501032030208,
  "created_at" : "Thu Sep 29 20:50:25 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119494348034408448",
  "geo" : {
  },
  "id_str" : "119498247210409984",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT you'll learn more pchem running lol",
  "id" : 119498247210409984,
  "in_reply_to_status_id" : 119494348034408448,
  "created_at" : "Thu Sep 29 19:46:16 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119498160879042560",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 seen your keys recently?",
  "id" : 119498160879042560,
  "created_at" : "Thu Sep 29 19:45:56 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 13, 29 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 57, 68 ],
      "id_str" : "18855629",
      "id" : 18855629
    }, {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "indices" : [ 87, 102 ],
      "id_str" : "63491769",
      "id" : 63491769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "putdateamonhisback",
      "indices" : [ 36, 55 ]
    }, {
      "text" : "CollNats",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119439949375352832",
  "text" : ".@vtcyclings @JacobnAndersson gonna #putdateamonhisback \"@usacycling: Registration for @USACcollegiate MTB nationals is now open! #CollNats\"",
  "id" : 119439949375352832,
  "created_at" : "Thu Sep 29 15:54:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fasterthanairplanes",
      "indices" : [ 58, 78 ]
    }, {
      "text" : "carmageddonasproof",
      "indices" : [ 79, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119421206255517696",
  "geo" : {
  },
  "id_str" : "119436904985927680",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris damn, that sucks. shoulda rode your bike #fasterthanairplanes #carmageddonasproof",
  "id" : 119436904985927680,
  "in_reply_to_status_id" : 119421206255517696,
  "created_at" : "Thu Sep 29 15:42:31 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119240549684350977",
  "text" : "computing 4x4 determininates on paper...my numerical analysis prof said if anyone ever made us do this, to send them to him lol",
  "id" : 119240549684350977,
  "created_at" : "Thu Sep 29 02:42:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 0, 8 ],
      "id_str" : "86132431",
      "id" : 86132431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119239610579689472",
  "geo" : {
  },
  "id_str" : "119239914561863680",
  "in_reply_to_user_id" : 86132431,
  "text" : "@bricec5 twas a manly man run, I'm excited too!",
  "id" : 119239914561863680,
  "in_reply_to_status_id" : 119239610579689472,
  "created_at" : "Thu Sep 29 02:39:45 +0000 2011",
  "in_reply_to_screen_name" : "bricec5",
  "in_reply_to_user_id_str" : "86132431",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 44, 51 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/ewytUr3R",
      "expanded_url" : "http://bit.ly/piPl76",
      "display_url" : "bit.ly/piPl76"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119187599167455233",
  "text" : "awesome MAN RUN, headed to see The Way now, @rkay21 on my way. run: http://t.co/ewytUr3R",
  "id" : 119187599167455233,
  "created_at" : "Wed Sep 28 23:11:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic",
      "screen_name" : "EpicCareers",
      "indices" : [ 0, 12 ],
      "id_str" : "148018144",
      "id" : 148018144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119140039811809280",
  "in_reply_to_user_id" : 148018144,
  "text" : "@EpicCareers it was great talking to you all at the Virginia Tech career fair!",
  "id" : 119140039811809280,
  "created_at" : "Wed Sep 28 20:02:53 +0000 2011",
  "in_reply_to_screen_name" : "EpicCareers",
  "in_reply_to_user_id_str" : "148018144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119122638781165568",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan ever heard of a company called EPIC? they do health care software, sounds sorta like what you do..talked to them today",
  "id" : 119122638781165568,
  "created_at" : "Wed Sep 28 18:53:44 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119047127803502592",
  "text" : "forgot that because of the test last night, we didn't have Algebra class today...didn't even eat breakfast #fail",
  "id" : 119047127803502592,
  "created_at" : "Wed Sep 28 13:53:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 3, 16 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "VirginiaTech",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "quackquackquack",
      "indices" : [ 89, 105 ]
    }, {
      "text" : "YoungGuns",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "WallStreet",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "WestWing",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119046918092505088",
  "text" : "RT @plaidavenger: T-minus 7 hours to Estevez-Sheen shenanigans at VT #wrvt #VirginiaTech #quackquackquack #YoungGuns #WallStreet #WestWing",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 51, 56 ]
      }, {
        "text" : "VirginiaTech",
        "indices" : [ 57, 70 ]
      }, {
        "text" : "quackquackquack",
        "indices" : [ 71, 87 ]
      }, {
        "text" : "YoungGuns",
        "indices" : [ 88, 98 ]
      }, {
        "text" : "WallStreet",
        "indices" : [ 99, 110 ]
      }, {
        "text" : "WestWing",
        "indices" : [ 111, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "119046746872610816",
    "text" : "T-minus 7 hours to Estevez-Sheen shenanigans at VT #wrvt #VirginiaTech #quackquackquack #YoungGuns #WallStreet #WestWing",
    "id" : 119046746872610816,
    "created_at" : "Wed Sep 28 13:52:10 +0000 2011",
    "user" : {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "protected" : false,
      "id_str" : "14193991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2915300835/2e61e76e46e76b2c27a4747c49b95c9a_normal.jpeg",
      "id" : 14193991,
      "verified" : false
    }
  },
  "id" : 119046918092505088,
  "created_at" : "Wed Sep 28 13:52:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/YY7ImV0u",
      "expanded_url" : "http://thewaytovt.eventbrite.com/",
      "display_url" : "thewaytovt.eventbrite.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119046823972323328",
  "text" : "@Tri_Gardner looks sold out: http://t.co/YY7ImV0u but I bet you could get in the back of burruss lol, the way I brought the canoe in",
  "id" : 119046823972323328,
  "created_at" : "Wed Sep 28 13:52:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119045457988161536",
  "text" : "@Tri_Gardner yeah I am! Do you have a ticket? You should come to man run and we'll go after",
  "id" : 119045457988161536,
  "created_at" : "Wed Sep 28 13:47:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/WmDS8mUW",
      "expanded_url" : "http://bit.ly/pjX2PR",
      "display_url" : "bit.ly/pjX2PR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "119030915660922880",
  "text" : "nice morning run: http://t.co/WmDS8mUW now class, job fair, lunch, lots of hw, another run, then The Way to VT!!",
  "id" : 119030915660922880,
  "created_at" : "Wed Sep 28 12:49:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "119000653753352192",
  "text" : "up early for Workout Wednesday edition of Bakers Dozen!",
  "id" : 119000653753352192,
  "created_at" : "Wed Sep 28 10:49:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118830305577680896",
  "text" : "you know that uneasy feeling when you finish a 2hr test in 40min, and it seemed easy, but everyone else is scribbling away...yup",
  "id" : 118830305577680896,
  "created_at" : "Tue Sep 27 23:32:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/tzvDrK2Z",
      "expanded_url" : "http://bit.ly/qn3O0X",
      "display_url" : "bit.ly/qn3O0X"
    } ]
  },
  "geo" : {
  },
  "id_str" : "118793558458236928",
  "text" : "studying for Abstract Algebra exam in one hour! part 1 of studying: http://t.co/tzvDrK2Z",
  "id" : 118793558458236928,
  "created_at" : "Tue Sep 27 21:06:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 3, 14 ],
      "id_str" : "15408193",
      "id" : 15408193
    }, {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 93, 106 ],
      "id_str" : "17900130",
      "id" : 17900130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118738041094422528",
  "text" : "RT @fatcyclist: If you're bored on your bike, you're doing it wrong. Or you're on rollers.  “@BicyclingMag: Getting bored on your bike?”",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bicycling Magazine",
        "screen_name" : "BicyclingMag",
        "indices" : [ 77, 90 ],
        "id_str" : "17900130",
        "id" : 17900130
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "118722629392809984",
    "text" : "If you're bored on your bike, you're doing it wrong. Or you're on rollers.  “@BicyclingMag: Getting bored on your bike?”",
    "id" : 118722629392809984,
    "created_at" : "Tue Sep 27 16:24:15 +0000 2011",
    "user" : {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "protected" : false,
      "id_str" : "15408193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3010461639/c3edf0ff84ed9988d5e552032346e5d4_normal.jpeg",
      "id" : 15408193,
      "verified" : false
    }
  },
  "id" : 118738041094422528,
  "created_at" : "Tue Sep 27 17:25:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Morrison",
      "screen_name" : "jpmor06",
      "indices" : [ 0, 8 ],
      "id_str" : "178447765",
      "id" : 178447765
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 9, 22 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/XG9J1Wzm",
      "expanded_url" : "http://2milechallenge.com/",
      "display_url" : "2milechallenge.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "118511889302040576",
  "in_reply_to_user_id" : 178447765,
  "text" : "@jpmor06 @williamenium I think it's a pretty cool concept, at least: http://t.co/XG9J1Wzm",
  "id" : 118511889302040576,
  "created_at" : "Tue Sep 27 02:26:50 +0000 2011",
  "in_reply_to_screen_name" : "jpmor06",
  "in_reply_to_user_id_str" : "178447765",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118466636608061440",
  "geo" : {
  },
  "id_str" : "118480012621000704",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo will do!",
  "id" : 118480012621000704,
  "in_reply_to_status_id" : 118466636608061440,
  "created_at" : "Tue Sep 27 00:20:10 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 0, 8 ],
      "id_str" : "86132431",
      "id" : 86132431
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 21, 30 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118466317606064128",
  "geo" : {
  },
  "id_str" : "118479950578860032",
  "in_reply_to_user_id" : 86132431,
  "text" : "@bricec5 definitely. @Run_Rudy is running as well, im planning on leaving at 730 from BBurg",
  "id" : 118479950578860032,
  "in_reply_to_status_id" : 118466317606064128,
  "created_at" : "Tue Sep 27 00:19:56 +0000 2011",
  "in_reply_to_screen_name" : "bricec5",
  "in_reply_to_user_id_str" : "86132431",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 4, 14 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tradition",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/AjeFQKhT",
      "expanded_url" : "http://4sq.com/n9wq1Z",
      "display_url" : "4sq.com/n9wq1Z"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304906931, -80.4153513908 ]
  },
  "id_str" : "118466299235016704",
  "text" : "pre @vtcycling team meeting #tradition (@ Moe's Southwest Grill) http://t.co/AjeFQKhT",
  "id" : 118466299235016704,
  "created_at" : "Mon Sep 26 23:25:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118406730056077313",
  "text" : "@Tri_Gardner it's a date",
  "id" : 118406730056077313,
  "created_at" : "Mon Sep 26 19:28:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 18, 33 ],
      "id_str" : "208127016",
      "id" : 208127016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "running",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "Blacksburg",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/CBKPj76M",
      "expanded_url" : "http://on.fb.me/p3Yj71",
      "display_url" : "on.fb.me/p3Yj71"
    } ]
  },
  "geo" : {
  },
  "id_str" : "118403300516311040",
  "text" : "heck yeah I am!! \"@BRMSBlacksburg Ready for the Mountain Top Trot race @MtnLake this weekend? http://t.co/CBKPj76M #running #Blacksburg\"",
  "id" : 118403300516311040,
  "created_at" : "Mon Sep 26 19:15:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118402595265060864",
  "text" : "talked to some schools and got some swag at the VT Prospective Graduate Student Fair",
  "id" : 118402595265060864,
  "created_at" : "Mon Sep 26 19:12:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118401431236657153",
  "text" : "@Tri_Gardner will be there! and yeah that sounds like a plan, will it be open?",
  "id" : 118401431236657153,
  "created_at" : "Mon Sep 26 19:07:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doc Pemberton",
      "screen_name" : "docpemberton",
      "indices" : [ 4, 17 ],
      "id_str" : "125790347",
      "id" : 125790347
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gottatrythis",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118363056299442176",
  "text" : "the @docpemberton coke machine is in d2 today, one guy just got a cake w his coke, the next a tshirt #gottatrythis",
  "id" : 118363056299442176,
  "created_at" : "Mon Sep 26 16:35:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 85, 94 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exhausted",
      "indices" : [ 120, 130 ]
    }, {
      "text" : "bedtime",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118172724400111616",
  "text" : "been doin HW since I got home (minus the time playing with Garmin Connect and eating @slpagsVT delic pizza she made)... #exhausted #bedtime",
  "id" : 118172724400111616,
  "created_at" : "Mon Sep 26 03:59:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/2ZWReLIa",
      "expanded_url" : "https://birdseyeview.net/cgi-local/ImageFolio42/imageFolio.cgi?search=185&cat=Triathlons%2F20110924_LIK&bool=and",
      "display_url" : "birdseyeview.net/cgi-local/Imag…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "118170500613668864",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy http://t.co/2ZWReLIa",
  "id" : 118170500613668864,
  "created_at" : "Mon Sep 26 03:50:17 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/tsj2PwlM",
      "expanded_url" : "https://birdseyeview.net/cgi-local/ImageFolio42/imageFolio.cgi?search=172&cat=Triathlons%2F20110924_LIK&bool=and",
      "display_url" : "birdseyeview.net/cgi-local/Imag…"
    }, {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/yYMSBeSQ",
      "expanded_url" : "http://www.setupevents.com/index.cfm?fuseaction=event_results&id=2644",
      "display_url" : "setupevents.com/index.cfm?fuse…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "118170102062526464",
  "text" : "big lick pictures: http://t.co/tsj2PwlM and results: http://t.co/yYMSBeSQ",
  "id" : 118170102062526464,
  "created_at" : "Mon Sep 26 03:48:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACC Cycling",
      "screen_name" : "ACCCycling",
      "indices" : [ 11, 22 ],
      "id_str" : "111463102",
      "id" : 111463102
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 34, 44 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "118064333589708800",
  "text" : "cleaned up @ACCCycling today with @VTCycling!! Sweet and hard day of racing, we won every race today ( all three ST, TT, XC)",
  "id" : 118064333589708800,
  "created_at" : "Sun Sep 25 20:48:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 28, 38 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117732174999982080",
  "text" : "almost to Williamsburg with @VTCycling to race tomorrow!!",
  "id" : 117732174999982080,
  "created_at" : "Sat Sep 24 22:48:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "byetoenail",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/8u3gUxWs",
      "expanded_url" : "http://twitpic.com/6q2ncb",
      "display_url" : "twitpic.com/6q2ncb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "117731167792410624",
  "text" : "some parts of becoming a runner, dont hurt but don't look nice. #byetoenail warning graphic: http://t.co/8u3gUxWs",
  "id" : 117731167792410624,
  "created_at" : "Sat Sep 24 22:44:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 4, 16 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 36, 45 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 46, 58 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 78, 87 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117669615269715968",
  "text" : "and @VTTriathlon as team killed it! @Run_Rudy @OGfromtheOB 1-2 in collegiate, @Run_Rudy 2nd overall. congrats to everyone!",
  "id" : 117669615269715968,
  "created_at" : "Sat Sep 24 18:39:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117650342736437248",
  "text" : "had an awesome race, and got my 2:30 goal with a 2:29!! And a 45min 10k. (last year was a 2:54)",
  "id" : 117650342736437248,
  "created_at" : "Sat Sep 24 17:23:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/cFG2Hp8U",
      "expanded_url" : "http://twitpic.com/6psnky",
      "display_url" : "twitpic.com/6psnky"
    } ]
  },
  "geo" : {
  },
  "id_str" : "117570623022178305",
  "text" : "go time http://t.co/cFG2Hp8U",
  "id" : 117570623022178305,
  "created_at" : "Sat Sep 24 12:06:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/d4zKGyw5",
      "expanded_url" : "http://twitpic.com/6pdvao",
      "display_url" : "twitpic.com/6pdvao"
    } ]
  },
  "geo" : {
  },
  "id_str" : "117305893942599680",
  "text" : "race set up, time for a swim and waterside!! Question: disc wheel or no if its raining tmrw http://t.co/d4zKGyw5",
  "id" : 117305893942599680,
  "created_at" : "Fri Sep 23 18:34:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117223141679435776",
  "text" : "headed to Smith Mtn Lake State Park! (if Kelly ever shows up)",
  "id" : 117223141679435776,
  "created_at" : "Fri Sep 23 13:05:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hugefail",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "nofoodthisweekend",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "117208590800011266",
  "text" : "forgot to put the stirrer in my bread machine last night #hugefail #nofoodthisweekend",
  "id" : 117208590800011266,
  "created_at" : "Fri Sep 23 12:08:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 23, 35 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/g1K4oAUw",
      "expanded_url" : "http://twitpic.com/6owl2q",
      "display_url" : "twitpic.com/6owl2q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116996002925379584",
  "text" : "dropped off the MTB to @runfasteraw to go to W&M, goin to borrow Tyler's disc wheel for the triathlon! http://t.co/g1K4oAUw",
  "id" : 116996002925379584,
  "created_at" : "Thu Sep 22 22:03:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116978055938973696",
  "geo" : {
  },
  "id_str" : "116979301496258560",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium no way is that rideable lol. you'd need some rubber or you'd be sliding all over, steel+pavement=rubber+ice",
  "id" : 116979301496258560,
  "in_reply_to_status_id" : 116978055938973696,
  "created_at" : "Thu Sep 22 20:56:53 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Lexie White",
      "screen_name" : "alexandramwhite",
      "indices" : [ 8, 24 ],
      "id_str" : "39083429",
      "id" : 39083429
    }, {
      "name" : "Paul Vines",
      "screen_name" : "IronCyclone",
      "indices" : [ 25, 37 ],
      "id_str" : "349885460",
      "id" : 349885460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/yCDQIaKd",
      "expanded_url" : "http://andyreagan.com/2011/07/02/rehoboth-beach/",
      "display_url" : "andyreagan.com/2011/07/02/reh…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116965895741505536",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 @alexandramwhite @ironcyclone pictures from Rehoboth Beach! http://t.co/yCDQIaKd",
  "id" : 116965895741505536,
  "created_at" : "Thu Sep 22 20:03:37 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Fulton",
      "screen_name" : "BigFluffyFuton",
      "indices" : [ 0, 15 ],
      "id_str" : "260786338",
      "id" : 260786338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116868986989318145",
  "geo" : {
  },
  "id_str" : "116888441731559424",
  "in_reply_to_user_id" : 260786338,
  "text" : "@BigFluffyFuton last year collegiate men were 1st, followed 3min by col ladies. they'll know @ ppu F. if we tri fast, leave 12 + drive fast!",
  "id" : 116888441731559424,
  "in_reply_to_status_id" : 116868986989318145,
  "created_at" : "Thu Sep 22 14:55:50 +0000 2011",
  "in_reply_to_screen_name" : "BigFluffyFuton",
  "in_reply_to_user_id_str" : "260786338",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116849328533946369",
  "text" : "sweet morning bike ride, can't beat that @Tri_Gardner. I couldve won FF last week with a K..made some major adjustments 4 this week, line -4",
  "id" : 116849328533946369,
  "created_at" : "Thu Sep 22 12:20:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116719162113536000",
  "geo" : {
  },
  "id_str" : "116723702464389120",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 sign me up!",
  "id" : 116723702464389120,
  "in_reply_to_status_id" : 116719162113536000,
  "created_at" : "Thu Sep 22 04:01:13 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 17, 29 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116715701116473344",
  "text" : "also just bought @OGfromtheOB's Garmin HR monitor, excited to see how hard im pushing the engine in future workouts!",
  "id" : 116715701116473344,
  "created_at" : "Thu Sep 22 03:29:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/MePthHyh",
      "expanded_url" : "http://twitpic.com/6ojrwf",
      "display_url" : "twitpic.com/6ojrwf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "116715294189293568",
  "text" : "new Hokie color Yankz quicklaces, from RunAbout Sports, ready for speedy transitions this weekend at Big Lick! http://t.co/MePthHyh",
  "id" : 116715294189293568,
  "created_at" : "Thu Sep 22 03:27:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116629740454035457",
  "text" : "is not having any fun- no Worlds or Man Run tonight for these legs. hopefully it pays off this weekend!",
  "id" : 116629740454035457,
  "created_at" : "Wed Sep 21 21:47:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 11, 22 ],
      "id_str" : "18855629",
      "id" : 18855629
    }, {
      "name" : "Richmond 2015",
      "screen_name" : "richmond2015",
      "indices" : [ 86, 99 ],
      "id_str" : "228424256",
      "id" : 228424256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadworlds",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116534257840701441",
  "text" : "awesome!! \"@usacycling: Its official!!! 2015 Road World Champs to Richmond! Way to go @richmond2015! #roadworlds\"",
  "id" : 116534257840701441,
  "created_at" : "Wed Sep 21 15:28:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GardenFreshBeats",
      "screen_name" : "GardenFreshBeat",
      "indices" : [ 3, 19 ],
      "id_str" : "308157623",
      "id" : 308157623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifeislike",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116325293983145984",
  "text" : "RT @GardenFreshBeat: #lifeislike a menu at a restaurant, you have to make choices.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lifeislike",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "116308818148859904",
    "text" : "#lifeislike a menu at a restaurant, you have to make choices.",
    "id" : 116308818148859904,
    "created_at" : "Wed Sep 21 00:32:37 +0000 2011",
    "user" : {
      "name" : "GardenFreshBeats",
      "screen_name" : "GardenFreshBeat",
      "protected" : false,
      "id_str" : "308157623",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2086818969/image_normal.jpg",
      "id" : 308157623,
      "verified" : false
    }
  },
  "id" : 116325293983145984,
  "created_at" : "Wed Sep 21 01:38:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 22, 34 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116308174344171520",
  "text" : "solid swim practice w @VTTriathlon! at the meeting now, pumped for Big Lick triathlon on Sat!!",
  "id" : 116308174344171520,
  "created_at" : "Wed Sep 21 00:30:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116296820568768513",
  "geo" : {
  },
  "id_str" : "116307791819444224",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis I don't see beer on the list??",
  "id" : 116307791819444224,
  "in_reply_to_status_id" : 116296820568768513,
  "created_at" : "Wed Sep 21 00:28:33 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116260329633222656",
  "geo" : {
  },
  "id_str" : "116276012035211264",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving yeah I thought that might be case",
  "id" : 116276012035211264,
  "in_reply_to_status_id" : 116260329633222656,
  "created_at" : "Tue Sep 20 22:22:16 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116256347904946176",
  "geo" : {
  },
  "id_str" : "116259927516905472",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving interesting stuff! it would also be interesting to know who the people buying the most expensive homes work for, pure curiosity",
  "id" : 116259927516905472,
  "in_reply_to_status_id" : 116256347904946176,
  "created_at" : "Tue Sep 20 21:18:21 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 0, 9 ],
      "id_str" : "195438525",
      "id" : 195438525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116229991586463744",
  "in_reply_to_user_id" : 195438525,
  "text" : "@cafeZulu you coming to homebrew club tonight?? I want to, but it would be good 4 me to go to tri meeting bc im racing big lick this wknd",
  "id" : 116229991586463744,
  "created_at" : "Tue Sep 20 19:19:24 +0000 2011",
  "in_reply_to_screen_name" : "cafeZulu",
  "in_reply_to_user_id_str" : "195438525",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Lexie White",
      "screen_name" : "alexandramwhite",
      "indices" : [ 8, 24 ],
      "id_str" : "39083429",
      "id" : 39083429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116151471854202880",
  "geo" : {
  },
  "id_str" : "116229804566650880",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 @alexandramwhite I'll get 'em up soon!!",
  "id" : 116229804566650880,
  "in_reply_to_status_id" : 116151471854202880,
  "created_at" : "Tue Sep 20 19:18:39 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 108, 115 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgeek",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "116174276217937920",
  "text" : "if someone tells me something is unique, the first thing I think to do is assume there is another #mathgeek @k8eb8e",
  "id" : 116174276217937920,
  "created_at" : "Tue Sep 20 15:38:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ugh",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/hlbkeylC",
      "expanded_url" : "http://4sq.com/oWoEzm",
      "display_url" : "4sq.com/oWoEzm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "116136128230342656",
  "text" : "cold and rainy #ugh but 8am group meeting was good, classss time (@ McBryde Hall) http://t.co/hlbkeylC",
  "id" : 116136128230342656,
  "created_at" : "Tue Sep 20 13:06:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115968975850053632",
  "geo" : {
  },
  "id_str" : "116001073390555138",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT I had to hop on fb to look this up...is it for real??",
  "id" : 116001073390555138,
  "in_reply_to_status_id" : 115968975850053632,
  "created_at" : "Tue Sep 20 04:09:45 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 61, 71 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hellyeah",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/OBCxGE9J",
      "expanded_url" : "http://www.acccycling.org/Results.html",
      "display_url" : "acccycling.org/Results.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "115988466512306176",
  "text" : "is currently second in the ACCC conference in MTB! #hellyeah @vtcycling click on overall results, men's b tab: http://t.co/OBCxGE9J",
  "id" : 115988466512306176,
  "created_at" : "Tue Sep 20 03:19:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115971690789474304",
  "text" : "@Tri_Gardner damn son!!!",
  "id" : 115971690789474304,
  "created_at" : "Tue Sep 20 02:13:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 37, 47 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Stan's NoTubes",
      "screen_name" : "NoTubes",
      "indices" : [ 72, 80 ],
      "id_str" : "28418145",
      "id" : 28418145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115969179085062144",
  "text" : "might have to go tubeless myself! RT @VTCycling \"got an awesome demo on @notubes from Zach Morrey at our meeting tonight!!\"",
  "id" : 115969179085062144,
  "created_at" : "Tue Sep 20 02:03:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wellsee",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115922614286954496",
  "text" : "new strategy to avoid running out of running shorts: hittin the shower with them on #wellsee",
  "id" : 115922614286954496,
  "created_at" : "Mon Sep 19 22:57:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 104, 113 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 114, 126 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 127, 137 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "fail",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "stillwayfun",
      "indices" : [ 42, 54 ]
    }, {
      "text" : "sorrylegs",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/I832QX9b",
      "expanded_url" : "http://bit.ly/riRGD6",
      "display_url" : "bit.ly/riRGD6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "115920943997652992",
  "text" : "11 mile speedy recovery run #whoops #fail #stillwayfun #sorrylegs. garmin connect: http://t.co/I832QX9b @run_rudy @ogfromtheob @wyattloud",
  "id" : 115920943997652992,
  "created_at" : "Mon Sep 19 22:51:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115864477609635840",
  "text" : "@Tri_Gardner I am not...going running to make up for this morning!",
  "id" : 115864477609635840,
  "created_at" : "Mon Sep 19 19:06:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifegoalcomplete",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115846493608488960",
  "text" : "asked for \"the usual\" sandwhich at d2 #lifegoalcomplete",
  "id" : 115846493608488960,
  "created_at" : "Mon Sep 19 17:55:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115758991698702336",
  "text" : "woke up at 6 to try to finish HW before baker's dozen...no luck. still working. hope the run was good @Tri_Gardner",
  "id" : 115758991698702336,
  "created_at" : "Mon Sep 19 12:07:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115572732695019520",
  "geo" : {
  },
  "id_str" : "115598569989341184",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 nice! i'm training for my first marathon in 7 weeks!",
  "id" : 115598569989341184,
  "in_reply_to_status_id" : 115572732695019520,
  "created_at" : "Mon Sep 19 01:30:21 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115567502876094465",
  "text" : "home from NC and got bread in, laundry done, unpacked and fueled up the car. $0.099 per mile in fuel!",
  "id" : 115567502876094465,
  "created_at" : "Sun Sep 18 23:26:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 34, 44 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115470669105467392",
  "text" : "gnar shredding dialed to the max \"@VTCycling: awesome racing today! top results: Men's A 4-5, Men's B 3-6-7, Mens C 2, Womens A 2-3\"",
  "id" : 115470669105467392,
  "created_at" : "Sun Sep 18 17:02:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notime2waste",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115291449033097217",
  "geo" : {
  },
  "id_str" : "115386187119734784",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e heres the eq why: real analysis + abstract algebra + 5000-level math modeling + numerical analysis + hist of math &gt; fb #notime2waste",
  "id" : 115386187119734784,
  "in_reply_to_status_id" : 115291449033097217,
  "created_at" : "Sun Sep 18 11:26:25 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115218372999909376",
  "geo" : {
  },
  "id_str" : "115245666581753856",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT good luck tomorrow!!",
  "id" : 115245666581753856,
  "in_reply_to_status_id" : 115218372999909376,
  "created_at" : "Sun Sep 18 02:08:02 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 3, 15 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 17, 27 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115209262678032384",
  "text" : "RT @LeeRMatthis: @VTCycling hope y'all r stickin' it to the ACCC!!!!   Go get tmrw!!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Virginia Tech ",
        "screen_name" : "VTCycling",
        "indices" : [ 0, 10 ],
        "id_str" : "117782776",
        "id" : 117782776
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "115183275739316225",
    "in_reply_to_user_id" : 117782776,
    "text" : "@VTCycling hope y'all r stickin' it to the ACCC!!!!   Go get tmrw!!",
    "id" : 115183275739316225,
    "created_at" : "Sat Sep 17 22:00:07 +0000 2011",
    "in_reply_to_screen_name" : "VTCycling",
    "in_reply_to_user_id_str" : "117782776",
    "user" : {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "protected" : false,
      "id_str" : "70417462",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1402226998/image_normal.jpg",
      "id" : 70417462,
      "verified" : false
    }
  },
  "id" : 115209262678032384,
  "created_at" : "Sat Sep 17 23:43:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115183417947205632",
  "geo" : {
  },
  "id_str" : "115208967944282113",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis I'm gonna try to, and yeah keep that rubber side down. somethin def went crunch in my shoulder today lol in tree hug 4/4",
  "id" : 115208967944282113,
  "in_reply_to_status_id" : 115183417947205632,
  "created_at" : "Sat Sep 17 23:42:13 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 103, 113 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chyeah",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "letsgo",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115150633098674177",
  "text" : "two awesome races today! punched a few too many trees in XC, but dominated short track #chyeah #letsgo @VTCycling",
  "id" : 115150633098674177,
  "created_at" : "Sat Sep 17 19:50:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 38, 48 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "115026809355120640",
  "text" : "rise and shine, its butt whoopin time @VTCycling! on our way to race in the rain",
  "id" : 115026809355120640,
  "created_at" : "Sat Sep 17 11:38:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 13, 21 ],
      "id_str" : "84075278",
      "id" : 84075278
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 36, 46 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "racefuel",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114867748089245697",
  "text" : "burrito stop @Moes_HQ #racefuel for @vtcycling!",
  "id" : 114867748089245697,
  "created_at" : "Sat Sep 17 01:06:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeworkintow",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114798557189509120",
  "text" : "time to get my MTB on. leaving for Raleigh for the weekend! #homeworkintow",
  "id" : 114798557189509120,
  "created_at" : "Fri Sep 16 20:31:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/QNTSsyoN",
      "expanded_url" : "http://www.youtube.com/watch?v=NJVO9ynytRs",
      "display_url" : "youtube.com/watch?v=NJVO9y…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114791532866973696",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan this should be our new squirrel guard: http://t.co/QNTSsyoN",
  "id" : 114791532866973696,
  "created_at" : "Fri Sep 16 20:03:28 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterride",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114790536925286400",
  "text" : "@Tri_Gardner MTB racing this weekend, but thanks. since you're a celebrity and all, you should just post #twitterride like lance, 1000s show",
  "id" : 114790536925286400,
  "created_at" : "Fri Sep 16 19:59:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 90, 100 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eastcoasters",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114757687660654592",
  "geo" : {
  },
  "id_str" : "114790027652890624",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis that was at #eastcoasters. bring your bike to the meeting on Monday. you fix @vtcycling's spines, we'll fix your derailer!",
  "id" : 114790027652890624,
  "in_reply_to_status_id" : 114757687660654592,
  "created_at" : "Fri Sep 16 19:57:29 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/vgnOBiR5",
      "expanded_url" : "http://twitpic.com/6lsizb",
      "display_url" : "twitpic.com/6lsizb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114756508893462529",
  "text" : "just sold my first road bike, found her a good home http://t.co/vgnOBiR5",
  "id" : 114756508893462529,
  "created_at" : "Fri Sep 16 17:44:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 121, 129 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/JdoM3pWZ",
      "expanded_url" : "http://bit.ly/oyV5kU",
      "display_url" : "bit.ly/oyV5kU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114681698154840064",
  "text" : "cold 8 miles, mmm warm maple oatmeal! Fun Friday ++  by andyreagan at Garmin Connect - Details: http://t.co/JdoM3pWZ via @AddThis",
  "id" : 114681698154840064,
  "created_at" : "Fri Sep 16 12:47:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louie Giglio",
      "screen_name" : "louiegiglio",
      "indices" : [ 3, 15 ],
      "id_str" : "14807546",
      "id" : 14807546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/4RDh1juO",
      "expanded_url" : "http://on.wsj.com/7XByez",
      "display_url" : "on.wsj.com/7XByez"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114548671684689921",
  "text" : "RT @louiegiglio: Rugby fans worldwide want the US to know just how much football (American) action is in a 3 hour game: http://t.co/4RDh1juO",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http://t.co/4RDh1juO",
        "expanded_url" : "http://on.wsj.com/7XByez",
        "display_url" : "on.wsj.com/7XByez"
      } ]
    },
    "geo" : {
    },
    "id_str" : "114481608647655424",
    "text" : "Rugby fans worldwide want the US to know just how much football (American) action is in a 3 hour game: http://t.co/4RDh1juO",
    "id" : 114481608647655424,
    "created_at" : "Thu Sep 15 23:31:57 +0000 2011",
    "user" : {
      "name" : "Louie Giglio",
      "screen_name" : "louiegiglio",
      "protected" : false,
      "id_str" : "14807546",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3312435472/6024091d339651439436fdaacce19521_normal.jpeg",
      "id" : 14807546,
      "verified" : true
    }
  },
  "id" : 114548671684689921,
  "created_at" : "Fri Sep 16 03:58:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creepy",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114547783788273665",
  "text" : "while sitting in the kitchen, I smelled something burning. investigated...the baseboard in my room was on...I didn't turn it on #creepy",
  "id" : 114547783788273665,
  "created_at" : "Fri Sep 16 03:54:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114484059111043072",
  "geo" : {
  },
  "id_str" : "114484554626109440",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy apparently not... haha i'm still feelin fresh-ish. next week I'll bring the pain",
  "id" : 114484554626109440,
  "in_reply_to_status_id" : 114484059111043072,
  "created_at" : "Thu Sep 15 23:43:39 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114479926912090112",
  "geo" : {
  },
  "id_str" : "114482456232599553",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy i like barely count either lol, too short!",
  "id" : 114482456232599553,
  "in_reply_to_status_id" : 114479926912090112,
  "created_at" : "Thu Sep 15 23:35:19 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 0, 13 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114481915096076290",
  "in_reply_to_user_id" : 25713870,
  "text" : "@williamenium you crushed that brah!! sub 10!!",
  "id" : 114481915096076290,
  "created_at" : "Thu Sep 15 23:33:10 +0000 2011",
  "in_reply_to_screen_name" : "williamenium",
  "in_reply_to_user_id_str" : "25713870",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 43, 53 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 54, 67 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 68, 80 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 81, 94 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/6tmkFsYf",
      "expanded_url" : "http://app.strava.com/rides/1635541#25934104",
      "display_url" : "app.strava.com/rides/1635541#…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114474446521241600",
  "text" : "just did a 10:19 up Harding and felt good! @VTCycling @williamenium @runfasteraw @blogblogblog http://t.co/6tmkFsYf",
  "id" : 114474446521241600,
  "created_at" : "Thu Sep 15 23:03:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 34, 44 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 45, 57 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114442682587283456",
  "text" : "time for the \"Assault of Harding\" @VTCycling @runfasteraw cold and windy, so mybe no records",
  "id" : 114442682587283456,
  "created_at" : "Thu Sep 15 20:57:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 49, 59 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114395753165754368",
  "text" : "one more class today! can smell the weekend. the @VTCycling \"assault of harding\" is at 5PM!!",
  "id" : 114395753165754368,
  "created_at" : "Thu Sep 15 17:50:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 3, 14 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114359170853117952",
  "text" : "RT @angryasian: Little bird says SRAM already has working hydro road brake/shift lever protos. Real disc road/CX is coming sooner than l ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "114341365319602176",
    "text" : "Little bird says SRAM already has working hydro road brake/shift lever protos. Real disc road/CX is coming sooner than later. Can't wait.",
    "id" : 114341365319602176,
    "created_at" : "Thu Sep 15 14:14:40 +0000 2011",
    "user" : {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "protected" : false,
      "id_str" : "16353686",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/904017577/105073547_normal.jpg",
      "id" : 16353686,
      "verified" : false
    }
  },
  "id" : 114359170853117952,
  "created_at" : "Thu Sep 15 15:25:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114122922125307905",
  "geo" : {
  },
  "id_str" : "114328125881581568",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet might? definitely am lol",
  "id" : 114328125881581568,
  "in_reply_to_status_id" : 114122922125307905,
  "created_at" : "Thu Sep 15 13:22:03 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114314957927092224",
  "geo" : {
  },
  "id_str" : "114321506439409664",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C duuuude. no idea!! shit was crazy....",
  "id" : 114321506439409664,
  "in_reply_to_status_id" : 114314957927092224,
  "created_at" : "Thu Sep 15 12:55:45 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/UZlbLb71",
      "expanded_url" : "http://andyreagan.com/2011/09/15/man-run/",
      "display_url" : "andyreagan.com/2011/09/15/man…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114321406178766850",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 I couldn't descride MAN RUN via text quite as well: http://t.co/UZlbLb71",
  "id" : 114321406178766850,
  "created_at" : "Thu Sep 15 12:55:21 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 54, 66 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 80, 90 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114089695658524674",
  "text" : "\"life is a collection of decisions\" and 6pm today its @VTTriathlon Man run &gt; @VTCycling Worlds &gt; Mercer info session &gt; HW",
  "id" : 114089695658524674,
  "created_at" : "Wed Sep 14 21:34:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 89, 98 ],
      "id_str" : "25850390",
      "id" : 25850390
    }, {
      "name" : "Paul Vines",
      "screen_name" : "PaulVines",
      "indices" : [ 99, 109 ],
      "id_str" : "97647246",
      "id" : 97647246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweet",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "114088768373395456",
  "text" : "got accepted to present a talk w my group @ NIMBioS Undergrad Research Conference #sweet @jdbrunnr @paulvines",
  "id" : 114088768373395456,
  "created_at" : "Wed Sep 14 21:30:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http://t.co/uQyv8oj",
      "expanded_url" : "http://www.bakadesuyo.com/is-your-brother-smart-then-you-might-be-crazy",
      "display_url" : "bakadesuyo.com/is-your-brothe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "114069635808231424",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet http://t.co/uQyv8oj",
  "id" : 114069635808231424,
  "created_at" : "Wed Sep 14 20:14:55 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114052236459524097",
  "geo" : {
  },
  "id_str" : "114062749692211200",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan yupp I shouted pretty loud lol, but knew it was hopeless",
  "id" : 114062749692211200,
  "in_reply_to_status_id" : 114052236459524097,
  "created_at" : "Wed Sep 14 19:47:33 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114048784308244480",
  "geo" : {
  },
  "id_str" : "114051093109018624",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan I saw you greekin' it up outside owens lol and shouted your name pretty loud but you were too greek-absorbed lol",
  "id" : 114051093109018624,
  "in_reply_to_status_id" : 114048784308244480,
  "created_at" : "Wed Sep 14 19:01:14 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/6tvRwez",
      "expanded_url" : "http://4sq.com/oBOcsk",
      "display_url" : "4sq.com/oBOcsk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "114023695504244736",
  "text" : "got applause for my ice cream cone #winning (@ Dietrick Dining Center) [pic]: http://t.co/6tvRwez",
  "id" : 114023695504244736,
  "created_at" : "Wed Sep 14 17:12:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wishmeluck",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113998986897133568",
  "text" : "job fair time #wishmeluck",
  "id" : 113998986897133568,
  "created_at" : "Wed Sep 14 15:34:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 0, 15 ],
      "id_str" : "208127016",
      "id" : 208127016
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 123, 132 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113992687807512576",
  "geo" : {
  },
  "id_str" : "113998846593474561",
  "in_reply_to_user_id" : 208127016,
  "text" : "@BRMSBlacksburg @Tri_Gardner said he can't do it because he's already signed up for a tri that day. he wants to give it to @Run_Rudy",
  "id" : 113998846593474561,
  "in_reply_to_status_id" : 113992687807512576,
  "created_at" : "Wed Sep 14 15:33:37 +0000 2011",
  "in_reply_to_screen_name" : "BRMSBlacksburg",
  "in_reply_to_user_id_str" : "208127016",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 76, 88 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 105, 114 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bakersdozen",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113977034287497217",
  "text" : "forgot to set the alarm and missed #bakersdozen, so thinking about my first @VTTriathlon MAN Run tonight @Run_Rudy",
  "id" : 113977034287497217,
  "created_at" : "Wed Sep 14 14:06:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 0, 14 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crackdown",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113813536018407424",
  "geo" : {
  },
  "id_str" : "113825432914231297",
  "in_reply_to_user_id" : 26010551,
  "text" : "@Thundercoffer everyone is getting pulled over on bike #crackdown",
  "id" : 113825432914231297,
  "in_reply_to_status_id" : 113813536018407424,
  "created_at" : "Wed Sep 14 04:04:32 +0000 2011",
  "in_reply_to_screen_name" : "Thundercoffer",
  "in_reply_to_user_id_str" : "26010551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 9, 21 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 95, 105 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113746487833411584",
  "text" : "time for @VTTriathlon swim practice then going to my first homebrew meeting since the spring w @Crispy__C!",
  "id" : 113746487833411584,
  "created_at" : "Tue Sep 13 22:50:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 13, 25 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113737795650064384",
  "text" : "@Tri_Gardner @VTTriathlon I know me either!! Yeah I guess so....haha",
  "id" : 113737795650064384,
  "created_at" : "Tue Sep 13 22:16:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 59, 74 ],
      "id_str" : "208127016",
      "id" : 208127016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "competition",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113734391641026560",
  "text" : "just won free entry into @MtnLake 's Mountain Top Trot via @BRMSBlacksburg!! Awesome!!! And @Tri_Gardner was the other winner #competition",
  "id" : 113734391641026560,
  "created_at" : "Tue Sep 13 22:02:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 3, 18 ],
      "id_str" : "208127016",
      "id" : 208127016
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 90, 101 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113734036542865411",
  "text" : "RT @BRMSBlacksburg: The winners of the entries to @MtnLake 's Mountain Top Trot Race are: @andyreagan & @Tri_Gardner !  Details to come  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 70, 81 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "113733705591308289",
    "text" : "The winners of the entries to @MtnLake 's Mountain Top Trot Race are: @andyreagan & @Tri_Gardner !  Details to come via Direct Message",
    "id" : 113733705591308289,
    "created_at" : "Tue Sep 13 22:00:03 +0000 2011",
    "user" : {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "protected" : false,
      "id_str" : "208127016",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1305562262/New_Image_normal.JPG",
      "id" : 208127016,
      "verified" : false
    }
  },
  "id" : 113734036542865411,
  "created_at" : "Tue Sep 13 22:01:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "useless",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113628966258089984",
  "text" : "so engineering expo (2nd largest job fair in the country) is today, but their website is down... #useless",
  "id" : 113628966258089984,
  "created_at" : "Tue Sep 13 15:03:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biking",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "ftw",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113628579560034306",
  "text" : "my kitchen -&gt; in classroom in McBryde in 7 minutes while eating breakfast on the way #biking #ftw",
  "id" : 113628579560034306,
  "created_at" : "Tue Sep 13 15:02:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 30, 40 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 64, 76 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/vcwZiXg",
      "expanded_url" : "http://twitpic.com/6k7ekm",
      "display_url" : "twitpic.com/6k7ekm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113487436763500544",
  "text" : "first prototype of Tuck Chiro @VTCycling aero helmet complete!! @LeeRMatthis http://t.co/vcwZiXg",
  "id" : 113487436763500544,
  "created_at" : "Tue Sep 13 05:41:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113461559245811712",
  "text" : "likes having the math lounge to himself, but time to head home",
  "id" : 113461559245811712,
  "created_at" : "Tue Sep 13 03:58:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/BpN1fpW",
      "expanded_url" : "http://connect.garmin.com/activity/104665100",
      "display_url" : "connect.garmin.com/activity/10466…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113456775654686720",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan I was checkin out your Garmin Connect, you're only four minutes off my record 37:41 Frank Gay Loop: http://t.co/BpN1fpW",
  "id" : 113456775654686720,
  "created_at" : "Tue Sep 13 03:39:37 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damn",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "pastmybedtime",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113448260768776194",
  "text" : "time flies when you're writing in LaTeX... #damn almost #pastmybedtime",
  "id" : 113448260768776194,
  "created_at" : "Tue Sep 13 03:05:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 42, 51 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http://t.co/cAJshiL",
      "expanded_url" : "http://bit.ly/nWNaEb",
      "display_url" : "bit.ly/nWNaEb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113429714550534144",
  "text" : "8:30's up the big hill, nice run Mom!! RT @dmreagan \"Run from the village to home by donnareagan at Garmin Connect: http://t.co/cAJshiL\"",
  "id" : 113429714550534144,
  "created_at" : "Tue Sep 13 01:52:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113429488162975744",
  "text" : "RT @bakadesuyo: What do very happy people have in common? http://ht.ly/6rwuX",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "113416657971593216",
    "text" : "What do very happy people have in common? http://ht.ly/6rwuX",
    "id" : 113416657971593216,
    "created_at" : "Tue Sep 13 01:00:13 +0000 2011",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 113429488162975744,
  "created_at" : "Tue Sep 13 01:51:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 12, 24 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 31, 41 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelinggreat",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113429427274264576",
  "text" : "adjusted by @LeeRMatthis @ the @VTCycling meeting #feelinggreat. homework until I finish now (hopefully by  morning!)",
  "id" : 113429427274264576,
  "created_at" : "Tue Sep 13 01:50:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegelife",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113421514791063552",
  "geo" : {
  },
  "id_str" : "113428906228453376",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet that's real #collegelife ...psh Asher Roth",
  "id" : 113428906228453376,
  "in_reply_to_status_id" : 113421514791063552,
  "created_at" : "Tue Sep 13 01:48:53 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113228728192090112",
  "geo" : {
  },
  "id_str" : "113229545120862208",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud it's a function set equal to a constant. like take f(x,y,z)=x^2+y^2+z^2, set =1, and the level set is a sphere",
  "id" : 113229545120862208,
  "in_reply_to_status_id" : 113228728192090112,
  "created_at" : "Mon Sep 12 12:36:41 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 121, 129 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http://t.co/Lu4FM41",
      "expanded_url" : "http://bit.ly/q4hu9x",
      "display_url" : "bit.ly/q4hu9x"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113221949651554304",
  "text" : "running while the sun rises #winning. Baker's Dozen: Champs 5K Loop on Garmin Connect - Details: http://t.co/Lu4FM41 via @AddThis",
  "id" : 113221949651554304,
  "created_at" : "Mon Sep 12 12:06:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 25, 36 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 64, 73 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 74, 90 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 91, 100 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "macellusmafia",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "113101534304280576",
  "text" : "not looking too good for @kreagannet's fantasy football team... @vmhilljr @RumblinStumblin @dmreagan super bowl here I come! #macellusmafia",
  "id" : 113101534304280576,
  "created_at" : "Mon Sep 12 04:08:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reagansarealwaysright",
      "indices" : [ 56, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113094568542613504",
  "geo" : {
  },
  "id_str" : "113098889141293056",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT haha well if a Reagan said it...must be right #reagansarealwaysright",
  "id" : 113098889141293056,
  "in_reply_to_status_id" : 113094568542613504,
  "created_at" : "Mon Sep 12 03:57:31 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 82, 95 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/5NIRyuJ",
      "expanded_url" : "http://twitpic.com/6jmicg",
      "display_url" : "twitpic.com/6jmicg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "113031731732422658",
  "text" : "I think most people would watch tv for a 20min study break, I built and rode this @williamenium http://t.co/5NIRyuJ",
  "id" : 113031731732422658,
  "created_at" : "Sun Sep 11 23:30:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112946269814661120",
  "geo" : {
  },
  "id_str" : "112947731705761794",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis yup. i'm only mildly allergic, so I still finished (not first anymore), but most people got attacked. there were 4 ambulances",
  "id" : 112947731705761794,
  "in_reply_to_status_id" : 112946269814661120,
  "created_at" : "Sun Sep 11 17:56:52 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112940552013627392",
  "text" : "good torn apart by the XC course today in two laps, which I crushed for 8 laps before. was in first with a gap, but bee's attacked",
  "id" : 112940552013627392,
  "created_at" : "Sun Sep 11 17:28:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112914283716804609",
  "geo" : {
  },
  "id_str" : "112939632454418432",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet haha that is what the predictions say, but they're never right",
  "id" : 112939632454418432,
  "in_reply_to_status_id" : 112914283716804609,
  "created_at" : "Sun Sep 11 17:24:41 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mtb",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112752291118989312",
  "text" : "@Tri_Gardner thanks man! heard you got 3rd cuz they sent you running the wrong way haha? we need to get you on a #mtb!",
  "id" : 112752291118989312,
  "created_at" : "Sun Sep 11 05:00:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112741683950661632",
  "geo" : {
  },
  "id_str" : "112751867573977088",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris new frame while you're at it? haha. decal looks sick",
  "id" : 112751867573977088,
  "in_reply_to_status_id" : 112741683950661632,
  "created_at" : "Sun Sep 11 04:58:34 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 3, 19 ],
      "id_str" : "361582244",
      "id" : 361582244
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 21, 30 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 43, 55 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112751622513364992",
  "text" : "RT @peacelovinchris: @Run_Rudy Way to lead @VTTriathlon in the Patriot half this afternoon! You guys crushed it!",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rudy Rutemiller",
        "screen_name" : "Run_Rudy",
        "indices" : [ 0, 9 ],
        "id_str" : "342318092",
        "id" : 342318092
      }, {
        "name" : "VT Triathlon",
        "screen_name" : "VTTriathlon",
        "indices" : [ 22, 34 ],
        "id_str" : "47645908",
        "id" : 47645908
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "112676275616878592",
    "in_reply_to_user_id" : 342318092,
    "text" : "@Run_Rudy Way to lead @VTTriathlon in the Patriot half this afternoon! You guys crushed it!",
    "id" : 112676275616878592,
    "created_at" : "Sat Sep 10 23:58:12 +0000 2011",
    "in_reply_to_screen_name" : "Run_Rudy",
    "in_reply_to_user_id_str" : "342318092",
    "user" : {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "protected" : false,
      "id_str" : "361582244",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1624940194/i460l189_normal",
      "id" : 361582244,
      "verified" : false
    }
  },
  "id" : 112751622513364992,
  "created_at" : "Sun Sep 11 04:57:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112609035064311808",
  "geo" : {
  },
  "id_str" : "112751132090187776",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr haha they are very sneaky! hope your ride went well!!",
  "id" : 112751132090187776,
  "in_reply_to_status_id" : 112609035064311808,
  "created_at" : "Sun Sep 11 04:55:39 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112605094540869632",
  "geo" : {
  },
  "id_str" : "112605304339955713",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT sounds good, I may be there a littler sooner too",
  "id" : 112605304339955713,
  "in_reply_to_status_id" : 112605094540869632,
  "created_at" : "Sat Sep 10 19:16:11 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112602948722372608",
  "geo" : {
  },
  "id_str" : "112604445715599360",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT soon, can I get you at your house at 3:40?",
  "id" : 112604445715599360,
  "in_reply_to_status_id" : 112602948722372608,
  "created_at" : "Sat Sep 10 19:12:46 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112602039351115777",
  "text" : "and other than hitting a tree, think I did well on the downhill! we'll see when times are up. time for some DUAL SLALOM",
  "id" : 112602039351115777,
  "created_at" : "Sat Sep 10 19:03:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 14, 30 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112601898728693760",
  "text" : ".@vtcycling's @JacobnAndersson held it down for 4th in the Men's A short track, and one second behind Christian on the downhill at 7:07",
  "id" : 112601898728693760,
  "created_at" : "Sat Sep 10 19:02:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112601738825043969",
  "text" : "place 2nd in the short track!! outsprinted an ASU guy on the uphill finish, only guy who beat me didn't do the uphill race earlier #boom",
  "id" : 112601738825043969,
  "created_at" : "Sat Sep 10 19:02:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112562875435991041",
  "geo" : {
  },
  "id_str" : "112601520784162816",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT sounds awesome! the dual slalom will start at 4:30, I'm home now to grab some pasta. want a ride down there? tweet bak, no phone",
  "id" : 112601520784162816,
  "in_reply_to_status_id" : 112562875435991041,
  "created_at" : "Sat Sep 10 19:01:09 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112552181206495232",
  "text" : "looks like Beard Face is gonna hang on for fourth! warming up for my own race",
  "id" : 112552181206495232,
  "created_at" : "Sat Sep 10 15:45:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112549037575651328",
  "text" : ".@vtcycling after a CRAZY 50 person men's c short track hole shot, Jacob Reymann aka Beard Facee is in third!",
  "id" : 112549037575651328,
  "created_at" : "Sat Sep 10 15:32:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 88, 95 ],
      "id_str" : "18177652",
      "id" : 18177652
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 97, 109 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 110, 126 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112534796512673793",
  "text" : ".@vtcycling's Jake A up Old Farm in 13:35! Every1 else looked great, times coming later @BenDUB! @runfasteraw @JacobnAndersson @J_Gardner90",
  "id" : 112534796512673793,
  "created_at" : "Sat Sep 10 14:36:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 11, 21 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lego",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112506014519144448",
  "text" : "race time! @VTCycling #lego",
  "id" : 112506014519144448,
  "created_at" : "Sat Sep 10 12:41:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 11, 23 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 24, 33 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112477786148585472",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud @OGfromtheOB @Run_Rudy get some today!!!",
  "id" : 112477786148585472,
  "created_at" : "Sat Sep 10 10:49:28 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mysteriousmushroomsandmold",
      "indices" : [ 108, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112345222448562177",
  "text" : "things that grow without a hint of sunlight scare me. which is why our basement is a very, very scary place #mysteriousmushroomsandmold",
  "id" : 112345222448562177,
  "created_at" : "Sat Sep 10 02:02:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/XbE5h2V",
      "expanded_url" : "http://twitter.com/#!/andyreagan/media/slideshow?url=http%3A%2F%2Ftwitpic.com%2F69pq8o",
      "display_url" : "twitter.com/#!/andyreagan/…"
    } ]
  },
  "in_reply_to_status_id_str" : "112303917345423361",
  "geo" : {
  },
  "id_str" : "112305196071272449",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel nonsense, I delivered a queen mattress on my bike the other week: http://t.co/XbE5h2V",
  "id" : 112305196071272449,
  "in_reply_to_status_id" : 112303917345423361,
  "created_at" : "Fri Sep 09 23:23:39 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112291683084931072",
  "text" : "@Tri_Gardner yessir I am, should be fun!",
  "id" : 112291683084931072,
  "created_at" : "Fri Sep 09 22:29:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112286994805174272",
  "text" : "@Tri_Gardner crush that shit!",
  "id" : 112286994805174272,
  "created_at" : "Fri Sep 09 22:11:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112278005669306368",
  "geo" : {
  },
  "id_str" : "112286553027522560",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel get a bike kiddo",
  "id" : 112286553027522560,
  "in_reply_to_status_id" : 112278005669306368,
  "created_at" : "Fri Sep 09 22:09:35 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realanalysis",
      "indices" : [ 26, 39 ]
    }, {
      "text" : "domination",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/3dTPAlY",
      "expanded_url" : "http://twitpic.com/6ibqyx",
      "display_url" : "twitpic.com/6ibqyx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "112183779589767168",
  "text" : "that's what I like to see #realanalysis #domination http://t.co/3dTPAlY",
  "id" : 112183779589767168,
  "created_at" : "Fri Sep 09 15:21:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 3, 18 ],
      "id_str" : "208127016",
      "id" : 208127016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NRV",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "blacksbu",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/34S71xM",
      "expanded_url" : "http://bit.ly/pSyrqc",
      "display_url" : "bit.ly/pSyrqc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "112182461621997569",
  "text" : "RT @BRMSBlacksburg: RT this & you could win a FREE entry into @MtnLake 's Mtn Top Trot race on Oct 1! http://t.co/34S71xM #NRV #blacksbu ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NRV",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "blacksburg",
        "indices" : [ 107, 118 ]
      }, {
        "text" : "hokies",
        "indices" : [ 119, 126 ]
      }, {
        "text" : "hot2trot",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 101 ],
        "url" : "http://t.co/34S71xM",
        "expanded_url" : "http://bit.ly/pSyrqc",
        "display_url" : "bit.ly/pSyrqc"
      } ]
    },
    "geo" : {
    },
    "id_str" : "112150773017747458",
    "text" : "RT this & you could win a FREE entry into @MtnLake 's Mtn Top Trot race on Oct 1! http://t.co/34S71xM #NRV #blacksburg #hokies #hot2trot",
    "id" : 112150773017747458,
    "created_at" : "Fri Sep 09 13:10:02 +0000 2011",
    "user" : {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "protected" : false,
      "id_str" : "208127016",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1305562262/New_Image_normal.JPG",
      "id" : 208127016,
      "verified" : false
    }
  },
  "id" : 112182461621997569,
  "created_at" : "Fri Sep 09 15:15:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112021519131099136",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris it was good catching up! that's exciting youre coming down at the end of the month, Id thought before it wouldnt be til dec",
  "id" : 112021519131099136,
  "created_at" : "Fri Sep 09 04:36:26 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 99, 108 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 109, 125 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111422385562992640",
  "geo" : {
  },
  "id_str" : "112020996046852097",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 okay sweet! yeah I graduate the 17th, so you should come down!! probs can catch a ride w @dmreagan @RumblinStumblin (my parents)",
  "id" : 112020996046852097,
  "in_reply_to_status_id" : 111422385562992640,
  "created_at" : "Fri Sep 09 04:34:21 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 74, 83 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 84, 100 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111269218749652992",
  "geo" : {
  },
  "id_str" : "112020790832140288",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 sweet! yeah i figure like you guys could even catch a ride down w @dmreagan @RumblinStumblin (talking abt my graduation guys)",
  "id" : 112020790832140288,
  "in_reply_to_status_id" : 111269218749652992,
  "created_at" : "Fri Sep 09 04:33:32 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/WWHl6xM",
      "expanded_url" : "http://www.youtube.com/watch?v=p3-eavMSBnk",
      "display_url" : "youtube.com/watch?v=p3-eav…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "112019166403379203",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 when you said do you take breaks, I immediately thought of this lol: http://t.co/WWHl6xM (replace playoffs with breaks)",
  "id" : 112019166403379203,
  "created_at" : "Fri Sep 09 04:27:05 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112015597784662016",
  "text" : "just realized that the Blacksburg Brew Do and Big Lick Triathlon (as well as W&M MTB Race) are the same day :( :(",
  "id" : 112015597784662016,
  "created_at" : "Fri Sep 09 04:12:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Belgium Brewing",
      "screen_name" : "newbelgium",
      "indices" : [ 40, 51 ],
      "id_str" : "18057459",
      "id" : 18057459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http://t.co/drWYHxU",
      "expanded_url" : "http://twitpic.com/6i46ai",
      "display_url" : "twitpic.com/6i46ai"
    } ]
  },
  "geo" : {
  },
  "id_str" : "112014857905242112",
  "text" : "real analysis done, my very hard earned @newbelgium recovery drink (now in VA!!) http://t.co/drWYHxU",
  "id" : 112014857905242112,
  "created_at" : "Fri Sep 09 04:09:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Bunce",
      "screen_name" : "ISMsaddles",
      "indices" : [ 0, 11 ],
      "id_str" : "18658970",
      "id" : 18658970
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 40, 52 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 57, 67 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112014169427021824",
  "in_reply_to_user_id" : 18658970,
  "text" : "@ISMsaddles do you sponsor teams? im on @VTTriathlon and @VTCycling, and would really love to try a saddle but we're broke college students",
  "id" : 112014169427021824,
  "created_at" : "Fri Sep 09 04:07:13 +0000 2011",
  "in_reply_to_screen_name" : "ISMsaddles",
  "in_reply_to_user_id_str" : "18658970",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 3, 13 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RealAthletesShaveTheirLegs",
      "indices" : [ 58, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "112001342628839424",
  "text" : "RT @WyattLoud Yes ladies, my legs are smoother than yours #RealAthletesShaveTheirLegs",
  "id" : 112001342628839424,
  "created_at" : "Fri Sep 09 03:16:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tiredlegs",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111943782798340096",
  "text" : "longest run ever: 18.11 miles in 2hr 42min, felt great but #tiredlegs",
  "id" : 111943782798340096,
  "created_at" : "Thu Sep 08 23:27:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111899642685427712",
  "text" : "64 days till Richmond Marathon! amped for a long run",
  "id" : 111899642685427712,
  "created_at" : "Thu Sep 08 20:32:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 46, 58 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111887117466091520",
  "text" : "done with classes! tonight: hw, long run, hw, @VTTriathlon swim practice, then hw!",
  "id" : 111887117466091520,
  "created_at" : "Thu Sep 08 19:42:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111859629016879105",
  "text" : "@Tri_Gardner yessir! I'll cya there",
  "id" : 111859629016879105,
  "created_at" : "Thu Sep 08 17:53:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burritotime",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111603919729340417",
  "text" : "cracked the Egyptians greatest accomplishment #burritotime",
  "id" : 111603919729340417,
  "created_at" : "Thu Sep 08 00:57:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hot",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111603653965656064",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy I see you running dtown, no shirt #hot haha",
  "id" : 111603653965656064,
  "created_at" : "Thu Sep 08 00:55:59 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111596354563883008",
  "text" : "whiteboards rock",
  "id" : 111596354563883008,
  "created_at" : "Thu Sep 08 00:26:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 47, 56 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "bedtime",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111282099998310400",
  "text" : "no better to cap it off than a solid hw sess w @slpagsVT. numerical analysis done thru next Thu #boom #bedtime",
  "id" : 111282099998310400,
  "created_at" : "Wed Sep 07 03:38:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 119, 131 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111281767129939968",
  "text" : "actually had an amazing run this afternoon in the rain, made it to a cool math talk, drafted a sick FF team, talked to @VTTriathlon AND",
  "id" : 111281767129939968,
  "created_at" : "Wed Sep 07 03:36:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 8, 17 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 18, 33 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111268468778733568",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @DKnick88 @ryandelgiudice when do you guys finish finals this fall? Bc you should all come down for my graduation!!!",
  "id" : 111268468778733568,
  "created_at" : "Wed Sep 07 02:44:04 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110917228353953792",
  "geo" : {
  },
  "id_str" : "111231376812032001",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e I def do need a haircut! but im afraid of all these places in blacksburg",
  "id" : 111231376812032001,
  "in_reply_to_status_id" : 110917228353953792,
  "created_at" : "Wed Sep 07 00:16:41 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "111166131179503616",
  "text" : "its cold. it's raining. going for a long run...",
  "id" : 111166131179503616,
  "created_at" : "Tue Sep 06 19:57:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111109668453097472",
  "geo" : {
  },
  "id_str" : "111165493079060480",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C wish I was that hip",
  "id" : 111165493079060480,
  "in_reply_to_status_id" : 111109668453097472,
  "created_at" : "Tue Sep 06 19:54:53 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110910454532014080",
  "text" : "ugh microsoft you suck. i installed windows 7 ultimate, and only have a key for \"enterprise\" edition, so i now have to reinstall the OS",
  "id" : 110910454532014080,
  "created_at" : "Tue Sep 06 03:01:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 66, 79 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http://t.co/Bg3HNaU",
      "expanded_url" : "http://lockerz.com/s/136197588",
      "display_url" : "lockerz.com/s/136197588"
    } ]
  },
  "geo" : {
  },
  "id_str" : "110853924088582144",
  "text" : "RT @ladyhokie11: A canoe in class :/ only in #wrvt here's ur pick @plaidavenger  http://t.co/Bg3HNaU",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Plaid Avenger",
        "screen_name" : "plaidavenger",
        "indices" : [ 49, 62 ],
        "id_str" : "14193991",
        "id" : 14193991
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 28, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http://t.co/Bg3HNaU",
        "expanded_url" : "http://lockerz.com/s/136197588",
        "display_url" : "lockerz.com/s/136197588"
      } ]
    },
    "geo" : {
    },
    "id_str" : "110852522587074560",
    "text" : "A canoe in class :/ only in #wrvt here's ur pick @plaidavenger  http://t.co/Bg3HNaU",
    "id" : 110852522587074560,
    "created_at" : "Mon Sep 05 23:11:15 +0000 2011",
    "user" : {
      "name" : "Tunnel Vision",
      "screen_name" : "SimplyFocused11",
      "protected" : false,
      "id_str" : "127414025",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3232220304/de1cdf4993c808b23eeb713010833646_normal.jpeg",
      "id" : 127414025,
      "verified" : false
    }
  },
  "id" : 110853924088582144,
  "created_at" : "Mon Sep 05 23:16:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Carter",
      "screen_name" : "hokiiegirl",
      "indices" : [ 3, 14 ],
      "id_str" : "199100558",
      "id" : 199100558
    }, {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 16, 29 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http://t.co/cka0lwK",
      "expanded_url" : "http://yfrog.com/h8w7aexj",
      "display_url" : "yfrog.com/h8w7aexj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "110853897966460929",
  "text" : "RT @hokiiegirl: @plaidavenger #wrvt 'bring a canoe nite' champs. http://t.co/cka0lwK",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Plaid Avenger",
        "screen_name" : "plaidavenger",
        "indices" : [ 0, 13 ],
        "id_str" : "14193991",
        "id" : 14193991
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 14, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 68 ],
        "url" : "http://t.co/cka0lwK",
        "expanded_url" : "http://yfrog.com/h8w7aexj",
        "display_url" : "yfrog.com/h8w7aexj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "110852384229572609",
    "in_reply_to_user_id" : 14193991,
    "text" : "@plaidavenger #wrvt 'bring a canoe nite' champs. http://t.co/cka0lwK",
    "id" : 110852384229572609,
    "created_at" : "Mon Sep 05 23:10:42 +0000 2011",
    "in_reply_to_screen_name" : "plaidavenger",
    "in_reply_to_user_id_str" : "14193991",
    "user" : {
      "name" : "Kate Carter",
      "screen_name" : "hokiiegirl",
      "protected" : false,
      "id_str" : "199100558",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1138834022/vt_ribbon_normal.jpg",
      "id" : 199100558,
      "verified" : false
    }
  },
  "id" : 110853897966460929,
  "created_at" : "Mon Sep 05 23:16:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Pritchard",
      "screen_name" : "katiepritchard",
      "indices" : [ 3, 18 ],
      "id_str" : "14194079",
      "id" : 14194079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http://t.co/ctqDgx4",
      "expanded_url" : "http://yfrog.com/nwgezxj",
      "display_url" : "yfrog.com/nwgezxj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "110853539689013248",
  "text" : "RT @katiepritchard: Canoe in #wrvt  http://t.co/ctqDgx4",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 16, 35 ],
        "url" : "http://t.co/ctqDgx4",
        "expanded_url" : "http://yfrog.com/nwgezxj",
        "display_url" : "yfrog.com/nwgezxj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "110852282198921217",
    "text" : "Canoe in #wrvt  http://t.co/ctqDgx4",
    "id" : 110852282198921217,
    "created_at" : "Mon Sep 05 23:10:18 +0000 2011",
    "user" : {
      "name" : "Katie Pritchard",
      "screen_name" : "katiepritchard",
      "protected" : false,
      "id_str" : "14194079",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1517926459/new_avatar_twitter_normal.jpg",
      "id" : 14194079,
      "verified" : false
    }
  },
  "id" : 110853539689013248,
  "created_at" : "Mon Sep 05 23:15:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 1, 14 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110853224357044225",
  "text" : ".@williamenium and I just brought a canoe to \"Bring your canoe to class night\" #wrvt",
  "id" : 110853224357044225,
  "created_at" : "Mon Sep 05 23:14:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 3, 16 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110845466949849088",
  "text" : "RT @plaidavenger: It's \"Bring a Canoe Nite\" in World Regions class! +10 for every boat brought into the room! #wrvt",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "110841879574220800",
    "text" : "It's \"Bring a Canoe Nite\" in World Regions class! +10 for every boat brought into the room! #wrvt",
    "id" : 110841879574220800,
    "created_at" : "Mon Sep 05 22:28:58 +0000 2011",
    "user" : {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "protected" : false,
      "id_str" : "14193991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2915300835/2e61e76e46e76b2c27a4747c49b95c9a_normal.jpeg",
      "id" : 14193991,
      "verified" : false
    }
  },
  "id" : 110845466949849088,
  "created_at" : "Mon Sep 05 22:43:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 12, 22 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 26, 38 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 67, 77 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110832197870690304",
  "text" : "sahweet! RT @vtcycling RT @LeeRMatthis Just got off the phone with @vtcycling!! Looking forward to working with them again this season!!!!",
  "id" : 110832197870690304,
  "created_at" : "Mon Sep 05 21:50:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/bVq2TOT",
      "expanded_url" : "http://www.youtube.com/watch?v=XsCvE2u6d4E",
      "display_url" : "youtube.com/watch?v=XsCvE2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "110791330518671360",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 I couldn't get the one from my friend so I took another quick video haha: http://t.co/bVq2TOT",
  "id" : 110791330518671360,
  "created_at" : "Mon Sep 05 19:08:06 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110741608701497344",
  "text" : "RT @VTCycling: meeting tonight at 8PM, in War 124. Come find out how to race our awesome home MTB race weekend for FREE!!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "110740539460173824",
    "text" : "meeting tonight at 8PM, in War 124. Come find out how to race our awesome home MTB race weekend for FREE!!",
    "id" : 110740539460173824,
    "created_at" : "Mon Sep 05 15:46:16 +0000 2011",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 110741608701497344,
  "created_at" : "Mon Sep 05 15:50:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110732014851850240",
  "text" : "forgot to bring my HW to class that I spent till 2AM last night working on, biked back in the rain to my house... ugh not a good start",
  "id" : 110732014851850240,
  "created_at" : "Mon Sep 05 15:12:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tiredddd",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110579198011252736",
  "text" : "abstract algebra proofs: 0. me: .8 (hopefully). time for bed #tiredddd",
  "id" : 110579198011252736,
  "created_at" : "Mon Sep 05 05:05:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 41, 51 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110453041165115392",
  "text" : "just returned from the weekend's races w @VTCycling, a super fun and successful weekend all around! brought home 2 top 5s my first wknd in B",
  "id" : 110453041165115392,
  "created_at" : "Sun Sep 04 20:43:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 0, 7 ],
      "id_str" : "18177652",
      "id" : 18177652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109862950537400321",
  "geo" : {
  },
  "id_str" : "110452633906593792",
  "in_reply_to_user_id" : 18177652,
  "text" : "@BenDUB twas limited reception, but the racing was excellent. jake nabbed two seconds, I got two top 5's, we won C's XC!",
  "id" : 110452633906593792,
  "in_reply_to_status_id" : 109862950537400321,
  "created_at" : "Sun Sep 04 20:42:14 +0000 2011",
  "in_reply_to_screen_name" : "BenDUB",
  "in_reply_to_user_id_str" : "18177652",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "110452406420111361",
  "text" : "@Tri_Gardner we did well! one win, and a bunch of top 5 finishes! just got back, there wasn't any reception out there",
  "id" : 110452406420111361,
  "created_at" : "Sun Sep 04 20:41:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "REI",
      "screen_name" : "REI",
      "indices" : [ 57, 61 ],
      "id_str" : "16583846",
      "id" : 16583846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109768113519734784",
  "text" : "tents set up just before the rain, excited to see how my @rei stays dry! no 3g so pix of mtb racing this weekend though",
  "id" : 109768113519734784,
  "created_at" : "Fri Sep 02 23:22:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ironic",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/rXFHakJ",
      "expanded_url" : "http://twitpic.com/6f2kzz",
      "display_url" : "twitpic.com/6f2kzz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109747339962482688",
  "text" : "the conservation police just passed us (they were speeding)  #ironic and check this out, crazy! http://t.co/rXFHakJ",
  "id" : 109747339962482688,
  "created_at" : "Fri Sep 02 21:59:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 16, 32 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "ACC Cycling",
      "screen_name" : "ACCCycling",
      "indices" : [ 39, 50 ],
      "id_str" : "111463102",
      "id" : 111463102
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 79, 89 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109699967265943553",
  "text" : "leaving 1hr! RT @JacobnAndersson First @ACCCycling mtb race of the season with @VTCycling and lots of fast people! Lets bring home the win!",
  "id" : 109699967265943553,
  "created_at" : "Fri Sep 02 18:51:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oops",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "omnomnom",
      "indices" : [ 6, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http://t.co/bN9drkP",
      "expanded_url" : "http://twitpic.com/6f0ap2",
      "display_url" : "twitpic.com/6f0ap2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109698647612071936",
  "text" : "#oops #omnomnom http://t.co/bN9drkP",
  "id" : 109698647612071936,
  "created_at" : "Fri Sep 02 18:46:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 53, 65 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109693740096028672",
  "geo" : {
  },
  "id_str" : "109694092656652288",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 sweet. and now you're officially part of the @VTTriathlon team, welcome! (they have a twitter too lol)",
  "id" : 109694092656652288,
  "in_reply_to_status_id" : 109693740096028672,
  "created_at" : "Fri Sep 02 18:28:04 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexistjokes",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109693201652252672",
  "text" : "@Tri_Gardner yeah man get u one! u can even get a combo breadmaker, dishwasher, snowblower. just give her a sponge and a shovel #sexistjokes",
  "id" : 109693201652252672,
  "created_at" : "Fri Sep 02 18:24:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM",
      "screen_name" : "uvmvermont",
      "indices" : [ 61, 72 ],
      "id_str" : "29447794",
      "id" : 29447794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http://t.co/7y3NzEg",
      "expanded_url" : "http://twitpic.com/6ezpqj",
      "display_url" : "twitpic.com/6ezpqj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109686922057760768",
  "text" : "a perfect loaf for this weekend and super awesome news about @uvmvermont's grad program, sounds amazing http://t.co/7y3NzEg",
  "id" : 109686922057760768,
  "created_at" : "Fri Sep 02 17:59:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109656383238057984",
  "geo" : {
  },
  "id_str" : "109659353128239104",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT haha definitely",
  "id" : 109659353128239104,
  "in_reply_to_status_id" : 109656383238057984,
  "created_at" : "Fri Sep 02 16:10:01 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 59, 66 ],
      "id_str" : "18177652",
      "id" : 18177652
    }, {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 71, 85 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109653835261280256",
  "text" : "successful day so far! awoke to a call to MTBing action by @BenDUB and @StephenAtHome's redition of Friday for 7AM Bakers Dozen \"Fun Friday\"",
  "id" : 109653835261280256,
  "created_at" : "Fri Sep 02 15:48:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109648323643838465",
  "geo" : {
  },
  "id_str" : "109653301166997504",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT and you're tellin me...",
  "id" : 109653301166997504,
  "in_reply_to_status_id" : 109648323643838465,
  "created_at" : "Fri Sep 02 15:45:58 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 81, 88 ],
      "id_str" : "18177652",
      "id" : 18177652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109599295350652928",
  "text" : "@Tri_Gardner good plan. i'm going MTB racing this weekend! check your email from @BenDUB and I think you might change your mind too",
  "id" : 109599295350652928,
  "created_at" : "Fri Sep 02 12:11:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109579195474116608",
  "geo" : {
  },
  "id_str" : "109599116501336064",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C cinnamon raison bread is correct!! i'll make some for tuesday!",
  "id" : 109599116501336064,
  "in_reply_to_status_id" : 109579195474116608,
  "created_at" : "Fri Sep 02 12:10:40 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109486091890991104",
  "geo" : {
  },
  "id_str" : "109577939443646464",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e you took reals lol? that was a tricky proof... hopefully I did it right!",
  "id" : 109577939443646464,
  "in_reply_to_status_id" : 109486091890991104,
  "created_at" : "Fri Sep 02 10:46:31 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109477430745509888",
  "text" : "@Tri_Gardner well considering that they about broke my eye sockets lol all yours. bakers dozen in t-7hrs?",
  "id" : 109477430745509888,
  "created_at" : "Fri Sep 02 04:07:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "622 North BBurg",
      "screen_name" : "622North",
      "indices" : [ 15, 24 ],
      "id_str" : "115245208",
      "id" : 115245208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109476768309710848",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan \"@622North: Yes RASTA is going down tonight at 622! Blacksburgs only reggae night! One hope One love\"",
  "id" : 109476768309710848,
  "created_at" : "Fri Sep 02 04:04:30 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109438439086239745",
  "geo" : {
  },
  "id_str" : "109469568430379009",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C close, but less to do with the beer, and more with cinnamons and raisons",
  "id" : 109469568430379009,
  "in_reply_to_status_id" : 109438439086239745,
  "created_at" : "Fri Sep 02 03:35:53 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109429127404204032",
  "text" : "a prize to the first to guess what im up to w last twitpic!",
  "id" : 109429127404204032,
  "created_at" : "Fri Sep 02 00:55:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109427814922588160",
  "geo" : {
  },
  "id_str" : "109428747798716416",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet I know where you are judging by the badge alone lol, sweet!",
  "id" : 109428747798716416,
  "in_reply_to_status_id" : 109427814922588160,
  "created_at" : "Fri Sep 02 00:53:41 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 19, 31 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 55, 65 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http://t.co/ZZLiWo9",
      "expanded_url" : "http://twitpic.com/6enp6s",
      "display_url" : "twitpic.com/6enp6s"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109428543280250880",
  "text" : "solid swim pract w @VTTriathlon! and nice running into @Crispy__C at, of all places, Kroger! http://t.co/ZZLiWo9",
  "id" : 109428543280250880,
  "created_at" : "Fri Sep 02 00:52:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http://t.co/nNuTfpH",
      "expanded_url" : "http://twitpic.com/6eluii",
      "display_url" : "twitpic.com/6eluii"
    }, {
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/sSRIBnx",
      "expanded_url" : "http://twitpic.com/6eluja",
      "display_url" : "twitpic.com/6eluja"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109389298637340672",
  "text" : "old man reagan, young hireable reagan http://t.co/nNuTfpH http://t.co/sSRIBnx",
  "id" : 109389298637340672,
  "created_at" : "Thu Sep 01 22:16:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109380254799380480",
  "text" : "just proved that there are infinitely many irrational and infinitely many rational numbers in any open set of real numbers! #boom",
  "id" : 109380254799380480,
  "created_at" : "Thu Sep 01 21:40:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 3, 15 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109352806875541504",
  "text" : "RT @VTTriathlon: SWIM PRACTICE at 7 in MCCOMAS",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "109318594927661056",
    "text" : "SWIM PRACTICE at 7 in MCCOMAS",
    "id" : 109318594927661056,
    "created_at" : "Thu Sep 01 17:35:58 +0000 2011",
    "user" : {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "protected" : false,
      "id_str" : "47645908",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1308014970/206316_10150222611186427_717896426_8927904_146677_n_normal.jpg",
      "id" : 47645908,
      "verified" : false
    }
  },
  "id" : 109352806875541504,
  "created_at" : "Thu Sep 01 19:51:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 23, 32 ],
      "id_str" : "195438525",
      "id" : 195438525
    }, {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 63, 73 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http://t.co/SpJXxX2",
      "expanded_url" : "http://4sq.com/nDYCLD",
      "display_url" : "4sq.com/nDYCLD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "109279902313877504",
  "text" : "between class ran into @cafezulu!! she literally just finished @bikebuild, so cool! (@ McBryde Hall w/ 5 others) http://t.co/SpJXxX2",
  "id" : 109279902313877504,
  "created_at" : "Thu Sep 01 15:02:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]