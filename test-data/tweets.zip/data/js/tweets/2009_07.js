Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 9, 16 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2943437440",
  "text" : "And yeah @kaitia its a good first race, by push I meant friendly push up a hill lol but per ur request if you're chargin ill stay clear lol",
  "id" : 2943437440,
  "created_at" : "Fri Jul 31 02:35:58 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2943394967",
  "text" : "Got home at 5:30, played bball for 2 hrs (going 4-0), biked for another 1.5 hrs hard, and just ate potatoes out of our garden for dinner!!",
  "id" : 2943394967,
  "created_at" : "Fri Jul 31 02:33:25 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 25, 32 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2937377758",
  "text" : "Haha you should grateful @kaitia! I wouldn't give just anyone a push...   And its 4:35 and I'm puttin in overtime!",
  "id" : 2937377758,
  "created_at" : "Thu Jul 30 20:36:18 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 4, 11 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2921136957",
  "text" : "Yay @kaitia lol that's sweet. Kaelyn I assume is running so she'll prolly beat my mom so I'll be sure to give you a push when I pass u lol!",
  "id" : 2921136957,
  "created_at" : "Thu Jul 30 01:25:09 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 28, 35 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2920294027",
  "text" : "Mmm ithaca root beer... And @kaitia that's awesome!! Who with??",
  "id" : 2920294027,
  "created_at" : "Thu Jul 30 00:35:12 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2920110995",
  "text" : "Just had the BEST fresh, local (cazenovia) \"tumbleweed\" burger at Empire Microbrewery! #FB http://mypict.me/fi5C",
  "id" : 2920110995,
  "created_at" : "Thu Jul 30 00:24:11 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2919442115",
  "text" : "Did my first ride with the new CytoMAX my bro got me for my bday, its supposed to do awesome things...I think it helped lol idk.",
  "id" : 2919442115,
  "created_at" : "Wed Jul 29 23:43:12 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2911510264",
  "text" : "Almost lunchtime! And hey ms. tweeeet @jcreichel what's up lol.",
  "id" : 2911510264,
  "created_at" : "Wed Jul 29 15:46:30 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 4, 11 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2881322838",
  "text" : "And @kaitia sry I missed your tweet, I promise we'll do it soon!! :)",
  "id" : 2881322838,
  "created_at" : "Tue Jul 28 01:11:58 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2881306294",
  "text" : "Just went for some waterskiing, nailed the slalom deep water start...doesn't get any better than skiing across the open water, surreal.",
  "id" : 2881306294,
  "created_at" : "Tue Jul 28 01:11:00 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 9, 16 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2859637067",
  "text" : "Haha yes @kaitia I opened up twitter to write how I've got nothing done today at all...got outta bed at 12:30 and just napped lol",
  "id" : 2859637067,
  "created_at" : "Sun Jul 26 22:23:24 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2841291978",
  "text" : "Thoroughly enjoying my birthday haha just relaxing now after a dominating round of disc golf",
  "id" : 2841291978,
  "created_at" : "Sat Jul 25 19:07:19 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 90, 97 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2837195383",
  "text" : "Is officially an old man haha...awesome day yesterday and its beautiful out today! Thanks @kaitia and bridge jumping will happen again!",
  "id" : 2837195383,
  "created_at" : "Sat Jul 25 13:39:30 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2829231341",
  "text" : "Bridge jumping was f'in amazing!!! At tullys for my bday with everybody (minus del) and @hweeks0",
  "id" : 2829231341,
  "created_at" : "Sat Jul 25 00:43:34 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2826610043",
  "text" : "Finally bridge jumping time! Ppl can't come but I guess were goin anyway haha",
  "id" : 2826610043,
  "created_at" : "Fri Jul 24 21:49:13 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2824555667",
  "text" : "Payin it forward...just helped a friend from work start THEIR car!",
  "id" : 2824555667,
  "created_at" : "Fri Jul 24 19:46:24 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 25, 32 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2818116537",
  "text" : "Tonight should be sweet, @kaitia, and omg turning 20 tomorrow!! Def the first time I've been weirded out about how old I am lol",
  "id" : 2818116537,
  "created_at" : "Fri Jul 24 13:19:26 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2797566033",
  "text" : "is a working machine...and just rearranged his desk for ultra maximum efficiency",
  "id" : 2797566033,
  "created_at" : "Thu Jul 23 12:57:06 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2782094257",
  "text" : "Holy computers!   ...and they can still barely keep up! http://mypict.me/cKeZ",
  "id" : 2782094257,
  "created_at" : "Wed Jul 22 18:03:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2780905543",
  "text" : "Is bball at 6 and then finishing hotel rwanda!",
  "id" : 2780905543,
  "created_at" : "Wed Jul 22 16:52:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2767333326",
  "text" : "Ugh rain=no vball and no biking... Watchin a movie later?",
  "id" : 2767333326,
  "created_at" : "Tue Jul 21 23:31:21 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 4, 11 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2757845776",
  "text" : "And @kaitia I would bet its from yesterday's ride...sorry...drink lots of water!",
  "id" : 2757845776,
  "created_at" : "Tue Jul 21 13:39:33 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2757745360",
  "text" : "Loves his cube...not. got up a little late this morning too whoops :-O   and no packed lunch this week :-( http://mypict.me/ckHP",
  "id" : 2757745360,
  "created_at" : "Tue Jul 21 13:32:18 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 21, 28 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2750922867",
  "text" : "Sorry to dissappoint @kaitia ...but WE didn't ride 22 lol that's counting the 3 each way from my house hahah. Bed time for me though!",
  "id" : 2750922867,
  "created_at" : "Tue Jul 21 02:57:23 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2747755955",
  "in_reply_to_user_id" : 31015715,
  "text" : "@kaitia Excellent ride today, very hilly 22 miles! Can't ask for better weather...and I actually saw (and heard!) an ice cream truck haha",
  "id" : 2747755955,
  "created_at" : "Mon Jul 20 23:30:02 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2744126016",
  "in_reply_to_user_id" : 31015715,
  "text" : "@kaitia just what it sounds like! Haha you can come if you want! :-P.  ....20 minutes left!",
  "id" : 2744126016,
  "created_at" : "Mon Jul 20 19:39:30 +0000 2009",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 48, 55 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2743832889",
  "text" : "has less than 2 hours at work! Then biking with @kaitia and then its finally bridge jumping time!",
  "id" : 2743832889,
  "created_at" : "Mon Jul 20 19:20:56 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2737275422",
  "text" : "is likin driving my Mom's new Subaru to work...8 hours to go...looks like a nice day out too, hopefully it still is tonight",
  "id" : 2737275422,
  "created_at" : "Mon Jul 20 11:35:51 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 10, 17 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2731594584",
  "text" : "Just like @kaitia haha gettin ready for another 40... 3 weeks of work left, 1 off, and then headin back to VA!",
  "id" : 2731594584,
  "created_at" : "Mon Jul 20 02:24:52 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2729785521",
  "text" : "Trying to find a movie to watch...",
  "id" : 2729785521,
  "created_at" : "Mon Jul 20 00:14:02 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2728968395",
  "text" : "Great ride today at the Ride for the Rescue. Was gonna finish with the lead but flatted... Met some cool ppl and had a great time regardless",
  "id" : 2728968395,
  "created_at" : "Sun Jul 19 23:09:45 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2717635224",
  "text" : "Has to get up for his bike race in 5 hours!!",
  "id" : 2717635224,
  "created_at" : "Sun Jul 19 05:10:33 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2713060723",
  "text" : "just had some delicious burgers from my Dad off the charcoal grill...and just chillin until zdan's tonight.",
  "id" : 2713060723,
  "created_at" : "Sat Jul 18 23:06:04 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 15, 22 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 66, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2709984480",
  "text" : "Is biking with @kaitia! Gettin ready for the Ride for the Rescue! #FB",
  "id" : 2709984480,
  "created_at" : "Sat Jul 18 18:56:36 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2698659457",
  "text" : "Had a good day at the Rescue Mission and a good light bike ride watching the Tour. Tine for bed? Looks like it lol..I'm exhausted.",
  "id" : 2698659457,
  "created_at" : "Sat Jul 18 00:55:01 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2686935577",
  "text" : "Is goin to drop his Mom off at the airport and workin at the Rescue Mission for the day!",
  "id" : 2686935577,
  "created_at" : "Fri Jul 17 11:43:36 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2680457800",
  "text" : "Had an awesome night/day today and needed vacation at Slades camp. And a good ride with E-Shields today...good bball games...great day. #FB",
  "id" : 2680457800,
  "created_at" : "Fri Jul 17 01:50:32 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2625999922",
  "text" : "Went from swimming and disc golf to actually biking in the rain and then running with my mom lol. Did a max HR test to 190, I've done better",
  "id" : 2625999922,
  "created_at" : "Tue Jul 14 03:16:30 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2619859551",
  "text" : "On my way home from work, then swimming and disc golf with my bro, then doing it all over again!",
  "id" : 2619859551,
  "created_at" : "Mon Jul 13 20:22:40 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2614415902",
  "text" : "Needs a vacation, its tough to keep going on 5 hours sleep on Mondays...",
  "id" : 2614415902,
  "created_at" : "Mon Jul 13 14:10:46 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2601962919",
  "text" : "Rode 63 miles this morning! It was a hard ride...burned 4572 calories!! Beautiful day out...and we still have dinosaur left over, soo good!",
  "id" : 2601962919,
  "created_at" : "Sun Jul 12 18:57:38 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://ubertwitter.com\" rel=\"nofollow\">UberTwitter</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2590017166",
  "text" : "Just embedded twitter to my webpage andyreagan.com and is updating this right now on my bb storm, sweetness!!",
  "id" : 2590017166,
  "created_at" : "Sat Jul 11 22:42:58 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2589040405",
  "text" : "does not know anyone else on twitter!!",
  "id" : 2589040405,
  "created_at" : "Sat Jul 11 21:21:08 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2588964275",
  "text" : "just got twitter, woohoo!",
  "id" : 2588964275,
  "created_at" : "Sat Jul 11 21:14:54 +0000 2009",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]