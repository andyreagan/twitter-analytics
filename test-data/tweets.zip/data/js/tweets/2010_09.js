Grailbird.data.tweets_2010_09 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25980237291",
  "text" : "got an 83 on linear algebra exam, class avg was a 63 so I guess ill take it...still wet and gross outside today getting here",
  "id" : 25980237291,
  "created_at" : "Thu Sep 30 13:43:26 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25851108198",
  "text" : "gettin to bed for an 8AM mtb ride tomorrow! to be follow by d2 lunch yeahhh",
  "id" : 25851108198,
  "created_at" : "Wed Sep 29 03:48:20 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25812486497",
  "text" : "human origins class now, then a research meeting, swim practice and tri meeting tonight!",
  "id" : 25812486497,
  "created_at" : "Tue Sep 28 19:20:12 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25809586712",
  "text" : "just took out the ball bearing that's been jingling in the frame of fixie since I first built him two years ago, back in the headset!!",
  "id" : 25809586712,
  "created_at" : "Tue Sep 28 18:38:56 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25803152324",
  "text" : "got an 80 on my modern algebra exam :-/ ...he took off lots of points for tiny errors in long proofs bc \"this is a proving course\" oh well",
  "id" : 25803152324,
  "created_at" : "Tue Sep 28 17:07:41 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25802789615",
  "text" : "and got d2 lunch for the first time this year! It kinda tore me up though lol not used to that much food",
  "id" : 25802789615,
  "created_at" : "Tue Sep 28 17:03:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25802723134",
  "text" : "ran this morning in my new shoes, it went well...did 400's on the track haha I need to get faster",
  "id" : 25802723134,
  "created_at" : "Tue Sep 28 17:02:24 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twit-rank.com\" rel=\"nofollow\">TwitRank</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TwitRank",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25705750622",
  "text" : "My Twitter Rank is &#34;Cool Person&#34;. What&#39;s your Rank? http://twit-rank.com #TwitRank",
  "id" : 25705750622,
  "created_at" : "Mon Sep 27 17:21:44 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 67, 76 ],
      "id_str" : "195438525",
      "id" : 195438525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25698053856",
  "text" : "and I did some research, I'm going to brew a maple nut brown ale!! @cafeZulu do you know where I could get fresh grade B maple syrup haha?",
  "id" : 25698053856,
  "created_at" : "Mon Sep 27 15:45:34 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25697867286",
  "text" : "wet, colder day out today...hello fall! was glad to have my fender and waterproof messenger bag today!!",
  "id" : 25697867286,
  "created_at" : "Mon Sep 27 15:43:24 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25624838402",
  "text" : "just got new running shoes! and picked up my bike, mtb'ing sounded awesome this weekend. and looked at ingredients for brewing soon!",
  "id" : 25624838402,
  "created_at" : "Sun Sep 26 21:19:56 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25606107060",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan can I call in the next hour or so?",
  "id" : 25606107060,
  "created_at" : "Sun Sep 26 16:51:06 +0000 2010",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25606092046",
  "text" : "slept for a solid 11 hours...and just did a 3 hour spin on the trainer watching star trek haha. time for peppperjack grilled cheese?",
  "id" : 25606092046,
  "created_at" : "Sun Sep 26 16:50:55 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25547033664",
  "text" : "instead going to see Elliot and Freeman play some bluegrass at the Cellar! Didn't get a nap in haha, but I'll be walkin back to crash soon",
  "id" : 25547033664,
  "created_at" : "Sun Sep 26 01:15:40 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25546954480",
  "text" : "is not going to App to race MTB tmrw haha my legs are shot, and a 3hr drive for a 7mi race...nope",
  "id" : 25546954480,
  "created_at" : "Sun Sep 26 01:14:32 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25533841138",
  "text" : "Is home! Got a half gallon of breyers vanilla and block of pepper jack cheese for my self-reward lol. time to shower, eat and nap!!",
  "id" : 25533841138,
  "created_at" : "Sat Sep 25 21:53:40 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25528407613",
  "text" : "Finished my first triathlon this morning!! It was tough, olympic distance, but I did it!",
  "id" : 25528407613,
  "created_at" : "Sat Sep 25 20:21:44 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 99, 111 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25438121543",
  "text" : "On my way to Big Lick, sooooo pumped!! 2 passenger vans full of people and big uhaul full of bikes @vttriathlon",
  "id" : 25438121543,
  "created_at" : "Fri Sep 24 20:57:15 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 12, 19 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25331203721",
  "text" : "Me too!! RT @k8eb8e Got a 100 on my stat test!!!",
  "id" : 25331203721,
  "created_at" : "Thu Sep 23 18:34:26 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25314700306",
  "text" : "test wasn't too bad, but we'll see haha",
  "id" : 25314700306,
  "created_at" : "Thu Sep 23 15:01:55 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25305484965",
  "text" : "headed to my Linear Algebra exam...i hate open book tests they scare me bc I have to know everything in the book now too",
  "id" : 25305484965,
  "created_at" : "Thu Sep 23 13:12:53 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25274612686",
  "geo" : {
  },
  "id_str" : "25274716019",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yeah i replied haha....",
  "id" : 25274716019,
  "in_reply_to_status_id" : 25274612686,
  "created_at" : "Thu Sep 23 03:33:55 +0000 2010",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25274447172",
  "text" : "awesome, my blog managed to lose half of my posts from this summer...just what i needed",
  "id" : 25274447172,
  "created_at" : "Thu Sep 23 03:30:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 0, 13 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25214231073",
  "geo" : {
  },
  "id_str" : "25229765575",
  "in_reply_to_user_id" : 18204345,
  "text" : "@blogblogblog okay awesome, thanks! I'll let you know how it comes/if I need help!",
  "id" : 25229765575,
  "in_reply_to_status_id" : 25214231073,
  "created_at" : "Wed Sep 22 17:14:57 +0000 2010",
  "in_reply_to_screen_name" : "blogblogblog",
  "in_reply_to_user_id_str" : "18204345",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 3, 18 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25229730809",
  "text" : "RT @ryandelgiudice: Sometimes you have to forget what you want to remember what you deserve.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "25213820084",
    "text" : "Sometimes you have to forget what you want to remember what you deserve.",
    "id" : 25213820084,
    "created_at" : "Wed Sep 22 14:01:42 +0000 2010",
    "user" : {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "protected" : true,
      "id_str" : "44471444",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1264948750/DSC00020_normal.jpg",
      "id" : 44471444,
      "verified" : false
    }
  },
  "id" : 25229730809,
  "created_at" : "Wed Sep 22 17:14:29 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25133479572",
  "text" : "and now the house is really clean!! Productive day so far haha, and after studying for stat exam...should be easy!",
  "id" : 25133479572,
  "created_at" : "Tue Sep 21 16:34:48 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25133388188",
  "text" : "washed the huge pile of dishes, cleaned the counters, vacuumed everything, picked stuff up, took out the mountain of recycling and the trash",
  "id" : 25133388188,
  "created_at" : "Tue Sep 21 16:33:42 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25063906791",
  "text" : "just got back from a 30 mile, 2 hour bike ride...I'm tired! Homework, cycling meeting, then studying stat for the night",
  "id" : 25063906791,
  "created_at" : "Mon Sep 20 22:35:06 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reidbeloni",
      "screen_name" : "blogblogblog",
      "indices" : [ 0, 13 ],
      "id_str" : "18204345",
      "id" : 18204345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "25031621421",
  "in_reply_to_user_id" : 18204345,
  "text" : "@blogblogblog do you still have that \"beer and cycling\" paper that you started for brewing science?",
  "id" : 25031621421,
  "created_at" : "Mon Sep 20 14:52:35 +0000 2010",
  "in_reply_to_screen_name" : "blogblogblog",
  "in_reply_to_user_id_str" : "18204345",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24991007020",
  "geo" : {
  },
  "id_str" : "25022555314",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice we do!! c'mon down lol",
  "id" : 25022555314,
  "in_reply_to_status_id" : 24991007020,
  "created_at" : "Mon Sep 20 12:57:19 +0000 2010",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/Zl0M4GB",
      "expanded_url" : "http://beta.mapmyrun.com/route/detail/23258914/?open_ive_done=1",
      "display_url" : "beta.mapmyrun.com/route/detail/2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "25020787193",
  "text" : "MapMyRun - Baker's Dozen, 9/20/10 in Blacksburg, VA http://t.co/Zl0M4GB - 6.98mi",
  "id" : 25020787193,
  "created_at" : "Mon Sep 20 12:31:37 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24784145017",
  "text" : "and drinkin high life in brewing class, then headin to NC State to race mtb this weekend!",
  "id" : 24784145017,
  "created_at" : "Fri Sep 17 19:03:05 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24784076470",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan got my care package!! Already ate a bag of no bakes...sooooo good, thanks!",
  "id" : 24784076470,
  "created_at" : "Fri Sep 17 19:02:03 +0000 2010",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24592197376",
  "text" : "it's laundry time! I made it 4 whole weeks...lol",
  "id" : 24592197376,
  "created_at" : "Wed Sep 15 18:12:18 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24585797262",
  "geo" : {
  },
  "id_str" : "24586030468",
  "in_reply_to_user_id" : 26517690,
  "text" : "doin stat hw with @kswedo!",
  "id" : 24586030468,
  "in_reply_to_status_id" : 24585797262,
  "created_at" : "Wed Sep 15 16:45:38 +0000 2010",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24578982555",
  "text" : "new (short) post on http://andyreagan.com!! And a whole new format for the future of my blog...unveiled!",
  "id" : 24578982555,
  "created_at" : "Wed Sep 15 15:20:22 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24516506080",
  "geo" : {
  },
  "id_str" : "24538821071",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice nice job on the 6k!! call me sometime chief",
  "id" : 24538821071,
  "in_reply_to_status_id" : 24516506080,
  "created_at" : "Wed Sep 15 03:55:10 +0000 2010",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24501855084",
  "text" : "And got milk for a mini wheat lunch, and bread for sandwiches for a snack before and after swimming tonight, packed them in a tupperware!",
  "id" : 24501855084,
  "created_at" : "Tue Sep 14 19:14:50 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24501789947",
  "text" : "didn't do as well as expected on my math HW...but not bad.  Got groceries on the way home to make PB cookies tonight!",
  "id" : 24501789947,
  "created_at" : "Tue Sep 14 19:13:47 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 43, 56 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 59, 70 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24320031969",
  "geo" : {
  },
  "id_str" : "24422304944",
  "in_reply_to_user_id" : 68794179,
  "text" : "Really enjoyed the cascades hike :) thanks @laurentappan!  @kreagannet wait till I start a fantasy cycling league...",
  "id" : 24422304944,
  "in_reply_to_status_id" : 24320031969,
  "created_at" : "Mon Sep 13 22:55:16 +0000 2010",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 116, 129 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24401381651",
  "text" : "had a research meeting this morning, finished my linear algebra HW, and now goin for a swim then to the cascades w/ @laurentappan!!",
  "id" : 24401381651,
  "created_at" : "Mon Sep 13 17:28:58 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike Daily",
      "screen_name" : "bikedaily",
      "indices" : [ 3, 13 ],
      "id_str" : "44246388",
      "id" : 44246388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24401190116",
  "text" : "RT @bikedaily: The longest \"tandem\" bike ever built was almost 67 feet long and could seat 35.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialoomph.com\" rel=\"nofollow\">SocialOomph</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "24392769947",
    "text" : "The longest \"tandem\" bike ever built was almost 67 feet long and could seat 35.",
    "id" : 24392769947,
    "created_at" : "Mon Sep 13 15:35:21 +0000 2010",
    "user" : {
      "name" : "Bike Daily",
      "screen_name" : "bikedaily",
      "protected" : false,
      "id_str" : "44246388",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/247557072/dailybike-logo1_normal.png",
      "id" : 44246388,
      "verified" : false
    }
  },
  "id" : 24401190116,
  "created_at" : "Mon Sep 13 17:26:15 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 82, 95 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24339063392",
  "text" : "just got home from the race weekend, unpacked, showered and I'm excited to go see @laurentappan after a long three days haha :)",
  "id" : 24339063392,
  "created_at" : "Mon Sep 13 01:48:30 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24312425243",
  "text" : "got a new front tire and the extra grip paid off today, I won the short track race! XC race was crazy, but I didn't crash and finished well",
  "id" : 24312425243,
  "created_at" : "Sun Sep 12 20:05:39 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24233239369",
  "text" : "had a great day racing bikes while we ripped it up to stay #1 in the conference! Idk if we did for sure lol...but how did tech lose to JMU??",
  "id" : 24233239369,
  "created_at" : "Sat Sep 11 23:10:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24157183557",
  "text" : "is in Richmond, got Chipotle for dinner in Charlottesville on the way. Gettin up real early to race MTB at W&M in the morning!",
  "id" : 24157183557,
  "created_at" : "Sat Sep 11 02:03:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24122449922",
  "text" : "I joined peopleforbikes.org in uniting a million voices to improve the future of biking. Won't you? http://bit.ly/bexolZ",
  "id" : 24122449922,
  "created_at" : "Fri Sep 10 17:11:59 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24116699144",
  "text" : "packing for racing this weekend then swimming before brewing science! Hopefully I don't have to leave class too early for the race",
  "id" : 24116699144,
  "created_at" : "Fri Sep 10 16:00:06 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24050199464",
  "text" : "time for swim practice!",
  "id" : 24050199464,
  "created_at" : "Thu Sep 09 22:48:16 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24050170246",
  "text" : "what i've learned: let wet books air dry lol and my FTP is 280 watts! At my weight, that's Cat 3 baby!",
  "id" : 24050170246,
  "created_at" : "Thu Sep 09 22:47:51 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 59, 68 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24049090249",
  "text" : "and an FTP (functional threshold power) power test (thanks @RBSherfy lol) tells how hard I can pedal (watts) before lactic acid builds up",
  "id" : 24049090249,
  "created_at" : "Thu Sep 09 22:32:18 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24048972308",
  "text" : "some answers lol: books was in freezer/oven because it got soaked, so I tried to first freeze the water and brush it off....then heat it off",
  "id" : 24048972308,
  "created_at" : "Thu Sep 09 22:30:37 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24031406189",
  "text" : "is going on an FTP power test ride...wish me watts!",
  "id" : 24031406189,
  "created_at" : "Thu Sep 09 17:58:36 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 83, 92 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24028845929",
  "text" : "only put my book in the oven after having it in the freezer all night didn't help, @vmhilljr",
  "id" : 24028845929,
  "created_at" : "Thu Sep 09 17:22:31 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24023124581",
  "text" : "in the oven*",
  "id" : 24023124581,
  "created_at" : "Thu Sep 09 16:11:22 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "24023107970",
  "text" : "left my modern algebra book in the over and it kinda melted, whoops",
  "id" : 24023107970,
  "created_at" : "Thu Sep 09 16:11:11 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 53, 62 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23261604219",
  "text" : "got the back 4 my phone in the mail! + a letter from @dmreagan! And just made a delic lunch! 2 classes, swimming, and tri meeting left today",
  "id" : 23261604219,
  "created_at" : "Tue Sep 07 18:44:48 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23250717836",
  "text" : "'s new shifter is in! But dk when I can go get it from Roanoke... And just got my fancy VBI email too haha email me areagan at vbi.vt.edu",
  "id" : 23250717836,
  "created_at" : "Tue Sep 07 16:15:35 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 124, 137 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23184278555",
  "text" : "just got back from a short tempo run after a 20mi bike ride, I swam today too haha..goin crazy. Cookin dinner now then game @laurentappan's!",
  "id" : 23184278555,
  "created_at" : "Mon Sep 06 22:53:17 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23149642768",
  "text" : "just officially signed up for my first triathlon!! Can I learn to swim a mile with enough left to bike 25mi and run 6mi by the 25th? #FB",
  "id" : 23149642768,
  "created_at" : "Mon Sep 06 14:35:02 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "23016476552",
  "text" : "Did ok uphill, blew up a tire in the downhill race today, got a new one at East Coasters and just got second in the short track MTB race!",
  "id" : 23016476552,
  "created_at" : "Sun Sep 05 00:27:19 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22925851919",
  "text" : "just went with dave and got a charcoal grill for $5!!",
  "id" : 22925851919,
  "created_at" : "Fri Sep 03 22:33:36 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22910626287",
  "text" : "didn't have my VT ID so I had to bike home to get it...but was able to swim 1500m in 50min b4 beer class! And dave brought a 6 pack yeahhhh",
  "id" : 22910626287,
  "created_at" : "Fri Sep 03 18:34:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22900113296",
  "text" : "is taking a break from reading about iron homeostatic mechanisms to swim for an hour...if I can make 1500m in 1hr, think I'm doin a tri 9/25",
  "id" : 22900113296,
  "created_at" : "Fri Sep 03 16:10:20 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22899355819",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice you should do this! http://www.philly.com/inquirer/local/20100903_Philly_s_2d_annual_Naked_Bike_Ride_set_for_Sunday.html",
  "id" : 22899355819,
  "created_at" : "Fri Sep 03 16:01:19 +0000 2010",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22898097927",
  "text" : "According to Mintel study, regular cyclists - bike &gt;once/week - are disproportionately likely to be well educated and have greater income",
  "id" : 22898097927,
  "created_at" : "Fri Sep 03 15:46:12 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 3, 12 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Adventure Journal",
      "screen_name" : "adventurevida",
      "indices" : [ 17, 31 ],
      "id_str" : "18931823",
      "id" : 18931823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22897848869",
  "text" : "RT @RBSherfy: RT @adventurevida Is This The Best Bike Lane Graffiti Ever? http://bit.ly/ad2QFI",
  "retweeted_status" : {
    "source" : "<a href=\"http://tweetmeme.com\" rel=\"nofollow\">TweetMeme</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adventure Journal",
        "screen_name" : "adventurevida",
        "indices" : [ 3, 17 ],
        "id_str" : "18931823",
        "id" : 18931823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22886261844",
    "text" : "RT @adventurevida Is This The Best Bike Lane Graffiti Ever? http://bit.ly/ad2QFI",
    "id" : 22886261844,
    "created_at" : "Fri Sep 03 13:21:28 +0000 2010",
    "user" : {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "protected" : false,
      "id_str" : "64328794",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2814889039/e6959e62768a895f3f8a4107a411edb5_normal.png",
      "id" : 64328794,
      "verified" : false
    }
  },
  "id" : 22897848869,
  "created_at" : "Fri Sep 03 15:43:14 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 43, 55 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22897423304",
  "text" : "had a great Fun Friday run this morning w/ @vttriathlon, and oh how I missed D2 brkfst. Got my ID badge, in my cubicle for research since 9!",
  "id" : 22897423304,
  "created_at" : "Fri Sep 03 15:38:10 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22877208120",
  "text" : "Goin for a run!",
  "id" : 22877208120,
  "created_at" : "Fri Sep 03 10:52:11 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22853696068",
  "text" : "had a great swim and been hangin out at the tri team social since, potluck theme: 'Merica so I brought skittles and PBR...freedom in a can!",
  "id" : 22853696068,
  "created_at" : "Fri Sep 03 02:55:01 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22819058253",
  "text" : "The piece that should be one http://twitpic.com/2kl58z",
  "id" : 22819058253,
  "created_at" : "Thu Sep 02 18:06:05 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22818978057",
  "text" : "SRAM shifter deconstructed! Upper right is the piece that broke, I'm suprised how easy it was to take apart haha http://twitpic.com/2kl4q9",
  "id" : 22818978057,
  "created_at" : "Thu Sep 02 18:04:52 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22812723050",
  "text" : "got to class in 6 minutes! That's from sitting at my computer to sitting in McBryde 240...try to beat that in a car or on the bus",
  "id" : 22812723050,
  "created_at" : "Thu Sep 02 16:35:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "indices" : [ 3, 9 ],
      "id_str" : "30967859",
      "id" : 30967859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pepsirefresh",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22812381290",
  "text" : "RT @bsim9: Vote to give this idea 50K: Empower 260 young adults to cycle cross-country for affordable housing #pepsirefresh http://pep.s ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pepsirefresh",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "22810558294",
    "text" : "Vote to give this idea 50K: Empower 260 young adults to cycle cross-country for affordable housing #pepsirefresh http://pep.si/d3gFbr",
    "id" : 22810558294,
    "created_at" : "Thu Sep 02 16:06:57 +0000 2010",
    "user" : {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "protected" : false,
      "id_str" : "30967859",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/136469345/Me_kicking_normal.jpg",
      "id" : 30967859,
      "verified" : false
    }
  },
  "id" : 22812381290,
  "created_at" : "Thu Sep 02 16:30:38 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22796568447",
  "text" : "had a great dinner last night at Lauren's...don't wanna go to class haha",
  "id" : 22796568447,
  "created_at" : "Thu Sep 02 13:11:35 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22736777612",
  "text" : "just picked up the MTB from East Coasters, new chain + shifter cable/housing = world of difference!!",
  "id" : 22736777612,
  "created_at" : "Wed Sep 01 20:06:12 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22726712019",
  "text" : "at East Coasters, and got 30% off from Giro's crash replacement plan. And getting 10% off everything because I rode my bike there! Yay EC!",
  "id" : 22726712019,
  "created_at" : "Wed Sep 01 17:33:46 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22726626555",
  "text" : "Annnd discovered a huge crack in my helmet! From wear tear I guess, but it won't do me any good anymore... Ordered the new Giro Prolight",
  "id" : 22726626555,
  "created_at" : "Wed Sep 01 17:32:40 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22726545955",
  "text" : "And met Emma's dad, Chris at East Coasters when I took the bike in. They're fixing it there, and loaned me a fixie MTB to get home",
  "id" : 22726545955,
  "created_at" : "Wed Sep 01 17:31:33 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22726475345",
  "text" : "went on a MTB up Old Farm today, and broke the chain four times!! Fixed it each time, but it kept getting shorter haha.",
  "id" : 22726475345,
  "created_at" : "Wed Sep 01 17:30:36 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 16, 29 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 57, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22677616149",
  "text" : "has been dating @laurentappan for ONE YEAR today!! &lt;3 #FB",
  "id" : 22677616149,
  "created_at" : "Wed Sep 01 04:10:57 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "22677374392",
  "text" : "just got car insurance again! And actually saved money with GEICO haha, AND found an old hokie passport in my glove box!!",
  "id" : 22677374392,
  "created_at" : "Wed Sep 01 04:07:09 +0000 2010",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]