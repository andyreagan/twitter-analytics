Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 59, 70 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 94, 103 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 104, 115 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notabadlife",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "pruney",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230165919350018050",
  "text" : "worst part is always getting out of the pool #notabadlife \"@skholden17: midnight swim #pruney @DKnick88 @andyreagan\"",
  "id" : 230165919350018050,
  "created_at" : "Tue Jul 31 05:00:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 16, 25 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 34, 50 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crazyson",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230102641261301760",
  "text" : "had both my Mom @dmreagan and Dad @RumblinStumblin on the back of the motorcycle up and down the street #crazyson",
  "id" : 230102641261301760,
  "created_at" : "Tue Jul 31 00:48:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 0, 11 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230098251183947777",
  "geo" : {
  },
  "id_str" : "230102465016651776",
  "in_reply_to_user_id" : 23695888,
  "text" : "@iamtedking sure did! came home on motorcycle, still working on motorcycle bike rack ha. legs feel great, somehow!! must have the beer recov",
  "id" : 230102465016651776,
  "in_reply_to_status_id" : 230098251183947777,
  "created_at" : "Tue Jul 31 00:47:57 +0000 2012",
  "in_reply_to_screen_name" : "iamtedking",
  "in_reply_to_user_id_str" : "23695888",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "indices" : [ 0, 13 ],
      "id_str" : "19867945",
      "id" : 19867945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229962620457861121",
  "geo" : {
  },
  "id_str" : "230000382909235200",
  "in_reply_to_user_id" : 19867945,
  "text" : "@closethedoor luckily the GoPro was too big for the hole in my bag, so I've got video evidence. Not sure I want to see my time up Kanc!",
  "id" : 230000382909235200,
  "in_reply_to_status_id" : 229962620457861121,
  "created_at" : "Mon Jul 30 18:02:19 +0000 2012",
  "in_reply_to_screen_name" : "closethedoor",
  "in_reply_to_user_id_str" : "19867945",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229995768285630466",
  "geo" : {
  },
  "id_str" : "230000033435615232",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser good to know!! yeah so many 0's and 1's have gone missing today",
  "id" : 230000033435615232,
  "in_reply_to_status_id" : 229995768285630466,
  "created_at" : "Mon Jul 30 18:00:55 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 19, 28 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229969933981868032",
  "text" : "headed for a run w @dmreagan...first run sans garmin in a longgg time. gonna suck to replace, can't replace the ride file. i'll get over it",
  "id" : 229969933981868032,
  "created_at" : "Mon Jul 30 16:01:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "indices" : [ 0, 13 ],
      "id_str" : "19867945",
      "id" : 19867945
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 51, 58 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229961234689175553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9801645667, -76.3052968667 ]
  },
  "id_str" : "229961870356914177",
  "in_reply_to_user_id" : 19867945,
  "text" : "@closethedoor I know, it's not real unless it's on @strava! Who will ever believe me...",
  "id" : 229961870356914177,
  "in_reply_to_status_id" : 229961234689175553,
  "created_at" : "Mon Jul 30 15:29:17 +0000 2012",
  "in_reply_to_screen_name" : "closethedoor",
  "in_reply_to_user_id_str" : "19867945",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229960885404307456",
  "text" : "can't find my garmin, and found a garmin-sized hole in the bottom of my backpack...soo bummed. I think I lost the #200NotOn100 file",
  "id" : 229960885404307456,
  "created_at" : "Mon Jul 30 15:25:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 59, 66 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/229953579308425216/photo/1",
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/7hwJCFCz",
      "media_url" : "http://pbs.twimg.com/media/AzD1j-HCIAI9V9P.jpg",
      "id_str" : "229953579312619522",
      "id" : 229953579312619522,
      "media_url_https" : "https://pbs.twimg.com/media/AzD1j-HCIAI9V9P.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/7hwJCFCz"
    } ],
    "hashtags" : [ {
      "text" : "oldman",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229953579308425216",
  "text" : "congratulations to the owner of his first mattress #oldman @DZdan1 http://t.co/7hwJCFCz",
  "id" : 229953579308425216,
  "created_at" : "Mon Jul 30 14:56:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 0, 12 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229776524960739329",
  "geo" : {
  },
  "id_str" : "229777170157932545",
  "in_reply_to_user_id" : 219863324,
  "text" : "@MechE_Hokie agreeeeee",
  "id" : 229777170157932545,
  "in_reply_to_status_id" : 229776524960739329,
  "created_at" : "Mon Jul 30 03:15:21 +0000 2012",
  "in_reply_to_screen_name" : "MechE_Hokie",
  "in_reply_to_user_id_str" : "219863324",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229712879006404608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9802036167, -76.3053695667 ]
  },
  "id_str" : "229764433273032704",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn ahhh jealous!! I came back to NY today for madre's bday. Will be back in Burlington for a reasonable length stay on Thursday ha",
  "id" : 229764433273032704,
  "in_reply_to_status_id" : 229712879006404608,
  "created_at" : "Mon Jul 30 02:24:44 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229758178643021824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9802055333, -76.3055097167 ]
  },
  "id_str" : "229758497561116672",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr burrrrrrrrrn!! no doubt she would have been, but the tweet was a few hours tardy",
  "id" : 229758497561116672,
  "in_reply_to_status_id" : 229758178643021824,
  "created_at" : "Mon Jul 30 02:01:09 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryank",
      "screen_name" : "ryantkelly",
      "indices" : [ 3, 14 ],
      "id_str" : "14462349",
      "id" : 14462349
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 16, 27 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229758185014185985",
  "text" : "RT @ryantkelly: @andyreagan I believe you mean “brass ball edition”",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "229635036641636353",
    "geo" : {
    },
    "id_str" : "229637985828745217",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan I believe you mean “brass ball edition”",
    "id" : 229637985828745217,
    "in_reply_to_status_id" : 229635036641636353,
    "created_at" : "Sun Jul 29 18:02:16 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "ryank",
      "screen_name" : "ryantkelly",
      "protected" : false,
      "id_str" : "14462349",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2391106989/gy95c1wnd20ws95zq0en_normal.jpeg",
      "id" : 14462349,
      "verified" : false
    }
  },
  "id" : 229758185014185985,
  "created_at" : "Mon Jul 30 01:59:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 92, 101 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longride",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229758033016803329",
  "text" : "made it to Marcellus on the motorbike #longride. 11hrs of travelling from ME all for my Mom @dmreagan's bday suprise!!",
  "id" : 229758033016803329,
  "created_at" : "Mon Jul 30 01:59:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 99, 111 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "T",
      "screen_name" : "Hash729",
      "indices" : [ 112, 120 ],
      "id_str" : "30673239",
      "id" : 30673239
    }, {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 121, 130 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229635036641636353",
  "text" : "#200noton100 \"extra amateur edition\" video will be coming out in a couple days, stay tuned! thanks @LeeRMatthis @Hash729 @RBSherfy",
  "id" : 229635036641636353,
  "created_at" : "Sun Jul 29 17:50:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Johnson",
      "screen_name" : "timjohnsoncx",
      "indices" : [ 0, 13 ],
      "id_str" : "17239853",
      "id" : 17239853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229612451228962816",
  "geo" : {
  },
  "id_str" : "229634661108834304",
  "in_reply_to_user_id" : 17239853,
  "text" : "@timjohnsoncx legs feel great actually. butt, not so much. how about you??",
  "id" : 229634661108834304,
  "in_reply_to_status_id" : 229612451228962816,
  "created_at" : "Sun Jul 29 17:49:04 +0000 2012",
  "in_reply_to_screen_name" : "timjohnsoncx",
  "in_reply_to_user_id_str" : "17239853",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7943487667, -72.5049991333 ]
  },
  "id_str" : "229606847626235904",
  "text" : "will be back in the #btv soon...still digesting the past 24 hours of crazy",
  "id" : 229606847626235904,
  "created_at" : "Sun Jul 29 15:58:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "indices" : [ 3, 16 ],
      "id_str" : "19867945",
      "id" : 19867945
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 18, 29 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229378404259078145",
  "text" : "RT @closethedoor: @andyreagan GREAT JOB OUT THERE! Unbelievable that you rode that far! #200noton100",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "200noton100",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229369694438711296",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan GREAT JOB OUT THERE! Unbelievable that you rode that far! #200noton100",
    "id" : 229369694438711296,
    "created_at" : "Sun Jul 29 00:16:11 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "protected" : false,
      "id_str" : "19867945",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1198606165/IMAG0252_normal.jpg",
      "id" : 19867945,
      "verified" : false
    }
  },
  "id" : 229378404259078145,
  "created_at" : "Sun Jul 29 00:50:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 31, 42 ],
      "id_str" : "23695888",
      "id" : 23695888
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 70, 81 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229378199488978944",
  "text" : "RT @ChrisDanforth: Congrats to @iamtedking for inspiring greatness in @andyreagan today. 200 mile ride from Burlington to Portland. Unre ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted King",
        "screen_name" : "iamtedking",
        "indices" : [ 12, 23 ],
        "id_str" : "23695888",
        "id" : 23695888
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 51, 62 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "200noton100",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229371548706942976",
    "text" : "Congrats to @iamtedking for inspiring greatness in @andyreagan today. 200 mile ride from Burlington to Portland. Unreal. #200noton100",
    "id" : 229371548706942976,
    "created_at" : "Sun Jul 29 00:23:33 +0000 2012",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 229378199488978944,
  "created_at" : "Sun Jul 29 00:49:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67313885, -70.3147576333 ]
  },
  "id_str" : "229355825897029632",
  "text" : "helloooooooooo Portland, ME #200noton100",
  "id" : 229355825897029632,
  "created_at" : "Sat Jul 28 23:21:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 69, 80 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.7935018667, -70.65101255 ]
  },
  "id_str" : "229334916561768448",
  "text" : "final pit stop 25mi from Scratch Bakery, almost there!! #200noton100 @iamtedking",
  "id" : 229334916561768448,
  "created_at" : "Sat Jul 28 21:57:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 112, 119 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229259244069867520",
  "text" : "hung with #200noton100 main group for 50 miles, now at 103 in Lincoln, NH, ready to climb the Kanc after lunch! @sspis1",
  "id" : 229259244069867520,
  "created_at" : "Sat Jul 28 16:57:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/229143146716618753/photo/1",
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/CKuGuU7h",
      "media_url" : "http://pbs.twimg.com/media/Ay4UelcCYAIQaOo.jpg",
      "id_str" : "229143146720813058",
      "id" : 229143146720813058,
      "media_url_https" : "https://pbs.twimg.com/media/Ay4UelcCYAIQaOo.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/CKuGuU7h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820673333, -73.2028396333 ]
  },
  "id_str" : "229143146716618753",
  "text" : "it's go time, breakfast made and headed to the start in 30min! http://t.co/CKuGuU7h",
  "id" : 229143146716618753,
  "created_at" : "Sat Jul 28 09:15:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "200on100",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "200noton100",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229063990335123457",
  "text" : "back in the #btv, and just watched last year's #200on100, if I could be any more excited idk. 4.5hrs of sleep here we go #200noton100",
  "id" : 229063990335123457,
  "created_at" : "Sat Jul 28 04:01:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229062615920431105",
  "geo" : {
  },
  "id_str" : "229063377798967296",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 cell phone is dead and charging for tomorrow, hope the party was good, and I'll tty tom!",
  "id" : 229063377798967296,
  "in_reply_to_status_id" : 229062615920431105,
  "created_at" : "Sat Jul 28 03:58:59 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 30, 39 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6372934, -70.2507423667 ]
  },
  "id_str" : "228985822655942656",
  "text" : "in Portland, ME! Listening to @Radiolab on the way = brilliant!! Even the through hikers I picked up were digging it",
  "id" : 228985822655942656,
  "created_at" : "Fri Jul 27 22:50:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/228897255736889344/photo/1",
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/U6OoWmeq",
      "media_url" : "http://pbs.twimg.com/media/Ay0012KCUAAxQIp.jpg",
      "id_str" : "228897255741083648",
      "id" : 228897255741083648,
      "media_url_https" : "https://pbs.twimg.com/media/Ay0012KCUAAxQIp.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/U6OoWmeq"
    } ],
    "hashtags" : [ {
      "text" : "carboloading",
      "indices" : [ 71, 84 ]
    }, {
      "text" : "actuallytraining",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48197335, -73.20304535 ]
  },
  "id_str" : "228897255736889344",
  "text" : "giant pb&amp;j's, a salad, and a gallon of water packed for the drive. #carboloading is easier than #actuallytraining http://t.co/U6OoWmeq",
  "id" : 228897255736889344,
  "created_at" : "Fri Jul 27 16:58:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 20, 32 ]
    }, {
      "text" : "ready",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/mFSUbZkp",
      "expanded_url" : "http://bit.ly/N8h1hP",
      "display_url" : "bit.ly/N8h1hP"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/AQyU8asu",
      "expanded_url" : "http://bit.ly/MKd9d6",
      "display_url" : "bit.ly/MKd9d6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228880399537930241",
  "text" : "google map route of #200noton100: http://t.co/mFSUbZkp (for printed backup) and downloadable garmin course: http://t.co/AQyU8asu #ready",
  "id" : 228880399537930241,
  "created_at" : "Fri Jul 27 15:51:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 112, 121 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228879973182734338",
  "text" : "about to drive to Portland, ME to drop my car there for #200noton100. dropping some supplies en route possibly. @Radiolab loaded up 4 drive!",
  "id" : 228879973182734338,
  "created_at" : "Fri Jul 27 15:50:12 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 97, 109 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "easy",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "proxy",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228855999744864256",
  "text" : "how to get the olympics free from BBC: trick them into thinking you're from Britain #easy #proxy @mrfrank5790",
  "id" : 228855999744864256,
  "created_at" : "Fri Jul 27 14:14:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realperson",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "feelsgood",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228833625297264640",
  "text" : "getting to the store and eating breakfast by 8am #realperson #feelsgood",
  "id" : 228833625297264640,
  "created_at" : "Fri Jul 27 12:46:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228702462033395712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822588833, -73.2031310667 ]
  },
  "id_str" : "228824833666998272",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 what do you by death density? it must not be number of deaths each over number of participants each year. is there a fairer assess?",
  "id" : 228824833666998272,
  "in_reply_to_status_id" : 228702462033395712,
  "created_at" : "Fri Jul 27 12:11:06 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 8, 15 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 55, 62 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228686247009337345",
  "geo" : {
  },
  "id_str" : "228694297086660609",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @DZdan1 and so 1 slap is awarded to the victor @sspis1. to be administered atthe any time, with no retaliation. any appeals?",
  "id" : 228694297086660609,
  "in_reply_to_status_id" : 228686247009337345,
  "created_at" : "Fri Jul 27 03:32:24 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 84, 93 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shoppingbagsizzle",
      "indices" : [ 55, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4814359833, -73.21960665 ]
  },
  "id_str" : "228630159748648960",
  "text" : "battery park summer concert with vermont's best burger #shoppingbagsizzle @SuMillie @dr_pyser",
  "id" : 228630159748648960,
  "created_at" : "Thu Jul 26 23:17:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228590303676878848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4812995833, -73.2091818667 ]
  },
  "id_str" : "228593010584215552",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser yeahh come to the concert!",
  "id" : 228593010584215552,
  "in_reply_to_status_id" : 228590303676878848,
  "created_at" : "Thu Jul 26 20:49:55 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VeloNews",
      "screen_name" : "velonews",
      "indices" : [ 3, 12 ],
      "id_str" : "5569742",
      "id" : 5569742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TdF",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/Bm9XFo5Z",
      "expanded_url" : "http://ow.ly/cwzVG",
      "display_url" : "ow.ly/cwzVG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228562120688693250",
  "text" : "RT @velonews: Wiggins, in his own words and unabridged in the press room after the stage 19 at the Tour: http://t.co/Bm9XFo5Z #TdF",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TdF",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http://t.co/Bm9XFo5Z",
        "expanded_url" : "http://ow.ly/cwzVG",
        "display_url" : "ow.ly/cwzVG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "228560402550759424",
    "text" : "Wiggins, in his own words and unabridged in the press room after the stage 19 at the Tour: http://t.co/Bm9XFo5Z #TdF",
    "id" : 228560402550759424,
    "created_at" : "Thu Jul 26 18:40:21 +0000 2012",
    "user" : {
      "name" : "VeloNews",
      "screen_name" : "velonews",
      "protected" : false,
      "id_str" : "5569742",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1685337825/velo-news-logo_normal.jpg",
      "id" : 5569742,
      "verified" : false
    }
  },
  "id" : 228562120688693250,
  "created_at" : "Thu Jul 26 18:47:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashhousehar",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228309585763651584",
  "text" : "RT @mrfrank5790: @andyreagan congrats on losing your hashing virginity! btw, u don't need to finish every beer they give u #hashhousehar ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hashhouseharriers",
        "indices" : [ 106, 124 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "228251927580917760",
    "geo" : {
    },
    "id_str" : "228309095659237376",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan congrats on losing your hashing virginity! btw, u don't need to finish every beer they give u #hashhouseharriers",
    "id" : 228309095659237376,
    "in_reply_to_status_id" : 228251927580917760,
    "created_at" : "Thu Jul 26 02:01:44 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 228309585763651584,
  "created_at" : "Thu Jul 26 02:03:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228185916127207424",
  "geo" : {
  },
  "id_str" : "228309349112635392",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e and by prime, you mean prime physically and mentally, right?",
  "id" : 228309349112635392,
  "in_reply_to_status_id" : 228185916127207424,
  "created_at" : "Thu Jul 26 02:02:45 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 51, 63 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/228251927580917760/photo/1",
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/UbR0FFP9",
      "media_url" : "http://pbs.twimg.com/media/Ayrp6zcCQAAj09d.jpg",
      "id_str" : "228251927585112064",
      "id" : 228251927585112064,
      "media_url_https" : "https://pbs.twimg.com/media/Ayrp6zcCQAAj09d.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/UbR0FFP9"
    } ],
    "hashtags" : [ {
      "text" : "hashhouseharriers",
      "indices" : [ 23, 41 ]
    }, {
      "text" : "hashing",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4610584167, -73.2080841333 ]
  },
  "id_str" : "228251927580917760",
  "text" : "going to my first hash #hashhouseharriers #hashing @mrfrank5790 http://t.co/UbR0FFP9",
  "id" : 228251927580917760,
  "created_at" : "Wed Jul 25 22:14:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chandler Delinks",
      "screen_name" : "cdelinks",
      "indices" : [ 0, 9 ],
      "id_str" : "36920127",
      "id" : 36920127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228127780603310080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822951667, -73.20321165 ]
  },
  "id_str" : "228170690698821632",
  "in_reply_to_user_id" : 36920127,
  "text" : "@cdelinks okay, so I'll bring two jars to eat one :-P",
  "id" : 228170690698821632,
  "in_reply_to_status_id" : 228127780603310080,
  "created_at" : "Wed Jul 25 16:51:46 +0000 2012",
  "in_reply_to_screen_name" : "cdelinks",
  "in_reply_to_user_id_str" : "36920127",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "craftbeer",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228158324321968133",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822705667, -73.2031143 ]
  },
  "id_str" : "228168825370202112",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud depends what you're in the mood for. IPA: stone, dfh 60min, hoppyum. Porter: brkyln maple, slumdog. Pilsner: victory. #craftbeer",
  "id" : 228168825370202112,
  "in_reply_to_status_id" : 228158324321968133,
  "created_at" : "Wed Jul 25 16:44:21 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creepedout",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819714833, -73.2032657833 ]
  },
  "id_str" : "228161620994568192",
  "text" : "neighbors porch light keeps turning on and off. did while I walked on porch. switch, just inside front door, was off, and works #creepedout",
  "id" : 228161620994568192,
  "created_at" : "Wed Jul 25 16:15:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 67, 74 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228153387315769344",
  "text" : "eggs over easy, choc chip pancakes, and cookies for breakfast #win @sspis1",
  "id" : 228153387315769344,
  "created_at" : "Wed Jul 25 15:43:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birthdaybros",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228151588248764416",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud Happy Bday Wyatt! #birthdaybros",
  "id" : 228151588248764416,
  "created_at" : "Wed Jul 25 15:35:52 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228146587526909952",
  "geo" : {
  },
  "id_str" : "228151390701232129",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 thanks Lauren!! :)",
  "id" : 228151390701232129,
  "in_reply_to_status_id" : 228146587526909952,
  "created_at" : "Wed Jul 25 15:35:05 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "old",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819731667, -73.20317705 ]
  },
  "id_str" : "227977143886417921",
  "text" : "#old",
  "id" : 227977143886417921,
  "created_at" : "Wed Jul 25 04:02:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/227949522100310018/photo/1",
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/8b7QkZqq",
      "media_url" : "http://pbs.twimg.com/media/AynW4fPCUAEaeVW.jpg",
      "id_str" : "227949522104504321",
      "id" : 227949522104504321,
      "media_url_https" : "https://pbs.twimg.com/media/AynW4fPCUAEaeVW.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/8b7QkZqq"
    } ],
    "hashtags" : [ {
      "text" : "whatagreatgirlfriend",
      "indices" : [ 36, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48201465, -73.2030442 ]
  },
  "id_str" : "227949522100310018",
  "text" : ".@sspis1 even lets me eat the dough #whatagreatgirlfriend http://t.co/8b7QkZqq",
  "id" : 227949522100310018,
  "created_at" : "Wed Jul 25 02:12:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/227880502672105473/photo/1",
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/3JBXvmr4",
      "media_url" : "http://pbs.twimg.com/media/AymYHB3CIAAdRo6.jpg",
      "id_str" : "227880502684688384",
      "id" : 227880502684688384,
      "media_url_https" : "https://pbs.twimg.com/media/AymYHB3CIAAdRo6.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/3JBXvmr4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4823184167, -73.2030501333 ]
  },
  "id_str" : "227880502672105473",
  "text" : "my very first miter, on the newly constructed standalone vise http://t.co/3JBXvmr4",
  "id" : 227880502672105473,
  "created_at" : "Tue Jul 24 21:38:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David I. Lehn",
      "screen_name" : "davidlehn",
      "indices" : [ 0, 10 ],
      "id_str" : "14871683",
      "id" : 14871683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227757264348512256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821692667, -73.2033190667 ]
  },
  "id_str" : "227768108755062784",
  "in_reply_to_user_id" : 14871683,
  "text" : "@davidlehn what about the 2011 dirty dawg? :-P",
  "id" : 227768108755062784,
  "in_reply_to_status_id" : 227757264348512256,
  "created_at" : "Tue Jul 24 14:12:03 +0000 2012",
  "in_reply_to_screen_name" : "davidlehn",
  "in_reply_to_user_id_str" : "14871683",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227577516368461824",
  "geo" : {
  },
  "id_str" : "227592186743644161",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser literally, running? PS that pic of the colorado river is awesome",
  "id" : 227592186743644161,
  "in_reply_to_status_id" : 227577516368461824,
  "created_at" : "Tue Jul 24 02:33:00 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227186041298231296",
  "geo" : {
  },
  "id_str" : "227192132346212353",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy sick!! represent",
  "id" : 227192132346212353,
  "in_reply_to_status_id" : 227186041298231296,
  "created_at" : "Mon Jul 23 00:03:20 +0000 2012",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 119, 124 ]
    }, {
      "text" : "tired",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227160639251034112",
  "text" : "just ran myself over with a dumptruck of riding and dehydration. 5:40 hours, 90 miles, 2x Bolton in 90+ deg baking sun #ouch #tired",
  "id" : 227160639251034112,
  "created_at" : "Sun Jul 22 21:58:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 51, 62 ],
      "id_str" : "23695888",
      "id" : 23695888
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 90, 97 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227035505076875264",
  "text" : "was going to go for a long run today...until I saw @iamtedking's #200NotOn100 training on @strava. Time to get some miles in!",
  "id" : 227035505076875264,
  "created_at" : "Sun Jul 22 13:40:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 51, 59 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 60, 67 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 68, 78 ],
      "id_str" : "528928681",
      "id" : 528928681
    }, {
      "name" : "Marc Reid",
      "screen_name" : "marcreid3",
      "indices" : [ 79, 89 ],
      "id_str" : "332021266",
      "id" : 332021266
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/226877862324625408/photo/1",
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/zFjUu2XG",
      "media_url" : "http://pbs.twimg.com/media/AyYINreCYAA-WZh.jpg",
      "id_str" : "226877862328819712",
      "id" : 226877862328819712,
      "media_url_https" : "https://pbs.twimg.com/media/AyYINreCYAA-WZh.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/zFjUu2XG"
    } ],
    "hashtags" : [ {
      "text" : "67brookestinyroom",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821165667, -73.2030211667 ]
  },
  "id_str" : "226877862324625408",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill we wish you were here!! #67brookestinyroom @Karo1yn @sspis1 @jcusick13 @marcreid3 http://t.co/zFjUu2XG",
  "id" : 226877862324625408,
  "created_at" : "Sun Jul 22 03:14:33 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226867310663720960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4834856833, -73.2043929167 ]
  },
  "id_str" : "226870663053459456",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser well \"australia australia australia\" just doesnt have the same ring to it",
  "id" : 226870663053459456,
  "in_reply_to_status_id" : 226867310663720960,
  "created_at" : "Sun Jul 22 02:45:55 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crazytimes",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226496964349554688",
  "geo" : {
  },
  "id_str" : "226869805054038018",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 I saw your family!! Your bro spotted me starting a USA chant and I called him Hunter by accident lol #crazytimes",
  "id" : 226869805054038018,
  "in_reply_to_status_id" : 226496964349554688,
  "created_at" : "Sun Jul 22 02:42:31 +0000 2012",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 17, 25 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 26, 36 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vtbrewersfest",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4765452667, -73.2207138333 ]
  },
  "id_str" : "226855396004999168",
  "text" : "let it be known: @Karo1yn @jcusick13 and I have WON #vtbrewersfest by drinking all of the best beer and starting the USA chant",
  "id" : 226855396004999168,
  "created_at" : "Sun Jul 22 01:45:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axetickle",
      "screen_name" : "axetickle",
      "indices" : [ 0, 10 ],
      "id_str" : "14666918",
      "id" : 14666918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/ED4EOycw",
      "expanded_url" : "http://www.youtube.com/watch?v=ta79ApkYFms",
      "display_url" : "youtube.com/watch?v=ta79Ap…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48083755, -73.22272515 ]
  },
  "id_str" : "226800944824860673",
  "text" : "@axetickle fixed! enjoy :) http://t.co/ED4EOycw",
  "id" : 226800944824860673,
  "created_at" : "Sat Jul 21 22:08:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vtbrewersfest",
      "indices" : [ 25, 39 ]
    }, {
      "text" : "chillin",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48087175, -73.222698 ]
  },
  "id_str" : "226800247727349760",
  "text" : "behind the scenes at the #vtbrewersfest is remarkably calm #chillin",
  "id" : 226800247727349760,
  "created_at" : "Sat Jul 21 22:06:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/ED4EOycw",
      "expanded_url" : "http://www.youtube.com/watch?v=ta79ApkYFms",
      "display_url" : "youtube.com/watch?v=ta79Ap…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226751532442451969",
  "text" : "first video with the GoPro: Spear-Dorset bike loop in 1min http://t.co/ED4EOycw",
  "id" : 226751532442451969,
  "created_at" : "Sat Jul 21 18:52:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226496964349554688",
  "geo" : {
  },
  "id_str" : "226726509140905984",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 awesome! soo much good beer. I'll be working it tonight, so maybe I'll be the one pouring it :-P",
  "id" : 226726509140905984,
  "in_reply_to_status_id" : 226496964349554688,
  "created_at" : "Sat Jul 21 17:13:06 +0000 2012",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 8, 19 ],
      "id_str" : "40995810",
      "id" : 40995810
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 30, 37 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 59, 70 ],
      "id_str" : "40995810",
      "id" : 40995810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226725751607660544",
  "geo" : {
  },
  "id_str" : "226726209130729473",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @anasemanas good luck @DZdan1. I'm counting on you @anasemanas to make sure he doesn't take any \"extra steps\"",
  "id" : 226726209130729473,
  "in_reply_to_status_id" : 226725751607660544,
  "created_at" : "Sat Jul 21 17:11:55 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 0, 11 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200noton100",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226725962233049089",
  "in_reply_to_user_id" : 23695888,
  "text" : "@iamtedking I'm stoked to try to hang to #200noton100 from Btown. Could I put a gal of gatorade and jar of fluff in the support van?",
  "id" : 226725962233049089,
  "created_at" : "Sat Jul 21 17:10:56 +0000 2012",
  "in_reply_to_screen_name" : "iamtedking",
  "in_reply_to_user_id_str" : "23695888",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4795357833, -73.2216178167 ]
  },
  "id_str" : "226477412395909120",
  "text" : "5 saranac 6 smuttynose 7 nargassett 8 saranac 9 defiant. winner: saranac lemon saison, among some great porters.",
  "id" : 226477412395909120,
  "created_at" : "Sat Jul 21 00:43:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTVbeerfest",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "bestunfollowmenow",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4796388833, -73.221669 ]
  },
  "id_str" : "226466789532520448",
  "text" : "1 harpoon rye ipa. 2 rock art. 3 flying goose cherry wheat 4 wormtown maizok 5 ipswitch oatmeal stout #BTVbeerfest #bestunfollowmenow",
  "id" : 226466789532520448,
  "created_at" : "Sat Jul 21 00:01:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "craftbeer",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4768709833, -73.2193629667 ]
  },
  "id_str" : "226448204512780289",
  "text" : "time to get my #craftbeer on as the Vermont Brewers Festival",
  "id" : 226448204512780289,
  "created_at" : "Fri Jul 20 22:47:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 20, 30 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatty",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226401179054272512",
  "text" : "it was great seeing @Crispy__C for some Bueno y Sano and Cremee chillin, got 2 for 1 on the burritos #fatty",
  "id" : 226401179054272512,
  "created_at" : "Fri Jul 20 19:40:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toys",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226331298694840320",
  "text" : "home in Burlington and first order of unpacking is to charge the droid, the garmin, and the gopro #toys",
  "id" : 226331298694840320,
  "created_at" : "Fri Jul 20 15:02:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 3, 12 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226330573147340802",
  "text" : "RT @vmhilljr: @andyreagan Better than \"bottom of Lake Champlain tweet.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "226319003168165890",
    "geo" : {
    },
    "id_str" : "226325596697935872",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan Better than \"bottom of Lake Champlain tweet.\"",
    "id" : 226325596697935872,
    "in_reply_to_status_id" : 226319003168165890,
    "created_at" : "Fri Jul 20 14:40:01 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "protected" : false,
      "id_str" : "104673361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1681278155/wally_normal.jpg",
      "id" : 104673361,
      "verified" : false
    }
  },
  "id" : 226330573147340802,
  "created_at" : "Fri Jul 20 14:59:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.49258505, -73.2896481 ]
  },
  "id_str" : "226319003168165890",
  "text" : "middle of Lake Champlain tweet",
  "id" : 226319003168165890,
  "created_at" : "Fri Jul 20 14:13:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 36, 47 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/ld8mqkfm",
      "expanded_url" : "http://twitter.com/sspis1/status/226288409411465216/photo/1",
      "display_url" : "pic.twitter.com/ld8mqkfm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226317447714717696",
  "text" : "RT @sspis1: last nights sampler for @andyreagan http://t.co/ld8mqkfm",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">Twitter MMS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 24, 35 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/sspis1/status/226288409411465216/photo/1",
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/ld8mqkfm",
        "media_url" : "http://pbs.twimg.com/media/AyPwHAQCMAAKJPD.jpg",
        "id_str" : "226288409415659520",
        "id" : 226288409415659520,
        "media_url_https" : "https://pbs.twimg.com/media/AyPwHAQCMAAKJPD.jpg",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com/ld8mqkfm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "226288409411465216",
    "text" : "last nights sampler for @andyreagan http://t.co/ld8mqkfm",
    "id" : 226288409411465216,
    "created_at" : "Fri Jul 20 12:12:16 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 226317447714717696,
  "created_at" : "Fri Jul 20 14:07:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 56, 67 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "riskyliving",
      "indices" : [ 68, 80 ]
    }, {
      "text" : "freeclimbing",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/BltlBaBz",
      "expanded_url" : "http://yfrog.com/odcn9owj",
      "display_url" : "yfrog.com/odcn9owj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.3217159667, -73.9131703833 ]
  },
  "id_str" : "226069280133885953",
  "text" : "\"@sspis1: http://t.co/BltlBaBz legit rock climbing with @andyreagan #riskyliving\" #freeclimbing",
  "id" : 226069280133885953,
  "created_at" : "Thu Jul 19 21:41:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Men's Humor",
      "screen_name" : "MensHumor",
      "indices" : [ 0, 10 ],
      "id_str" : "355741893",
      "id" : 355741893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226036234940735490",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2409521167, -73.9545317667 ]
  },
  "id_str" : "226038222499749888",
  "in_reply_to_user_id" : 355741893,
  "text" : "@MensHumor what about the morning disappearing trick?",
  "id" : 226038222499749888,
  "in_reply_to_status_id" : 226036234940735490,
  "created_at" : "Thu Jul 19 19:38:06 +0000 2012",
  "in_reply_to_screen_name" : "MensHumor",
  "in_reply_to_user_id_str" : "355741893",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226031276354850817",
  "geo" : {
  },
  "id_str" : "226037930446159873",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 thanks! we sure are. we'll have to drag your butt up one of these peaks soon, its so fun! I'm hooked",
  "id" : 226037930446159873,
  "in_reply_to_status_id" : 226031276354850817,
  "created_at" : "Thu Jul 19 19:36:56 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.1521259333, -73.9802397667 ]
  },
  "id_str" : "225987198820962304",
  "text" : "clear enough day to see Camel's Hump and Mt Mansfield some 30 or 40 miles away in VT #cool (wouldn't be able to in a picture tho)",
  "id" : 225987198820962304,
  "created_at" : "Thu Jul 19 16:15:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/225983033860317184/photo/1",
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/9AbEmF9m",
      "media_url" : "http://pbs.twimg.com/media/AyLaXzrCYAAuwAf.jpg",
      "id_str" : "225983033864511488",
      "id" : 225983033864511488,
      "media_url_https" : "https://pbs.twimg.com/media/AyLaXzrCYAAuwAf.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/9AbEmF9m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225983033860317184",
  "text" : "remnants of a 1962 B-47 crash on top of Wright Mtn http://t.co/9AbEmF9m",
  "id" : 225983033860317184,
  "created_at" : "Thu Jul 19 15:58:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/225714940437217280/photo/1",
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/z9gIzPx1",
      "media_url" : "http://pbs.twimg.com/media/AyHmit3CQAA_Edu.jpg",
      "id_str" : "225714940445605888",
      "id" : 225714940445605888,
      "media_url_https" : "https://pbs.twimg.com/media/AyHmit3CQAA_Edu.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/z9gIzPx1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225714940437217280",
  "text" : "and back to the bottom for a self reward! http://t.co/z9gIzPx1",
  "id" : 225714940437217280,
  "created_at" : "Wed Jul 18 22:13:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 41, 48 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yup",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225708020489924609",
  "text" : "From the top of whiteface mtn, just rode @sspis1's 30 lb mtb up the 3600ft, 8 mile climb #yup",
  "id" : 225708020489924609,
  "created_at" : "Wed Jul 18 21:46:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 72, 83 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/225404047451107330/photo/1",
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/ESBcwNsn",
      "media_url" : "http://pbs.twimg.com/media/AyDLyXOCMAEZ-qt.jpg",
      "id_str" : "225404047455301633",
      "id" : 225404047455301633,
      "media_url_https" : "https://pbs.twimg.com/media/AyDLyXOCMAEZ-qt.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/ESBcwNsn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225404047451107330",
  "text" : "I wish I could still sign up now! Thanks for the early birthday present @withane271 http://t.co/ESBcwNsn",
  "id" : 225404047451107330,
  "created_at" : "Wed Jul 18 01:38:08 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 35, 42 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 65, 76 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boysandtheirtoys",
      "indices" : [ 77, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/RAWdhdfh",
      "expanded_url" : "http://yfrog.com/obfo4luqj",
      "display_url" : "yfrog.com/obfo4luqj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225401068463460353",
  "text" : "rubber band guns are for all ages \"@sspis1: http://t.co/RAWdhdfh @andyreagan #boysandtheirtoys\"",
  "id" : 225401068463460353,
  "created_at" : "Wed Jul 18 01:26:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 74, 86 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 87, 100 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 101, 114 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/225379833838968832/photo/1",
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/HzOaXyLj",
      "media_url" : "http://pbs.twimg.com/media/AyC1w8fCIAA5sAT.jpg",
      "id_str" : "225379833843163136",
      "id" : 225379833843163136,
      "media_url_https" : "https://pbs.twimg.com/media/AyC1w8fCIAA5sAT.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/HzOaXyLj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225379833838968832",
  "text" : "transition looking sweet for Ironman Placid! So many TT bikes in town too @VTTriathlon @UVMTriathlon @usatriathlon http://t.co/HzOaXyLj",
  "id" : 225379833838968832,
  "created_at" : "Wed Jul 18 00:01:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 51, 58 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 59, 70 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dark",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225347379094761472",
  "text" : "\"just break her spirit, not her body\" -Mr Spisiak. @sspis1 @withane271 #dark",
  "id" : 225347379094761472,
  "created_at" : "Tue Jul 17 21:52:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225346384864358400",
  "text" : "\"The .9 mile segment of the Range Trail btwn Saddleback and Basin Mtns is one of the most difficult in the high peaks.\" -McMartin, easssy",
  "id" : 225346384864358400,
  "created_at" : "Tue Jul 17 21:48:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/225257661573242882/photo/1",
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/YoYow8ra",
      "media_url" : "http://pbs.twimg.com/media/AyBGplWCIAEqq8v.jpg",
      "id_str" : "225257661581631489",
      "id" : 225257661581631489,
      "media_url_https" : "https://pbs.twimg.com/media/AyBGplWCIAEqq8v.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/YoYow8ra"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225257661573242882",
  "text" : "canoeing by Whiteface Mtn today, just checked out some peregrin falcons and wild wolves too http://t.co/YoYow8ra",
  "id" : 225257661573242882,
  "created_at" : "Tue Jul 17 15:56:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tired",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225040795441430528",
  "text" : "its been a wild 24 hours, I'm ready for some sleep! Motorcycle trip and hiking 5 peaks with many adventures #tired",
  "id" : 225040795441430528,
  "created_at" : "Tue Jul 17 01:34:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "man",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224594194541461504",
  "text" : "passed the motorcycle driving and written tests with flying colors! got that fancy M sticker on my license, it stands for #man",
  "id" : 224594194541461504,
  "created_at" : "Sun Jul 15 20:00:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pretendathleteprobz",
      "indices" : [ 116, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224282344683601920",
  "text" : "is it normal to eat a 1.5 cans of beans, a cup of rice, a whole tomato, three wraps, and a jar of salsa for dinner? #pretendathleteprobz",
  "id" : 224282344683601920,
  "created_at" : "Sat Jul 14 23:20:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "summer",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224278685732175874",
  "text" : "front porch w Victory Summer Love and home made burritos (aka taco salad) after a day of riding motorcycles #awesome #summer",
  "id" : 224278685732175874,
  "created_at" : "Sat Jul 14 23:06:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 3, 14 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/olOAOaQ7",
      "expanded_url" : "http://www.200on100.com",
      "display_url" : "200on100.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224244085739884544",
  "text" : "RT @iamtedking: Remember that the hashtag doesn't match the website http://t.co/olOAOaQ7 #200NotOn100 Version 2.0, hope to see you there!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "200NotOn100",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/olOAOaQ7",
        "expanded_url" : "http://www.200on100.com",
        "display_url" : "200on100.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "224235238295994368",
    "text" : "Remember that the hashtag doesn't match the website http://t.co/olOAOaQ7 #200NotOn100 Version 2.0, hope to see you there!",
    "id" : 224235238295994368,
    "created_at" : "Sat Jul 14 20:13:41 +0000 2012",
    "user" : {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "protected" : false,
      "id_str" : "23695888",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2244513395/IMAG0190-1_normal.jpg",
      "id" : 23695888,
      "verified" : false
    }
  },
  "id" : 224244085739884544,
  "created_at" : "Sat Jul 14 20:48:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/224168217520766976/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/sCQpWXzk",
      "media_url" : "http://pbs.twimg.com/media/Axxnzl-CAAAFKN8.jpg",
      "id_str" : "224168217524961280",
      "id" : 224168217524961280,
      "media_url_https" : "https://pbs.twimg.com/media/Axxnzl-CAAAFKN8.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/sCQpWXzk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224168217520766976",
  "text" : "today's two wheels have a motor http://t.co/sCQpWXzk",
  "id" : 224168217520766976,
  "created_at" : "Sat Jul 14 15:47:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224111705293197312",
  "text" : "time to ride!",
  "id" : 224111705293197312,
  "created_at" : "Sat Jul 14 12:02:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tallpeopleprobz",
      "indices" : [ 104, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223956823064064000",
  "text" : "i'm really amazed that motorcycles dont come in different sizes. the engine, sure, but not the frame... #tallpeopleprobz",
  "id" : 223956823064064000,
  "created_at" : "Sat Jul 14 01:47:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 8, 20 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kudos",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/LaCxuZ8m",
      "expanded_url" : "http://www.strava.com/segments/irish-hill-down-1617246",
      "display_url" : "strava.com/segments/irish…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223940553811828736",
  "text" : "game on @bikingbiebs #kudos http://t.co/LaCxuZ8m",
  "id" : 223940553811828736,
  "created_at" : "Sat Jul 14 00:42:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 47, 58 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badassboyfriend",
      "indices" : [ 59, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/pK6YjMNK",
      "expanded_url" : "http://yfrog.com/es56970204j",
      "display_url" : "yfrog.com/es56970204j"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223900831043424257",
  "text" : "RT @sspis1: http://t.co/pK6YjMNK shopping with @andyreagan #badassboyfriend",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 35, 46 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badassboyfriend",
        "indices" : [ 47, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/pK6YjMNK",
        "expanded_url" : "http://yfrog.com/es56970204j",
        "display_url" : "yfrog.com/es56970204j"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223884039122206721",
    "text" : "http://t.co/pK6YjMNK shopping with @andyreagan #badassboyfriend",
    "id" : 223884039122206721,
    "created_at" : "Fri Jul 13 20:58:09 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 223900831043424257,
  "created_at" : "Fri Jul 13 22:04:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justlikehighschool",
      "indices" : [ 57, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223899837421199360",
  "text" : "begin motorcycle course, watching a movie on a little tv #justlikehighschool",
  "id" : 223899837421199360,
  "created_at" : "Fri Jul 13 22:00:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/223850385796898819/photo/1",
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/z6Umkdog",
      "media_url" : "http://pbs.twimg.com/media/AxtGvWjCIAEFt8m.png",
      "id_str" : "223850385805287425",
      "id" : 223850385805287425,
      "media_url_https" : "https://pbs.twimg.com/media/AxtGvWjCIAEFt8m.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/z6Umkdog"
    } ],
    "hashtags" : [ {
      "text" : "maths",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223850385796898819",
  "text" : "is that what Mathematical Analysis looks like? Theorems labeled from \"baby\" Rudin, graphed in Gephi #maths http://t.co/z6Umkdog",
  "id" : 223850385796898819,
  "created_at" : "Fri Jul 13 18:44:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223598769256673280",
  "geo" : {
  },
  "id_str" : "223849826163499008",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e that was the before picture :P",
  "id" : 223849826163499008,
  "in_reply_to_status_id" : 223598769256673280,
  "created_at" : "Fri Jul 13 18:42:12 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 37, 44 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 46, 57 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alwaysfun",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "studmuffin",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/yD8mFCyv",
      "expanded_url" : "http://twitter.com/sspis1/status/223584242414784512/photo/1",
      "display_url" : "pic.twitter.com/yD8mFCyv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223584802228539392",
  "text" : "playing with power tools #alwaysfun \"@sspis1: @andyreagan #studmuffin http://t.co/yD8mFCyv\"",
  "id" : 223584802228539392,
  "created_at" : "Fri Jul 13 01:09:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 22, 29 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 32, 43 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lowerears",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/KHY77baP",
      "expanded_url" : "http://twitter.com/sspis1/status/223583826260144128/photo/1",
      "display_url" : "pic.twitter.com/KHY77baP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223584654651953152",
  "text" : "never been so scared \"@sspis1: .@andyreagan trusted me with scissor and a razor today #lowerears http://t.co/KHY77baP\"",
  "id" : 223584654651953152,
  "created_at" : "Fri Jul 13 01:08:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/2qXBPhgf",
      "expanded_url" : "http://burlington.craigslist.org/mcy/3123891845.html",
      "display_url" : "burlington.craigslist.org/mcy/3123891845…"
    }, {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/eseleaa5",
      "expanded_url" : "http://burlington.craigslist.org/boa/3072116460.html",
      "display_url" : "burlington.craigslist.org/boa/3072116460…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223199866304733184",
  "text" : "headed out on a run. things I hope to find for free: http://t.co/2qXBPhgf http://t.co/eseleaa5",
  "id" : 223199866304733184,
  "created_at" : "Wed Jul 11 23:39:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yummm",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/6tIeY7H9",
      "expanded_url" : "http://yfrog.com/khyzknjmj",
      "display_url" : "yfrog.com/khyzknjmj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223198768114319362",
  "text" : "RT @sspis1: http://t.co/6tIeY7H9 avacado dip for lunch! #yummm",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yummm",
        "indices" : [ 44, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/6tIeY7H9",
        "expanded_url" : "http://yfrog.com/khyzknjmj",
        "display_url" : "yfrog.com/khyzknjmj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223119954071912451",
    "text" : "http://t.co/6tIeY7H9 avacado dip for lunch! #yummm",
    "id" : 223119954071912451,
    "created_at" : "Wed Jul 11 18:21:57 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 223198768114319362,
  "created_at" : "Wed Jul 11 23:35:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biking",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223118872700657664",
  "text" : "passed about 100 cars doing errands today #biking",
  "id" : 223118872700657664,
  "created_at" : "Wed Jul 11 18:17:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningtofilletbraze",
      "indices" : [ 99, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223111546077843458",
  "text" : "found the Advanced Welding Institute in So Burlington while riding by...had to go in, it's awesome #learningtofilletbraze",
  "id" : 223111546077843458,
  "created_at" : "Wed Jul 11 17:48:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222519485351989248",
  "text" : "back in the #btv",
  "id" : 222519485351989248,
  "created_at" : "Tue Jul 10 02:35:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 33, 40 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 41, 48 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222382248907902978",
  "text" : "at best, america walks on dunkin @sspis1 @DZdan1",
  "id" : 222382248907902978,
  "created_at" : "Mon Jul 09 17:30:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 27, 38 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 43, 50 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222370102258044929",
  "text" : "RT @DZdan1: Disc golf with @andyreagan and @sspis1 before they head back to Burlington.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 15, 26 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 31, 38 ],
        "id_str" : "282847130",
        "id" : 282847130
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222315352489590784",
    "text" : "Disc golf with @andyreagan and @sspis1 before they head back to Burlington.",
    "id" : 222315352489590784,
    "created_at" : "Mon Jul 09 13:04:45 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 222370102258044929,
  "created_at" : "Mon Jul 09 16:42:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 21, 32 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 72, 79 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 84, 95 ],
      "id_str" : "40995810",
      "id" : 40995810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222363925994418178",
  "text" : "RT @DZdan1: Defeated @andyreagan by two strokes on the day. Lunch w him @sspis1 and @anasemanas before I leave for North Carolina tonight.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 9, 20 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 60, 67 ],
        "id_str" : "282847130",
        "id" : 282847130
      }, {
        "name" : "Hannah Weeks",
        "screen_name" : "anasemanas",
        "indices" : [ 72, 83 ],
        "id_str" : "40995810",
        "id" : 40995810
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222362096791322624",
    "text" : "Defeated @andyreagan by two strokes on the day. Lunch w him @sspis1 and @anasemanas before I leave for North Carolina tonight.",
    "id" : 222362096791322624,
    "created_at" : "Mon Jul 09 16:10:29 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 222363925994418178,
  "created_at" : "Mon Jul 09 16:17:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 3, 12 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 47, 58 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 59, 70 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 75, 82 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "VulcanogoBoom",
      "screen_name" : "vulcanogoboom",
      "indices" : [ 84, 98 ],
      "id_str" : "495562928",
      "id" : 495562928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cannolis",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222111081806569472",
  "text" : "RT @DKnick88: Ready to crush some tenders with @andyreagan @skholden17 and @sspis1. @vulcanogoboom is certainly missing out #cannolis",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 33, 44 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Sarah Holden",
        "screen_name" : "skholden17",
        "indices" : [ 45, 56 ],
        "id_str" : "214582389",
        "id" : 214582389
      }, {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 61, 68 ],
        "id_str" : "282847130",
        "id" : 282847130
      }, {
        "name" : "VulcanogoBoom",
        "screen_name" : "vulcanogoboom",
        "indices" : [ 70, 84 ],
        "id_str" : "495562928",
        "id" : 495562928
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cannolis",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "222110243088371712",
    "text" : "Ready to crush some tenders with @andyreagan @skholden17 and @sspis1. @vulcanogoboom is certainly missing out #cannolis",
    "id" : 222110243088371712,
    "created_at" : "Sun Jul 08 23:29:43 +0000 2012",
    "user" : {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "protected" : false,
      "id_str" : "204631321",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3194859210/2cfdf039ddb963cafa9970cf96a5b8d2_normal.jpeg",
      "id" : 204631321,
      "verified" : false
    }
  },
  "id" : 222111081806569472,
  "created_at" : "Sun Jul 08 23:33:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 20, 29 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221980066463232000",
  "text" : "an awesome race for @dmreagan, crushin a 7:40 mile after ditching me a few miles in!",
  "id" : 221980066463232000,
  "created_at" : "Sun Jul 08 14:52:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 1, 10 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/221963567820320768/photo/1",
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/SLZYxlQm",
      "media_url" : "http://pbs.twimg.com/media/AxSSsF0CMAEFa1D.jpg",
      "id_str" : "221963567820320769",
      "id" : 221963567820320769,
      "media_url_https" : "https://pbs.twimg.com/media/AxSSsF0CMAEFa1D.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/SLZYxlQm"
    } ],
    "hashtags" : [ {
      "text" : "boilermaker",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221963567820320768",
  "text" : ".@dmreagan is ready to run the #boilermaker http://t.co/SLZYxlQm",
  "id" : 221963567820320768,
  "created_at" : "Sun Jul 08 13:46:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221913444981555200",
  "geo" : {
  },
  "id_str" : "221919943686488064",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 have fun!!",
  "id" : 221919943686488064,
  "in_reply_to_status_id" : 221913444981555200,
  "created_at" : "Sun Jul 08 10:53:32 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 19, 28 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boilermaker",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221899685831507969",
  "text" : "up at 4:30 to take @dmreagan to the #boilermaker, somebody must love their Mom",
  "id" : 221899685831507969,
  "created_at" : "Sun Jul 08 09:33:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 53, 69 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 88, 97 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 102, 109 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drivewayballin",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221784839618179073",
  "text" : "it was a narrow win in 2v2 basketball for myself and @RumblinStumblin versus the duo of @dmreagan and @sspis1 #drivewayballin",
  "id" : 221784839618179073,
  "created_at" : "Sun Jul 08 01:56:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 23, 30 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 31, 42 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 43, 59 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 60, 69 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatlocalbeer",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221745520467652608",
  "text" : "at Empire Brewery with @sspis1 @kreagannet @RumblinStumblin @dmreagan #greatlocalbeer",
  "id" : 221745520467652608,
  "created_at" : "Sat Jul 07 23:20:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan",
      "screen_name" : "dan",
      "indices" : [ 15, 19 ],
      "id_str" : "61",
      "id" : 61
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 55, 66 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 67, 78 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 79, 88 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 89, 96 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtimes",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221443243139792896",
  "text" : "RT @sspis1: RT @Dan Zdanowski Cookout and yard games w @skholden17 @andyreagan @DKnick88 @sspis1 #goodtimes",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.htc.com\" rel=\"nofollow\">  HTC Peep</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan",
        "screen_name" : "dan",
        "indices" : [ 3, 7 ],
        "id_str" : "61",
        "id" : 61
      }, {
        "name" : "Sarah Holden",
        "screen_name" : "skholden17",
        "indices" : [ 43, 54 ],
        "id_str" : "214582389",
        "id" : 214582389
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 55, 66 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 67, 76 ],
        "id_str" : "204631321",
        "id" : 204631321
      }, {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 77, 84 ],
        "id_str" : "282847130",
        "id" : 282847130
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "goodtimes",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221420508762214403",
    "text" : "RT @Dan Zdanowski Cookout and yard games w @skholden17 @andyreagan @DKnick88 @sspis1 #goodtimes",
    "id" : 221420508762214403,
    "created_at" : "Sat Jul 07 01:48:57 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 221443243139792896,
  "created_at" : "Sat Jul 07 03:19:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 51, 58 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221291782057627648",
  "text" : "while driving... \"is that a skunk or your socks?\" -@sspis1 \"honestly, i'm not sure\" -me",
  "id" : 221291782057627648,
  "created_at" : "Fri Jul 06 17:17:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arturo Gómez Rubio",
      "screen_name" : "ArtGomezRubio",
      "indices" : [ 0, 14 ],
      "id_str" : "458170958",
      "id" : 458170958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221061776484208641",
  "geo" : {
  },
  "id_str" : "221093328157016065",
  "in_reply_to_user_id" : 458170958,
  "text" : "@ArtGomezRubio good work! wetsuits make it easy or i'd be at the bottom of a lake as well",
  "id" : 221093328157016065,
  "in_reply_to_status_id" : 221061776484208641,
  "created_at" : "Fri Jul 06 04:08:51 +0000 2012",
  "in_reply_to_screen_name" : "ArtGomezRubio",
  "in_reply_to_user_id_str" : "458170958",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Glatt",
      "screen_name" : "Doug_Glatt_69",
      "indices" : [ 3, 17 ],
      "id_str" : "543087600",
      "id" : 543087600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221091946343563266",
  "text" : "RT @Doug_Glatt_69: Retweet this with your elbow. (No cheating!)",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221077839930335232",
    "text" : "Retweet this with your elbow. (No cheating!)",
    "id" : 221077839930335232,
    "created_at" : "Fri Jul 06 03:07:19 +0000 2012",
    "user" : {
      "name" : "Doug Glatt",
      "screen_name" : "Doug_Glatt_69",
      "protected" : false,
      "id_str" : "543087600",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3225542253/1c3166d2aa8b56f5b0d4bb903497fd98_normal.jpeg",
      "id" : 543087600,
      "verified" : false
    }
  },
  "id" : 221091946343563266,
  "created_at" : "Fri Jul 06 04:03:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IRONIC",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221091755532107776",
  "text" : "drive-in movie theater remind us between movies to \"do our part to keep the environment clean\" and \"preserve our natural resources\" #IRONIC",
  "id" : 221091755532107776,
  "created_at" : "Fri Jul 06 04:02:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 26, 37 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Alyssa Cavallari ",
      "screen_name" : "aacavallari",
      "indices" : [ 38, 50 ],
      "id_str" : "268043555",
      "id" : 268043555
    }, {
      "name" : "Jess R",
      "screen_name" : "JessRunk",
      "indices" : [ 55, 64 ],
      "id_str" : "584170070",
      "id" : 584170070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221072220154380288",
  "text" : "RT @sspis1: Drive in with @andyreagan @aacavallari and @jessrunk",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 14, 25 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Alyssa Cavallari ",
        "screen_name" : "aacavallari",
        "indices" : [ 26, 38 ],
        "id_str" : "268043555",
        "id" : 268043555
      }, {
        "name" : "Jess R",
        "screen_name" : "JessRunk",
        "indices" : [ 43, 52 ],
        "id_str" : "584170070",
        "id" : 584170070
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221053017150066688",
    "text" : "Drive in with @andyreagan @aacavallari and @jessrunk",
    "id" : 221053017150066688,
    "created_at" : "Fri Jul 06 01:28:40 +0000 2012",
    "user" : {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "protected" : false,
      "id_str" : "282847130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2857158536/1da8f1e797d884a5008e75009c0f8668_normal.jpeg",
      "id" : 282847130,
      "verified" : false
    }
  },
  "id" : 221072220154380288,
  "created_at" : "Fri Jul 06 02:44:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 35, 46 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221051465362440193",
  "text" : "and after an excellent dinner from @withane271, and a run w Molly, we're at the drive in's!!",
  "id" : 221051465362440193,
  "created_at" : "Fri Jul 06 01:22:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "easydays",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221044745907089409",
  "text" : "went for par at the Chestnut Ridge disc golf, from the blue tee's (so expert) on the back 9! #easydays",
  "id" : 221044745907089409,
  "created_at" : "Fri Jul 06 00:55:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/220604669825781760/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/TLR2GXdk",
      "media_url" : "http://pbs.twimg.com/media/Aw--x0UCEAAqQLJ.jpg",
      "id_str" : "220604669829976064",
      "id" : 220604669829976064,
      "media_url_https" : "https://pbs.twimg.com/media/Aw--x0UCEAAqQLJ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/TLR2GXdk"
    } ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.7666605833, -78.6297445333 ]
  },
  "id_str" : "220604669825781760",
  "text" : "disc golf with the red, white and blue discs today #america http://t.co/TLR2GXdk",
  "id" : 220604669825781760,
  "created_at" : "Wed Jul 04 19:47:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/VbW8PSnl",
      "expanded_url" : "http://bit.ly/OpcXy4",
      "display_url" : "bit.ly/OpcXy4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220565999882215424",
  "text" : "a look at the whole trip: 500+ miles, 16,000 calories, 22,000ft of climbing http://t.co/VbW8PSnl",
  "id" : 220565999882215424,
  "created_at" : "Wed Jul 04 17:13:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 109, 116 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220538073312804864",
  "text" : "Dave Matthews was great last night, and sleeping in today was almost as good! Relaxing 'Merica style today w @sspis1",
  "id" : 220538073312804864,
  "created_at" : "Wed Jul 04 15:22:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220338317433110528",
  "geo" : {
  },
  "id_str" : "220537723755311105",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy thanks!! concert was great!",
  "id" : 220537723755311105,
  "in_reply_to_status_id" : 220338317433110528,
  "created_at" : "Wed Jul 04 15:21:05 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220279389814927360",
  "geo" : {
  },
  "id_str" : "220537674556121088",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser thanks!! twas great indeed",
  "id" : 220537674556121088,
  "in_reply_to_status_id" : 220279389814927360,
  "created_at" : "Wed Jul 04 15:20:53 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 15, 22 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Ashley Martin",
      "screen_name" : "AshleyMartin00",
      "indices" : [ 23, 38 ],
      "id_str" : "277595810",
      "id" : 277595810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dmb",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "dmb",
      "indices" : [ 5, 9 ]
    }, {
      "text" : "dmb",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220309563155558400",
  "text" : "#dmb #dmb #dmb @sspis1 @ashleymartin00",
  "id" : 220309563155558400,
  "created_at" : "Wed Jul 04 00:14:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dmb",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9269261167, -78.3785807167 ]
  },
  "id_str" : "220295282120867843",
  "text" : "Brenda Carlyle (sp?) on stage! #dmb Beginning of a perfect capstone to a long journey!",
  "id" : 220295282120867843,
  "created_at" : "Tue Jul 03 23:17:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220274057659154432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.94573825, -78.4851110333 ]
  },
  "id_str" : "220274259447123968",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 I'm here too!! Lawn seats?",
  "id" : 220274259447123968,
  "in_reply_to_status_id" : 220274057659154432,
  "created_at" : "Tue Jul 03 21:54:10 +0000 2012",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 22, 29 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9416779333, -78.5104443333 ]
  },
  "id_str" : "220273968580542464",
  "text" : "arrived at la casa de @sspis1, headed to see some DMB action at Darien Lake now!",
  "id" : 220273968580542464,
  "created_at" : "Tue Jul 03 21:53:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 29, 42 ],
      "id_str" : "285218603",
      "id" : 285218603
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 43, 50 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Samantha Wheeler",
      "screen_name" : "samwheel6",
      "indices" : [ 51, 61 ],
      "id_str" : "472332315",
      "id" : 472332315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.21462325, -77.9395904 ]
  },
  "id_str" : "220162615031238656",
  "text" : "at the USA Brockport Diner w @EStoeckeler4 @sspis1 @samwheel6 before finishing our biking adventure",
  "id" : 220162615031238656,
  "created_at" : "Tue Jul 03 14:30:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabi Roozee",
      "screen_name" : "surfingabi",
      "indices" : [ 0, 11 ],
      "id_str" : "72438398",
      "id" : 72438398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https://t.co/qEE35RXT",
      "expanded_url" : "https://mobile.twitter.com/andyreagan/status/219934722598502400",
      "display_url" : "mobile.twitter.com/andyreagan/sta…"
    } ]
  },
  "in_reply_to_status_id_str" : "219933540027088896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2082835167, -77.9435638 ]
  },
  "id_str" : "219942603775418369",
  "in_reply_to_user_id" : 72438398,
  "text" : "@surfingabi yes https://t.co/qEE35RXT",
  "id" : 219942603775418369,
  "in_reply_to_status_id" : 219933540027088896,
  "created_at" : "Mon Jul 02 23:56:17 +0000 2012",
  "in_reply_to_screen_name" : "surfingabi",
  "in_reply_to_user_id_str" : "72438398",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 0, 13 ],
      "id_str" : "285218603",
      "id" : 285218603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2085091667, -77.9436216333 ]
  },
  "id_str" : "219937971330228225",
  "in_reply_to_user_id" : 285218603,
  "text" : "@EStoeckeler4 brooklyn brewery (either lager or summer)",
  "id" : 219937971330228225,
  "created_at" : "Mon Jul 02 23:37:53 +0000 2012",
  "in_reply_to_screen_name" : "EStoeckeler4",
  "in_reply_to_user_id_str" : "285218603",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/219934722598502400/photo/1",
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/I3JbODBR",
      "media_url" : "http://pbs.twimg.com/media/Aw1ddwaCAAAJkek.jpg",
      "id_str" : "219934722602696704",
      "id" : 219934722602696704,
      "media_url_https" : "https://pbs.twimg.com/media/Aw1ddwaCAAAJkek.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/I3JbODBR"
    } ],
    "hashtags" : [ {
      "text" : "recovery",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2084621667, -77.9433631 ]
  },
  "id_str" : "219934722598502400",
  "text" : "#recovery http://t.co/I3JbODBR",
  "id" : 219934722598502400,
  "created_at" : "Mon Jul 02 23:25:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 45, 52 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boss",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "champstatus",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.20853815, -77.9433427667 ]
  },
  "id_str" : "219933143103307777",
  "text" : "arrived in Brockport NY, 103.7 miles marking @sspis1's first century #boss #champstatus",
  "id" : 219933143103307777,
  "created_at" : "Mon Jul 02 23:18:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Stoeckeler",
      "screen_name" : "EStoeckeler4",
      "indices" : [ 16, 29 ],
      "id_str" : "285218603",
      "id" : 285218603
    }, {
      "name" : "Scott Harrington",
      "screen_name" : "S_W_Harrington",
      "indices" : [ 31, 46 ],
      "id_str" : "127541935",
      "id" : 127541935
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 48, 59 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 66, 73 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ftw",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http://t.co/0qk4yIEO",
      "expanded_url" : "http://twitter.com/EStoeckeler4/status/219931333005291520/photo/1",
      "display_url" : "pic.twitter.com/0qk4yIEO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2085844833, -77.9434042 ]
  },
  "id_str" : "219932962161041408",
  "text" : "tan lines #ftw \"@EStoeckeler4: @S_W_Harrington, @andyreagan &amp; @sspis1 biked 450ish miles here, drive 30 and come hang http://t.co/0qk4yIEO\"",
  "id" : 219932962161041408,
  "created_at" : "Mon Jul 02 23:17:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 36, 46 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/219890065608949760/photo/1",
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/4gsyn6hO",
      "media_url" : "http://pbs.twimg.com/media/Aw002YKCQAAf_dj.jpg",
      "id_str" : "219890065613144064",
      "id" : 219890065613144064,
      "media_url_https" : "https://pbs.twimg.com/media/Aw002YKCQAAf_dj.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/4gsyn6hO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.1870498333, -77.7471073167 ]
  },
  "id_str" : "219890065608949760",
  "text" : "86 miles in. cars use gas for fuel, @bikebuild moves with these http://t.co/4gsyn6hO",
  "id" : 219890065608949760,
  "created_at" : "Mon Jul 02 20:27:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/219778058176036865/photo/1",
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/JdaJmsQC",
      "media_url" : "http://pbs.twimg.com/media/AwzO-r-CAAEZjVj.jpg",
      "id_str" : "219778058184425473",
      "id" : 219778058184425473,
      "media_url_https" : "https://pbs.twimg.com/media/AwzO-r-CAAEZjVj.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/JdaJmsQC"
    } ],
    "hashtags" : [ {
      "text" : "pretty",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.3106856667, -76.7129032167 ]
  },
  "id_str" : "219778058176036865",
  "text" : "wait, is this upstate NY? #pretty (mile 26 of 115!) http://t.co/JdaJmsQC",
  "id" : 219778058176036865,
  "created_at" : "Mon Jul 02 13:02:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 32, 39 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 44, 55 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burlingtontobuffalo",
      "indices" : [ 89, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219593250309279744",
  "text" : "RT @DZdan1: Took the day to see @sspis1 and @andyreagan on their bike trip through cuse. #burlingtontobuffalo",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 20, 27 ],
        "id_str" : "282847130",
        "id" : 282847130
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 32, 43 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "burlingtontobuffalo",
        "indices" : [ 77, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "219557235418865664",
    "text" : "Took the day to see @sspis1 and @andyreagan on their bike trip through cuse. #burlingtontobuffalo",
    "id" : 219557235418865664,
    "created_at" : "Sun Jul 01 22:24:58 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 219593250309279744,
  "created_at" : "Mon Jul 02 00:48:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whoops",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.3679199167, -76.2839925833 ]
  },
  "id_str" : "219477315271393280",
  "text" : "is in Palermo, NY now! Was trying to catch riders in front of me, but there were none apparently #whoops",
  "id" : 219477315271393280,
  "created_at" : "Sun Jul 01 17:07:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.4828528833, -75.3312559667 ]
  },
  "id_str" : "219364693112922112",
  "text" : "its July! Pumpin some of Hans' euro beats at 5am, going to be a good day to ride",
  "id" : 219364693112922112,
  "created_at" : "Sun Jul 01 09:39:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]