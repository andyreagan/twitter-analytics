Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/153165815028514816/photo/1",
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/lzM4Scqu",
      "media_url" : "http://pbs.twimg.com/media/AiAnf0zCAAM-nCh.jpg",
      "id_str" : "153165815032709123",
      "id" : 153165815032709123,
      "media_url_https" : "https://pbs.twimg.com/media/AiAnf0zCAAM-nCh.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/lzM4Scqu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "153165815028514816",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy let me know if you can't read it http://t.co/lzM4Scqu",
  "id" : 153165815028514816,
  "created_at" : "Sat Dec 31 17:29:12 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 18, 27 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152804616420073472",
  "text" : "going for a run w @dmreagan in this warmth! shorts and tech t today! ps how u know ur in good shape: HR strap wont tighten any more ha",
  "id" : 152804616420073472,
  "created_at" : "Fri Dec 30 17:33:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 9, 20 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 38, 47 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 94, 105 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/OUlhXGKo",
      "expanded_url" : "http://4sq.com/tZRrro",
      "display_url" : "4sq.com/tZRrro"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0480471, -76.15458 ]
  },
  "id_str" : "152529385575038977",
  "text" : "dinner w @kreagannet @rumblinstumblim @dmreagan and Carl and Dee (@ Empire Brewing Company w/ @kreagannet) http://t.co/OUlhXGKo",
  "id" : 152529385575038977,
  "created_at" : "Thu Dec 29 23:20:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152501453624324098",
  "text" : "where i believe that the question is rather begin 'how should we live'",
  "id" : 152501453624324098,
  "created_at" : "Thu Dec 29 21:29:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152501335869243393",
  "text" : "\"good carbs, bad carbs\" starts well, but poses the premise 'what should we eat to live a long and healthy life'",
  "id" : 152501335869243393,
  "created_at" : "Thu Dec 29 21:28:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 2, 11 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "lindz",
      "screen_name" : "lindzshark",
      "indices" : [ 12, 23 ],
      "id_str" : "230893616",
      "id" : 230893616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/p8w7wze5",
      "expanded_url" : "http://4sq.com/vd1JBf",
      "display_url" : "4sq.com/vd1JBf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0481438, -76.228938 ]
  },
  "id_str" : "152438849019195392",
  "text" : "w @dknick88 @lindzshark (@ Tully's Good Times) http://t.co/p8w7wze5",
  "id" : 152438849019195392,
  "created_at" : "Thu Dec 29 17:20:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/BysrORkB",
      "expanded_url" : "http://www.medscape.com/viewarticle/438238",
      "display_url" : "medscape.com/viewarticle/43…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "152438326115315713",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT not sure if I ever dug it up for you, but I know I mentioned this study: http://t.co/BysrORkB",
  "id" : 152438326115315713,
  "created_at" : "Thu Dec 29 17:18:23 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 36, 47 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kidding",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152277651732701185",
  "text" : "internet at the house went down, so @kreagannet and I had to actually talk to eachother. was just as bad as it sounds #kidding",
  "id" : 152277651732701185,
  "created_at" : "Thu Dec 29 06:39:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152226815040159744",
  "text" : "an off day at school is 5-10mi of commuting by bicycle. an off day at home... walking down the stairs twice",
  "id" : 152226815040159744,
  "created_at" : "Thu Dec 29 03:17:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 99, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152152956123357184",
  "text" : "while in grad school, 20% of my college loans will be paid for by inflation by the time i graduate #win",
  "id" : 152152956123357184,
  "created_at" : "Wed Dec 28 22:24:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 36, 45 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/152065545791995904/photo/1",
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/eBcvgyZD",
      "media_url" : "http://pbs.twimg.com/media/Ahw-zufCAAAboXJ.jpg",
      "id_str" : "152065545796190208",
      "id" : 152065545796190208,
      "media_url_https" : "https://pbs.twimg.com/media/Ahw-zufCAAAboXJ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/eBcvgyZD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152065545791995904",
  "text" : "awesome late christmas present that @dmreagan almost forgot to give us http://t.co/eBcvgyZD",
  "id" : 152065545791995904,
  "created_at" : "Wed Dec 28 16:37:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "152049544035713024",
  "text" : "cant seem to sleep less than 10 hours this break, but im okay with that",
  "id" : 152049544035713024,
  "created_at" : "Wed Dec 28 15:33:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 55, 62 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "John Schlegel",
      "screen_name" : "jschlegs31",
      "indices" : [ 64, 75 ],
      "id_str" : "248895700",
      "id" : 248895700
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 77, 86 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151892340934590464",
  "geo" : {
  },
  "id_str" : "151893100141355008",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 not at all. a solid performance all around @DZdan1, @jschlegs31, @DKnick88, John and Nadia. was dissappointed only by ur exit",
  "id" : 151893100141355008,
  "in_reply_to_status_id" : 151892340934590464,
  "created_at" : "Wed Dec 28 05:11:51 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151882543866707968",
  "text" : "and team 'wispering eye' finishing w a respectable 50pts after a successful 10pt (max) dbl jeopardy wager correct by yours truly",
  "id" : 151882543866707968,
  "created_at" : "Wed Dec 28 04:29:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151881869644922881",
  "text" : "RT @DZdan1: Other trivia teams awesome names: \"sanduskys shower buddies\" \"our couches pull out but we don't\" \"tittsburg feelers\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "151856595293306881",
    "text" : "Other trivia teams awesome names: \"sanduskys shower buddies\" \"our couches pull out but we don't\" \"tittsburg feelers\"",
    "id" : 151856595293306881,
    "created_at" : "Wed Dec 28 02:46:48 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 151881869644922881,
  "created_at" : "Wed Dec 28 04:27:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151881837956964352",
  "text" : "also among the best names: kim jong is longer ill, jingle balls, certified giants ....and many less appropriate",
  "id" : 151881837956964352,
  "created_at" : "Wed Dec 28 04:27:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151845432669114368",
  "text" : "hit 3 bulls eyes with 3 darts, and balanced a golf ball on top of another golf ball for our bonus points! cell phones away",
  "id" : 151845432669114368,
  "created_at" : "Wed Dec 28 02:02:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 3, 12 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trivianight",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151822595191345152",
  "text" : "RT @DKnick88: Ready to dominate #trivianight",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trivianight",
        "indices" : [ 18, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "151816884071841792",
    "text" : "Ready to dominate #trivianight",
    "id" : 151816884071841792,
    "created_at" : "Wed Dec 28 00:09:00 +0000 2011",
    "user" : {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "protected" : false,
      "id_str" : "204631321",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3194859210/2cfdf039ddb963cafa9970cf96a5b8d2_normal.jpeg",
      "id" : 204631321,
      "verified" : false
    }
  },
  "id" : 151822595191345152,
  "created_at" : "Wed Dec 28 00:31:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 40, 51 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 52, 61 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 62, 73 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "John Schlegel",
      "screen_name" : "jschlegs31",
      "indices" : [ 78, 89 ],
      "id_str" : "248895700",
      "id" : 248895700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreamteam",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151822569786445824",
  "text" : "RT @DZdan1: Headed to trivia night with @andyreagan @DKnick88 @skholden17 and @jschlegs31 #dreamteam",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 28, 39 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 40, 49 ],
        "id_str" : "204631321",
        "id" : 204631321
      }, {
        "name" : "Sarah Holden",
        "screen_name" : "skholden17",
        "indices" : [ 50, 61 ],
        "id_str" : "214582389",
        "id" : 214582389
      }, {
        "name" : "John Schlegel",
        "screen_name" : "jschlegs31",
        "indices" : [ 66, 77 ],
        "id_str" : "248895700",
        "id" : 248895700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dreamteam",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "151808771289657345",
    "text" : "Headed to trivia night with @andyreagan @DKnick88 @skholden17 and @jschlegs31 #dreamteam",
    "id" : 151808771289657345,
    "created_at" : "Tue Dec 27 23:36:46 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 151822569786445824,
  "created_at" : "Wed Dec 28 00:31:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151775335430623232",
  "geo" : {
  },
  "id_str" : "151793534624735232",
  "in_reply_to_user_id" : 254218062,
  "text" : "@ashley_martin00 sweet! pick an action movie and set it up facing the TV. if you're good, pop in COD3 lol",
  "id" : 151793534624735232,
  "in_reply_to_status_id" : 151775335430623232,
  "created_at" : "Tue Dec 27 22:36:13 +0000 2011",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trainertime",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/Xb14azEu",
      "expanded_url" : "http://twitpic.com/7zfnln",
      "display_url" : "twitpic.com/7zfnln"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151762517809561600",
  "text" : "#trainertime is better with blu ray on 1080p bigscreen http://t.co/Xb14azEu",
  "id" : 151762517809561600,
  "created_at" : "Tue Dec 27 20:32:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/YKpx6A2r",
      "expanded_url" : "http://twitpic.com/7zex68",
      "display_url" : "twitpic.com/7zex68"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151745127856087040",
  "text" : "mmmm fresh guac http://t.co/YKpx6A2r",
  "id" : 151745127856087040,
  "created_at" : "Tue Dec 27 19:23:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151688826648141826",
  "geo" : {
  },
  "id_str" : "151712390357073921",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 congrats dude (for real). whats your cum?",
  "id" : 151712390357073921,
  "in_reply_to_status_id" : 151688826648141826,
  "created_at" : "Tue Dec 27 17:13:47 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151520361710764032",
  "geo" : {
  },
  "id_str" : "151521412564267009",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy a convo btwn jill and twitter: 'am i an alchy?' says jill. twitter responds 'sorry'",
  "id" : 151521412564267009,
  "in_reply_to_status_id" : 151520361710764032,
  "created_at" : "Tue Dec 27 04:34:54 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151516913451810817",
  "geo" : {
  },
  "id_str" : "151520706654515202",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr You're welcome, and thanks again for the book! I gotcha covered",
  "id" : 151520706654515202,
  "in_reply_to_status_id" : 151516913451810817,
  "created_at" : "Tue Dec 27 04:32:06 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151415528370614274",
  "geo" : {
  },
  "id_str" : "151428419941441536",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 ok okk haha 10min is at all itll take you for the 5k anyway",
  "id" : 151428419941441536,
  "in_reply_to_status_id" : 151415528370614274,
  "created_at" : "Mon Dec 26 22:25:23 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151414577786142720",
  "geo" : {
  },
  "id_str" : "151428242191040512",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris I'll never forget!",
  "id" : 151428242191040512,
  "in_reply_to_status_id" : 151414577786142720,
  "created_at" : "Mon Dec 26 22:24:40 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151387527486517248",
  "geo" : {
  },
  "id_str" : "151395815066304512",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 good luck!!",
  "id" : 151395815066304512,
  "in_reply_to_status_id" : 151387527486517248,
  "created_at" : "Mon Dec 26 20:15:49 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 61, 72 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/6mqGEfMt",
      "expanded_url" : "http://twitpic.com/7yyt02",
      "display_url" : "twitpic.com/7yyt02"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151371184682975232",
  "text" : "feel weird wearing UVM gear... thanks for the sweatshirt bro @kreagannet http://t.co/6mqGEfMt",
  "id" : 151371184682975232,
  "created_at" : "Mon Dec 26 18:37:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 33, 45 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/B3D0CAJX",
      "expanded_url" : "http://twitpic.com/7yyrxn",
      "display_url" : "twitpic.com/7yyrxn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151370489288331264",
  "text" : "proof of a solid roller workout (@UVM_cycling road season in sight) http://t.co/B3D0CAJX",
  "id" : 151370489288331264,
  "created_at" : "Mon Dec 26 18:35:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 1, 8 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "151165343577014272",
  "text" : ".@dzdan1 merry birthday!!",
  "id" : 151165343577014272,
  "created_at" : "Mon Dec 26 05:00:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https://t.co/OOtFJhHu",
      "expanded_url" : "https://market.android.com/details?id=com.groundspeak.geocaching&hl=en",
      "display_url" : "market.android.com/details?id=com…"
    }, {
      "indices" : [ 54, 75 ],
      "url" : "https://t.co/nPypD0Y2",
      "expanded_url" : "https://market.android.com/details?id=cgeo.geocaching&feature=related_apps#?t=W251bGwsMSwxLDEwOSwiY2dlby5nZW9jYWNoaW5nIl0",
      "display_url" : "market.android.com/details?id=cge…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151163787385372672",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 official one: https://t.co/OOtFJhHu free one: https://t.co/nPypD0Y2.",
  "id" : 151163787385372672,
  "created_at" : "Mon Dec 26 04:53:50 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 8, 19 ],
      "id_str" : "40995810",
      "id" : 40995810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151162385464442880",
  "geo" : {
  },
  "id_str" : "151163683840589824",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @anasemanas sooo cuute you two!",
  "id" : 151163683840589824,
  "in_reply_to_status_id" : 151162385464442880,
  "created_at" : "Mon Dec 26 04:53:25 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 59, 67 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/eIiUzm46",
      "expanded_url" : "http://bit.ly/vuF77u",
      "display_url" : "bit.ly/vuF77u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "151076705203785729",
  "text" : "Christmas Day bike ride! Details: http://t.co/eIiUzm46 via @AddThis",
  "id" : 151076705203785729,
  "created_at" : "Sun Dec 25 23:07:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reaganchristmascomesearly",
      "indices" : [ 95, 121 ]
    }, {
      "text" : "success",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150782296096641024",
  "text" : "per usual, the 'open one gift on Christmas Eve' turned into 'open all the gifts Christmas Eve' #reaganchristmascomesearly #success",
  "id" : 150782296096641024,
  "created_at" : "Sun Dec 25 03:37:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 33, 44 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/ABHnHa5O",
      "expanded_url" : "http://twitpic.com/7y1n5c",
      "display_url" : "twitpic.com/7y1n5c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150750351815999489",
  "text" : "you gotta see this, present from @kreagannet http://t.co/ABHnHa5O",
  "id" : 150750351815999489,
  "created_at" : "Sun Dec 25 01:30:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150721494211756032",
  "geo" : {
  },
  "id_str" : "150722037743226880",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT haha suppose i'll have to add a condition to my statement. only allowable if snow on roads!",
  "id" : 150722037743226880,
  "in_reply_to_status_id" : 150721494211756032,
  "created_at" : "Sat Dec 24 23:38:28 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150681310267060225",
  "text" : "wrapping and delivering Christmas prewsents for my fwends was awesome, free motion rollers 2.0 assembled, and now family Christmas!",
  "id" : 150681310267060225,
  "created_at" : "Sat Dec 24 20:56:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 3, 14 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 38, 49 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150680966522863617",
  "text" : "RT @skholden17: Loved my present from @andyreagan can't wait to start training in it!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 22, 33 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "150639023264763905",
    "text" : "Loved my present from @andyreagan can't wait to start training in it!",
    "id" : 150639023264763905,
    "created_at" : "Sat Dec 24 18:08:36 +0000 2011",
    "user" : {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "protected" : false,
      "id_str" : "214582389",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3122605201/bbe442be6791d79c0b7662898c2dcd57_normal.png",
      "id" : 214582389,
      "verified" : false
    }
  },
  "id" : 150680966522863617,
  "created_at" : "Sat Dec 24 20:55:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 0, 14 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150612779294916608",
  "geo" : {
  },
  "id_str" : "150613545577492481",
  "in_reply_to_user_id" : 26010551,
  "text" : "@Thundercoffer its really cool! enjoy",
  "id" : 150613545577492481,
  "in_reply_to_status_id" : 150612779294916608,
  "created_at" : "Sat Dec 24 16:27:22 +0000 2011",
  "in_reply_to_screen_name" : "Thundercoffer",
  "in_reply_to_user_id_str" : "26010551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150431051842461696",
  "geo" : {
  },
  "id_str" : "150435338496647168",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 nice! which model? start logging some 50mi rides and you'll be really like me haha",
  "id" : 150435338496647168,
  "in_reply_to_status_id" : 150431051842461696,
  "created_at" : "Sat Dec 24 04:39:14 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 29, 38 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reallyhappenedapparently",
      "indices" : [ 79, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150434959444815872",
  "text" : "just met the girls whose car @DKnick88 fell asleep in back in the day downtown #reallyhappenedapparently",
  "id" : 150434959444815872,
  "created_at" : "Sat Dec 24 04:37:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackandtan",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "colemans",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150409026902032384",
  "text" : "#blackandtan #colemans",
  "id" : 150409026902032384,
  "created_at" : "Sat Dec 24 02:54:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NYproblems",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "justwannagoout",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150393434023280642",
  "text" : "ice scraper broke in half its so cold #NYproblems #justwannagoout",
  "id" : 150393434023280642,
  "created_at" : "Sat Dec 24 01:52:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "christmas",
      "indices" : [ 5, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/6aml6raQ",
      "expanded_url" : "http://twitpic.com/7xgceh",
      "display_url" : "twitpic.com/7xgceh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150390074951995393",
  "text" : "mmmm #christmas http://t.co/6aml6raQ",
  "id" : 150390074951995393,
  "created_at" : "Sat Dec 24 01:39:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/OGR1sBqm",
      "expanded_url" : "http://twitpic.com/7xgcc4",
      "display_url" : "twitpic.com/7xgcc4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150390039904391168",
  "text" : "FREE MOTION ROLLERS ARE AWESOME, video coming sonn http://t.co/OGR1sBqm",
  "id" : 150390039904391168,
  "created_at" : "Sat Dec 24 01:39:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/3x96QKhy",
      "expanded_url" : "http://twitpic.com/7xa7nn",
      "display_url" : "twitpic.com/7xa7nn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "150262333497802752",
  "text" : "check out the snowww http://t.co/3x96QKhy",
  "id" : 150262333497802752,
  "created_at" : "Fri Dec 23 17:11:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fingerscrossed",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150262066178035712",
  "text" : "a white christmas possible in SYR! #fingerscrossed",
  "id" : 150262066178035712,
  "created_at" : "Fri Dec 23 17:10:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatread",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "150260777478127617",
  "text" : "just finished reading \"brain rules\" #greatread",
  "id" : 150260777478127617,
  "created_at" : "Fri Dec 23 17:05:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150243248156311552",
  "geo" : {
  },
  "id_str" : "150248815092449280",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT look closely at the surface of the nose of the shuttle, imma be modeling that!",
  "id" : 150248815092449280,
  "in_reply_to_status_id" : 150243248156311552,
  "created_at" : "Fri Dec 23 16:18:03 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149940260258844673",
  "text" : "lets be real, who with 5 fingers on each hand doesnt love power tools",
  "id" : 149940260258844673,
  "created_at" : "Thu Dec 22 19:51:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MOOTS",
      "screen_name" : "MOOTSCYCLES",
      "indices" : [ 0, 12 ],
      "id_str" : "71604171",
      "id" : 71604171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149837062437220352",
  "geo" : {
  },
  "id_str" : "149861398271373312",
  "in_reply_to_user_id" : 71604171,
  "text" : "@MOOTSCYCLES well i'll just have to stay tuned!",
  "id" : 149861398271373312,
  "in_reply_to_status_id" : 149837062437220352,
  "created_at" : "Thu Dec 22 14:38:36 +0000 2011",
  "in_reply_to_screen_name" : "MOOTSCYCLES",
  "in_reply_to_user_id_str" : "71604171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MOOTS",
      "screen_name" : "MOOTSCYCLES",
      "indices" : [ 0, 12 ],
      "id_str" : "71604171",
      "id" : 71604171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149707087386128384",
  "geo" : {
  },
  "id_str" : "149724559266947072",
  "in_reply_to_user_id" : 71604171,
  "text" : "@MOOTSCYCLES I really want a PsychloX w discs and a belt drive, but dont see a frame break as an option. Is it?",
  "id" : 149724559266947072,
  "in_reply_to_status_id" : 149707087386128384,
  "created_at" : "Thu Dec 22 05:34:51 +0000 2011",
  "in_reply_to_screen_name" : "MOOTSCYCLES",
  "in_reply_to_user_id_str" : "71604171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Dear Blank",
      "screen_name" : "dearblankplease",
      "indices" : [ 9, 25 ],
      "id_str" : "154786349",
      "id" : 154786349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/m2F7yQAb",
      "expanded_url" : "http://lil.as/6d2",
      "display_url" : "lil.as/6d2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "149721246454644736",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 \"@dearblankplease: Chemistry nerds: The name's Bond. Ionic Bond. Taken, not shared. Sincerely, you're welcome. http://t.co/m2F7yQAb\"",
  "id" : 149721246454644736,
  "created_at" : "Thu Dec 22 05:21:41 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149681316089180161",
  "geo" : {
  },
  "id_str" : "149683715998621697",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 smoke em out, smoke em out, smoke em out!",
  "id" : 149683715998621697,
  "in_reply_to_status_id" : 149681316089180161,
  "created_at" : "Thu Dec 22 02:52:33 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149683641474228224",
  "text" : "pool at the marcellus village tavern",
  "id" : 149683641474228224,
  "created_at" : "Thu Dec 22 02:52:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 53, 62 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 67, 78 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149640260291264513",
  "text" : "tuna steak and zucchini sticks w @RumblinStumblinand @dmreagan and @kreagannet (the whole fam!)",
  "id" : 149640260291264513,
  "created_at" : "Wed Dec 21 23:59:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james farrell",
      "screen_name" : "jamesfarrell__",
      "indices" : [ 3, 18 ],
      "id_str" : "309741214",
      "id" : 309741214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149598575188381698",
  "text" : "RT @jamesfarrell__: this rain is whack wheres the snow?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "149598187223654400",
    "text" : "this rain is whack wheres the snow?",
    "id" : 149598187223654400,
    "created_at" : "Wed Dec 21 21:12:41 +0000 2011",
    "user" : {
      "name" : "james farrell",
      "screen_name" : "jamesfarrell__",
      "protected" : false,
      "id_str" : "309741214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3090934890/8e90bf5b61feba9eea35ada423db3cf4_normal.jpeg",
      "id" : 309741214,
      "verified" : false
    }
  },
  "id" : 149598575188381698,
  "created_at" : "Wed Dec 21 21:14:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/Ib9xLdF7",
      "expanded_url" : "http://bikeloft.com/site/page.cfm?PageID=37",
      "display_url" : "bikeloft.com/site/page.cfm?…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "149597490293915648",
  "text" : "syracuse's mountain bike trails...aka making me miss Blacksburg: http://t.co/Ib9xLdF7",
  "id" : 149597490293915648,
  "created_at" : "Wed Dec 21 21:09:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 0, 9 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149591594700521472",
  "geo" : {
  },
  "id_str" : "149594643976306688",
  "in_reply_to_user_id" : 23640974,
  "text" : "@jpbeatty yup sure is! they're both on twitter too (ha)",
  "id" : 149594643976306688,
  "in_reply_to_status_id" : 149591594700521472,
  "created_at" : "Wed Dec 21 20:58:37 +0000 2011",
  "in_reply_to_screen_name" : "jpbeatty",
  "in_reply_to_user_id_str" : "23640974",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 17, 24 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149522617420877827",
  "text" : "giving a talk to @DZdan1's high school class on mathematical chaos!",
  "id" : 149522617420877827,
  "created_at" : "Wed Dec 21 16:12:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 0, 11 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149356213463810048",
  "geo" : {
  },
  "id_str" : "149356813886832640",
  "in_reply_to_user_id" : 16353686,
  "text" : "@angryasian agreed! as with helmet-mounted light...perfect to aim right  at car windows!",
  "id" : 149356813886832640,
  "in_reply_to_status_id" : 149356213463810048,
  "created_at" : "Wed Dec 21 05:13:34 +0000 2011",
  "in_reply_to_screen_name" : "angryasian",
  "in_reply_to_user_id_str" : "16353686",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 0, 11 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/gGCsfEtb",
      "expanded_url" : "http://www.amazon.com/Delta-Airzound-Bike-Horn/dp/B000ACAMJC/ref=sr_1_1?ie=UTF8&qid=1324444179&sr=8-1",
      "display_url" : "amazon.com/Delta-Airzound…"
    } ]
  },
  "in_reply_to_status_id_str" : "149354659549675521",
  "geo" : {
  },
  "id_str" : "149355943744909312",
  "in_reply_to_user_id" : 16353686,
  "text" : "@angryasian ever used/heard an Airzound horn? so loud, I'm almost afraid to use mine, and it refills w a bike pump http://t.co/gGCsfEtb",
  "id" : 149355943744909312,
  "in_reply_to_status_id" : 149354659549675521,
  "created_at" : "Wed Dec 21 05:10:06 +0000 2011",
  "in_reply_to_screen_name" : "angryasian",
  "in_reply_to_user_id_str" : "16353686",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excellent",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "proven",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149345645700988928",
  "text" : "chap 1 of brain rules, chaps 1-2 of nonlinear dynamics #excellent lessons to be learned: exercise boosts brain power #proven",
  "id" : 149345645700988928,
  "created_at" : "Wed Dec 21 04:29:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenDUB",
      "screen_name" : "BenDUB",
      "indices" : [ 27, 34 ],
      "id_str" : "18177652",
      "id" : 18177652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/r3pvaXYz",
      "expanded_url" : "http://twitpic.com/7w4gnc",
      "display_url" : "twitpic.com/7w4gnc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "149342223731920896",
  "text" : "\"for the heavy hipsters\" - @BenDUB http://t.co/r3pvaXYz",
  "id" : 149342223731920896,
  "created_at" : "Wed Dec 21 04:15:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 1, 8 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149335689568333824",
  "text" : ".@dzdan1 \"If u wanted to create an edu envir that was directly opposed to what the brain is good at doing, u prob would design a classroom\"",
  "id" : 149335689568333824,
  "created_at" : "Wed Dec 21 03:49:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149313360272441344",
  "text" : "tullys as good as ever. ahh reading about nonlinear dynamics before bed",
  "id" : 149313360272441344,
  "created_at" : "Wed Dec 21 02:20:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149303964670767107",
  "geo" : {
  },
  "id_str" : "149312693558448130",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 no cheating! don't look at anything",
  "id" : 149312693558448130,
  "in_reply_to_status_id" : 149303964670767107,
  "created_at" : "Wed Dec 21 02:18:14 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/whZgQEQd",
      "expanded_url" : "http://twitpic.com/7w08dz",
      "display_url" : "twitpic.com/7w08dz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "149248543050301440",
  "text" : "its starting to look a lot like Christmas (for me) http://t.co/whZgQEQd",
  "id" : 149248543050301440,
  "created_at" : "Tue Dec 20 22:03:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 26, 41 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149248322908065793",
  "text" : "excellent track workout w @ryandelgiudice, I probably wouldnt have braved the cold without him!",
  "id" : 149248322908065793,
  "created_at" : "Tue Dec 20 22:02:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149213189459021824",
  "text" : "and spent the first two days at home reclaiming my room from a storage closet! only here for two wks tho",
  "id" : 149213189459021824,
  "created_at" : "Tue Dec 20 19:42:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woopwoop",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "149213000514011136",
  "text" : "has got a place to live in Burlington #woopwoop",
  "id" : 149213000514011136,
  "created_at" : "Tue Dec 20 19:42:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148908789272281088",
  "geo" : {
  },
  "id_str" : "148982829118791680",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 came out great, thanks! Wish I had measured the ABV, don't think its very strong, I drank till I was full lol and wasn't feeling it",
  "id" : 148982829118791680,
  "in_reply_to_status_id" : 148908789272281088,
  "created_at" : "Tue Dec 20 04:27:29 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148935432137216000",
  "text" : "fillet mignon and homebrewed vanilla porter = perfect",
  "id" : 148935432137216000,
  "created_at" : "Tue Dec 20 01:19:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/CVTMujgm",
      "expanded_url" : "http://twitpic.com/7vltxq",
      "display_url" : "twitpic.com/7vltxq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148906263613407232",
  "text" : "graduation brew tapped!! http://t.co/CVTMujgm",
  "id" : 148906263613407232,
  "created_at" : "Mon Dec 19 23:23:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 35, 44 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148882264632197121",
  "text" : "solid christmas shopping spree for @dmreagan in Skaneateles, with a delicious stop at Doug's fish fry",
  "id" : 148882264632197121,
  "created_at" : "Mon Dec 19 21:47:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 0, 11 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148785295897268224",
  "geo" : {
  },
  "id_str" : "148880891983298560",
  "in_reply_to_user_id" : 55931868,
  "text" : "@andyreagan no worries!",
  "id" : 148880891983298560,
  "in_reply_to_status_id" : 148785295897268224,
  "created_at" : "Mon Dec 19 21:42:25 +0000 2011",
  "in_reply_to_screen_name" : "andyreagan",
  "in_reply_to_user_id_str" : "55931868",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/3PFhcLkd",
      "expanded_url" : "http://twitpic.com/7vi36m",
      "display_url" : "twitpic.com/7vi36m"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148819142303154176",
  "text" : "the best way to fix a bent derailer hanger? http://t.co/3PFhcLkd",
  "id" : 148819142303154176,
  "created_at" : "Mon Dec 19 17:37:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/XqcFCcme",
      "expanded_url" : "http://twitpic.com/7vi1ru",
      "display_url" : "twitpic.com/7vi1ru"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148818270487711745",
  "text" : "new XTR derailer pulleys installed, check out the wear on the old ones http://t.co/XqcFCcme",
  "id" : 148818270487711745,
  "created_at" : "Mon Dec 19 17:33:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 0, 16 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148793432486322176",
  "in_reply_to_user_id" : 226946313,
  "text" : "@BlacksburgStuff it's been real, loved your updates while a student in Blacksburg, but Ive graduated now so ill \"follow ya later\" ha",
  "id" : 148793432486322176,
  "created_at" : "Mon Dec 19 15:54:53 +0000 2011",
  "in_reply_to_screen_name" : "BlacksburgStuff",
  "in_reply_to_user_id_str" : "226946313",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fleet Feet Sports",
      "screen_name" : "FleetFeetSYR",
      "indices" : [ 0, 13 ],
      "id_str" : "21203615",
      "id" : 21203615
    }, {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 35, 49 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148785295897268224",
  "in_reply_to_user_id" : 21203615,
  "text" : "@FleetFeetSYR do you guys have the @brooksrunning pureproject line in yet? none of my LRS's in Blacksburg had them and I'm in Syr now",
  "id" : 148785295897268224,
  "created_at" : "Mon Dec 19 15:22:33 +0000 2011",
  "in_reply_to_screen_name" : "FleetFeetSYR",
  "in_reply_to_user_id_str" : "21203615",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 50, 61 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodlife",
      "indices" : [ 62, 71 ]
    }, {
      "text" : "whataday",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148614485630914560",
  "text" : "unpacked and enjoying a winter lager w the broski @kreagannet #goodlife #whataday",
  "id" : 148614485630914560,
  "created_at" : "Mon Dec 19 04:03:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 120, 129 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/RU3GvwSS",
      "expanded_url" : "http://fuel.ly/102161",
      "display_url" : "fuel.ly/102161"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148573895262339072",
  "text" : "my first logged trip is the worst in awhile \"Check out my Honda Accord performance on Fuelly: http://t.co/RU3GvwSS\" thx @rbsherfy 4 the tip",
  "id" : 148573895262339072,
  "created_at" : "Mon Dec 19 01:22:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148568139620302848",
  "geo" : {
  },
  "id_str" : "148568877150900224",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis if I ran out, I was fully prepared to get my bike out of the back seat and go find gas lol",
  "id" : 148568877150900224,
  "in_reply_to_status_id" : 148568139620302848,
  "created_at" : "Mon Dec 19 01:02:35 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/vDdAMCrX",
      "expanded_url" : "http://twitpic.com/7v7lyb",
      "display_url" : "twitpic.com/7v7lyb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148567532394119169",
  "text" : "that moment when you realize you're on E but there are no exits.... http://t.co/vDdAMCrX",
  "id" : 148567532394119169,
  "created_at" : "Mon Dec 19 00:57:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148526544862711810",
  "text" : "excellent trail run...who ever said that dogs cant keep up? I was the one panting after a few 630s on trails, trying to keep up",
  "id" : 148526544862711810,
  "created_at" : "Sun Dec 18 22:14:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poconolife",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148484388789821440",
  "text" : "moved abt three tons of stones so far, now going for an extended trail run! #poconolife",
  "id" : 148484388789821440,
  "created_at" : "Sun Dec 18 19:26:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148385384819200000",
  "text" : "up early to move stone while the grounds still frozen",
  "id" : 148385384819200000,
  "created_at" : "Sun Dec 18 12:53:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 43, 50 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 55, 64 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148226781286121472",
  "text" : "is at Davids house in the poconos! wishing @DZdan1 and @DKnick88 a safe drive home!",
  "id" : 148226781286121472,
  "created_at" : "Sun Dec 18 02:23:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 24, 33 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148071745499308033",
  "geo" : {
  },
  "id_str" : "148141113897779201",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr hahahaha burn @dmreagan",
  "id" : 148141113897779201,
  "in_reply_to_status_id" : 148071745499308033,
  "created_at" : "Sat Dec 17 20:42:48 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/fX1kSicu",
      "expanded_url" : "http://ht.ly/82rih",
      "display_url" : "ht.ly/82rih"
    } ]
  },
  "geo" : {
  },
  "id_str" : "148140483573596161",
  "text" : "RT @bakadesuyo: Do taller people earn more money because they're actually smarter? http://t.co/fX1kSicu",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http://t.co/fX1kSicu",
        "expanded_url" : "http://ht.ly/82rih",
        "display_url" : "ht.ly/82rih"
      } ]
    },
    "geo" : {
    },
    "id_str" : "148100271338307584",
    "text" : "Do taller people earn more money because they're actually smarter? http://t.co/fX1kSicu",
    "id" : 148100271338307584,
    "created_at" : "Sat Dec 17 18:00:30 +0000 2011",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 148140483573596161,
  "created_at" : "Sat Dec 17 20:40:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 3, 12 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148140360579813376",
  "text" : "RT @dmreagan: home in Marcellus.  Pilot unpacked.  Ready to  tap Andy's graduation brew ans watch some SU bball.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "148128740038279168",
    "text" : "home in Marcellus.  Pilot unpacked.  Ready to  tap Andy's graduation brew ans watch some SU bball.",
    "id" : 148128740038279168,
    "created_at" : "Sat Dec 17 19:53:38 +0000 2011",
    "user" : {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "protected" : true,
      "id_str" : "70117835",
      "profile_image_url_https" : "https://si0.twimg.com/sticky/default_profile_images/default_profile_4_normal.png",
      "id" : 70117835,
      "verified" : false
    }
  },
  "id" : 148140360579813376,
  "created_at" : "Sat Dec 17 20:39:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 19, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "148112377127247872",
  "text" : "BUH BYE BLACKSBURG #fb",
  "id" : 148112377127247872,
  "created_at" : "Sat Dec 17 18:48:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147879568219443200",
  "geo" : {
  },
  "id_str" : "147926563739013120",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy yo so you're still in town? farm run tomorrow AM? maybe drive to bottom, run farm snake beast farm",
  "id" : 147926563739013120,
  "in_reply_to_status_id" : 147879568219443200,
  "created_at" : "Sat Dec 17 06:30:15 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 27, 34 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 39, 48 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147926045943808000",
  "text" : "excellent night downtown w @DZdan1 and @DKnick88!",
  "id" : 147926045943808000,
  "created_at" : "Sat Dec 17 06:28:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147901274711531520",
  "text" : "what if the hokey pokey really is what its all about",
  "id" : 147901274711531520,
  "created_at" : "Sat Dec 17 04:49:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "napsareawesome",
      "indices" : [ 35, 50 ]
    }, {
      "text" : "napsforeveryone",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147812160372883457",
  "text" : "just woke up from a very solid nap #napsareawesome #napsforeveryone",
  "id" : 147812160372883457,
  "created_at" : "Fri Dec 16 22:55:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "graduation",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/0ga2VCb7",
      "expanded_url" : "http://twitpic.com/7u4bpm",
      "display_url" : "twitpic.com/7u4bpm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147746587030986752",
  "text" : "that time!! #graduation http://t.co/0ga2VCb7",
  "id" : 147746587030986752,
  "created_at" : "Fri Dec 16 18:35:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetghosts",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147746560208404481",
  "text" : "and apologies for all these old tweets going out, just hit \"send drafts\" of all the unsent tweets #tweetghosts",
  "id" : 147746560208404481,
  "created_at" : "Fri Dec 16 18:34:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146070390568005632",
  "geo" : {
  },
  "id_str" : "147746413978193922",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 haha ummm sure! you gotta tell me though",
  "id" : 147746413978193922,
  "in_reply_to_status_id" : 146070390568005632,
  "created_at" : "Fri Dec 16 18:34:24 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 50, 64 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veryexcited",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147746408206831616",
  "text" : "great visit to UVM, and it was a pleasure meeting @ChrisDanforth and his students. #veryexcited",
  "id" : 147746408206831616,
  "created_at" : "Fri Dec 16 18:34:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noshavenovember",
      "indices" : [ 16, 32 ]
    }, {
      "text" : "vtmp",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "vtdudeprobs",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147746404243222530",
  "text" : "my beard itches #noshavenovember #vtmp &lt;-- #vtdudeprobs",
  "id" : 147746404243222530,
  "created_at" : "Fri Dec 16 18:34:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/IUDvKcAX",
      "expanded_url" : "http://twitpic.com/7u4bez",
      "display_url" : "twitpic.com/7u4bez"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147746397842702336",
  "text" : "the good life http://t.co/IUDvKcAX",
  "id" : 147746397842702336,
  "created_at" : "Fri Dec 16 18:34:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147746389454098432",
  "text" : "is graduated!!!",
  "id" : 147746389454098432,
  "created_at" : "Fri Dec 16 18:34:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 31, 47 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D2",
      "indices" : [ 4, 7 ]
    }, {
      "text" : "McGangbang",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/iXdUsMKy",
      "expanded_url" : "http://twitpic.com/7u4bau",
      "display_url" : "twitpic.com/7u4bau"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147746330826129409",
  "text" : "the #D2 #McGangbang done right @jacobnandersson http://t.co/iXdUsMKy",
  "id" : 147746330826129409,
  "created_at" : "Fri Dec 16 18:34:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147702137344892929",
  "text" : "40deg and extremely windy on top of Wisp, time to attempt to warm up on the bike!",
  "id" : 147702137344892929,
  "created_at" : "Fri Dec 16 15:38:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 79, 84 ]
    }, {
      "text" : "closecall",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147702128637521921",
  "text" : "missed the signup for the Chili Challenge...but theyre still lettin me do it!! #phew #closecall",
  "id" : 147702128637521921,
  "created_at" : "Fri Dec 16 15:38:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147690314969255936",
  "geo" : {
  },
  "id_str" : "147692996194861056",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e thanks :)",
  "id" : 147692996194861056,
  "in_reply_to_status_id" : 147690314969255936,
  "created_at" : "Fri Dec 16 15:02:08 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 39, 46 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 51, 60 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147591743695622144",
  "text" : "quality porch chillin and catchin up w @DZdan1 and @DKnick88...they're in #blacksburg!!! Graduation in t-minus 7hrs",
  "id" : 147591743695622144,
  "created_at" : "Fri Dec 16 08:19:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 50, 59 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/MXHuIWac",
      "expanded_url" : "http://twitpic.com/7tvqvl",
      "display_url" : "twitpic.com/7tvqvl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147545111717359616",
  "text" : "hammering metal poles is definitely therapeutic ( @slpagsVT ) http://t.co/MXHuIWac",
  "id" : 147545111717359616,
  "created_at" : "Fri Dec 16 05:14:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147522887413276672",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy did you ever find a belt drive cross SS? I want a BD, IGH, Disc Brake cross bike for a new commuter + self grad present lol",
  "id" : 147522887413276672,
  "created_at" : "Fri Dec 16 03:46:11 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147499390771269632",
  "text" : "got my UVM email all set up! feeling official... hit me up andrew dot reagan at uvm dot edu",
  "id" : 147499390771269632,
  "created_at" : "Fri Dec 16 02:12:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 0, 11 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147497194600140800",
  "geo" : {
  },
  "id_str" : "147497913067642882",
  "in_reply_to_user_id" : 15408193,
  "text" : "@fatcyclist 51",
  "id" : 147497913067642882,
  "in_reply_to_status_id" : 147497194600140800,
  "created_at" : "Fri Dec 16 02:06:57 +0000 2011",
  "in_reply_to_screen_name" : "fatcyclist",
  "in_reply_to_user_id_str" : "15408193",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 3, 19 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 55, 64 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 65, 76 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147495696247963649",
  "text" : "RT @RumblinStumblin excellent dinner @ the inn at VT w @dmreagan @andyreagan and Jean the night before he graduates tomorrow!",
  "id" : 147495696247963649,
  "created_at" : "Fri Dec 16 01:58:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Men's Humor",
      "screen_name" : "MensHumor",
      "indices" : [ 15, 25 ],
      "id_str" : "355741893",
      "id" : 355741893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyLastWordsWillBe",
      "indices" : [ 27, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147417514060685313",
  "text" : "true story... \"@MensHumor: #MyLastWordsWillBe \"Don't worry guys, I've done this a thousand times!\"\"",
  "id" : 147417514060685313,
  "created_at" : "Thu Dec 15 20:47:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 11, 18 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 77, 88 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147415303310155776",
  "text" : "woooo!! RT @dzdan1 Road trip destination Blacksburg VA. On 81 almost to bing @andyreagan",
  "id" : 147415303310155776,
  "created_at" : "Thu Dec 15 20:38:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 3, 12 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 14, 25 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147414069115236355",
  "text" : "RT @vmhilljr: @andyreagan The skies are crying!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "147413656219553793",
    "geo" : {
    },
    "id_str" : "147413918686511105",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan The skies are crying!",
    "id" : 147413918686511105,
    "in_reply_to_status_id" : 147413656219553793,
    "created_at" : "Thu Dec 15 20:33:11 +0000 2011",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "protected" : false,
      "id_str" : "104673361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1681278155/wally_normal.jpg",
      "id" : 104673361,
      "verified" : false
    }
  },
  "id" : 147414069115236355,
  "created_at" : "Thu Dec 15 20:33:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147413656219553793",
  "text" : "is totally packed up. really though what the heck blacksburg...gorgeous and sunny to cold and raining in 10min",
  "id" : 147413656219553793,
  "created_at" : "Thu Dec 15 20:32:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147357630623522816",
  "text" : "amazing morning run w the gang!",
  "id" : 147357630623522816,
  "created_at" : "Thu Dec 15 16:49:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldladies",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147138815822278656",
  "text" : "graduation party awesome. playing bingo at the bar #oldladies",
  "id" : 147138815822278656,
  "created_at" : "Thu Dec 15 02:20:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "147037420964159488",
  "text" : "unbelieveable out right now, sunny and warm on Dec 14...the cornhole and drinking have begun!!",
  "id" : 147037420964159488,
  "created_at" : "Wed Dec 14 19:37:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147009821420433408",
  "geo" : {
  },
  "id_str" : "147020841014665216",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis even better, re-use! these guys are destined for homebrew",
  "id" : 147020841014665216,
  "in_reply_to_status_id" : 147009821420433408,
  "created_at" : "Wed Dec 14 18:31:14 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/6ptdKyn5",
      "expanded_url" : "http://twitpic.com/7t984d",
      "display_url" : "twitpic.com/7t984d"
    } ]
  },
  "geo" : {
  },
  "id_str" : "147006134367166464",
  "text" : "an average night, ya know http://t.co/6ptdKyn5",
  "id" : 147006134367166464,
  "created_at" : "Wed Dec 14 17:32:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aboutthattime",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146986030065651712",
  "text" : "just got my cap and gown #aboutthattime",
  "id" : 146986030065651712,
  "created_at" : "Wed Dec 14 16:12:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/oB8CbTnW",
      "expanded_url" : "http://twitpic.com/7t6224",
      "display_url" : "twitpic.com/7t6224"
    } ]
  },
  "geo" : {
  },
  "id_str" : "146985813199171584",
  "text" : "most of my things packed and ready to send home with David! http://t.co/oB8CbTnW",
  "id" : 146985813199171584,
  "created_at" : "Wed Dec 14 16:12:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "psycho",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146753589828796416",
  "geo" : {
  },
  "id_str" : "146839634306019328",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy who the hell is this girl lol? #wtf #psycho",
  "id" : 146839634306019328,
  "in_reply_to_status_id" : 146753589828796416,
  "created_at" : "Wed Dec 14 06:31:11 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146838951817256960",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 technology has failed us... (my phone suddenly thought, and has continued 2 think despite resets, there is no signal in bburg)",
  "id" : 146838951817256960,
  "created_at" : "Wed Dec 14 06:28:28 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146732321310113793",
  "text" : "at Bull n Bones w mis padres!",
  "id" : 146732321310113793,
  "created_at" : "Tue Dec 13 23:24:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 1, 17 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 22, 31 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "sosoexcited",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146699571945414656",
  "text" : ".@RumblinStumblin and @dmreagan are almost to #blacksburg?! #sosoexcited",
  "id" : 146699571945414656,
  "created_at" : "Tue Dec 13 21:14:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnabedifferentnow",
      "indices" : [ 52, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146695304186560515",
  "text" : "annnnd my paper is submitted. GOODBYE UNDERGRADUATE #gonnabedifferentnow",
  "id" : 146695304186560515,
  "created_at" : "Tue Dec 13 20:57:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146669687210651648",
  "geo" : {
  },
  "id_str" : "146695047042174977",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy no dude but it look awesome, that's what I do already!",
  "id" : 146695047042174977,
  "in_reply_to_status_id" : 146669687210651648,
  "created_at" : "Tue Dec 13 20:56:39 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "almostdone",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146633984644890625",
  "text" : "turning in my algebra final, very nearly complete...one paper left! #almostdone",
  "id" : 146633984644890625,
  "created_at" : "Tue Dec 13 16:54:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146623507458035713",
  "text" : "thinking about throwing in the towel on algebra so I can ride my bike...",
  "id" : 146623507458035713,
  "created_at" : "Tue Dec 13 16:12:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/XUYiEagk",
      "expanded_url" : "http://twitpic.com/7smcaj",
      "display_url" : "twitpic.com/7smcaj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "146452158525612032",
  "text" : "and I won the Garmin raffle!! http://t.co/XUYiEagk",
  "id" : 146452158525612032,
  "created_at" : "Tue Dec 13 04:51:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146451952509792256",
  "text" : "so, a few updates: MCing the races was awesome! going to miss this community so much",
  "id" : 146451952509792256,
  "created_at" : "Tue Dec 13 04:50:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfectstudybreak",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146374401812733952",
  "text" : "time for the East Coasters Cup Invitational TruGold racing action and customer apprec night!! Food, beer, bike racing #perfectstudybreak",
  "id" : 146374401812733952,
  "created_at" : "Mon Dec 12 23:42:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigwatts",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "fb",
      "indices" : [ 23, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/wBM6jfE6",
      "expanded_url" : "http://twitpic.com/7sfxrw",
      "display_url" : "twitpic.com/7sfxrw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "146307055702118400",
  "text" : "look closely #bigwatts #fb http://t.co/wBM6jfE6",
  "id" : 146307055702118400,
  "created_at" : "Mon Dec 12 19:14:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getonmylevel",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146302087288983552",
  "text" : "show up 15min late to my hist of math final, crush it, first person to leave #getonmylevel",
  "id" : 146302087288983552,
  "created_at" : "Mon Dec 12 18:55:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laundrycalled",
      "indices" : [ 68, 82 ]
    }, {
      "text" : "bedsoonthough",
      "indices" : [ 83, 97 ]
    }, {
      "text" : "brainisfull",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146110039244025856",
  "text" : "is breaking my own rule...not asleep 8 hours before my final at 9AM #laundrycalled #bedsoonthough #brainisfull",
  "id" : 146110039244025856,
  "created_at" : "Mon Dec 12 06:12:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146093158751682560",
  "geo" : {
  },
  "id_str" : "146107024084705280",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT hahaha i'll give ya that one, i def chuckled",
  "id" : 146107024084705280,
  "in_reply_to_status_id" : 146093158751682560,
  "created_at" : "Mon Dec 12 06:00:03 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146089307822764032",
  "geo" : {
  },
  "id_str" : "146091029899128832",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT aw you're just sayin that because i'm outta this world",
  "id" : 146091029899128832,
  "in_reply_to_status_id" : 146089307822764032,
  "created_at" : "Mon Dec 12 04:56:30 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146080760284192769",
  "geo" : {
  },
  "id_str" : "146081226858565632",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy haha yessir!",
  "id" : 146081226858565632,
  "in_reply_to_status_id" : 146080760284192769,
  "created_at" : "Mon Dec 12 04:17:33 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146070267121238016",
  "geo" : {
  },
  "id_str" : "146079998204321792",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy +2 for extreme accuracy! not sure where these pts go lol. great idea, will try that if my DIY free motion rollers fail",
  "id" : 146079998204321792,
  "in_reply_to_status_id" : 146070267121238016,
  "created_at" : "Mon Dec 12 04:12:40 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146077675910463488",
  "geo" : {
  },
  "id_str" : "146079748274135040",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy right-o! 1 point! that does sound pretty epic...I was thinking DIY free motion rollers though lol (google \"e-motion rollers\")",
  "id" : 146079748274135040,
  "in_reply_to_status_id" : 146077675910463488,
  "created_at" : "Mon Dec 12 04:11:40 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146070390568005632",
  "geo" : {
  },
  "id_str" : "146079406450937856",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 haha ummm sure! you gotta tell me though",
  "id" : 146079406450937856,
  "in_reply_to_status_id" : 146070390568005632,
  "created_at" : "Mon Dec 12 04:10:19 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146065028422971392",
  "geo" : {
  },
  "id_str" : "146065361614274560",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 haha...a cassette has no bearings, and they won't fit my BB...looks like you're waiting to see until tmrw nite @ trugold",
  "id" : 146065361614274560,
  "in_reply_to_status_id" : 146065028422971392,
  "created_at" : "Mon Dec 12 03:14:30 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 7, 18 ]
    }, {
      "text" : "lookrediculous",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146064875683188736",
  "text" : "25F in #blacksburg and riding my bike to David's to pick something up...necessitates one piece ski suit! #lookrediculous",
  "id" : 146064875683188736,
  "created_at" : "Mon Dec 12 03:12:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146064399495471104",
  "geo" : {
  },
  "id_str" : "146064606396293120",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 close and not even close. skateboard wheels + bearings...think how would I use them in relation to riding my bike (it's hard lol)",
  "id" : 146064606396293120,
  "in_reply_to_status_id" : 146064399495471104,
  "created_at" : "Mon Dec 12 03:11:30 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/MwbAQwkx",
      "expanded_url" : "http://twitpic.com/7s5ud9",
      "display_url" : "twitpic.com/7s5ud9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "146063384264187904",
  "text" : "also got these guys in the snail mail today... +1 point for what they are, +100 for what the heck imma do with them! http://t.co/MwbAQwkx",
  "id" : 146063384264187904,
  "created_at" : "Mon Dec 12 03:06:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "146046892759973888",
  "text" : "in other news, I'm going to be MC'ing the TruGold East Coasters Cup tomorrow!! 7-9 @ East Coasters Tmrw. Gonna be lots of fun!!!!",
  "id" : 146046892759973888,
  "created_at" : "Mon Dec 12 02:01:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/Jonr6Pci",
      "expanded_url" : "http://bit.ly/uAKrPY",
      "display_url" : "bit.ly/uAKrPY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "146046446725111809",
  "text" : "algebra take home final taking shape...only time I've left the study cave (aka my room) was for a good run w/ Chrissy: http://t.co/Jonr6Pci",
  "id" : 146046446725111809,
  "created_at" : "Mon Dec 12 01:59:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaɴɴoɴ ɱarίε ♡",
      "screen_name" : "shanzy_mariee",
      "indices" : [ 0, 14 ],
      "id_str" : "304221559",
      "id" : 304221559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/lb6iM9vE",
      "expanded_url" : "http://www.youtube.com/watch?v=1EY7lYRneHc",
      "display_url" : "youtube.com/watch?v=1EY7lY…"
    } ]
  },
  "in_reply_to_status_id_str" : "146009108229799937",
  "geo" : {
  },
  "id_str" : "146009939435978752",
  "in_reply_to_user_id" : 304221559,
  "text" : "@shanzy_mariee for real, you should tell them to HTFU: http://t.co/lb6iM9vE",
  "id" : 146009939435978752,
  "in_reply_to_status_id" : 146009108229799937,
  "created_at" : "Sun Dec 11 23:34:16 +0000 2011",
  "in_reply_to_screen_name" : "shanzy_mariee",
  "in_reply_to_user_id_str" : "304221559",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaɴɴoɴ ɱarίε ♡",
      "screen_name" : "shanzy_mariee",
      "indices" : [ 0, 14 ],
      "id_str" : "304221559",
      "id" : 304221559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146007702563336193",
  "geo" : {
  },
  "id_str" : "146008045049217024",
  "in_reply_to_user_id" : 304221559,
  "text" : "@shanzy_mariee hahaha i know :-P",
  "id" : 146008045049217024,
  "in_reply_to_status_id" : 146007702563336193,
  "created_at" : "Sun Dec 11 23:26:45 +0000 2011",
  "in_reply_to_screen_name" : "shanzy_mariee",
  "in_reply_to_user_id_str" : "304221559",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaɴɴoɴ ɱarίε ♡",
      "screen_name" : "shanzy_mariee",
      "indices" : [ 0, 14 ],
      "id_str" : "304221559",
      "id" : 304221559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ironytweet",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146007217836003328",
  "geo" : {
  },
  "id_str" : "146007449801998337",
  "in_reply_to_user_id" : 304221559,
  "text" : "@shanzy_mariee #ironytweet",
  "id" : 146007449801998337,
  "in_reply_to_status_id" : 146007217836003328,
  "created_at" : "Sun Dec 11 23:24:23 +0000 2011",
  "in_reply_to_screen_name" : "shanzy_mariee",
  "in_reply_to_user_id_str" : "304221559",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "booyah",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "burlingtonwatchout",
      "indices" : [ 67, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145977788204191744",
  "text" : "just got my official acceptance letter to UVM in the mail! #booyah #burlingtonwatchout",
  "id" : 145977788204191744,
  "created_at" : "Sun Dec 11 21:26:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "finally",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145975868555137024",
  "text" : "short run study break! #finally",
  "id" : 145975868555137024,
  "created_at" : "Sun Dec 11 21:18:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "somanyalgorithmstoremember",
      "indices" : [ 54, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145968733121282049",
  "text" : "internalizing 14 weeks of numerical analysis in 1 day #somanyalgorithmstoremember",
  "id" : 145968733121282049,
  "created_at" : "Sun Dec 11 20:50:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/VvB91TWs",
      "expanded_url" : "http://lmgtfy.com/?q=bmi+calculator&l=1",
      "display_url" : "lmgtfy.com/?q=bmi+calcula…"
    } ]
  },
  "in_reply_to_status_id_str" : "145950292565954560",
  "geo" : {
  },
  "id_str" : "145953130197155841",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 http://t.co/VvB91TWs",
  "id" : 145953130197155841,
  "in_reply_to_status_id" : 145950292565954560,
  "created_at" : "Sun Dec 11 19:48:32 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatsnotright",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145913273248788481",
  "text" : "at 6'4\" 170lbs, I'd need to lose 20lbs to be underweight by my BMI #thatsnotright",
  "id" : 145913273248788481,
  "created_at" : "Sun Dec 11 17:10:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Ciccone",
      "screen_name" : "JonCiccone",
      "indices" : [ 10, 21 ],
      "id_str" : "42425909",
      "id" : 42425909
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 26, 39 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 84, 92 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145708994936307712",
  "text" : "glad that @jonciccone let @laurentappan eat dinner, it was fun eating with you guys @Moes_HQ!",
  "id" : 145708994936307712,
  "created_at" : "Sun Dec 11 03:38:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 3, 14 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "145274377490018305",
  "text" : "RT @kreagannet of all the times to get sick...right before finals...",
  "id" : 145274377490018305,
  "created_at" : "Fri Dec 09 22:51:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 3, 17 ],
      "id_str" : "326870950",
      "id" : 326870950
    }, {
      "name" : "Allison Walker",
      "screen_name" : "AWalk27",
      "indices" : [ 22, 30 ],
      "id_str" : "309424446",
      "id" : 309424446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatimayserve",
      "indices" : [ 93, 107 ]
    }, {
      "text" : "vthero",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144984835407101952",
  "text" : "RT @BlackSheep_VT: RT @awalk27: RIP Deriek Crouse, you took Ut Prosim to another level today #thatimayserve #vthero",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Walker",
        "screen_name" : "AWalk27",
        "indices" : [ 3, 11 ],
        "id_str" : "309424446",
        "id" : 309424446
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thatimayserve",
        "indices" : [ 74, 88 ]
      }, {
        "text" : "vthero",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "144969436619743232",
    "text" : "RT @awalk27: RIP Deriek Crouse, you took Ut Prosim to another level today #thatimayserve #vthero",
    "id" : 144969436619743232,
    "created_at" : "Fri Dec 09 02:39:41 +0000 2011",
    "user" : {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "protected" : false,
      "id_str" : "326870950",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1440736506/sheepbeerhat5_normal.jpg",
      "id" : 326870950,
      "verified" : false
    }
  },
  "id" : 144984835407101952,
  "created_at" : "Fri Dec 09 03:40:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 0, 14 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144938008804720640",
  "geo" : {
  },
  "id_str" : "144940093780668417",
  "in_reply_to_user_id" : 154139533,
  "text" : "@rickygargiulo and you weren't even in d5 for 6 hours today lol",
  "id" : 144940093780668417,
  "in_reply_to_status_id" : 144938008804720640,
  "created_at" : "Fri Dec 09 00:43:05 +0000 2011",
  "in_reply_to_screen_name" : "rickygargiulo",
  "in_reply_to_user_id_str" : "154139533",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stressrelief",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144933791545294848",
  "geo" : {
  },
  "id_str" : "144939956274610176",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons yeah that was a necessary run! #stressrelief",
  "id" : 144939956274610176,
  "in_reply_to_status_id" : 144933791545294848,
  "created_at" : "Fri Dec 09 00:42:33 +0000 2011",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trey ",
      "screen_name" : "TheHokieStone",
      "indices" : [ 3, 17 ],
      "id_str" : "202495816",
      "id" : 202495816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144932316647657472",
  "text" : "RT @TheHokieStone: Sunset on campus..love this school and this little town, I wouldn't want to be anywhere else. Go Hokies http://t.co/C ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/CqsIGRWI",
        "expanded_url" : "http://twitpic.com/7qheqt",
        "display_url" : "twitpic.com/7qheqt"
      } ]
    },
    "geo" : {
    },
    "id_str" : "144910367561232384",
    "text" : "Sunset on campus..love this school and this little town, I wouldn't want to be anywhere else. Go Hokies http://t.co/CqsIGRWI",
    "id" : 144910367561232384,
    "created_at" : "Thu Dec 08 22:44:58 +0000 2011",
    "user" : {
      "name" : "Trey ",
      "screen_name" : "TheHokieStone",
      "protected" : false,
      "id_str" : "202495816",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1144436584/hokiestone_normal.jpg",
      "id" : 202495816,
      "verified" : false
    }
  },
  "id" : 144932316647657472,
  "created_at" : "Fri Dec 09 00:12:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 45, 57 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 58, 71 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/MLmrHsEa",
      "expanded_url" : "http://bit.ly/v9yn28",
      "display_url" : "bit.ly/v9yn28"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144931662185242628",
  "text" : "after lock down, went on a great trail run w @runfasteraw @williamenium Jan Chrissy + Rachel! Garmin Connect - Details: http://t.co/MLmrHsEa",
  "id" : 144931662185242628,
  "created_at" : "Fri Dec 09 00:09:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lusher",
      "screen_name" : "brianlusher",
      "indices" : [ 3, 15 ],
      "id_str" : "130674872",
      "id" : 130674872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144892305160142848",
  "text" : "RT @brianlusher: Law enforcement agencies have determined there is no longer an active threat or need to secure in place. Resume normal  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 131, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "144891603830587393",
    "text" : "Law enforcement agencies have determined there is no longer an active threat or need to secure in place. Resume normal activities. #fb",
    "id" : 144891603830587393,
    "created_at" : "Thu Dec 08 21:30:24 +0000 2011",
    "user" : {
      "name" : "Brian Lusher",
      "screen_name" : "brianlusher",
      "protected" : false,
      "id_str" : "130674872",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/809444882/24097_397183329427_502144427_5037085_6678863_n_normal.jpg",
      "id" : 130674872,
      "verified" : false
    }
  },
  "id" : 144892305160142848,
  "created_at" : "Thu Dec 08 21:33:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Simmerman",
      "screen_name" : "bsim9",
      "indices" : [ 0, 6 ],
      "id_str" : "30967859",
      "id" : 30967859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144876441367097344",
  "geo" : {
  },
  "id_str" : "144877167434678272",
  "in_reply_to_user_id" : 30967859,
  "text" : "@bsim9 thanks britt :)",
  "id" : 144877167434678272,
  "in_reply_to_status_id" : 144876441367097344,
  "created_at" : "Thu Dec 08 20:33:03 +0000 2011",
  "in_reply_to_screen_name" : "bsim9",
  "in_reply_to_user_id_str" : "30967859",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144842282904977408",
  "geo" : {
  },
  "id_str" : "144842965754458112",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr its not, but im safe",
  "id" : 144842965754458112,
  "in_reply_to_status_id" : 144842282904977408,
  "created_at" : "Thu Dec 08 18:17:08 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144841489091014656",
  "text" : "is inside on lockdown.",
  "id" : 144841489091014656,
  "created_at" : "Thu Dec 08 18:11:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144820541554040833",
  "text" : "either I got a lot more clever, or my analysis final was a breeze...hoping the prior",
  "id" : 144820541554040833,
  "created_at" : "Thu Dec 08 16:48:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "somenight",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144674583847501825",
  "text" : "had an awesome time at the Bike Riders Ball, was voted Prom King + endowed with camo crown, and post-ball mission was successful #somenight",
  "id" : 144674583847501825,
  "created_at" : "Thu Dec 08 07:08:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/EN8Ei6W6",
      "expanded_url" : "http://twitpic.com/7q016e",
      "display_url" : "twitpic.com/7q016e"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144564638493851649",
  "text" : "Bikers Ball!! Look at this classy chap, Mr Jan Grajkowski for ya http://t.co/EN8Ei6W6",
  "id" : 144564638493851649,
  "created_at" : "Wed Dec 07 23:51:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 96, 110 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144462992484999168",
  "text" : "is for sure going to University of Vermont this spring to study uncertainty quantification with @ChrisDanforth! #fb",
  "id" : 144462992484999168,
  "created_at" : "Wed Dec 07 17:07:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 23, 36 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Jacob Aber",
      "screen_name" : "jabervt",
      "indices" : [ 37, 45 ],
      "id_str" : "370283022",
      "id" : 370283022
    }, {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 46, 55 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 56, 66 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TRUGold",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/XGU72NV6",
      "expanded_url" : "http://twitpic.com/7puurs",
      "display_url" : "twitpic.com/7puurs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144461874044485632",
  "text" : "#TRUGold racing time!! @williamenium @jabervt @aJohnnyD @VTCycling http://t.co/XGU72NV6",
  "id" : 144461874044485632,
  "created_at" : "Wed Dec 07 17:02:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irony",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "fb",
      "indices" : [ 68, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/tuRqRTBn",
      "expanded_url" : "http://twitpic.com/7putnq",
      "display_url" : "twitpic.com/7putnq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144461311936446464",
  "text" : "the \"sust careers with global impact\" tablecard is laminated #irony #fb http://t.co/tuRqRTBn",
  "id" : 144461311936446464,
  "created_at" : "Wed Dec 07 17:00:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "achievement",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144458346529947648",
  "text" : "4000 tweets!!! #achievement",
  "id" : 144458346529947648,
  "created_at" : "Wed Dec 07 16:48:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144452100422770688",
  "text" : "actually proved one right on reals that he marked off, so I got a 92 #boom",
  "id" : 144452100422770688,
  "created_at" : "Wed Dec 07 16:23:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vatech",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "soambivalentaboutgraduating",
      "indices" : [ 57, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144446948789854210",
  "text" : "done with classes at #vatech and as undergrad forevaaa!! #soambivalentaboutgraduating",
  "id" : 144446948789854210,
  "created_at" : "Wed Dec 07 16:03:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144416549581762560",
  "text" : "and my second-to-last at virginia tech begins!",
  "id" : 144416549581762560,
  "created_at" : "Wed Dec 07 14:02:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toocute",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "wanttostealhimlol",
      "indices" : [ 28, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144413152782729216",
  "geo" : {
  },
  "id_str" : "144416275614007296",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e definitely #toocute #wanttostealhimlol",
  "id" : 144416275614007296,
  "in_reply_to_status_id" : 144413152782729216,
  "created_at" : "Wed Dec 07 14:01:37 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144411456568430592",
  "geo" : {
  },
  "id_str" : "144412876042547200",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e Haha. I think you're right, I couldn't handle the leaf photoshoot",
  "id" : 144412876042547200,
  "in_reply_to_status_id" : 144411456568430592,
  "created_at" : "Wed Dec 07 13:48:07 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144409447261929472",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e i had some strange dreams last night lol, but in all of them, you had 6 kids lol! somehow all 5 months old lol",
  "id" : 144409447261929472,
  "created_at" : "Wed Dec 07 13:34:29 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "living",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144408497600204801",
  "text" : "alarm this morning and breadmaker went off at the saame time! #living",
  "id" : 144408497600204801,
  "created_at" : "Wed Dec 07 13:30:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144301089846607872",
  "text" : "using the delay timer on the breadmaker for the first time, mmm fresh bread in the AM",
  "id" : 144301089846607872,
  "created_at" : "Wed Dec 07 06:23:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damn",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144287572397522944",
  "text" : "and my reals prof had our exams graded and online in 2hours #damn, beat the class median of 79!",
  "id" : 144287572397522944,
  "created_at" : "Wed Dec 07 05:30:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144278891803054080",
  "geo" : {
  },
  "id_str" : "144286038569914368",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw glad to hear that you're feeling good!!",
  "id" : 144286038569914368,
  "in_reply_to_status_id" : 144278891803054080,
  "created_at" : "Wed Dec 07 05:24:06 +0000 2011",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vintage",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/xnjICHzz",
      "expanded_url" : "http://twitpic.com/7pm90q",
      "display_url" : "twitpic.com/7pm90q"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144285958697795584",
  "text" : "present from bradner, an old cycling road sign! #vintage http://t.co/xnjICHzz",
  "id" : 144285958697795584,
  "created_at" : "Wed Dec 07 05:23:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "finally",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "morefun",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144258870821396480",
  "text" : "think i did well on the reals exam!! #finally and now i just finished typing the take home final #morefun",
  "id" : 144258870821396480,
  "created_at" : "Wed Dec 07 03:36:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hammertime",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "iwish",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144164975840206848",
  "text" : "#hammertime before my real analysis test tonight? #iwish",
  "id" : 144164975840206848,
  "created_at" : "Tue Dec 06 21:23:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 10, 19 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 91, 98 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontneedanythingthoughreally",
      "indices" : [ 36, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/9nGAlhSY",
      "expanded_url" : "http://www.amazon.com/registry/wishlist/1SVL3CE39069/ref=cm_sw_r_tw_ws_-sO3ob0206JAQ",
      "display_url" : "amazon.com/registry/wishl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "144164411538546688",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @vmhilljr just some ideas #dontneedanythingthoughreally http://t.co/9nGAlhSY via @amazon",
  "id" : 144164411538546688,
  "created_at" : "Tue Dec 06 21:20:48 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodthingdavidisntontwitter",
      "indices" : [ 86, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144103282229514240",
  "text" : "and by useful, i might mean i can stuff their milk crate full of wet leaves every day #goodthingdavidisntontwitter",
  "id" : 144103282229514240,
  "created_at" : "Tue Dec 06 17:17:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justlookattherack",
      "indices" : [ 94, 112 ]
    }, {
      "text" : "usefulsometimes",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144102897146265600",
  "text" : "advantage to all my friends at tech riding bikes... i know exactly where every one of them is #justlookattherack #usefulsometimes",
  "id" : 144102897146265600,
  "created_at" : "Tue Dec 06 17:16:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144093411018944512",
  "geo" : {
  },
  "id_str" : "144094998877569024",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr well lets not speculate too much here, pretty sure I know my algebra theorems as well as I know the Cellar's tap list, pretty sure",
  "id" : 144094998877569024,
  "in_reply_to_status_id" : 144093411018944512,
  "created_at" : "Tue Dec 06 16:44:59 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144091253531873281",
  "geo" : {
  },
  "id_str" : "144092609869123584",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr hahaha you dont graduate with honors by doing ALL (albeit most) studying at the bars",
  "id" : 144092609869123584,
  "in_reply_to_status_id" : 144091253531873281,
  "created_at" : "Tue Dec 06 16:35:29 +0000 2011",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikersball",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144091007691145216",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT bring your table tennis game back from no joisey cuz you're goin down at #bikersball",
  "id" : 144091007691145216,
  "created_at" : "Tue Dec 06 16:29:07 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lastchancetostayinbburg",
      "indices" : [ 51, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144089592029642753",
  "text" : "have to pay my library fines before I can graduate #lastchancetostayinbburg",
  "id" : 144089592029642753,
  "created_at" : "Tue Dec 06 16:23:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "144077153770799105",
  "text" : "presentations this AM in mathbio: twitter as disease (SIR), model of neglected disease, and spatial tumor growth",
  "id" : 144077153770799105,
  "created_at" : "Tue Dec 06 15:34:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143873012872122368",
  "geo" : {
  },
  "id_str" : "143893421612990464",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson thanks Jake!!!",
  "id" : 143893421612990464,
  "in_reply_to_status_id" : 143873012872122368,
  "created_at" : "Tue Dec 06 03:23:59 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/qw4KCoOL",
      "expanded_url" : "http://www.ted.com/talks/richard_dawkins_on_our_queer_universe.html",
      "display_url" : "ted.com/talks/richard_…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "143893124127801344",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 blow your mind http://t.co/qw4KCoOL",
  "id" : 143893124127801344,
  "created_at" : "Tue Dec 06 03:22:48 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toomuchwork",
      "indices" : [ 24, 36 ]
    }, {
      "text" : "actuallyrelativelywarmout",
      "indices" : [ 37, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143565208995102720",
  "text" : "actually going home now #toomuchwork #actuallyrelativelywarmout",
  "id" : 143565208995102720,
  "created_at" : "Mon Dec 05 05:39:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sorrymathbiohomework",
      "indices" : [ 18, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143552903582449664",
  "text" : "callin it a night #sorrymathbiohomework",
  "id" : 143552903582449664,
  "created_at" : "Mon Dec 05 04:50:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143543773371174913",
  "geo" : {
  },
  "id_str" : "143544389430550528",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT yupp. happy/angry drunk == happy/angry person on the inside",
  "id" : 143544389430550528,
  "in_reply_to_status_id" : 143543773371174913,
  "created_at" : "Mon Dec 05 04:17:04 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/hYDdNeHq",
      "expanded_url" : "http://www.bakadesuyo.com/do-baseball-pitchers-hit-batters-more-often-w",
      "display_url" : "bakadesuyo.com/do-baseball-pi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "143534405472890880",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 http://t.co/hYDdNeHq",
  "id" : 143534405472890880,
  "created_at" : "Mon Dec 05 03:37:23 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/uylGTQfQ",
      "expanded_url" : "http://www.bakadesuyo.com/its-not-the-booze-talking",
      "display_url" : "bakadesuyo.com/its-not-the-bo…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "143533064776192002",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT http://t.co/uylGTQfQ doesn't explain drunken personality changes, now does it",
  "id" : 143533064776192002,
  "created_at" : "Mon Dec 05 03:32:04 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143521742483238912",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr looks like we're playing you guys in the Sugar Bowl, if we're both in Boston then we might have to stay in separate rooms lol",
  "id" : 143521742483238912,
  "created_at" : "Mon Dec 05 02:47:04 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/M4NSsLv2",
      "expanded_url" : "http://connect.garmin.com/activity/132702815",
      "display_url" : "connect.garmin.com/activity/13270…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "143480752095510528",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 http://t.co/M4NSsLv2",
  "id" : 143480752095510528,
  "created_at" : "Mon Dec 05 00:04:11 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 37, 46 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143410223741276161",
  "geo" : {
  },
  "id_str" : "143425546041303040",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 i think you meant to ask @DKnick88, the grilled cheese king lol",
  "id" : 143425546041303040,
  "in_reply_to_status_id" : 143410223741276161,
  "created_at" : "Sun Dec 04 20:24:49 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143209368601632769",
  "text" : "it appears that a few too many tried to drink away tonight's sorrows...car full of (and driven by) some drunks threw a full beer?!",
  "id" : 143209368601632769,
  "created_at" : "Sun Dec 04 06:05:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 3, 17 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drinkingawaymysorrows",
      "indices" : [ 87, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143178617285910529",
  "text" : "RT @BlackSheep_VT: OH HEY VIRGINIA TECH.... I WISH YOU'D START PLAYING LIKE CHAMPIONS. #drinkingawaymysorrows",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drinkingawaymysorrows",
        "indices" : [ 68, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "143176408510906368",
    "text" : "OH HEY VIRGINIA TECH.... I WISH YOU'D START PLAYING LIKE CHAMPIONS. #drinkingawaymysorrows",
    "id" : 143176408510906368,
    "created_at" : "Sun Dec 04 03:54:50 +0000 2011",
    "user" : {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "protected" : false,
      "id_str" : "326870950",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1440736506/sheepbeerhat5_normal.jpg",
      "id" : 326870950,
      "verified" : false
    }
  },
  "id" : 143178617285910529,
  "created_at" : "Sun Dec 04 04:03:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeanne McAndrews",
      "screen_name" : "Jeanneface_",
      "indices" : [ 3, 15 ],
      "id_str" : "338753061",
      "id" : 338753061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143178492266283009",
  "text" : "RT @Jeanneface_: Did the refs get paid during halftime?",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "143172526435082241",
    "text" : "Did the refs get paid during halftime?",
    "id" : 143172526435082241,
    "created_at" : "Sun Dec 04 03:39:24 +0000 2011",
    "user" : {
      "name" : "Jeanne McAndrews",
      "screen_name" : "Jeanneface_",
      "protected" : true,
      "id_str" : "338753061",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2700422139/badccb8708bddce7b869833359f5ff3f_normal.jpeg",
      "id" : 338753061,
      "verified" : false
    }
  },
  "id" : 143178492266283009,
  "created_at" : "Sun Dec 04 04:03:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ugly",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "getittogether",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143168313558712321",
  "text" : "noooooooooo #ugly #getittogether",
  "id" : 143168313558712321,
  "created_at" : "Sun Dec 04 03:22:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 19, 28 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 29, 41 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 42, 54 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 55, 65 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Wilson Hale",
      "screen_name" : "winslowins",
      "indices" : [ 66, 77 ],
      "id_str" : "30274505",
      "id" : 30274505
    }, {
      "name" : "NCSU Cycling Club",
      "screen_name" : "NCStateCycling",
      "indices" : [ 78, 93 ],
      "id_str" : "292063766",
      "id" : 292063766
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 94, 106 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 107, 123 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterftw",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143162822036164609",
  "text" : "watchin the game w @Run_Rudy @runfasteraw @OGfromtheOB @WyattLoud @winslowins @NCStateCycling @VTTriathlon @JacobnAndersson!! #twitterftw",
  "id" : 143162822036164609,
  "created_at" : "Sun Dec 04 03:00:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 3, 15 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 36, 47 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beast",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143123930373300224",
  "text" : "RT @LeeRMatthis: Y'all shoulda seen @andyreagan on the borrowed bike!!!   Hung in there hard and couldn't even extend his legs!!!!  #beast",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 19, 30 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beast",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "143109129165209602",
    "text" : "Y'all shoulda seen @andyreagan on the borrowed bike!!!   Hung in there hard and couldn't even extend his legs!!!!  #beast",
    "id" : 143109129165209602,
    "created_at" : "Sat Dec 03 23:27:29 +0000 2011",
    "user" : {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "protected" : false,
      "id_str" : "70417462",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1402226998/image_normal.jpg",
      "id" : 70417462,
      "verified" : false
    }
  },
  "id" : 143123930373300224,
  "created_at" : "Sun Dec 04 00:26:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "putnam",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "143035616374947840",
  "text" : "well how I understand why the median score is 1 out of 120. first 3 hours done, 3 more hours of #putnam",
  "id" : 143035616374947840,
  "created_at" : "Sat Dec 03 18:35:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/BiGH5YmL",
      "expanded_url" : "http://en.wikipedia.org/wiki/William_Lowell_Putnam_Mathematical_Competition",
      "display_url" : "en.wikipedia.org/wiki/William_L…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "142978799758348289",
  "text" : "this is what I'm talking about: http://t.co/BiGH5YmL",
  "id" : 142978799758348289,
  "created_at" : "Sat Dec 03 14:49:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "putnamexam",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "howcleverami",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142978036990607360",
  "text" : "time to take the Putnam!! #putnamexam #howcleverami",
  "id" : 142978036990607360,
  "created_at" : "Sat Dec 03 14:46:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BIRODITALIA",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142768487364952064",
  "text" : "rode my bike to Reinhard's house at the top of Brush Mtn for a get together! Now it's time for the #BIRODITALIA",
  "id" : 142768487364952064,
  "created_at" : "Sat Dec 03 00:53:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142731283104141312",
  "text" : "gorgeous sunset! biking to the after-final-research-group-meeting at Reinhards house (on top of Brush Mountain!!)",
  "id" : 142731283104141312,
  "created_at" : "Fri Dec 02 22:26:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "happyhour",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142703287173517312",
  "text" : "nailed my presentation! #boom #happyhour",
  "id" : 142703287173517312,
  "created_at" : "Fri Dec 02 20:34:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142606224632979458",
  "text" : "just learned how to tie a bowtie in algebra class, thanks Dr Brown haha",
  "id" : 142606224632979458,
  "created_at" : "Fri Dec 02 14:09:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/Zl1Vh7rv",
      "expanded_url" : "http://twitpic.com/7muz63",
      "display_url" : "twitpic.com/7muz63"
    } ]
  },
  "geo" : {
  },
  "id_str" : "142428548542644225",
  "text" : "peanut butter no bakes!! http://t.co/Zl1Vh7rv",
  "id" : 142428548542644225,
  "created_at" : "Fri Dec 02 02:23:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 40, 52 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142399590023434241",
  "text" : "time for the Betty Crocker Cookoff with @VTTriathlon",
  "id" : 142399590023434241,
  "created_at" : "Fri Dec 02 00:28:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazing",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "getbusyliving",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142383328157376512",
  "text" : "impromptu run through the fields and into the sunset #amazing #getbusyliving",
  "id" : 142383328157376512,
  "created_at" : "Thu Dec 01 23:23:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegehouseproblems",
      "indices" : [ 117, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142358953769181185",
  "text" : "at least I have the squirrels that live in the walls to keep me company when both my roommates are gone for the week #collegehouseproblems",
  "id" : 142358953769181185,
  "created_at" : "Thu Dec 01 21:46:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "numericalanalysisjokes",
      "indices" : [ 103, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142281229511831552",
  "text" : "inverting a matrix is a \"computational sin, right up there with finding the determinant\" -dr boorgaard #numericalanalysisjokes",
  "id" : 142281229511831552,
  "created_at" : "Thu Dec 01 16:37:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/3ztHT2mZ",
      "expanded_url" : "http://ht.ly/7L7xt",
      "display_url" : "ht.ly/7L7xt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "142274974487543810",
  "text" : "RT @bakadesuyo: 5 things you didn't know about Twitter: http://t.co/3ztHT2mZ",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http://t.co/3ztHT2mZ",
        "expanded_url" : "http://ht.ly/7L7xt",
        "display_url" : "ht.ly/7L7xt"
      } ]
    },
    "geo" : {
    },
    "id_str" : "142271756856590336",
    "text" : "5 things you didn't know about Twitter: http://t.co/3ztHT2mZ",
    "id" : 142271756856590336,
    "created_at" : "Thu Dec 01 16:00:04 +0000 2011",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 142274974487543810,
  "created_at" : "Thu Dec 01 16:12:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 13, 29 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 33, 42 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 44, 55 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 56, 67 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FeelLikeKevin",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142273081271005186",
  "text" : "is this true @RumblinStumblin?? \"@vmhilljr: @andyreagan @kreagannet Watching Donna work around house. #FeelLikeKevin\"",
  "id" : 142273081271005186,
  "created_at" : "Thu Dec 01 16:05:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "142119717501534209",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan can you email me your peanut butter no-bake recipe?",
  "id" : 142119717501534209,
  "created_at" : "Thu Dec 01 05:55:55 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]