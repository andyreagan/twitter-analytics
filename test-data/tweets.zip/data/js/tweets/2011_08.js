Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 15, 24 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 78, 90 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nightrunning",
      "indices" : [ 45, 58 ]
    }, {
      "text" : "bestworstdecision",
      "indices" : [ 59, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109055695957143552",
  "text" : "go get it!! RT @Run_Rudy 20 years, 20 miles? #nightrunning #bestworstdecision @OGfromtheOB",
  "id" : 109055695957143552,
  "created_at" : "Thu Sep 01 00:11:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109035287354687489",
  "geo" : {
  },
  "id_str" : "109055399633756160",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 so I've heard",
  "id" : 109055399633756160,
  "in_reply_to_status_id" : 109035287354687489,
  "created_at" : "Thu Sep 01 00:10:08 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 92, 101 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 102, 116 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http://t.co/vqiKvgv",
      "expanded_url" : "http://bit.ly/oW3Vp4",
      "display_url" : "bit.ly/oW3Vp4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "109055302476894208",
  "text" : "freakin fast wednesday worlds, cant believe I flatted with the front group feelin strong... @aJohnnyD @rickygargiulo http://t.co/vqiKvgv",
  "id" : 109055302476894208,
  "created_at" : "Thu Sep 01 00:09:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "indices" : [ 3, 17 ],
      "id_str" : "154139533",
      "id" : 154139533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109017462107938816",
  "text" : "RT @rickygargiulo: Pre-Wednesday Worlds cappuccino.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "109015372765732864",
    "text" : "Pre-Wednesday Worlds cappuccino.",
    "id" : 109015372765732864,
    "created_at" : "Wed Aug 31 21:31:04 +0000 2011",
    "user" : {
      "name" : "Ricky Gargiulo",
      "screen_name" : "rickygargiulo",
      "protected" : false,
      "id_str" : "154139533",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1791315410/1190084-7e9aa922c6b25f8dca8685ac3eda3d30_normal.jpeg",
      "id" : 154139533,
      "verified" : false
    }
  },
  "id" : 109017462107938816,
  "created_at" : "Wed Aug 31 21:39:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "109007712511205376",
  "text" : "read most of the book \"The Essence of Chaos\" by Dr. Lorenz today! #boom HW, bike racing, then more HW tonight",
  "id" : 109007712511205376,
  "created_at" : "Wed Aug 31 21:00:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 91, 99 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http://t.co/8Pee2nO",
      "expanded_url" : "http://bit.ly/rggpao",
      "display_url" : "bit.ly/rggpao"
    } ]
  },
  "geo" : {
  },
  "id_str" : "108876058966753280",
  "text" : "solid 7AM Baker's Dozen by andyreagan at Garmin Connect - Details: http://t.co/8Pee2nO via @AddThis",
  "id" : 108876058966753280,
  "created_at" : "Wed Aug 31 12:17:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 40, 52 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bed",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108735980143513600",
  "text" : "there were over 100 people at the first @VTTriathlon meeting, awesome! finished numerical analysis before the meeting, algebra after... #bed",
  "id" : 108735980143513600,
  "created_at" : "Wed Aug 31 03:00:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108683483806826496",
  "geo" : {
  },
  "id_str" : "108735637812809729",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud hang in there!! you're crushin it dude (I had 103mi total, no swimming lol)",
  "id" : 108735637812809729,
  "in_reply_to_status_id" : 108683483806826496,
  "created_at" : "Wed Aug 31 02:59:30 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/X7zLSgH",
      "expanded_url" : "http://www.youtube.com/watch?v=avYUL1A-WUM",
      "display_url" : "youtube.com/watch?v=avYUL1…"
    } ]
  },
  "in_reply_to_status_id_str" : "108619279351554048",
  "geo" : {
  },
  "id_str" : "108629329570824192",
  "in_reply_to_user_id" : 70474456,
  "text" : "@bpolson89 speaking of tour groups... we need to do this: http://t.co/X7zLSgH",
  "id" : 108629329570824192,
  "in_reply_to_status_id" : 108619279351554048,
  "created_at" : "Tue Aug 30 19:57:05 +0000 2011",
  "in_reply_to_screen_name" : "britty_kitty89",
  "in_reply_to_user_id_str" : "70474456",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108595815781629952",
  "geo" : {
  },
  "id_str" : "108596068056436737",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan cool that you're going down haha?",
  "id" : 108596068056436737,
  "in_reply_to_status_id" : 108595815781629952,
  "created_at" : "Tue Aug 30 17:44:54 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 50, 61 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 62, 71 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 72, 81 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 82, 98 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108595545525846016",
  "text" : "signed up for the family fantasy football league! @kreagannet @vmhilljr @dmreagan @RumblinStumblin y'all are goin down!!",
  "id" : 108595545525846016,
  "created_at" : "Tue Aug 30 17:42:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http://t.co/gLMYNbt",
      "expanded_url" : "http://4sq.com/qpmq3f",
      "display_url" : "4sq.com/qpmq3f"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "108535797434679297",
  "text" : "\"defn 4: a steady state is unstable if it is not stable\" ha really? (@ McBryde Hall w/ 4 others) http://t.co/gLMYNbt",
  "id" : 108535797434679297,
  "created_at" : "Tue Aug 30 13:45:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 42, 55 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 72, 82 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108381375056449538",
  "text" : "super fun first meeting / moe's / hangout @williamenium's place after w @VTCycling! back to the HW",
  "id" : 108381375056449538,
  "created_at" : "Tue Aug 30 03:31:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notreadytoleave",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108298265656705024",
  "text" : "my DARS (degree audit report: says if i have enough classes) has been cleared to all green, I'm ready to graduate but #notreadytoleave",
  "id" : 108298265656705024,
  "created_at" : "Mon Aug 29 22:01:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/ynWIJlU",
      "expanded_url" : "http://connect.garmin.com/activity/110432478",
      "display_url" : "connect.garmin.com/activity/11043…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "108297969350094849",
  "text" : "*SAYG Ride was good, hate my phone's autocorrect...I'm fighting it every message. ride data!: http://t.co/ynWIJlU",
  "id" : 108297969350094849,
  "created_at" : "Mon Aug 29 22:00:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108296320992821248",
  "text" : "RT @VTCycling: First meeting of the year tonight...ready to see all the lovely faces of vt's cyclists tonight 6:30 in squires 345",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "108286460297363456",
    "text" : "First meeting of the year tonight...ready to see all the lovely faces of vt's cyclists tonight 6:30 in squires 345",
    "id" : 108286460297363456,
    "created_at" : "Mon Aug 29 21:14:38 +0000 2011",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 108296320992821248,
  "created_at" : "Mon Aug 29 21:53:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 12, 22 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http://t.co/cUtIMJ8",
      "expanded_url" : "http://twitpic.com/6d92sg",
      "display_url" : "twitpic.com/6d92sg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "108278321632133120",
  "text" : "SAYS ride w @vtcycling http://t.co/cUtIMJ8",
  "id" : 108278321632133120,
  "created_at" : "Mon Aug 29 20:42:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "failure",
      "indices" : [ 5, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http://t.co/ENR9o4I",
      "expanded_url" : "http://twitpic.com/6d7pr0",
      "display_url" : "twitpic.com/6d7pr0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "108246866017267712",
  "text" : "tire #failure http://t.co/ENR9o4I",
  "id" : 108246866017267712,
  "created_at" : "Mon Aug 29 18:37:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/gjOlqxn",
      "expanded_url" : "http://4sq.com/nXop5W",
      "display_url" : "4sq.com/nXop5W"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "108232000967671808",
  "text" : "I'm at Dietrick Dining Center (285 Ag Quad Lane, Blacksburg) http://t.co/gjOlqxn",
  "id" : 108232000967671808,
  "created_at" : "Mon Aug 29 17:38:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/GbJh9FO",
      "expanded_url" : "http://4sq.com/qowvl9",
      "display_url" : "4sq.com/qowvl9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "108169951050866689",
  "text" : "I'm at McBryde Hall (225 Stanger St., Drillfield Drive, Blacksburg) http://t.co/GbJh9FO",
  "id" : 108169951050866689,
  "created_at" : "Mon Aug 29 13:31:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 26, 33 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 34, 43 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "108025850896719872",
  "text" : "saw \"Buck\" at the Lyric w @rkay21 @slpagsVT and Paul, wasn't bad. baker's dozen \"mellow monday\" at 7AM!",
  "id" : 108025850896719872,
  "created_at" : "Mon Aug 29 03:59:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 8, 24 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 25, 34 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 73, 87 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/xkKzPv4",
      "expanded_url" : "http://bit.ly/q7yRtv",
      "display_url" : "bit.ly/q7yRtv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107944580791549952",
  "text" : "skype w @rumblinstumblin @dmreagan! just got back from 4 X Harding w new @chriskingbuzz wheelset, it's awesome! garmin: http://t.co/xkKzPv4",
  "id" : 107944580791549952,
  "created_at" : "Sun Aug 28 22:36:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 3, 18 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107942225270407168",
  "text" : "RT @ryandelgiudice: Life's good",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "107940331147902976",
    "text" : "Life's good",
    "id" : 107940331147902976,
    "created_at" : "Sun Aug 28 22:19:15 +0000 2011",
    "user" : {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "protected" : true,
      "id_str" : "44471444",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1264948750/DSC00020_normal.jpg",
      "id" : 44471444,
      "verified" : false
    }
  },
  "id" : 107942225270407168,
  "created_at" : "Sun Aug 28 22:26:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/ULG1e3p",
      "expanded_url" : "http://www.computing.vt.edu/internet_and_web/internet_access/vpn.html",
      "display_url" : "computing.vt.edu/internet_and_w…"
    } ]
  },
  "in_reply_to_status_id_str" : "107908637644701696",
  "geo" : {
  },
  "id_str" : "107916022799011840",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud you can download software at home, through a VPN (easy to set up): http://t.co/ULG1e3p",
  "id" : 107916022799011840,
  "in_reply_to_status_id" : 107908637644701696,
  "created_at" : "Sun Aug 28 20:42:39 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FlightBlogger",
      "screen_name" : "flightblogger",
      "indices" : [ 3, 17 ],
      "id_str" : "533285192",
      "id" : 533285192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whya",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107594591041110017",
  "text" : "RT @flightblogger: CNN reporters, hoping for the best shot possible, have quickly become leading candidates for natural selection. #whya ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whyareyouinthewater",
        "indices" : [ 112, 132 ]
      }, {
        "text" : "irene",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "107574219193319424",
    "text" : "CNN reporters, hoping for the best shot possible, have quickly become leading candidates for natural selection. #whyareyouinthewater #irene",
    "id" : 107574219193319424,
    "created_at" : "Sat Aug 27 22:04:27 +0000 2011",
    "user" : {
      "name" : "Jon Ostrower",
      "screen_name" : "jonostrower",
      "protected" : false,
      "id_str" : "14892330",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1452693218/100_1765_normal.JPG",
      "id" : 14892330,
      "verified" : false
    }
  },
  "id" : 107594591041110017,
  "created_at" : "Sat Aug 27 23:25:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 10, 20 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http://t.co/SkKXgWB",
      "expanded_url" : "http://bit.ly/nDxkvU",
      "display_url" : "bit.ly/nDxkvU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107485207455744000",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy @WyattLoud here's the garmin data: http://t.co/SkKXgWB",
  "id" : 107485207455744000,
  "created_at" : "Sat Aug 27 16:10:45 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 15, 25 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 56, 67 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 68, 77 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107469554141237248",
  "text" : "sweet run!! RT @WyattLoud 2 hours of trail running with @andyreagan @Run_Rudy and gang, great way to start the day",
  "id" : 107469554141237248,
  "created_at" : "Sat Aug 27 15:08:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 99, 109 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107454152413683712",
  "geo" : {
  },
  "id_str" : "107467639479205888",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy haha nah, Kay held on but Tyler snatched my record, and I was cool as long as we had the @VTCycling sweep",
  "id" : 107467639479205888,
  "in_reply_to_status_id" : 107454152413683712,
  "created_at" : "Sat Aug 27 15:00:56 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107426977832636416",
  "text" : "\"plastic bags are industrial tumbleweed\" -me",
  "id" : 107426977832636416,
  "created_at" : "Sat Aug 27 12:19:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 17, 27 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 28, 37 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107425348366499841",
  "text" : "long trail run w @WyattLoud @Run_Rudy Chrissy and others at Poverty Creek!",
  "id" : 107425348366499841,
  "created_at" : "Sat Aug 27 12:12:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 10, 20 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 21, 33 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "partythenrun",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "dontbeweak",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107311218808717312",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy @WyattLoud @OGfromtheOB y'all better MAN UP and still come trail run tmrw morning!! #partythenrun #dontbeweak",
  "id" : 107311218808717312,
  "created_at" : "Sat Aug 27 04:39:22 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gobblerfest",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/VUP14ty",
      "expanded_url" : "http://twitpic.com/6bq71b",
      "display_url" : "twitpic.com/6bq71b"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107261427257065472",
  "text" : "currently leading the spin bike wattage contest for an ipod touch! #gobblerfest http://t.co/VUP14ty",
  "id" : 107261427257065472,
  "created_at" : "Sat Aug 27 01:21:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107255392333078528",
  "geo" : {
  },
  "id_str" : "107260661519761408",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet curable only by copious amounts of alcohol, im pretty sure",
  "id" : 107260661519761408,
  "in_reply_to_status_id" : 107255392333078528,
  "created_at" : "Sat Aug 27 01:18:29 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cirriculumvitae",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http://t.co/oxv0cyF",
      "expanded_url" : "http://andyreagan.com/wp-content/uploads/2011/08/Reagan-CV.pdf",
      "display_url" : "andyreagan.com/wp-content/upl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107189132970827776",
  "text" : "#cirriculumvitae complete! well, 4 the moment. slow installation of MS Word, so 1.5hrs=pretty beastly. check it out: http://t.co/oxv0cyF",
  "id" : 107189132970827776,
  "created_at" : "Fri Aug 26 20:34:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 25, 35 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107162767613640705",
  "geo" : {
  },
  "id_str" : "107163649117917184",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy come visit the @vtcycling booth soon (when I get there at 4 or 5!) we're like 3rd row in squires parking lot!",
  "id" : 107163649117917184,
  "in_reply_to_status_id" : 107162767613640705,
  "created_at" : "Fri Aug 26 18:52:59 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsfindout",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107163301380751360",
  "text" : ".@vtcycling is set up for Gobblerfest!! now downloading and installing MS Word to make a CV, can I do it in all in an hour? #letsfindout",
  "id" : 107163301380751360,
  "created_at" : "Fri Aug 26 18:51:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http://t.co/oMqpjMH",
      "expanded_url" : "http://4sq.com/r8rd9a",
      "display_url" : "4sq.com/r8rd9a"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "107072437002309632",
  "text" : "printing out the finishing touches to my first HW's! (@ Virginia Bioinformatics Institute (VBI)) http://t.co/oMqpjMH",
  "id" : 107072437002309632,
  "created_at" : "Fri Aug 26 12:50:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 126, 134 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/jclABFq",
      "expanded_url" : "http://bit.ly/q1itL5",
      "display_url" : "bit.ly/q1itL5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "107066846942986240",
  "text" : "nice 1hr morning run: Baker's Dozen Fun Friday (Dry Heave) by andyreagan at Garmin Connect - Details: http://t.co/jclABFq via @AddThis",
  "id" : 107066846942986240,
  "created_at" : "Fri Aug 26 12:28:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "107043381938634752",
  "text" : "baker's dozen friday fun run! anyone else up this early?",
  "id" : 107043381938634752,
  "created_at" : "Fri Aug 26 10:55:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 3, 10 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 56, 65 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "babytweet",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/AwkXYPL",
      "expanded_url" : "http://yfrog.com/hwvmhj",
      "display_url" : "yfrog.com/hwvmhj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "106916713387397120",
  "text" : "RT @k8eb8e: May I present the cutest baby in the world! @jpbeatty #babytweet  http://t.co/AwkXYPL",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Beatty",
        "screen_name" : "jpbeatty",
        "indices" : [ 44, 53 ],
        "id_str" : "23640974",
        "id" : 23640974
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "babytweet",
        "indices" : [ 54, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http://t.co/AwkXYPL",
        "expanded_url" : "http://yfrog.com/hwvmhj",
        "display_url" : "yfrog.com/hwvmhj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "106913966176993283",
    "text" : "May I present the cutest baby in the world! @jpbeatty #babytweet  http://t.co/AwkXYPL",
    "id" : 106913966176993283,
    "created_at" : "Fri Aug 26 02:20:50 +0000 2011",
    "user" : {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "protected" : false,
      "id_str" : "26517690",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/673880411/IMG_0050_normal.JPG",
      "id" : 26517690,
      "verified" : false
    }
  },
  "id" : 106916713387397120,
  "created_at" : "Fri Aug 26 02:31:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106898982579605504",
  "geo" : {
  },
  "id_str" : "106899671452090368",
  "in_reply_to_user_id" : 70474456,
  "text" : "@bpolson89 haha okay!",
  "id" : 106899671452090368,
  "in_reply_to_status_id" : 106898982579605504,
  "created_at" : "Fri Aug 26 01:24:02 +0000 2011",
  "in_reply_to_screen_name" : "britty_kitty89",
  "in_reply_to_user_id_str" : "70474456",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 97, 105 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http://t.co/uXU52S2",
      "expanded_url" : "http://bit.ly/n7vC5E",
      "display_url" : "bit.ly/n7vC5E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "106884866548830209",
  "text" : "fun run in, now time to chow and finish up hw! Garmin Connect - Details: http://t.co/uXU52S2 via @AddThis",
  "id" : 106884866548830209,
  "created_at" : "Fri Aug 26 00:25:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interestingthought",
      "indices" : [ 46, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106797611410927616",
  "text" : "\"ontogeny recapitulates phylogeny\" -Dr Norton #interestingthought",
  "id" : 106797611410927616,
  "created_at" : "Thu Aug 25 18:38:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http://t.co/xu4WQ7C",
      "expanded_url" : "http://twitpic.com/6b2crh",
      "display_url" : "twitpic.com/6b2crh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "106776897265999872",
  "text" : "always does: http://t.co/xu4WQ7C",
  "id" : 106776897265999872,
  "created_at" : "Thu Aug 25 17:16:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106486767938580480",
  "geo" : {
  },
  "id_str" : "106753007533821952",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 wow look at you! remember, none of them are 18",
  "id" : 106753007533821952,
  "in_reply_to_status_id" : 106486767938580480,
  "created_at" : "Thu Aug 25 15:41:15 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 3, 17 ],
      "id_str" : "113114946",
      "id" : 113114946
    }, {
      "name" : "Starlight Apparel",
      "screen_name" : "starlightbikes",
      "indices" : [ 43, 58 ],
      "id_str" : "109032076",
      "id" : 109032076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106750069730062337",
  "text" : "my @ChrisKingBuzz R45 wheelset is finished @starlightbikes!! Super pumped to ride them!",
  "id" : 106750069730062337,
  "created_at" : "Thu Aug 25 15:29:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freshmanyear",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/ljdnSza",
      "expanded_url" : "http://4sq.com/ruLW8m",
      "display_url" : "4sq.com/ruLW8m"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304308964, -80.4234302044 ]
  },
  "id_str" : "106749349010223104",
  "text" : "#freshmanyear feels like yesterday (@ Randolph Hall) http://t.co/ljdnSza",
  "id" : 106749349010223104,
  "created_at" : "Thu Aug 25 15:26:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http://t.co/rqdu2yv",
      "expanded_url" : "http://4sq.com/rhh13Q",
      "display_url" : "4sq.com/rhh13Q"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "106720060931977217",
  "text" : "I'm at McBryde Hall (225 Stanger St., Drillfield Drive, Blacksburg) http://t.co/rqdu2yv",
  "id" : 106720060931977217,
  "created_at" : "Thu Aug 25 13:30:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106557926948339712",
  "text" : "really good WW race ride, almost won the sandy rd sprint!! long day of hw and such...time for some shut eye",
  "id" : 106557926948339712,
  "created_at" : "Thu Aug 25 02:46:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 69, 80 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 112, 119 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106340913680363520",
  "text" : "followed my twitterati, bought the cheaper book online, so I can buy @kreagannet something nice, get chipotle w @k8eb8e, + buy an airhorn!",
  "id" : 106340913680363520,
  "created_at" : "Wed Aug 24 12:23:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106165379272941568",
  "text" : "is it worth returning a textbook and buying it online to save $25?",
  "id" : 106165379272941568,
  "created_at" : "Wed Aug 24 00:46:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 3, 12 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106161400837185537",
  "text" : "RT @dmreagan: just beat @rumblinstumbn in around the world and cornhole",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "106160953451757568",
    "text" : "just beat @rumblinstumbn in around the world and cornhole",
    "id" : 106160953451757568,
    "created_at" : "Wed Aug 24 00:28:38 +0000 2011",
    "user" : {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "protected" : true,
      "id_str" : "70117835",
      "profile_image_url_https" : "https://si0.twimg.com/sticky/default_profile_images/default_profile_4_normal.png",
      "id" : 70117835,
      "verified" : false
    }
  },
  "id" : 106161400837185537,
  "created_at" : "Wed Aug 24 00:30:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whocarestweet",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106149100445110272",
  "text" : "just stubbed my toe...real bad. #whocarestweet",
  "id" : 106149100445110272,
  "created_at" : "Tue Aug 23 23:41:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "graduatingisscary",
      "indices" : [ 44, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106134888117321728",
  "text" : "career fair is Sept 28, workin on my resume #graduatingisscary",
  "id" : 106134888117321728,
  "created_at" : "Tue Aug 23 22:45:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106040336345866241",
  "text" : "walking home and back bc I forgot the bike lock key, today's #fail",
  "id" : 106040336345866241,
  "created_at" : "Tue Aug 23 16:29:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/9zKPUlM",
      "expanded_url" : "http://4sq.com/rbCe4t",
      "display_url" : "4sq.com/rbCe4t"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2304308964, -80.4234302044 ]
  },
  "id_str" : "106017381041717249",
  "text" : "Numerical Analysis w Dr. Borgaard (@ Randolph Hall) http://t.co/9zKPUlM",
  "id" : 106017381041717249,
  "created_at" : "Tue Aug 23 14:58:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "106007316079456256",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr taking an ODE class; first day, first model: snowshoe rabbits, canada lynx model haha",
  "id" : 106007316079456256,
  "created_at" : "Tue Aug 23 14:18:08 +0000 2011",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http://t.co/R9AOtj3",
      "expanded_url" : "http://4sq.com/nHWYfT",
      "display_url" : "4sq.com/nHWYfT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2305462186, -80.4217940569 ]
  },
  "id_str" : "106005533064048640",
  "text" : "in Modeling and Simulation of Biological Systems, it seems interesting! (@ McBryde Hall w/ 4 others) http://t.co/R9AOtj3",
  "id" : 106005533064048640,
  "created_at" : "Tue Aug 23 14:11:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodnight",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105842092613447680",
  "text" : "the tall bike is complete!! riding to class tomorrow, going to be amazing. long long long day #goodnight",
  "id" : 105842092613447680,
  "created_at" : "Tue Aug 23 03:21:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 36, 46 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 47, 59 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 60, 70 ],
      "id_str" : "45430885",
      "id" : 45430885
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 84, 97 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 98, 114 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "late",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "sick",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105800132699766784",
  "text" : "#late to cycling officers meeting w @vtcycling @runfasteraw @bdoyle613 @J_Gardner90 @williamenium @JacobnAndersson. MTB race gonna be #sick!",
  "id" : 105800132699766784,
  "created_at" : "Tue Aug 23 00:34:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette Torres",
      "screen_name" : "girlinblack",
      "indices" : [ 3, 15 ],
      "id_str" : "53983",
      "id" : 53983
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrvt",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "justfyi",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "winning",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105787015550861313",
  "text" : "RT @girlinblack: @andyreagan: There are more people here for #wrvt than were here for Ben Folds. #justfyi #winning",
  "retweeted_status" : {
    "source" : "<a href=\"http://ubersocial.com\" rel=\"nofollow\">UberSocial for BlackBerry</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrvt",
        "indices" : [ 44, 49 ]
      }, {
        "text" : "justfyi",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "winning",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "105777802875371520",
    "geo" : {
    },
    "id_str" : "105781606698057728",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan: There are more people here for #wrvt than were here for Ben Folds. #justfyi #winning",
    "id" : 105781606698057728,
    "in_reply_to_status_id" : 105777802875371520,
    "created_at" : "Mon Aug 22 23:21:15 +0000 2011",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Josette Torres",
      "screen_name" : "girlinblack",
      "protected" : false,
      "id_str" : "53983",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2347599229/bujlej4i1ksjaoi15rur_normal.jpeg",
      "id" : 53983,
      "verified" : false
    }
  },
  "id" : 105787015550861313,
  "created_at" : "Mon Aug 22 23:42:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 1, 10 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 15, 31 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http://t.co/3s8JVmu",
      "expanded_url" : "http://twitpic.com/6a5qdp",
      "display_url" : "twitpic.com/6a5qdp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105782254718038016",
  "text" : ".@dmreagan and @RumblinStumblin finished their cornhole boards! looking sweet: http://t.co/3s8JVmu",
  "id" : 105782254718038016,
  "created_at" : "Mon Aug 22 23:23:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Avenger",
      "screen_name" : "plaidavenger",
      "indices" : [ 11, 24 ],
      "id_str" : "14193991",
      "id" : 14193991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madness",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "wrvt",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105777802875371520",
  "text" : "amazing... @plaidavenger PACKS a 3000 person auditorium. there is nowhere to sit!! #madness #wrvt",
  "id" : 105777802875371520,
  "created_at" : "Mon Aug 22 23:06:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "virginiatech",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105777116125212672",
  "text" : "#virginiatech needs more bike parking for world regions class, woulda taken a pic but id look like a creeper lol",
  "id" : 105777116125212672,
  "created_at" : "Mon Aug 22 23:03:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noquestions",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105774469787811840",
  "text" : "most efficient way to eat pasta: sport #noquestions",
  "id" : 105774469787811840,
  "created_at" : "Mon Aug 22 22:52:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notime",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "cookfaster",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http://t.co/TfFzGti",
      "expanded_url" : "http://twitpic.com/6a59in",
      "display_url" : "twitpic.com/6a59in"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105772311344459777",
  "text" : "pasta before class at 7 #notime #cookfaster http://t.co/TfFzGti",
  "id" : 105772311344459777,
  "created_at" : "Mon Aug 22 22:44:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikedealswhileriding",
      "indices" : [ 62, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http://t.co/SgKMiKl",
      "expanded_url" : "http://twitpic.com/6a53ts",
      "display_url" : "twitpic.com/6a53ts"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105768780533215232",
  "text" : "sold Justin my old cassette and brake mid-ride, on the front! #bikedealswhileriding http://t.co/SgKMiKl",
  "id" : 105768780533215232,
  "created_at" : "Mon Aug 22 22:30:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105768285034909696",
  "text" : "awesome inaugural SAYG ride! 10+ people, lots of new faces.",
  "id" : 105768285034909696,
  "created_at" : "Mon Aug 22 22:28:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http://t.co/MPgCsQi",
      "expanded_url" : "http://twitpic.com/6a3hz7",
      "display_url" : "twitpic.com/6a3hz7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105729783412957184",
  "text" : "my door is appropriately decorated now: http://t.co/MPgCsQi",
  "id" : 105729783412957184,
  "created_at" : "Mon Aug 22 19:55:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Bull",
      "screen_name" : "redbull",
      "indices" : [ 22, 30 ],
      "id_str" : "17540485",
      "id" : 17540485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http://t.co/DFzT6Kq",
      "expanded_url" : "http://twitpic.com/6a2xr7",
      "display_url" : "twitpic.com/6a2xr7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105715957149859840",
  "text" : "can't agree more with @redbull on this one: http://t.co/DFzT6Kq",
  "id" : 105715957149859840,
  "created_at" : "Mon Aug 22 19:00:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105713595228237824",
  "text" : "awesome first d2 lunch w everyone!! just bought all my textbooks...$450 #ouch",
  "id" : 105713595228237824,
  "created_at" : "Mon Aug 22 18:50:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/yfo4101",
      "expanded_url" : "http://4sq.com/qF304X",
      "display_url" : "4sq.com/qF304X"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "105673173122564096",
  "text" : "sooo manyyy people! (@ Dietrick Dining Center) http://t.co/yfo4101",
  "id" : 105673173122564096,
  "created_at" : "Mon Aug 22 16:10:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris King ",
      "screen_name" : "ChrisKingBuzz",
      "indices" : [ 0, 14 ],
      "id_str" : "113114946",
      "id" : 113114946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105667631016722432",
  "geo" : {
  },
  "id_str" : "105670702522318849",
  "in_reply_to_user_id" : 113114946,
  "text" : "@ChrisKingBuzz Sick!! I wanted one a month ago, but wasn't patient and went with red, still looks awesome.",
  "id" : 105670702522318849,
  "in_reply_to_status_id" : 105667631016722432,
  "created_at" : "Mon Aug 22 16:00:33 +0000 2011",
  "in_reply_to_screen_name" : "ChrisKingBuzz",
  "in_reply_to_user_id_str" : "113114946",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105663980130930689",
  "geo" : {
  },
  "id_str" : "105665419762864128",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel hahaha who knows... well good luck at ALBANY!",
  "id" : 105665419762864128,
  "in_reply_to_status_id" : 105663980130930689,
  "created_at" : "Mon Aug 22 15:39:33 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105663453510893568",
  "geo" : {
  },
  "id_str" : "105663885528403969",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel you must've been too drunk to remember where you were going lol, i was sober and heard oswego!!",
  "id" : 105663885528403969,
  "in_reply_to_status_id" : 105663453510893568,
  "created_at" : "Mon Aug 22 15:33:28 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http://t.co/DaqwEHi",
      "expanded_url" : "http://4sq.com/pgtBAr",
      "display_url" : "4sq.com/pgtBAr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "105663035535917056",
  "text" : "well, they don't seem impossible. two homeworks due Friday to start! (@ Virginia Bioinformatics Institute (VBI)) http://t.co/DaqwEHi",
  "id" : 105663035535917056,
  "created_at" : "Mon Aug 22 15:30:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104966621109567488",
  "geo" : {
  },
  "id_str" : "105662700276817920",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel you too! sorry for the slow reply, but also glad to see that you got most of your partying out before classes at Oswego lol",
  "id" : 105662700276817920,
  "in_reply_to_status_id" : 104966621109567488,
  "created_at" : "Mon Aug 22 15:28:45 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anxious",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http://t.co/4veRug8",
      "expanded_url" : "http://bit.ly/oNGiiK",
      "display_url" : "bit.ly/oNGiiK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105613092003643392",
  "text" : "Baker's Dozen was a nice easy run: http://t.co/4veRug8 ...now to REAL ANALYSIS followed by ABSTRACT ALGEBRA ahhhhhhhh #anxious for these 2",
  "id" : 105613092003643392,
  "created_at" : "Mon Aug 22 12:11:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105593775946076160",
  "text" : "baker's dozen!",
  "id" : 105593775946076160,
  "created_at" : "Mon Aug 22 10:54:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105467668676620289",
  "text" : "got a bike lock now, thanks Trish! excited for bakers dozen tmrw @ 7am and d2 lunch w the tri team!",
  "id" : 105467668676620289,
  "created_at" : "Mon Aug 22 02:33:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105438738942918656",
  "geo" : {
  },
  "id_str" : "105465859149008896",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e you betcha. with 5 for a bike delivery, that puppy netted me 25 buckaroos. better than in a dumpster!",
  "id" : 105465859149008896,
  "in_reply_to_status_id" : 105438738942918656,
  "created_at" : "Mon Aug 22 02:26:34 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/b0Jm29N",
      "expanded_url" : "http://twitpic.com/69pq8o",
      "display_url" : "twitpic.com/69pq8o"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105422761438089216",
  "text" : "just delivered a QUEEN MATTRESS on my TRIKE!! Check it:  http://t.co/b0Jm29N",
  "id" : 105422761438089216,
  "created_at" : "Sun Aug 21 23:35:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 23, 32 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everynight",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http://t.co/6VGe0FN",
      "expanded_url" : "http://twitpic.com/69p0yg",
      "display_url" : "twitpic.com/69p0yg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105408187326398465",
  "text" : "spaghetti and roting w @dmreagan's homemade sauce #everynight http://t.co/6VGe0FN",
  "id" : 105408187326398465,
  "created_at" : "Sun Aug 21 22:37:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 5, 12 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "handy",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 48 ],
      "url" : "http://t.co/vdFcYlw",
      "expanded_url" : "http://twitpic.com/69oeid",
      "display_url" : "twitpic.com/69oeid"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105395526350024704",
  "text" : "hung @rkay21's mirror #handy http://t.co/vdFcYlw",
  "id" : 105395526350024704,
  "created_at" : "Sun Aug 21 21:47:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105380966918406144",
  "text" : "putting in new mtb bottom bracket, same model!",
  "id" : 105380966918406144,
  "created_at" : "Sun Aug 21 20:49:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "byefacebook",
      "indices" : [ 86, 98 ]
    }, {
      "text" : "fb",
      "indices" : [ 99, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105378908496596992",
  "text" : "has a hard semester starting tomorrow, and there will time later to spend on Facebook #byefacebook #fb",
  "id" : 105378908496596992,
  "created_at" : "Sun Aug 21 20:41:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "darn",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105378214838403072",
  "text" : "putting on the MTB seat that I won, I noticed that was strangely wide for a men's seat....google search and yup, it's a women's seat #darn",
  "id" : 105378214838403072,
  "created_at" : "Sun Aug 21 20:38:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "righttoolis90percentofthejob",
      "indices" : [ 89, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105294262484209664",
  "text" : "went to go MTBing w Christian and others, but he nor I have the right BB tool for my MTB #righttoolis90percentofthejob",
  "id" : 105294262484209664,
  "created_at" : "Sun Aug 21 15:04:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 36, 45 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 94, 101 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/JmkceyY",
      "expanded_url" : "http://app.strava.com/rides/burkes-garden-1308104?ref=1MT1yaWRlX3NoYXJlOzI9dHdpdHRlcjs0PTE4Mjk%3D",
      "display_url" : "app.strava.com/rides/burkes-g…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105157120541999104",
  "text" : "WOW awesome ride! A 4hr century... \"@aJohnnyD: went for a 103 mile road ride. Check it out on @Strava http://t.co/JmkceyY\"",
  "id" : 105157120541999104,
  "created_at" : "Sun Aug 21 05:59:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 43 ],
      "url" : "http://t.co/Kzgvqsz",
      "expanded_url" : "http://twitpic.com/698nr9",
      "display_url" : "twitpic.com/698nr9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "105095255992434688",
  "text" : "hipster kitty (its pbr) http://t.co/Kzgvqsz",
  "id" : 105095255992434688,
  "created_at" : "Sun Aug 21 01:53:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105043589515575297",
  "geo" : {
  },
  "id_str" : "105084869083799553",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 onion fire tower?",
  "id" : 105084869083799553,
  "in_reply_to_status_id" : 105043589515575297,
  "created_at" : "Sun Aug 21 01:12:39 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doesntgetbetter",
      "indices" : [ 75, 91 ]
    }, {
      "text" : "coolnightairinmyface",
      "indices" : [ 92, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105084696727261184",
  "text" : "6 pack in the chrome and riding the fixie at night thru bburg to a potluck #doesntgetbetter #coolnightairinmyface",
  "id" : 105084696727261184,
  "created_at" : "Sun Aug 21 01:11:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatty",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "didntmind",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105039199379529728",
  "text" : "cooked a pound of rotini so I could have some for lunch tomorrow. no saran wrap = ate it all #fatty #didntmind",
  "id" : 105039199379529728,
  "created_at" : "Sat Aug 20 22:11:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http://t.co/GMZfUT7",
      "expanded_url" : "http://4sq.com/ndaTOs",
      "display_url" : "4sq.com/ndaTOs"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2341, -80.4091 ]
  },
  "id_str" : "105023930519134208",
  "text" : "I'm at International Bicycle Barracks (523 Jackson St, Blacksburg) http://t.co/GMZfUT7",
  "id" : 105023930519134208,
  "created_at" : "Sat Aug 20 21:10:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "notmyday",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "105017142101032960",
  "text" : "got off I-81 to take the backway to avoid construction, and took a wrong turn...got a nice tour of SW VA #fail #notmyday",
  "id" : 105017142101032960,
  "created_at" : "Sat Aug 20 20:43:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wahhh",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104968490045284352",
  "text" : "the dew messed up my cornhole boards, forgot both running shorts + bottle, not going to make homeplace ride, and only getting 35mpg #wahhh",
  "id" : 104968490045284352,
  "created_at" : "Sat Aug 20 17:30:12 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104873976681086976",
  "text" : "here I come #blacksburg",
  "id" : 104873976681086976,
  "created_at" : "Sat Aug 20 11:14:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 29, 45 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http://t.co/Cnf8vLW",
      "expanded_url" : "http://4sq.com/naH6V3",
      "display_url" : "4sq.com/naH6V3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0480471, -76.15458 ]
  },
  "id_str" : "104742837584801793",
  "text" : "grilled salmon 4 dinner from @rumblinstumblin, and Empire Black Magic to top off my time home! http://t.co/Cnf8vLW",
  "id" : 104742837584801793,
  "created_at" : "Sat Aug 20 02:33:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 29, 40 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/JhCkSua",
      "expanded_url" : "http://twitpic.com/68n2jb",
      "display_url" : "twitpic.com/68n2jb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104698448934219776",
  "text" : "had fun chillin w brotherman @kreagannet, he's got a nice place up in Syr. Cornhole boards finished!! http://t.co/JhCkSua",
  "id" : 104698448934219776,
  "created_at" : "Fri Aug 19 23:37:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne County Life",
      "screen_name" : "waynecountylife",
      "indices" : [ 0, 16 ],
      "id_str" : "37779442",
      "id" : 37779442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104603852715724802",
  "geo" : {
  },
  "id_str" : "104606308010962944",
  "in_reply_to_user_id" : 37779442,
  "text" : "@waynecountylife 99 Chapparal 21ft w cabin. List is $8990",
  "id" : 104606308010962944,
  "in_reply_to_status_id" : 104603852715724802,
  "created_at" : "Fri Aug 19 17:31:01 +0000 2011",
  "in_reply_to_screen_name" : "waynecountylife",
  "in_reply_to_user_id_str" : "37779442",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 58, 67 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104606035196645376",
  "text" : "survived the noon heat and sun for a nice 8 miler, my Mom @dmreagan joined for the latter half! Had to tell her to slow down!!",
  "id" : 104606035196645376,
  "created_at" : "Fri Aug 19 17:29:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bburg",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104393278606159872",
  "geo" : {
  },
  "id_str" : "104604595745079296",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud sounds awesome!! Im attempting to make it to #bburg for homeplace ride!",
  "id" : 104604595745079296,
  "in_reply_to_status_id" : 104393278606159872,
  "created_at" : "Fri Aug 19 17:24:13 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104406289148416000",
  "geo" : {
  },
  "id_str" : "104604061562699776",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 I will let you know soon! (blog post coming)",
  "id" : 104604061562699776,
  "in_reply_to_status_id" : 104406289148416000,
  "created_at" : "Fri Aug 19 17:22:06 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104362743171256320",
  "text" : "lightning orange clouds",
  "id" : 104362743171256320,
  "created_at" : "Fri Aug 19 01:23:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104346527346077696",
  "geo" : {
  },
  "id_str" : "104362610962595840",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 I wanna race you down ...me on foot",
  "id" : 104362610962595840,
  "in_reply_to_status_id" : 104346527346077696,
  "created_at" : "Fri Aug 19 01:22:40 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boomboommexmex",
      "indices" : [ 41, 56 ]
    }, {
      "text" : "mmmm",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104266418119380992",
  "text" : "and I couldn't be home for two weeks w/o #boomboommexmex, grabbed a couple tacos on the way home #mmmm",
  "id" : 104266418119380992,
  "created_at" : "Thu Aug 18 19:00:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 21, 30 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104266136677400577",
  "text" : "got cracked corn for @dmreagan to make cornhole bags, and paint to totally finish the boards",
  "id" : 104266136677400577,
  "created_at" : "Thu Aug 18 18:59:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 12, 28 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 96, 104 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http://t.co/HnBFOIR",
      "expanded_url" : "http://bit.ly/pvFvLP",
      "display_url" : "bit.ly/pvFvLP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "104217724099641344",
  "text" : "fast walk w @rumblinstumblin by andyreagan at Garmin Connect - Details: http://t.co/HnBFOIR via @AddThis",
  "id" : 104217724099641344,
  "created_at" : "Thu Aug 18 15:46:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "104038840632745985",
  "text" : "RT @DZdan1: The CNY \"B\" team goes 5-3 and finishes in the top 32 of 104. We were the talk of the park. Good week @theDREAMbudday.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "104013900164505600",
    "text" : "The CNY \"B\" team goes 5-3 and finishes in the top 32 of 104. We were the talk of the park. Good week @theDREAMbudday.",
    "id" : 104013900164505600,
    "created_at" : "Thu Aug 18 02:17:00 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 104038840632745985,
  "created_at" : "Thu Aug 18 03:56:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 24, 40 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 109 ],
      "url" : "http://t.co/Jcj2LaJ",
      "expanded_url" : "http://twitpic.com/67p6vy",
      "display_url" : "twitpic.com/67p6vy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103982268414042113",
  "text" : "now to play the old man @rumblinstumblin in some cornhole on our nearly completed boards! http://t.co/Jcj2LaJ",
  "id" : 103982268414042113,
  "created_at" : "Thu Aug 18 00:11:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103981959956533248",
  "text" : "got between 1350-1500 on the GRE (it gives a range immediately) and then went on a sweet 8mi moderate/easy run!",
  "id" : 103981959956533248,
  "created_at" : "Thu Aug 18 00:10:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103886344018870272",
  "text" : "go time",
  "id" : 103886344018870272,
  "created_at" : "Wed Aug 17 17:50:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prettysureitsbroken",
      "indices" : [ 85, 105 ]
    }, {
      "text" : "fatty",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103688014043160576",
  "text" : "fun bonfire, took a frisbee to the nose at Mach speed and ate a whole box of grahams #prettysureitsbroken #fatty",
  "id" : 103688014043160576,
  "created_at" : "Wed Aug 17 04:42:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 3, 12 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 22, 33 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "starsoutcigarsout",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103620434360156160",
  "text" : "RT @DKnick88: Over to @andyreagan house for a fire! #starsoutcigarsout",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 8, 19 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "starsoutcigarsout",
        "indices" : [ 38, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "103612415513600000",
    "text" : "Over to @andyreagan house for a fire! #starsoutcigarsout",
    "id" : 103612415513600000,
    "created_at" : "Tue Aug 16 23:41:39 +0000 2011",
    "user" : {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "protected" : false,
      "id_str" : "204631321",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3194859210/2cfdf039ddb963cafa9970cf96a5b8d2_normal.jpeg",
      "id" : 204631321,
      "verified" : false
    }
  },
  "id" : 103620434360156160,
  "created_at" : "Wed Aug 17 00:13:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103537439196459008",
  "text" : "GRE practice done. score: 1370-1520 (it only gives a range). big day is tmrw",
  "id" : 103537439196459008,
  "created_at" : "Tue Aug 16 18:43:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnasuck",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103474727603019777",
  "text" : "time to do that GRE thang (practice test now, real thing tmrw) #gonnasuck",
  "id" : 103474727603019777,
  "created_at" : "Tue Aug 16 14:34:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103474343211839489",
  "geo" : {
  },
  "id_str" : "103474588272431106",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e yay! :)",
  "id" : 103474588272431106,
  "in_reply_to_status_id" : 103474343211839489,
  "created_at" : "Tue Aug 16 14:33:58 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybeworthit",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103311913475260416",
  "text" : "actually checked, and I'm really only one class away from Chemistry minor... #maybeworthit",
  "id" : 103311913475260416,
  "created_at" : "Tue Aug 16 03:47:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http://t.co/5EhwKsT",
      "expanded_url" : "http://bit.ly/kCC1tp",
      "display_url" : "bit.ly/kCC1tp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103309139391946752",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e hopefully this is just nerdy enough to make up for me being the LAST to wish you a happy bday!! http://t.co/5EhwKsT",
  "id" : 103309139391946752,
  "created_at" : "Tue Aug 16 03:36:32 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103289459516248064",
  "text" : "16mi run was killer at marathon pace, should'nt have done it the day after a hard TT, but I finished!",
  "id" : 103289459516248064,
  "created_at" : "Tue Aug 16 02:18:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kait",
      "screen_name" : "Kaitia",
      "indices" : [ 0, 7 ],
      "id_str" : "31015715",
      "id" : 31015715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103233348046036992",
  "geo" : {
  },
  "id_str" : "103288045406666752",
  "in_reply_to_user_id" : 31015715,
  "text" : "@Kaitia right!?",
  "id" : 103288045406666752,
  "in_reply_to_status_id" : 103233348046036992,
  "created_at" : "Tue Aug 16 02:12:43 +0000 2011",
  "in_reply_to_screen_name" : "Kaitia",
  "in_reply_to_user_id_str" : "31015715",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfectscore",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103176946149621760",
  "text" : "finished reading the GRE prep book...time for a nap before my 16mi run! practice test tmrw, real thing wed, gettin a #perfectscore (on math)",
  "id" : 103176946149621760,
  "created_at" : "Mon Aug 15 18:51:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103172904027557888",
  "geo" : {
  },
  "id_str" : "103176273630728192",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet nice! you actually started 20 sec behind the team that beat us, but they had the guy who won by minutes...he crushed",
  "id" : 103176273630728192,
  "in_reply_to_status_id" : 103172904027557888,
  "created_at" : "Mon Aug 15 18:48:35 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 34 ],
      "url" : "http://t.co/tHZcSMr",
      "expanded_url" : "http://twitpic.com/66lufn",
      "display_url" : "twitpic.com/66lufn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103144305937494016",
  "text" : "like the ocean http://t.co/tHZcSMr",
  "id" : 103144305937494016,
  "created_at" : "Mon Aug 15 16:41:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http://t.co/EFn5KuB",
      "expanded_url" : "http://4sq.com/qYLcT8",
      "display_url" : "4sq.com/qYLcT8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.2697962333, -76.9788966333 ]
  },
  "id_str" : "103137527271137280",
  "text" : "grilled haddock! (@ Abe's Waterfront) http://t.co/EFn5KuB",
  "id" : 103137527271137280,
  "created_at" : "Mon Aug 15 16:14:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103137342075834368",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan boat delivered, going for a walk on the lake",
  "id" : 103137342075834368,
  "created_at" : "Mon Aug 15 16:13:53 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 7, 23 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrydriving",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "103113161833586688",
  "text" : "my dad @RumblinStumblin insists on \"let's keep going on 38\" until we almost hit the lake anyway...finally he listens to gps #countrydriving",
  "id" : 103113161833586688,
  "created_at" : "Mon Aug 15 14:37:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http://t.co/PyM2xCT",
      "expanded_url" : "http://twitpic.com/66jmzv",
      "display_url" : "twitpic.com/66jmzv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "103103921337282561",
  "text" : "on the way to Sodus Bay to sell our boat http://t.co/PyM2xCT",
  "id" : 103103921337282561,
  "created_at" : "Mon Aug 15 14:01:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102939368687271937",
  "geo" : {
  },
  "id_str" : "102941016256036864",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 nice work!",
  "id" : 102941016256036864,
  "in_reply_to_status_id" : 102939368687271937,
  "created_at" : "Mon Aug 15 03:13:45 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102929396339445760",
  "text" : "was FIRST of 375 bikers by *1:05* on the biking alone, but a 3min transistion = 13th overall. needed to sign up earlier for a better spot!!",
  "id" : 102929396339445760,
  "created_at" : "Mon Aug 15 02:27:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 81, 92 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 93, 102 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 120, 136 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102928934731132930",
  "text" : "results for 2011 Great Race posted, Team Reagan coming in second place! Nice job @kreagannet @dmreagan, and our sponsor @RumblinStumblin",
  "id" : 102928934731132930,
  "created_at" : "Mon Aug 15 02:25:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 85, 96 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 101, 110 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102759652411973634",
  "text" : "passed like 150 people, passed by no one! avg 23.4mph, unofficial time of 24:45 (w.o @kreagannet and @dmreagan's transitions)",
  "id" : 102759652411973634,
  "created_at" : "Sun Aug 14 15:13:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102727299048280064",
  "text" : "the Great Race starts in 25min, bike leg domination coming up soon",
  "id" : 102727299048280064,
  "created_at" : "Sun Aug 14 13:04:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http://t.co/SJI7Oq5",
      "expanded_url" : "http://twitpic.com/65iaej",
      "display_url" : "twitpic.com/65iaej"
    } ]
  },
  "geo" : {
  },
  "id_str" : "102417206742228992",
  "text" : "changin the oil: http://t.co/SJI7Oq5",
  "id" : 102417206742228992,
  "created_at" : "Sat Aug 13 16:32:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102203267135700992",
  "geo" : {
  },
  "id_str" : "102203967534137344",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 truth. uh oh, well be nice to it!",
  "id" : 102203967534137344,
  "in_reply_to_status_id" : 102203267135700992,
  "created_at" : "Sat Aug 13 02:24:59 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102203249033101313",
  "geo" : {
  },
  "id_str" : "102203839335243777",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan should be. peaks after midnight, but its gonna be hard to see with a full moon.",
  "id" : 102203839335243777,
  "in_reply_to_status_id" : 102203249033101313,
  "created_at" : "Sat Aug 13 02:24:28 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102203065746202624",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan meteor shower tonight, maybe you could see your first shooting star!",
  "id" : 102203065746202624,
  "created_at" : "Sat Aug 13 02:21:24 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102200991537041410",
  "geo" : {
  },
  "id_str" : "102202827992088576",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 you mostly have...",
  "id" : 102202827992088576,
  "in_reply_to_status_id" : 102200991537041410,
  "created_at" : "Sat Aug 13 02:20:27 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "missedmyfriday",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "102126133931282432",
  "text" : "just woke up from an 8 hour nap, whoops. #missedmyfriday",
  "id" : 102126133931282432,
  "created_at" : "Fri Aug 12 21:15:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 10, 21 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102049713515278337",
  "geo" : {
  },
  "id_str" : "102125095820083200",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @skholden17 it is, mostly!! It's oil, egg yolk, and vinegar or lemon juice.",
  "id" : 102125095820083200,
  "in_reply_to_status_id" : 102049713515278337,
  "created_at" : "Fri Aug 12 21:11:34 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101988867984461824",
  "geo" : {
  },
  "id_str" : "101989593229955072",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving Skaneateles Lake, its one of the finger lakes in upstate NY, where im from. Beautiful lake, city of Syracuse drinks it straight!",
  "id" : 101989593229955072,
  "in_reply_to_status_id" : 101988867984461824,
  "created_at" : "Fri Aug 12 12:13:08 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 35, 51 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/abfF0X7",
      "expanded_url" : "http://twitpic.com/64u8dp",
      "display_url" : "twitpic.com/64u8dp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101986493614141440",
  "text" : "diggin up potatoes for breakfast w @RumblinStumblin http://t.co/abfF0X7",
  "id" : 101986493614141440,
  "created_at" : "Fri Aug 12 12:00:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 30, 39 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http://t.co/5lEtHXu",
      "expanded_url" : "http://twitpic.com/64shiz",
      "display_url" : "twitpic.com/64shiz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101950822287548416",
  "text" : "up @ 5 for a sunrise kayak! w @dmreagan http://t.co/5lEtHXu",
  "id" : 101950822287548416,
  "created_at" : "Fri Aug 12 09:39:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 41, 52 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 62, 69 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 70, 79 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 80, 91 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101860362013519872",
  "text" : "tullys was just what I needed, good call @skholden17! dtown w @DZdan1 @DKnick88 @skholden17 and @MathewFox1!!",
  "id" : 101860362013519872,
  "created_at" : "Fri Aug 12 03:39:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stein Kåre Holden",
      "screen_name" : "SkHolden",
      "indices" : [ 30, 39 ],
      "id_str" : "753063618",
      "id" : 753063618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http://t.co/VxpAQvb",
      "expanded_url" : "http://bit.ly/n09xsJ",
      "display_url" : "bit.ly/n09xsJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101797461584125954",
  "text" : "thena nice 5mi Recovery Run w @skholden. think she learned not to eat a whole footlong b4! Garmin Connect - Details: http://t.co/VxpAQvb",
  "id" : 101797461584125954,
  "created_at" : "Thu Aug 11 23:29:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 11, 18 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 133, 140 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101797123296731137",
  "text" : "meanwhile, @dzdan1 lost his favorite disc en route 2 a disc golf victory on a new course. summer standings may be final, 3-2.5-1 for @dzdan1",
  "id" : 101797123296731137,
  "created_at" : "Thu Aug 11 23:28:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 51, 62 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 107, 114 ],
      "id_str" : "15324722",
      "id" : 15324722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http://t.co/eEnSqY9",
      "expanded_url" : "http://bit.ly/mVEWWu",
      "display_url" : "bit.ly/mVEWWu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101796635067158528",
  "text" : "Great Race team practice 2day @ Emerson Park, only @kreagannet practiced! Lookin good still, 5mph for 2mi. @garmin: http://t.co/eEnSqY9 #fb",
  "id" : 101796635067158528,
  "created_at" : "Thu Aug 11 23:26:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 38, 54 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 92, 99 ],
      "id_str" : "15324722",
      "id" : 15324722
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 125, 133 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http://t.co/9zXkXVX",
      "expanded_url" : "http://bit.ly/opFFyW",
      "display_url" : "bit.ly/opFFyW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101795684839211008",
  "text" : "sub 15min/mi walking today for 2.3mi, @rumblinstumblin gettin it!  Marcellus Park Walk from @garmin: http://t.co/9zXkXVX via @AddThis",
  "id" : 101795684839211008,
  "created_at" : "Thu Aug 11 23:22:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 12, 28 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 33, 42 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 67, 74 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 76, 87 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 93, 102 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9767090875, -76.3356685638 ]
  },
  "id_str" : "101692105579184134",
  "text" : "nice walk w @rumblinstumblin and @dmreagan. now headed to Auburn w @dzdan1, @kreagannet, and @dmreagan! http://4sq.com/pIA7Y1",
  "id" : 101692105579184134,
  "created_at" : "Thu Aug 11 16:31:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 52, 66 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http://t.co/DKFJGn6",
      "expanded_url" : "http://bit.ly/pg6TjH",
      "display_url" : "bit.ly/pg6TjH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101447957395668992",
  "text" : "out with the old, in with the new. first run in new @brooksrunning Ghost 4 was excellent. 9mi tempo w/ 5mi @ 7min: http://t.co/DKFJGn6 #fb",
  "id" : 101447957395668992,
  "created_at" : "Thu Aug 11 00:20:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsgo",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101422194189549570",
  "text" : "9 mile tempo run, 5 miles at 15k-half pace #letsgo",
  "id" : 101422194189549570,
  "created_at" : "Wed Aug 10 22:38:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 17, 33 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0059875333, -76.3102537 ]
  },
  "id_str" : "101406915002777601",
  "text" : "fresh fruit stop @rumblinstumblin (@ Oliver's Produce) http://4sq.com/oFOfFD",
  "id" : 101406915002777601,
  "created_at" : "Wed Aug 10 21:37:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 12, 26 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.051442, -76.06945885 ]
  },
  "id_str" : "101385050087620608",
  "text" : "getting the @brooksrunning Ghost 4's (@ Fleet Feet Syracuse) http://4sq.com/oWfmq7",
  "id" : 101385050087620608,
  "created_at" : "Wed Aug 10 20:10:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 44, 51 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101311650711355394",
  "text" : "headed out for another round of disc golf w @DZdan1, the saga continues.",
  "id" : 101311650711355394,
  "created_at" : "Wed Aug 10 15:19:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101284928049774592",
  "text" : "RT @MathewFox1: Great day to be great",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101281943064285184",
    "text" : "Great day to be great",
    "id" : 101281943064285184,
    "created_at" : "Wed Aug 10 13:21:11 +0000 2011",
    "user" : {
      "name" : "Mr. Fox",
      "screen_name" : "El__Capitan1",
      "protected" : false,
      "id_str" : "91222764",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3294564583/68563b55baa3d8d0f81444b34ed58359_normal.jpeg",
      "id" : 91222764,
      "verified" : false
    }
  },
  "id" : 101284928049774592,
  "created_at" : "Wed Aug 10 13:33:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 94, 103 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/Qrvr1Rg",
      "expanded_url" : "http://bit.ly/rhcgtu",
      "display_url" : "bit.ly/rhcgtu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101284867165274112",
  "text" : "she left my Garmin on all night, but also ran a 7:16 mile (avg 8, 4 5mi) yesterday! Nice work @dmreagan!! Check it out: http://t.co/Qrvr1Rg",
  "id" : 101284867165274112,
  "created_at" : "Wed Aug 10 13:32:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101227173804908544",
  "geo" : {
  },
  "id_str" : "101283447011688449",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel you could've seen sunny there again haha",
  "id" : 101283447011688449,
  "in_reply_to_status_id" : 101227173804908544,
  "created_at" : "Wed Aug 10 13:27:10 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 15, 22 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xyzaffair",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101134292838649857",
  "text" : "true story... \"@DZdan1: Despite my attempts to sabotage our team, we didn't finish last at trivia night #xyzaffair\"",
  "id" : 101134292838649857,
  "created_at" : "Wed Aug 10 03:34:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Mick Hagan",
      "screen_name" : "theKIDSnice",
      "indices" : [ 12, 24 ],
      "id_str" : "288612882",
      "id" : 288612882
    }, {
      "name" : "Sam Sherman",
      "screen_name" : "SMSherman",
      "indices" : [ 41, 51 ],
      "id_str" : "128663009",
      "id" : 128663009
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 52, 63 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Hannah Weeks",
      "screen_name" : "anasemanas",
      "indices" : [ 64, 75 ],
      "id_str" : "40995810",
      "id" : 40995810
    }, {
      "name" : "lindz",
      "screen_name" : "lindzshark",
      "indices" : [ 76, 87 ],
      "id_str" : "230893616",
      "id" : 230893616
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stepdownbitch",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101089261901721600",
  "text" : "RT @DZdan1: @theKIDSnice @theDREAMbudday @SMSherman @andyreagan @anasemanas @lindzshark drinkin and thinkin baby TRIVIA NIGHT #stepdownbitch",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mick Hagan",
        "screen_name" : "theKIDSnice",
        "indices" : [ 0, 12 ],
        "id_str" : "288612882",
        "id" : 288612882
      }, {
        "name" : "Sam Sherman",
        "screen_name" : "SMSherman",
        "indices" : [ 29, 39 ],
        "id_str" : "128663009",
        "id" : 128663009
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 40, 51 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Hannah Weeks",
        "screen_name" : "anasemanas",
        "indices" : [ 52, 63 ],
        "id_str" : "40995810",
        "id" : 40995810
      }, {
        "name" : "lindz",
        "screen_name" : "lindzshark",
        "indices" : [ 64, 75 ],
        "id_str" : "230893616",
        "id" : 230893616
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stepdownbitch",
        "indices" : [ 114, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "101082204779712512",
    "in_reply_to_user_id" : 288612882,
    "text" : "@theKIDSnice @theDREAMbudday @SMSherman @andyreagan @anasemanas @lindzshark drinkin and thinkin baby TRIVIA NIGHT #stepdownbitch",
    "id" : 101082204779712512,
    "created_at" : "Wed Aug 10 00:07:30 +0000 2011",
    "in_reply_to_screen_name" : "theKIDSnice",
    "in_reply_to_user_id_str" : "288612882",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 101089261901721600,
  "created_at" : "Wed Aug 10 00:35:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http://t.co/QYTj5a3",
      "expanded_url" : "http://twitpic.com/63nq9l",
      "display_url" : "twitpic.com/63nq9l"
    } ]
  },
  "geo" : {
  },
  "id_str" : "101081853758406656",
  "text" : "at Coleman's for trivia night! check out the only upside down stop light in the US: http://t.co/QYTj5a3",
  "id" : 101081853758406656,
  "created_at" : "Wed Aug 10 00:06:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0477691826, -76.1818921566 ]
  },
  "id_str" : "101081834473005057",
  "text" : "I'm at Coleman's Authentic Irish Pub (100 S Lowell Ave, at Tompkins St, Syracuse) w/ 8 others http://4sq.com/npOpro",
  "id" : 101081834473005057,
  "created_at" : "Wed Aug 10 00:06:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101063985729781760",
  "text" : "had a blast checking out a future potential lake house on skan lake! even got to take a swim, amazing water",
  "id" : 101063985729781760,
  "created_at" : "Tue Aug 09 22:55:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 56, 63 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 67, 78 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "101005131088277504",
  "text" : "and the Great Summer 2011 Disc Golf Classic now sits at @DZdan1 2, @andyreagan 1.5 (9 holes = .5)",
  "id" : 101005131088277504,
  "created_at" : "Tue Aug 09 19:01:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 12, 23 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "John Schlegel",
      "screen_name" : "jschlegs31",
      "indices" : [ 42, 53 ],
      "id_str" : "248895700",
      "id" : 248895700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100788924556902400",
  "text" : "RT @DZdan1: @andyreagan and I stuck it to @jschlegs31 and Phil in spades tonight. Relaxing and disc golf in the morning.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "John Schlegel",
        "screen_name" : "jschlegs31",
        "indices" : [ 30, 41 ],
        "id_str" : "248895700",
        "id" : 248895700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100786918425497600",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan and I stuck it to @jschlegs31 and Phil in spades tonight. Relaxing and disc golf in the morning.",
    "id" : 100786918425497600,
    "created_at" : "Tue Aug 09 04:34:08 +0000 2011",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 100788924556902400,
  "created_at" : "Tue Aug 09 04:42:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 19, 26 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100788759557189632",
  "text" : "then won some $$ w @DZdan1 playin spades, now exhausted",
  "id" : 100788759557189632,
  "created_at" : "Tue Aug 09 04:41:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 109, 118 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 119, 135 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100788531605147648",
  "text" : "awesome night. salmon, Gatorade then out for maple ice cream, then homemade bread and grapes to recover! thx @dmreagan @RumblinStumblin",
  "id" : 100788531605147648,
  "created_at" : "Tue Aug 09 04:40:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100755543114780672",
  "geo" : {
  },
  "id_str" : "100787915042467840",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD wow!! congratulations man.",
  "id" : 100787915042467840,
  "in_reply_to_status_id" : 100755543114780672,
  "created_at" : "Tue Aug 09 04:38:06 +0000 2011",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 120, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http://t.co/vrROscY",
      "expanded_url" : "http://bit.ly/o50QF4",
      "display_url" : "bit.ly/o50QF4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "100732644085612544",
  "text" : "ran to dtown Skaneateles and BACK from my house!! Longest run ever, 15mi, and I felt great. Garmin: http://t.co/vrROscY #fb",
  "id" : 100732644085612544,
  "created_at" : "Tue Aug 09 00:58:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "fb",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100658252064362496",
  "text" : "went to the Oakley store to get lenses for the pair I found, and they aren't real #fail #fb",
  "id" : 100658252064362496,
  "created_at" : "Mon Aug 08 20:02:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100609580102459392",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet you ever gonna come home bro?",
  "id" : 100609580102459392,
  "created_at" : "Mon Aug 08 16:49:27 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100588719345631232",
  "geo" : {
  },
  "id_str" : "100608652242726912",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 im running to skan and back once it cools off tonight",
  "id" : 100608652242726912,
  "in_reply_to_status_id" : 100588719345631232,
  "created_at" : "Mon Aug 08 16:45:46 +0000 2011",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Student",
      "screen_name" : "AmazonStudent",
      "indices" : [ 71, 85 ],
      "id_str" : "166707531",
      "id" : 166707531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100590177034047488",
  "text" : "just bought a GRE test prep book... got it w 2day shipping for 17 from @AmazonStudent, it was 41 w slow shipping from ETS #win",
  "id" : 100590177034047488,
  "created_at" : "Mon Aug 08 15:32:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 3, 10 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 45, 56 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 61, 68 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100584045557194752",
  "text" : "RT @sspis1: frisbee golf+spades= epic day w/ @andyreagan and @DZdan1",
  "id" : 100584045557194752,
  "created_at" : "Mon Aug 08 15:07:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 81, 89 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http://t.co/Ddur86v",
      "expanded_url" : "http://bit.ly/pNY7Vt",
      "display_url" : "bit.ly/pNY7Vt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "100222294324027392",
  "text" : "Quick 5mi run by andyreagan at Garmin Connect - Details: http://t.co/Ddur86v via @AddThis",
  "id" : 100222294324027392,
  "created_at" : "Sun Aug 07 15:10:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100197025471135745",
  "text" : "woke up too late to beat the heat on a long run... so its a quick 5",
  "id" : 100197025471135745,
  "created_at" : "Sun Aug 07 13:30:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 45, 56 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 97, 104 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100085442292101120",
  "text" : "RT @DZdan1: Good seeing and catching up with @andyreagan tonight. Busy day tomorrow with him and @sspis1! Can't wait. Night.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 33, 44 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Sam Spisiak",
        "screen_name" : "sspis1",
        "indices" : [ 85, 92 ],
        "id_str" : "282847130",
        "id" : 282847130
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "100083982359732224",
    "text" : "Good seeing and catching up with @andyreagan tonight. Busy day tomorrow with him and @sspis1! Can't wait. Night.",
    "id" : 100083982359732224,
    "created_at" : "Sun Aug 07 06:00:55 +0000 2011",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 100085442292101120,
  "created_at" : "Sun Aug 07 06:06:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 20, 27 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 66, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http://t.co/4APqk5x",
      "expanded_url" : "http://twitpic.com/629wjq",
      "display_url" : "twitpic.com/629wjq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "100080173172531200",
  "text" : "worlds largest most @DZdan1's house. must've found his roid stash #fb http://t.co/4APqk5x",
  "id" : 100080173172531200,
  "created_at" : "Sun Aug 07 05:45:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "100029716454588417",
  "text" : "HOME! 596.8mi in 11hrs @ 38.52mpg. highlights included two powernaps, two rumble strip touches, and braking four times on I-81 total",
  "id" : 100029716454588417,
  "created_at" : "Sun Aug 07 02:25:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 68, 77 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 78, 85 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99988523544875008",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin be home in two hours according to DROID. @DKnick88 @DZdan1 hang out later tonight?",
  "id" : 99988523544875008,
  "created_at" : "Sat Aug 06 23:41:36 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99848035126882306",
  "text" : "packed, got my last free d2 breakfast ha, and on the road (at a stoplight lol) now!",
  "id" : 99848035126882306,
  "created_at" : "Sat Aug 06 14:23:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99822475852001280",
  "text" : "drop/add is open! so many fun sounding math classes to take...but history of mathematics, and applications of math modeling conflict",
  "id" : 99822475852001280,
  "created_at" : "Sat Aug 06 12:41:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99617306023432192",
  "text" : "ran the first quarter in 63 (on pace for a 4:12 mile) then proceeded to explode extremely massively. ouch. finished in like 5:20",
  "id" : 99617306023432192,
  "created_at" : "Fri Aug 05 23:06:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99602242306445312",
  "text" : "running to the race as my warmup, so no phone aka results until I get home!",
  "id" : 99602242306445312,
  "created_at" : "Fri Aug 05 22:06:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http://t.co/qB2CllJ",
      "expanded_url" : "http://twitpic.com/61hi6l",
      "display_url" : "twitpic.com/61hi6l"
    } ]
  },
  "geo" : {
  },
  "id_str" : "99598812821200896",
  "text" : "the shirts are sweet: http://t.co/qB2CllJ",
  "id" : 99598812821200896,
  "created_at" : "Fri Aug 05 21:53:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 68, 80 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99598673050222592",
  "text" : "just signed up for the Draper Mile! put down expected time: 4:59 ...@leermatthis imma need u after if I get it lol",
  "id" : 99598673050222592,
  "created_at" : "Fri Aug 05 21:52:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 3, 19 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99572871424262145",
  "text" : "RT @BlacksburgStuff: Tomorrow's weather is unpredictable, so go to Steppin' Out tonight!  :D",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "99572052603846656",
    "text" : "Tomorrow's weather is unpredictable, so go to Steppin' Out tonight!  :D",
    "id" : 99572052603846656,
    "created_at" : "Fri Aug 05 20:06:41 +0000 2011",
    "user" : {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "protected" : false,
      "id_str" : "226946313",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1354924918/Downtown_Blacksburg_from_top_of_crane_normal.jpg",
      "id" : 226946313,
      "verified" : false
    }
  },
  "id" : 99572871424262145,
  "created_at" : "Fri Aug 05 20:09:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99572854114361344",
  "text" : "after I left @vbiatvt at 3, finally, officially dropped chemical eng. and chemistry as majors! and picked up mtb bike from East Coasters :)",
  "id" : 99572854114361344,
  "created_at" : "Fri Aug 05 20:09:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99572529496203264",
  "text" : "final presentations this morning went awesome! looking forward to continuing on the project in the fall",
  "id" : 99572529496203264,
  "created_at" : "Fri Aug 05 20:08:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99304157793619969",
  "text" : "good potluck, thanks Kate! working more on presentation slides, then heading to bed",
  "id" : 99304157793619969,
  "created_at" : "Fri Aug 05 02:22:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "99267346010611712",
  "text" : "been @vbiatvt from 8-8, with only a lunch break, damn. (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/nQmT4U",
  "id" : 99267346010611712,
  "created_at" : "Thu Aug 04 23:55:54 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 0, 8 ],
      "id_str" : "86132431",
      "id" : 86132431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99223439860174848",
  "geo" : {
  },
  "id_str" : "99243993354878976",
  "in_reply_to_user_id" : 86132431,
  "text" : "@bricec5 yeah man, I signed up for the full. there are a ton of others doing it as well, you definitely should!!",
  "id" : 99243993354878976,
  "in_reply_to_status_id" : 99223439860174848,
  "created_at" : "Thu Aug 04 22:23:06 +0000 2011",
  "in_reply_to_screen_name" : "bricec5",
  "in_reply_to_user_id_str" : "86132431",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech News",
      "screen_name" : "vtnews",
      "indices" : [ 3, 10 ],
      "id_str" : "17374056",
      "id" : 17374056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VirginiaTech",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99189803538583552",
  "text" : "RT @vtnews: The campus alert is lifted. See email or www.vt.edu for further information. #VirginiaTech",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VirginiaTech",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "99188878900084736",
    "text" : "The campus alert is lifted. See email or www.vt.edu for further information. #VirginiaTech",
    "id" : 99188878900084736,
    "created_at" : "Thu Aug 04 18:44:06 +0000 2011",
    "user" : {
      "name" : "Virginia Tech News",
      "screen_name" : "vtnews",
      "protected" : false,
      "id_str" : "17374056",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/65547724/twitter_vtshield_normal.jpg",
      "id" : 17374056,
      "verified" : false
    }
  },
  "id" : 99189803538583552,
  "created_at" : "Thu Aug 04 18:47:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.234623, -80.4215736333 ]
  },
  "id_str" : "99171901049548801",
  "text" : "lunch w Julia! (@ India Garden) http://4sq.com/ozpi6o",
  "id" : 99171901049548801,
  "created_at" : "Thu Aug 04 17:36:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99123454627954689",
  "geo" : {
  },
  "id_str" : "99124859002560512",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan didn't get the description...",
  "id" : 99124859002560512,
  "in_reply_to_status_id" : 99123454627954689,
  "created_at" : "Thu Aug 04 14:29:42 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99119267810783232",
  "geo" : {
  },
  "id_str" : "99122426662764547",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan yeah I'm in VBI. hoping it's nothing",
  "id" : 99122426662764547,
  "in_reply_to_status_id" : 99119267810783232,
  "created_at" : "Thu Aug 04 14:20:02 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 0, 10 ],
      "id_str" : "9463702",
      "id" : 9463702
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 32, 40 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99117427358568448",
  "geo" : {
  },
  "id_str" : "99122349323984896",
  "in_reply_to_user_id" : 9463702,
  "text" : "@NRVLiving hoping that as well. @twitter is useful!",
  "id" : 99122349323984896,
  "in_reply_to_status_id" : 99117427358568448,
  "created_at" : "Thu Aug 04 14:19:44 +0000 2011",
  "in_reply_to_screen_name" : "NRVLiving",
  "in_reply_to_user_id_str" : "9463702",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Town of Blacksburg",
      "screen_name" : "Blacksburg_Gov",
      "indices" : [ 3, 18 ],
      "id_str" : "16000679",
      "id" : 16000679
    }, {
      "name" : "Virginia Tech News",
      "screen_name" : "vtnews",
      "indices" : [ 23, 30 ],
      "id_str" : "17374056",
      "id" : 17374056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99115539678502913",
  "text" : "RT @Blacksburg_Gov: RT @vtnews: VT Alert: Person with a gun reported near Dietrick. Stay Inside. Secure doors. Emergency personnel respo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Virginia Tech News",
        "screen_name" : "vtnews",
        "indices" : [ 3, 10 ],
        "id_str" : "17374056",
        "id" : 17374056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "99113518749585409",
    "text" : "RT @vtnews: VT Alert: Person with a gun reported near Dietrick. Stay Inside. Secure doors. Emergency personnel responding. Call 911 for help",
    "id" : 99113518749585409,
    "created_at" : "Thu Aug 04 13:44:38 +0000 2011",
    "user" : {
      "name" : "Town of Blacksburg",
      "screen_name" : "Blacksburg_Gov",
      "protected" : false,
      "id_str" : "16000679",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/64290122/twittersquares_normal.jpg",
      "id" : 16000679,
      "verified" : false
    }
  },
  "id" : 99115539678502913,
  "created_at" : "Thu Aug 04 13:52:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "99075054452740097",
  "text" : "up early to work on wrapping up research before final presentations tmrw AM",
  "id" : 99075054452740097,
  "created_at" : "Thu Aug 04 11:11:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brightroom sports",
      "screen_name" : "brPhototweets",
      "indices" : [ 32, 46 ],
      "id_str" : "40012463",
      "id" : 40012463
    }, {
      "name" : "Set Up Events",
      "screen_name" : "SetUpEvents",
      "indices" : [ 68, 80 ],
      "id_str" : "93096808",
      "id" : 93096808
    }, {
      "name" : "Richmond Tri Club",
      "screen_name" : "richtriclub",
      "indices" : [ 81, 93 ],
      "id_str" : "101910975",
      "id" : 101910975
    }, {
      "name" : "3Sports, Inc.",
      "screen_name" : "3Sports",
      "indices" : [ 94, 102 ],
      "id_str" : "51456528",
      "id" : 51456528
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 103, 116 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98968327233351680",
  "text" : "just ordered a sweet photo from @brPhototweets of myself racing the @SetUpEvents @richtriclub @3Sports @usatriathlon!!",
  "id" : 98968327233351680,
  "created_at" : "Thu Aug 04 04:07:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98938520156119040",
  "text" : "@Slpags08 welcome to tweet land!!",
  "id" : 98938520156119040,
  "created_at" : "Thu Aug 04 02:09:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "needshelves",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http://t.co/NvdJIKt",
      "expanded_url" : "http://twitpic.com/60ltzw",
      "display_url" : "twitpic.com/60ltzw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98933387867336707",
  "text" : "laundry in, and picked up my new bb! finishing the move downstairs now #needshelves http://t.co/NvdJIKt",
  "id" : 98933387867336707,
  "created_at" : "Thu Aug 04 01:48:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98925635124211712",
  "geo" : {
  },
  "id_str" : "98933182090579968",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 that's why I waved lol",
  "id" : 98933182090579968,
  "in_reply_to_status_id" : 98925635124211712,
  "created_at" : "Thu Aug 04 01:48:03 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98927652190162944",
  "geo" : {
  },
  "id_str" : "98933028499365890",
  "in_reply_to_user_id" : 253660652,
  "text" : "@J_Gardner90 it made it through worlds lol",
  "id" : 98933028499365890,
  "in_reply_to_status_id" : 98927652190162944,
  "created_at" : "Thu Aug 04 01:47:26 +0000 2011",
  "in_reply_to_screen_name" : "Bugmanjg",
  "in_reply_to_user_id_str" : "253660652",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 117, 125 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http://t.co/gD9PPmg",
      "expanded_url" : "http://bit.ly/mZD55T",
      "display_url" : "bit.ly/mZD55T"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98914836410404864",
  "text" : "solid ride! beautiful night out. Wednesday Worlds by andyreagan at Garmin Connect - Details: http://t.co/gD9PPmg via @AddThis",
  "id" : 98914836410404864,
  "created_at" : "Thu Aug 04 00:35:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/HnMkcrS",
      "expanded_url" : "http://twitpic.com/60iydp",
      "display_url" : "twitpic.com/60iydp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98876535695613952",
  "text" : "just noticed THIS on my rear tire... ridable?? well, going to worlds anyway http://t.co/HnMkcrS",
  "id" : 98876535695613952,
  "created_at" : "Wed Aug 03 22:02:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 3, 12 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http://t.co/rcdA1by",
      "expanded_url" : "http://www.riderichmond.net/2011/06/know-your-rights-spoke-card-released/",
      "display_url" : "riderichmond.net/2011/06/know-y…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98787116934365184",
  "text" : "RT @aJohnnyD: Virginia State code. Know your rights! Spoke Card released!: http://t.co/rcdA1by",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http://t.co/rcdA1by",
        "expanded_url" : "http://www.riderichmond.net/2011/06/know-your-rights-spoke-card-released/",
        "display_url" : "riderichmond.net/2011/06/know-y…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "98786393433718784",
    "text" : "Virginia State code. Know your rights! Spoke Card released!: http://t.co/rcdA1by",
    "id" : 98786393433718784,
    "created_at" : "Wed Aug 03 16:04:46 +0000 2011",
    "user" : {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "protected" : false,
      "id_str" : "77300651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/436050487/John_D_RIDING_normal.JPG",
      "id" : 77300651,
      "verified" : false
    }
  },
  "id" : 98787116934365184,
  "created_at" : "Wed Aug 03 16:07:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike & Build",
      "screen_name" : "bikebuild",
      "indices" : [ 34, 44 ],
      "id_str" : "19693586",
      "id" : 19693586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http://t.co/12wgCL6",
      "expanded_url" : "http://www.stayclassy.org/classy-awards",
      "display_url" : "stayclassy.org/classy-awards"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98770699036008448",
  "text" : "Vote for your favorite non-profit @bikebuild for the 3rd annual CLASSY Awards, under the most creative category http://t.co/12wgCL6!",
  "id" : 98770699036008448,
  "created_at" : "Wed Aug 03 15:02:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98602769551855617",
  "text" : "passed 1000mi on my Garmin today! breakdown: 206 running in 34 runs, 782 cycling in 25 rides, and the rest in 6 swims",
  "id" : 98602769551855617,
  "created_at" : "Wed Aug 03 03:55:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ninite.com",
      "screen_name" : "ninite",
      "indices" : [ 28, 35 ],
      "id_str" : "252889303",
      "id" : 252889303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98577869743194112",
  "text" : "after a fresh OS installed, @ninite installed all of my software automatically. sweet!!",
  "id" : 98577869743194112,
  "created_at" : "Wed Aug 03 02:16:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http://t.co/YHPGMxA",
      "expanded_url" : "http://www.bicyclebuys.com/locks/U-Locks/1729907",
      "display_url" : "bicyclebuys.com/locks/U-Locks/…"
    } ]
  },
  "in_reply_to_status_id_str" : "98531192676171776",
  "geo" : {
  },
  "id_str" : "98577627572482049",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy it wasn't locked at all. in fact, I don't have a lock lol. is yours like this: http://t.co/YHPGMxA",
  "id" : 98577627572482049,
  "in_reply_to_status_id" : 98531192676171776,
  "created_at" : "Wed Aug 03 02:15:12 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http://t.co/7C0jPce",
      "expanded_url" : "http://twitpic.com/6018ju",
      "display_url" : "twitpic.com/6018ju"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98522367218823168",
  "text" : "forgot how much fun this was haha http://t.co/7C0jPce",
  "id" : 98522367218823168,
  "created_at" : "Tue Aug 02 22:35:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/EwmoqEI",
      "expanded_url" : "http://twitpic.com/6014y8",
      "display_url" : "twitpic.com/6014y8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98520325653921792",
  "text" : "not sure why last tweet didn't include pic, but good news: there were no extra screws when done http://t.co/EwmoqEI",
  "id" : 98520325653921792,
  "created_at" : "Tue Aug 02 22:27:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98518211821187072",
  "text" : "putting my laptop back together",
  "id" : 98518211821187072,
  "created_at" : "Tue Aug 02 22:19:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http://t.co/MJQgZxG",
      "expanded_url" : "http://twitpic.com/600q23",
      "display_url" : "twitpic.com/600q23"
    } ]
  },
  "geo" : {
  },
  "id_str" : "98511814823919616",
  "text" : "really? check this out http://t.co/MJQgZxG",
  "id" : 98511814823919616,
  "created_at" : "Tue Aug 02 21:53:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98504011094835200",
  "text" : "another way to visualize a discrete model trajectory http://twitpic.com/600c7l",
  "id" : 98504011094835200,
  "created_at" : "Tue Aug 02 21:22:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 3, 17 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fourthousandplusmiles",
      "indices" : [ 65, 87 ]
    }, {
      "text" : "nbd",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98497309939208193",
  "text" : "RT @Thundercoffer: Just finished biking across the United States #fourthousandplusmiles #nbd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fourthousandplusmiles",
        "indices" : [ 46, 68 ]
      }, {
        "text" : "nbd",
        "indices" : [ 69, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "98474312570388480",
    "text" : "Just finished biking across the United States #fourthousandplusmiles #nbd",
    "id" : 98474312570388480,
    "created_at" : "Tue Aug 02 19:24:40 +0000 2011",
    "user" : {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "protected" : true,
      "id_str" : "26010551",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1195108903/bri46_normal.jpg",
      "id" : 26010551,
      "verified" : false
    }
  },
  "id" : 98497309939208193,
  "created_at" : "Tue Aug 02 20:56:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GardenFreshBeats",
      "screen_name" : "GardenFreshBeat",
      "indices" : [ 0, 16 ],
      "id_str" : "308157623",
      "id" : 308157623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98443662886842368",
  "geo" : {
  },
  "id_str" : "98445150354800640",
  "in_reply_to_user_id" : 308157623,
  "text" : "@GardenFreshBeat he'd be superpussy",
  "id" : 98445150354800640,
  "in_reply_to_status_id" : 98443662886842368,
  "created_at" : "Tue Aug 02 17:28:47 +0000 2011",
  "in_reply_to_screen_name" : "GardenFreshBeat",
  "in_reply_to_user_id_str" : "308157623",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98443788086808576",
  "text" : "ate lunch in 10min to go pay rent and utility bills, glad that didn't take two whole hours... vt elec had my payments going to wrong house",
  "id" : 98443788086808576,
  "created_at" : "Tue Aug 02 17:23:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharkweek",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98209604504272897",
  "geo" : {
  },
  "id_str" : "98227519525888000",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 relax and put on #sharkweek!",
  "id" : 98227519525888000,
  "in_reply_to_status_id" : 98209604504272897,
  "created_at" : "Tue Aug 02 03:04:00 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98208891283845121",
  "text" : "moving into the room downstairs, its 8.5ft by 11ft (96sq ft). gonna be cozy. now headed out to hit the track, hopefully its cool",
  "id" : 98208891283845121,
  "created_at" : "Tue Aug 02 01:49:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swva",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98193859581984769",
  "text" : "put the old fridge in the front yard... a self-proclaimed scrapper was at our door in less than 15 min!! only in #swva",
  "id" : 98193859581984769,
  "created_at" : "Tue Aug 02 00:50:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    }, {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 8, 21 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98142552238198785",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 @laurentappan I got one 6th and one 8th...lol. and what abt the ct??",
  "id" : 98142552238198785,
  "created_at" : "Mon Aug 01 21:26:22 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priceless",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98139205229744128",
  "text" : "cost to fly home, 485 (plus 45min drive to airport too). cost to drive home, 80ish. spending yet another 10hrs of my life on i-81 #priceless",
  "id" : 98139205229744128,
  "created_at" : "Mon Aug 01 21:13:04 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98112758154928128",
  "geo" : {
  },
  "id_str" : "98138421691813889",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 yay! i should be home around 6",
  "id" : 98138421691813889,
  "in_reply_to_status_id" : 98112758154928128,
  "created_at" : "Mon Aug 01 21:09:57 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 35, 48 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 49, 56 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98138281438490625",
  "text" : "is drop/add not open right now...? @laurentappan @jbice0",
  "id" : 98138281438490625,
  "created_at" : "Mon Aug 01 21:09:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98089749943812097",
  "text" : "attending Franziska's Ph.D defense",
  "id" : 98089749943812097,
  "created_at" : "Mon Aug 01 17:56:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98041224673497088",
  "geo" : {
  },
  "id_str" : "98054022736527360",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet go to bed on time? not feelin particularly sorry for ya, bud. i'll be home this weekend btw lol",
  "id" : 98054022736527360,
  "in_reply_to_status_id" : 98041224673497088,
  "created_at" : "Mon Aug 01 15:34:35 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "htfu",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98017301403680768",
  "geo" : {
  },
  "id_str" : "98032396007510016",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet really? #htfu its 9am brah",
  "id" : 98032396007510016,
  "in_reply_to_status_id" : 98017301403680768,
  "created_at" : "Mon Aug 01 14:08:39 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "98028768010043393",
  "text" : "shoot me in the foot, Reinhard asked everyone what the diff was between f5 and z mod 5, and I knew exactly, but didn't say it",
  "id" : 98028768010043393,
  "created_at" : "Mon Aug 01 13:54:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2210593095, -80.4265093803 ]
  },
  "id_str" : "98015679361454080",
  "text" : "weekly presentations...one week left! (@ Virginia Bioinformatics Institute (VBI)) http://4sq.com/pWMKh0",
  "id" : 98015679361454080,
  "created_at" : "Mon Aug 01 13:02:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.2245364152, -80.4211235046 ]
  },
  "id_str" : "98013271101161472",
  "text" : "pb toast w reeses pieces! (@ Dietrick Dining Center w/ 2 others) [pic]: http://4sq.com/oAldmT",
  "id" : 98013271101161472,
  "created_at" : "Mon Aug 01 12:52:39 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97886204896346112",
  "geo" : {
  },
  "id_str" : "97886541929652225",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 sick!",
  "id" : 97886541929652225,
  "in_reply_to_status_id" : 97886204896346112,
  "created_at" : "Mon Aug 01 04:29:04 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 20, 29 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97886463781388288",
  "text" : "RT @Eric_Wagner_71: @DKnick88 happy birthday",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry®</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 0, 9 ],
        "id_str" : "204631321",
        "id" : 204631321
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "97881892224901121",
    "in_reply_to_user_id" : 204631321,
    "text" : "@DKnick88 happy birthday",
    "id" : 97881892224901121,
    "created_at" : "Mon Aug 01 04:10:36 +0000 2011",
    "in_reply_to_screen_name" : "DKnick88",
    "in_reply_to_user_id_str" : "204631321",
    "user" : {
      "name" : "Eric Wagner",
      "screen_name" : "ewags71",
      "protected" : false,
      "id_str" : "29055432",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3170396628/4c90f1c1ccf7eb5388f6b996b8a6334e_normal.jpeg",
      "id" : 29055432,
      "verified" : false
    }
  },
  "id" : 97886463781388288,
  "created_at" : "Mon Aug 01 04:28:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]