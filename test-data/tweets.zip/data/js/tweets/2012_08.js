Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Red Bull",
      "screen_name" : "redbull",
      "indices" : [ 56, 64 ],
      "id_str" : "17540485",
      "id" : 17540485
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lakegeorgetri",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241690949963612161",
  "text" : "RT @UVMTriathlon: sweatshirts, socks, water bottles and @redbull at packet pick up!! ready to dominate tomorrow #lakegeorgetri",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Bull",
        "screen_name" : "redbull",
        "indices" : [ 38, 46 ],
        "id_str" : "17540485",
        "id" : 17540485
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lakegeorgetri",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "241687886867615744",
    "text" : "sweatshirts, socks, water bottles and @redbull at packet pick up!! ready to dominate tomorrow #lakegeorgetri",
    "id" : 241687886867615744,
    "created_at" : "Sat Sep 01 00:04:17 +0000 2012",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 241690949963612161,
  "created_at" : "Sat Sep 01 00:16:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/ndDyoBL5",
      "expanded_url" : "http://twitter.com/UVMTriathlon/status/241636117538037760/photo/1",
      "display_url" : "pic.twitter.com/ndDyoBL5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241642951325937664",
  "text" : "RT @UVMTriathlon: Packing bikes and getting pumped. Lake George here we come! http://t.co/ndDyoBL5",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/UVMTriathlon/status/241636117538037760/photo/1",
        "indices" : [ 60, 80 ],
        "url" : "http://t.co/ndDyoBL5",
        "media_url" : "http://pbs.twimg.com/media/A1p2xMcCYAAKYX2.jpg",
        "id_str" : "241636117542232064",
        "id" : 241636117542232064,
        "media_url_https" : "https://pbs.twimg.com/media/A1p2xMcCYAAKYX2.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/ndDyoBL5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "241636117538037760",
    "text" : "Packing bikes and getting pumped. Lake George here we come! http://t.co/ndDyoBL5",
    "id" : 241636117538037760,
    "created_at" : "Fri Aug 31 20:38:35 +0000 2012",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 241642951325937664,
  "created_at" : "Fri Aug 31 21:05:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241628262722330624",
  "text" : "first VACC job submitted and headed out to Lake George for the triathlon tomorrow!",
  "id" : 241628262722330624,
  "created_at" : "Fri Aug 31 20:07:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241618831557160961",
  "text" : "and after cleaning part of  the Mt Everest of dishes in my sink this AM, my roomie finished the ascent #phew",
  "id" : 241618831557160961,
  "created_at" : "Fri Aug 31 19:29:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 95, 108 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241618829149601792",
  "text" : "missed the 7AM swim this morning, narrowly, and the noon was even better! well represented was @UVMTriathlon",
  "id" : 241618829149601792,
  "created_at" : "Fri Aug 31 19:29:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241304855925387265",
  "geo" : {
  },
  "id_str" : "241333267595407361",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill yess! every time the wind blows north I wish you were here so we could TT spear north again",
  "id" : 241333267595407361,
  "in_reply_to_status_id" : 241304855925387265,
  "created_at" : "Fri Aug 31 00:35:09 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241245772165808128",
  "text" : "tough decisions in my life: the vermont spartan beast or downtown 10k (or neither to break up 9 straight racing weekends)...",
  "id" : 241245772165808128,
  "created_at" : "Thu Aug 30 18:47:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241220891592232961",
  "geo" : {
  },
  "id_str" : "241222278875058177",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 i hate this idea of \"binning\" people. oh, you're a DEMOCRAT, that defines you on some real \"important\" issues I bet",
  "id" : 241222278875058177,
  "in_reply_to_status_id" : 241220891592232961,
  "created_at" : "Thu Aug 30 17:14:07 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/Ll4neEiN",
      "expanded_url" : "http://en.wikipedia.org/wiki/Military_budget_of_the_United_States",
      "display_url" : "en.wikipedia.org/wiki/Military_…"
    } ]
  },
  "in_reply_to_status_id_str" : "241215634262859776",
  "geo" : {
  },
  "id_str" : "241216154952155136",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 an end to war?? really?? he's no less controlled than the rest of them http://t.co/Ll4neEiN",
  "id" : 241216154952155136,
  "in_reply_to_status_id" : 241215634262859776,
  "created_at" : "Thu Aug 30 16:49:47 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241205629610508289",
  "geo" : {
  },
  "id_str" : "241215500502306817",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 you seriously think he's going to do those things?",
  "id" : 241215500502306817,
  "in_reply_to_status_id" : 241205629610508289,
  "created_at" : "Thu Aug 30 16:47:11 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 0, 10 ],
      "id_str" : "74822774",
      "id" : 74822774
    }, {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 11, 21 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241192924547801089",
  "geo" : {
  },
  "id_str" : "241194802857787393",
  "in_reply_to_user_id" : 74822774,
  "text" : "@b_devaney @jcusick13 actually as much as we can use of cascade, fuggles, and one other. should we send heady topper to kiddie table?",
  "id" : 241194802857787393,
  "in_reply_to_status_id" : 241192924547801089,
  "created_at" : "Thu Aug 30 15:24:56 +0000 2012",
  "in_reply_to_screen_name" : "b_devaney",
  "in_reply_to_user_id_str" : "74822774",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Strickland",
      "screen_name" : "TrueBS",
      "indices" : [ 3, 10 ],
      "id_str" : "45957932",
      "id" : 45957932
    }, {
      "name" : "Lovely Bicycle!",
      "screen_name" : "lovelybicycle",
      "indices" : [ 81, 95 ],
      "id_str" : "277081038",
      "id" : 277081038
    }, {
      "name" : "Darryl",
      "screen_name" : "lovingthebike",
      "indices" : [ 96, 110 ],
      "id_str" : "100054962",
      "id" : 100054962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/Fh6sir0D",
      "expanded_url" : "http://bit.ly/S1UQCy",
      "display_url" : "bit.ly/S1UQCy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241194538767642624",
  "text" : "RT @TrueBS: every km covered on bike costs society 8 cents, by car 50 cents (via @lovelybicycle @lovingthebike)  http://t.co/Fh6sir0D",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lovely Bicycle!",
        "screen_name" : "lovelybicycle",
        "indices" : [ 69, 83 ],
        "id_str" : "277081038",
        "id" : 277081038
      }, {
        "name" : "Darryl",
        "screen_name" : "lovingthebike",
        "indices" : [ 84, 98 ],
        "id_str" : "100054962",
        "id" : 100054962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http://t.co/Fh6sir0D",
        "expanded_url" : "http://bit.ly/S1UQCy",
        "display_url" : "bit.ly/S1UQCy"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241193089925005312",
    "text" : "every km covered on bike costs society 8 cents, by car 50 cents (via @lovelybicycle @lovingthebike)  http://t.co/Fh6sir0D",
    "id" : 241193089925005312,
    "created_at" : "Thu Aug 30 15:18:08 +0000 2012",
    "user" : {
      "name" : "Bill Strickland",
      "screen_name" : "TrueBS",
      "protected" : false,
      "id_str" : "45957932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2528084928/r3dgphnf1v2lqk6fjfsu_normal.jpeg",
      "id" : 45957932,
      "verified" : false
    }
  },
  "id" : 241194538767642624,
  "created_at" : "Thu Aug 30 15:23:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 8, 21 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241193601638486016",
  "geo" : {
  },
  "id_str" : "241194405887881216",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill @UVMTriathlon very cool",
  "id" : 241194405887881216,
  "in_reply_to_status_id" : 241193601638486016,
  "created_at" : "Thu Aug 30 15:23:22 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/yDDa0rWn",
      "expanded_url" : "http://bit.ly/HqI1cG",
      "display_url" : "bit.ly/HqI1cG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241184412077797377",
  "text" : "RT @dr_pyser: wind map is looking pretty epic over louisiana right now: http://t.co/yDDa0rWn",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/yDDa0rWn",
        "expanded_url" : "http://bit.ly/HqI1cG",
        "display_url" : "bit.ly/HqI1cG"
      } ]
    },
    "geo" : {
    },
    "id_str" : "241158106598502400",
    "text" : "wind map is looking pretty epic over louisiana right now: http://t.co/yDDa0rWn",
    "id" : 241158106598502400,
    "created_at" : "Thu Aug 30 12:59:07 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 241184412077797377,
  "created_at" : "Thu Aug 30 14:43:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 21, 31 ],
      "id_str" : "528928681",
      "id" : 528928681
    }, {
      "name" : "Brian Devaney",
      "screen_name" : "b_devaney",
      "indices" : [ 32, 42 ],
      "id_str" : "74822774",
      "id" : 74822774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/PA2JOO6X",
      "expanded_url" : "http://twitpic.com/ap8qib",
      "display_url" : "twitpic.com/ap8qib"
    } ]
  },
  "geo" : {
  },
  "id_str" : "241173359403098113",
  "text" : "fresh grown hops!!!! @jcusick13 @b_devaney http://t.co/PA2JOO6X",
  "id" : 241173359403098113,
  "created_at" : "Thu Aug 30 13:59:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 21, 33 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241156173846425601",
  "text" : "great swim this AM w @mrfrank5790 , I better be careful or I'll know how to swim eventually",
  "id" : 241156173846425601,
  "created_at" : "Thu Aug 30 12:51:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241022358268301312",
  "geo" : {
  },
  "id_str" : "241120647827300352",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 that's excellent! took me a couple seconds",
  "id" : 241120647827300352,
  "in_reply_to_status_id" : 241022358268301312,
  "created_at" : "Thu Aug 30 10:30:16 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hash",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "hashhouseharriers",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240943295310749696",
  "text" : "fun TT ride w Patty K, now its #hash time #hashhouseharriers",
  "id" : 240943295310749696,
  "created_at" : "Wed Aug 29 22:45:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chandler Delinks",
      "screen_name" : "cdelinks",
      "indices" : [ 0, 9 ],
      "id_str" : "36920127",
      "id" : 36920127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240539896773763072",
  "geo" : {
  },
  "id_str" : "240557585038716928",
  "in_reply_to_user_id" : 36920127,
  "text" : "@cdelinks oh so instead of warranty my cracked frame, they give you a jacket. I get it haha",
  "id" : 240557585038716928,
  "in_reply_to_status_id" : 240539896773763072,
  "created_at" : "Tue Aug 28 21:12:52 +0000 2012",
  "in_reply_to_screen_name" : "cdelinks",
  "in_reply_to_user_id_str" : "36920127",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240530828273258496",
  "text" : "really excited about my classes this semester! my MacBook just picked a really bad time to crap out though, computerless for 3-5 days",
  "id" : 240530828273258496,
  "created_at" : "Tue Aug 28 19:26:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240222016551124992",
  "text" : "RT @UVMTriathlon: First meeting of the year is tonight at 8pm in the Mt. Mansfield room!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240220601531392000",
    "text" : "First meeting of the year is tonight at 8pm in the Mt. Mansfield room!",
    "id" : 240220601531392000,
    "created_at" : "Mon Aug 27 22:53:49 +0000 2012",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 240222016551124992,
  "created_at" : "Mon Aug 27 22:59:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240170280742424576",
  "text" : "RT @dr_pyser: best data-driven eye candy you'll see all week: small arms and ammunition - imports and exports 1992-2010. http://t.co/XKp ...",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bigdata",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/XKpLSnwG",
        "expanded_url" : "http://bit.ly/MfDuP5",
        "display_url" : "bit.ly/MfDuP5"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240168065063608320",
    "text" : "best data-driven eye candy you'll see all week: small arms and ammunition - imports and exports 1992-2010. http://t.co/XKpLSnwG #bigdata",
    "id" : 240168065063608320,
    "created_at" : "Mon Aug 27 19:25:03 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 240170280742424576,
  "created_at" : "Mon Aug 27 19:33:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/Y1scXcRt",
      "expanded_url" : "http://www.skipix.com/skipixv2/viewlargeimage.php?lang=en&photosetid=8453&filename=IMG_1900.jpg&position=27&total=76",
      "display_url" : "skipix.com/skipixv2/viewl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240144558791487489",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 great sequence of shots here http://t.co/Y1scXcRt",
  "id" : 240144558791487489,
  "created_at" : "Mon Aug 27 17:51:39 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 100, 112 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "painface",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/DNAiFn8N",
      "expanded_url" : "http://www.skipix.com/skipixv2/viewlargeimage.php?lang=en&photosetid=8452&filename=IMG_1856.jpg&position=60&total=76",
      "display_url" : "skipix.com/skipixv2/viewl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240144230004170752",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth I went and found the worst picture I could of the fro #painface http://t.co/DNAiFn8N @mrfrank5790",
  "id" : 240144230004170752,
  "created_at" : "Mon Aug 27 17:50:20 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/PE5PlaKE",
      "expanded_url" : "http://twitpic.com/aobv9u",
      "display_url" : "twitpic.com/aobv9u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240120707621740544",
  "text" : "my notes for math class came out as bike frame designs...whoops http://t.co/PE5PlaKE",
  "id" : 240120707621740544,
  "created_at" : "Mon Aug 27 16:16:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 0, 7 ],
      "id_str" : "549461514",
      "id" : 549461514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240083505420308481",
  "geo" : {
  },
  "id_str" : "240100264047161344",
  "in_reply_to_user_id" : 549461514,
  "text" : "@ttmill sad",
  "id" : 240100264047161344,
  "in_reply_to_status_id" : 240083505420308481,
  "created_at" : "Mon Aug 27 14:55:38 +0000 2012",
  "in_reply_to_screen_name" : "ttmill",
  "in_reply_to_user_id_str" : "549461514",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstclasstweet",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240093577227694080",
  "text" : "#firstclasstweet",
  "id" : 240093577227694080,
  "created_at" : "Mon Aug 27 14:29:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240076457672601601",
  "geo" : {
  },
  "id_str" : "240082074818719745",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT ah...",
  "id" : 240082074818719745,
  "in_reply_to_status_id" : 240076457672601601,
  "created_at" : "Mon Aug 27 13:43:21 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 0, 10 ],
      "id_str" : "363086298",
      "id" : 363086298
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 11, 24 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/bc82UNEi",
      "expanded_url" : "http://www.pigmantri.com/jmsracing/results12/usatage12.html",
      "display_url" : "pigmantri.com/jmsracing/resu…"
    } ]
  },
  "in_reply_to_status_id_str" : "240066476156006401",
  "geo" : {
  },
  "id_str" : "240067536245362688",
  "in_reply_to_user_id" : 363086298,
  "text" : "@conneryVT @usatriathlon http://t.co/bc82UNEi",
  "id" : 240067536245362688,
  "in_reply_to_status_id" : 240066476156006401,
  "created_at" : "Mon Aug 27 12:45:35 +0000 2012",
  "in_reply_to_screen_name" : "conneryVT",
  "in_reply_to_user_id_str" : "363086298",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "indices" : [ 3, 16 ],
      "id_str" : "49445813",
      "id" : 49445813
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 115, 126 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/7WBfyD1A",
      "expanded_url" : "http://changizi.wordpress.com/2009/09/18/how-not-to-get-absorbed-in-someone-elses-abdomen/",
      "display_url" : "changizi.wordpress.com/2009/09/18/how…"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/PUmNmktP",
      "expanded_url" : "http://blogs.discovermagazine.com/crux/2011/11/04/carl-sagan-patron-saint-of-science-monks/",
      "display_url" : "blogs.discovermagazine.com/crux/2011/11/0…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239893860782837760",
  "text" : "RT @MarkChangizi: And don't forget aloofness http://t.co/7WBfyD1A and spiritualiciousness http://t.co/PUmNmktP (cc @bakadesuyo )",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Barker",
        "screen_name" : "bakadesuyo",
        "indices" : [ 97, 108 ],
        "id_str" : "21424637",
        "id" : 21424637
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http://t.co/7WBfyD1A",
        "expanded_url" : "http://changizi.wordpress.com/2009/09/18/how-not-to-get-absorbed-in-someone-elses-abdomen/",
        "display_url" : "changizi.wordpress.com/2009/09/18/how…"
      }, {
        "indices" : [ 72, 92 ],
        "url" : "http://t.co/PUmNmktP",
        "expanded_url" : "http://blogs.discovermagazine.com/crux/2011/11/04/carl-sagan-patron-saint-of-science-monks/",
        "display_url" : "blogs.discovermagazine.com/crux/2011/11/0…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "239889687689433088",
    "text" : "And don't forget aloofness http://t.co/7WBfyD1A and spiritualiciousness http://t.co/PUmNmktP (cc @bakadesuyo )",
    "id" : 239889687689433088,
    "created_at" : "Mon Aug 27 00:58:53 +0000 2012",
    "user" : {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "protected" : false,
      "id_str" : "49445813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3170948141/9590642bbc2fba2279db6ead55b66fb0_normal.jpeg",
      "id" : 49445813,
      "verified" : false
    }
  },
  "id" : 239893860782837760,
  "created_at" : "Mon Aug 27 01:15:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "indices" : [ 3, 16 ],
      "id_str" : "49445813",
      "id" : 49445813
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 33, 44 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/V0kl6kNH",
      "expanded_url" : "http://www.bakadesuyo.com/what-does-it-take-to-become-an-expert-at-anyt",
      "display_url" : "bakadesuyo.com/what-does-it-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239893845469446144",
  "text" : "RT @MarkChangizi: Expertness, by @bakadesuyo http://t.co/V0kl6kNH",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Barker",
        "screen_name" : "bakadesuyo",
        "indices" : [ 15, 26 ],
        "id_str" : "21424637",
        "id" : 21424637
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http://t.co/V0kl6kNH",
        "expanded_url" : "http://www.bakadesuyo.com/what-does-it-take-to-become-an-expert-at-anyt",
        "display_url" : "bakadesuyo.com/what-does-it-t…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "239889598149427200",
    "text" : "Expertness, by @bakadesuyo http://t.co/V0kl6kNH",
    "id" : 239889598149427200,
    "created_at" : "Mon Aug 27 00:58:31 +0000 2012",
    "user" : {
      "name" : "Mark Changizi",
      "screen_name" : "MarkChangizi",
      "protected" : false,
      "id_str" : "49445813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3170948141/9590642bbc2fba2279db6ead55b66fb0_normal.jpeg",
      "id" : 49445813,
      "verified" : false
    }
  },
  "id" : 239893845469446144,
  "created_at" : "Mon Aug 27 01:15:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 13, 27 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/613rxarp",
      "expanded_url" : "http://www.dailymail.co.uk/news/article-2192849/Olympian-Nick-Symmonds-runs-beer-mile-chugging-brews.html?ito=feeds-newsxml",
      "display_url" : "dailymail.co.uk/news/article-2…"
    } ]
  },
  "in_reply_to_status_id_str" : "239883331192377344",
  "geo" : {
  },
  "id_str" : "239885697853583360",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 @ChrisDanforth watch him attempt it: http://t.co/613rxarp",
  "id" : 239885697853583360,
  "in_reply_to_status_id" : 239883331192377344,
  "created_at" : "Mon Aug 27 00:43:01 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 1, 13 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikes",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/i5AJlRFy",
      "expanded_url" : "http://twitpic.com/ao1oqp",
      "display_url" : "twitpic.com/ao1oqp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239811116526620672",
  "text" : ".@UVM_cycling #bikes http://t.co/i5AJlRFy",
  "id" : 239811116526620672,
  "created_at" : "Sun Aug 26 19:46:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/J3WDCAwT",
      "expanded_url" : "http://www.ebay.com/itm/2012-SRAM-Force-TT-Build-Group-172-5-39-53-GXP-BB-11-25-/251066885383?pt=Cycling_Parts_Accessories&hash=item3a74c0a507#ht_2851wt_1189",
      "display_url" : "ebay.com/itm/2012-SRAM-…"
    }, {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/atIEfDe5",
      "expanded_url" : "http://www.ebay.com/itm/3T-Brezza-Team-Aero-Bar-40cm-31-8mm-Time-Trial-Triathlon-Bike-Base-Handlebar-/160869587398?pt=Cycling_Parts_Accessories&hash=item25749319c6#ht_2502wt_985",
      "display_url" : "ebay.com/itm/3T-Brezza-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239488684720812033",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris how did you build it up? http://t.co/J3WDCAwT http://t.co/atIEfDe5",
  "id" : 239488684720812033,
  "created_at" : "Sat Aug 25 22:25:26 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/ABPrNZmb",
      "expanded_url" : "http://www.ebay.com/itm/Full-Carbon-Time-Trial-Triathlon-TT-Bike-Frame-58cm-Fork-Seatpost-FR-106-/350586382372?pt=Road_Bikes&hash=item51a093a824#ht_1679wt_1202",
      "display_url" : "ebay.com/itm/Full-Carbo…"
    }, {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/y5W7Avfr",
      "expanded_url" : "http://www.ebay.com/itm/Shimano-Dura-Ace-Di2-6-Piece-TT-Tri-Group-New-/150432113534?pt=Cycling_Parts_Accessories&hash=item230673e37e#ht_1625wt_908",
      "display_url" : "ebay.com/itm/Shimano-Du…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239487131008000000",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris do you still like you TT frame? thinking of building one http://t.co/ABPrNZmb http://t.co/y5W7Avfr",
  "id" : 239487131008000000,
  "created_at" : "Sat Aug 25 22:19:16 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1K2GO SPORTS",
      "screen_name" : "1K2GOSPORTS",
      "indices" : [ 0, 12 ],
      "id_str" : "202685669",
      "id" : 202685669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239420980559245312",
  "geo" : {
  },
  "id_str" : "239478359149654016",
  "in_reply_to_user_id" : 202685669,
  "text" : "@1K2GOSPORTS hey now...be nice",
  "id" : 239478359149654016,
  "in_reply_to_status_id" : 239420980559245312,
  "created_at" : "Sat Aug 25 21:44:24 +0000 2012",
  "in_reply_to_screen_name" : "1K2GOSPORTS",
  "in_reply_to_user_id_str" : "202685669",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239431378452758529",
  "geo" : {
  },
  "id_str" : "239477377208578048",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 wish ya were! when you comin up??",
  "id" : 239477377208578048,
  "in_reply_to_status_id" : 239431378452758529,
  "created_at" : "Sat Aug 25 21:40:30 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recovery",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239406704700305408",
  "text" : "farmers market lunch #recovery",
  "id" : 239406704700305408,
  "created_at" : "Sat Aug 25 16:59:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 58, 69 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Chris danfo",
      "screen_name" : "Chrisdanfo",
      "indices" : [ 125, 136 ],
      "id_str" : "848050795",
      "id" : 848050795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239397595435397121",
  "text" : "RT @mrfrank5790: I did a triathlon! insanity! congrats to @andyreagan for dominating the age group and going real hard. also @ChrisDanfo ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 41, 52 ],
        "id_str" : "55931868",
        "id" : 55931868
      }, {
        "name" : "Chris Danforth",
        "screen_name" : "ChrisDanforth",
        "indices" : [ 108, 122 ],
        "id_str" : "301579658",
        "id" : 301579658
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fast",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "239397139027996672",
    "text" : "I did a triathlon! insanity! congrats to @andyreagan for dominating the age group and going real hard. also @ChrisDanforth smoked me #fast",
    "id" : 239397139027996672,
    "created_at" : "Sat Aug 25 16:21:40 +0000 2012",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 239397595435397121,
  "created_at" : "Sat Aug 25 16:23:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 1, 15 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Race Vermont",
      "screen_name" : "RaceVermont",
      "indices" : [ 20, 32 ],
      "id_str" : "52089213",
      "id" : 52089213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239387715429363712",
  "text" : ".@ChrisDanforth, an @RaceVermont veteran, with a solid performance as well \"oh, I didn't bike all summer, nbd\"",
  "id" : 239387715429363712,
  "created_at" : "Sat Aug 25 15:44:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 12, 24 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Race Vermont",
      "screen_name" : "RaceVermont",
      "indices" : [ 84, 96 ],
      "id_str" : "52089213",
      "id" : 52089213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shelburnesprint",
      "indices" : [ 67, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239386715251433472",
  "text" : "congrats to @mrfrank5790 micron a truly impressive FIRST triathlon #shelburnesprint @RaceVermont",
  "id" : 239386715251433472,
  "created_at" : "Sat Aug 25 15:40:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 12, 22 ],
      "id_str" : "363086298",
      "id" : 363086298
    }, {
      "name" : "1K2GO SPORTS",
      "screen_name" : "1K2GOSPORTS",
      "indices" : [ 26, 38 ],
      "id_str" : "202685669",
      "id" : 202685669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239386378364923904",
  "text" : "congrats to @conneryVT of @1K2GOSPORTS on the overall win at Shelburne Sprint too",
  "id" : 239386378364923904,
  "created_at" : "Sat Aug 25 15:38:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239386010272817153",
  "text" : "it was awesome actually getting a glimpse of what \"racing\" a triathlon means, had to push on the run back after seeing my AG at turnaround",
  "id" : 239386010272817153,
  "created_at" : "Sat Aug 25 15:37:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 89, 97 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239385539831275521",
  "text" : "took the AG win and ...5th overall? Another pint glass for the collection on Brookes Ave @Karo1yn",
  "id" : 239385539831275521,
  "created_at" : "Sat Aug 25 15:35:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 22, 36 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 37, 49 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triathlon",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239324506634739712",
  "text" : "race time! #triathlon @ChrisDanforth @mrfrank5790",
  "id" : 239324506634739712,
  "created_at" : "Sat Aug 25 11:33:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239140729606246401",
  "geo" : {
  },
  "id_str" : "239142224208728065",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 yeah I'll bike there too. it will be a good warm up",
  "id" : 239142224208728065,
  "in_reply_to_status_id" : 239140729606246401,
  "created_at" : "Fri Aug 24 23:28:43 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239137070336053248",
  "geo" : {
  },
  "id_str" : "239138571271938048",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr tell me more about this \"beer marathon\" of which you speak",
  "id" : 239138571271938048,
  "in_reply_to_status_id" : 239137070336053248,
  "created_at" : "Fri Aug 24 23:14:13 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239137066766696449",
  "geo" : {
  },
  "id_str" : "239138457652445184",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 I should.....but I'm not feeling it at the moment",
  "id" : 239138457652445184,
  "in_reply_to_status_id" : 239137066766696449,
  "created_at" : "Fri Aug 24 23:13:45 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 104, 116 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/1KWlml8S",
      "expanded_url" : "http://connect.garmin.com/activity/214478304",
      "display_url" : "connect.garmin.com/activity/21447…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239133792277770240",
  "text" : "this just in: the #beermile running calories burned do not cancel out the beer. acute observation thx 2 @mrfrank5790 http://t.co/1KWlml8S",
  "id" : 239133792277770240,
  "created_at" : "Fri Aug 24 22:55:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 0, 12 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/1KWlml8S",
      "expanded_url" : "http://connect.garmin.com/activity/214478304",
      "display_url" : "connect.garmin.com/activity/21447…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239131817742069760",
  "in_reply_to_user_id" : 468499498,
  "text" : "@mrfrank5790 my #beermile splits were 6:59 running, 3:17 drinking. shame, I'll have to practice drinking for next run http://t.co/1KWlml8S",
  "id" : 239131817742069760,
  "created_at" : "Fri Aug 24 22:47:22 +0000 2012",
  "in_reply_to_screen_name" : "mrfrank5790",
  "in_reply_to_user_id_str" : "468499498",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/q9L5zBge",
      "expanded_url" : "http://twitpic.com/amyujs",
      "display_url" : "twitpic.com/amyujs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238794662591225857",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn http://t.co/q9L5zBge",
  "id" : 238794662591225857,
  "created_at" : "Fri Aug 24 00:27:38 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 73, 85 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 86, 100 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 101, 112 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/Kc2rjY65",
      "expanded_url" : "http://twitpic.com/amymk5",
      "display_url" : "twitpic.com/amymk5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238787380952305665",
  "text" : "elliptical chainings installed, see you guys at the finish line Saturday @mrfrank5790 @ChrisDanforth @peterdodds http://t.co/Kc2rjY65",
  "id" : 238787380952305665,
  "created_at" : "Thu Aug 23 23:58:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238678995682603008",
  "geo" : {
  },
  "id_str" : "238692475412295680",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn again???",
  "id" : 238692475412295680,
  "in_reply_to_status_id" : 238678995682603008,
  "created_at" : "Thu Aug 23 17:41:35 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238464762214772736",
  "geo" : {
  },
  "id_str" : "238624752791605248",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy 203 miles, 14 hours (12 in the saddle). those guys did it in 11",
  "id" : 238624752791605248,
  "in_reply_to_status_id" : 238464762214772736,
  "created_at" : "Thu Aug 23 13:12:29 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 117, 132 ],
      "id_str" : "320947874",
      "id" : 320947874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238442800230834176",
  "text" : "finished my virgin #beermile in 10:16... I think it breaks down into 50% stomach, 30% chugging, 20% running ability. @BurlingtonHash",
  "id" : 238442800230834176,
  "created_at" : "Thu Aug 23 01:09:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 11, 23 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 61, 72 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 111, 122 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 123, 137 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238442328283549697",
  "text" : "solid run \"@mrfrank5790: 8:51 #beermile. narrow victory over @andyreagan. got 2nd behind an ironman. @SuMillie @peterdodds @ChrisDanforth\"",
  "id" : 238442328283549697,
  "created_at" : "Thu Aug 23 01:07:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238396405394309120",
  "text" : "tonight I set my sights on an 8 minute mile. but not just any mile... #beermile",
  "id" : 238396405394309120,
  "created_at" : "Wed Aug 22 22:05:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 6, 17 ],
      "id_str" : "23695888",
      "id" : 23695888
    }, {
      "name" : "Tim Johnson",
      "screen_name" : "timjohnsoncx",
      "indices" : [ 18, 31 ],
      "id_str" : "17239853",
      "id" : 17239853
    }, {
      "name" : "ryank",
      "screen_name" : "ryantkelly",
      "indices" : [ 36, 47 ],
      "id_str" : "14462349",
      "id" : 14462349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/6WrkP4PA",
      "expanded_url" : "http://bit.ly/OTvv6h",
      "display_url" : "bit.ly/OTvv6h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238393365912227840",
  "text" : "catch @iamtedking @timjohnsoncx and @ryantkelly riding #200NotOn100 http://t.co/6WrkP4PA",
  "id" : 238393365912227840,
  "created_at" : "Wed Aug 22 21:53:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/6WrkP4PA",
      "expanded_url" : "http://bit.ly/OTvv6h",
      "display_url" : "bit.ly/OTvv6h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238393026865688578",
  "text" : "after much editing, I've condensed 2 hours of #200NotOn100 footage into a sweet 11min: http://t.co/6WrkP4PA",
  "id" : 238393026865688578,
  "created_at" : "Wed Aug 22 21:51:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 3, 15 ],
      "id_str" : "468499498",
      "id" : 468499498
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 80, 91 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "hashhouseharriers",
      "indices" : [ 55, 73 ]
    }, {
      "text" : "hash",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238391261223071744",
  "text" : "RT @mrfrank5790: #beermile today! apply game-face now! #hashhouseharriers #hash @andyreagan",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 63, 74 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beermile",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "hashhouseharriers",
        "indices" : [ 38, 56 ]
      }, {
        "text" : "hash",
        "indices" : [ 57, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "238391016271519744",
    "text" : "#beermile today! apply game-face now! #hashhouseharriers #hash @andyreagan",
    "id" : 238391016271519744,
    "created_at" : "Wed Aug 22 21:43:42 +0000 2012",
    "user" : {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "protected" : false,
      "id_str" : "468499498",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1901468255/image_normal.jpg",
      "id" : 468499498,
      "verified" : false
    }
  },
  "id" : 238391261223071744,
  "created_at" : "Wed Aug 22 21:44:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doingitright",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/FIn7nshU",
      "expanded_url" : "http://twitpic.com/amkeyj",
      "display_url" : "twitpic.com/amkeyj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238372938582212610",
  "text" : "hit 500 miles picking up CSA! #doingitright http://t.co/FIn7nshU",
  "id" : 238372938582212610,
  "created_at" : "Wed Aug 22 20:31:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/xhF6OpiZ",
      "expanded_url" : "http://www.bakadesuyo.com/can-starving-yourself-for-a-while-every-day-i",
      "display_url" : "bakadesuyo.com/can-starving-y…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238339621631709184",
  "text" : "the health benefits of fasting amaze me http://t.co/xhF6OpiZ",
  "id" : 238339621631709184,
  "created_at" : "Wed Aug 22 18:19:28 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Culture Cycles",
      "screen_name" : "CultureCycles",
      "indices" : [ 3, 17 ],
      "id_str" : "39440392",
      "id" : 39440392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/7SRmVc79",
      "expanded_url" : "http://bit.ly/SmLv5A",
      "display_url" : "bit.ly/SmLv5A"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238307007772381184",
  "text" : "RT @CultureCycles: Custom Firefly Belt Driven Titanium Commuter Bike, Rohloff-Equipped: This is what a commute... http://t.co/7SRmVc79 h ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/7SRmVc79",
        "expanded_url" : "http://bit.ly/SmLv5A",
        "display_url" : "bit.ly/SmLv5A"
      }, {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/Mr8Ru0wt",
        "expanded_url" : "http://culturecycles.com",
        "display_url" : "culturecycles.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "238305124836069377",
    "text" : "Custom Firefly Belt Driven Titanium Commuter Bike, Rohloff-Equipped: This is what a commute... http://t.co/7SRmVc79 http://t.co/Mr8Ru0wt",
    "id" : 238305124836069377,
    "created_at" : "Wed Aug 22 16:02:23 +0000 2012",
    "user" : {
      "name" : "Culture Cycles",
      "screen_name" : "CultureCycles",
      "protected" : false,
      "id_str" : "39440392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1180562888/sidebarlogo_normal.jpg",
      "id" : 39440392,
      "verified" : false
    }
  },
  "id" : 238307007772381184,
  "created_at" : "Wed Aug 22 16:09:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "indices" : [ 3, 16 ],
      "id_str" : "14882900",
      "id" : 14882900
    }, {
      "name" : "Nick Symmonds",
      "screen_name" : "NickSymmonds",
      "indices" : [ 19, 32 ],
      "id_str" : "464805322",
      "id" : 464805322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/dbnUCLpf",
      "expanded_url" : "http://ow.ly/d9jJa",
      "display_url" : "ow.ly/d9jJa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238295352116121601",
  "text" : "RT @runnersworld: .@NickSymmonds moves up in distance, lowers the U.S. beer mile record to 5:19. http://t.co/dbnUCLpf",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Symmonds",
        "screen_name" : "NickSymmonds",
        "indices" : [ 1, 14 ],
        "id_str" : "464805322",
        "id" : 464805322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/dbnUCLpf",
        "expanded_url" : "http://ow.ly/d9jJa",
        "display_url" : "ow.ly/d9jJa"
      } ]
    },
    "geo" : {
    },
    "id_str" : "238290721545801728",
    "text" : ".@NickSymmonds moves up in distance, lowers the U.S. beer mile record to 5:19. http://t.co/dbnUCLpf",
    "id" : 238290721545801728,
    "created_at" : "Wed Aug 22 15:05:09 +0000 2012",
    "user" : {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "protected" : false,
      "id_str" : "14882900",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3207393329/d6f10524b380d7bb42b1ae48ca839d79_normal.jpeg",
      "id" : 14882900,
      "verified" : true
    }
  },
  "id" : 238295352116121601,
  "created_at" : "Wed Aug 22 15:23:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1K2GO SPORTS",
      "screen_name" : "1K2GOSPORTS",
      "indices" : [ 0, 12 ],
      "id_str" : "202685669",
      "id" : 202685669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238141495503384576",
  "in_reply_to_user_id" : 202685669,
  "text" : "@1K2GOSPORTS busting parties like a champ, i was at Ike's apartment lol",
  "id" : 238141495503384576,
  "created_at" : "Wed Aug 22 05:12:11 +0000 2012",
  "in_reply_to_screen_name" : "1K2GOSPORTS",
  "in_reply_to_user_id_str" : "202685669",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beermile",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/01QkY1Dr",
      "expanded_url" : "http://en.m.wikipedia.org/wiki/Beer_mile",
      "display_url" : "en.m.wikipedia.org/wiki/Beer_mile"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238046166552571904",
  "text" : "\"Much like the four-minute barrier in the mile run, the five-minute barrier tempts beer-milers world wide.\" http://t.co/01QkY1Dr #beermile",
  "id" : 238046166552571904,
  "created_at" : "Tue Aug 21 22:53:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "robot",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238031201997291520",
  "text" : "in the meantime, forgot to eat lunch #robot",
  "id" : 238031201997291520,
  "created_at" : "Tue Aug 21 21:53:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "framebuilding",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/3QNYjOZu",
      "expanded_url" : "http://twitpic.com/am8e5a",
      "display_url" : "twitpic.com/am8e5a"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238030966747168769",
  "text" : "check it out!! front end complete #framebuilding http://t.co/3QNYjOZu",
  "id" : 238030966747168769,
  "created_at" : "Tue Aug 21 21:52:59 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/jMrhXcsB",
      "expanded_url" : "http://twitpic.com/am6jl8",
      "display_url" : "twitpic.com/am6jl8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237966115379236864",
  "text" : "front triangle nearing completion! http://t.co/jMrhXcsB",
  "id" : 237966115379236864,
  "created_at" : "Tue Aug 21 17:35:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SLACKER",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237920877575012353",
  "geo" : {
  },
  "id_str" : "237965994155470849",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn we live approx 2 blocks away #SLACKER",
  "id" : 237965994155470849,
  "in_reply_to_status_id" : 237920877575012353,
  "created_at" : "Tue Aug 21 17:34:48 +0000 2012",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 8, 15 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237925890892369920",
  "geo" : {
  },
  "id_str" : "237965770938781697",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @DZdan1 date??",
  "id" : 237965770938781697,
  "in_reply_to_status_id" : 237925890892369920,
  "created_at" : "Tue Aug 21 17:33:55 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "framebuilding",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/7Wj83IVM",
      "expanded_url" : "http://twitpic.com/alxhjw",
      "display_url" : "twitpic.com/alxhjw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237731618696077314",
  "text" : "fillet numero uno. one down, twelve to go #framebuilding http://t.co/7Wj83IVM",
  "id" : 237731618696077314,
  "created_at" : "Tue Aug 21 02:03:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/MqwkxMur",
      "expanded_url" : "http://twitpic.com/alwk4t",
      "display_url" : "twitpic.com/alwk4t"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237703158565052416",
  "text" : "got home from my ride to my new 29er mountain bike!! http://t.co/MqwkxMur",
  "id" : 237703158565052416,
  "created_at" : "Tue Aug 21 00:10:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/wICfu6u9",
      "expanded_url" : "http://twitpic.com/alwhv9",
      "display_url" : "twitpic.com/alwhv9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237701166576832512",
  "text" : "rear tire to frame clearance...no wonder the fresh asphalt got stuck today: (hand for reference) http://t.co/wICfu6u9",
  "id" : 237701166576832512,
  "created_at" : "Tue Aug 21 00:02:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237665092748066816",
  "geo" : {
  },
  "id_str" : "237700154696798209",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy like the design!!",
  "id" : 237700154696798209,
  "in_reply_to_status_id" : 237665092748066816,
  "created_at" : "Mon Aug 20 23:58:27 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    }, {
      "name" : "Adam Alter",
      "screen_name" : "adamleealter",
      "indices" : [ 101, 114 ],
      "id_str" : "23443908",
      "id" : 23443908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/1akRicdu",
      "expanded_url" : "http://i.imgur.com/rDGrP.gif",
      "display_url" : "i.imgur.com/rDGrP.gif"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237699682091024384",
  "text" : "RT @stevenstrogatz: Freaky animation of a ball rolling on a Möbius triangle http://t.co/1akRicdu via @adamleealter",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Alter",
        "screen_name" : "adamleealter",
        "indices" : [ 81, 94 ],
        "id_str" : "23443908",
        "id" : 23443908
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http://t.co/1akRicdu",
        "expanded_url" : "http://i.imgur.com/rDGrP.gif",
        "display_url" : "i.imgur.com/rDGrP.gif"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237683417221836800",
    "text" : "Freaky animation of a ball rolling on a Möbius triangle http://t.co/1akRicdu via @adamleealter",
    "id" : 237683417221836800,
    "created_at" : "Mon Aug 20 22:51:57 +0000 2012",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 237699682091024384,
  "created_at" : "Mon Aug 20 23:56:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 21, 33 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triprobz",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237699050349150208",
  "text" : "solid road ride with @UVM_cycling getting ready for the fall season. received adequate crap for putting miles in TT position #triprobz",
  "id" : 237699050349150208,
  "created_at" : "Mon Aug 20 23:54:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237642922810552320",
  "geo" : {
  },
  "id_str" : "237648374608838656",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 that's what I meant!",
  "id" : 237648374608838656,
  "in_reply_to_status_id" : 237642922810552320,
  "created_at" : "Mon Aug 20 20:32:42 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bike League ",
      "screen_name" : "BikeLeague",
      "indices" : [ 9, 20 ],
      "id_str" : "25085215",
      "id" : 25085215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/91vRhGnR",
      "expanded_url" : "http://bellehelmets.myshopify.com/collections/designs",
      "display_url" : "bellehelmets.myshopify.com/collections/de…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237640828548431872",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@BikeLeague: Just stumbled across some eye candy for your head http://t.co/91vRhGnR\"",
  "id" : 237640828548431872,
  "created_at" : "Mon Aug 20 20:02:43 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 12, 22 ],
      "id_str" : "528928681",
      "id" : 528928681
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 23, 31 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/YOAmkzxA",
      "expanded_url" : "http://twitpic.com/aliq9g",
      "display_url" : "twitpic.com/aliq9g"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237326802933141505",
  "text" : "Al's Frys w @jcusick13 @Karo1yn http://t.co/YOAmkzxA",
  "id" : 237326802933141505,
  "created_at" : "Sun Aug 19 23:14:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "ouch",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237310811348013056",
  "text" : "worst part of #USATAGNC12 triathlon is scrubbing off the \"temporary\" tatoo numbers with a brillo pad #ouch",
  "id" : 237310811348013056,
  "created_at" : "Sun Aug 19 22:11:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 121, 132 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237302751745413120",
  "text" : "RT @dr_pyser: and meanwhile, this is the. best. thing. i have seen today. i clearly should have done today's triathalon. @andyreagan htt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 107, 118 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/dr_pyser/status/237298651007971329/photo/1",
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/V0FliRoB",
        "media_url" : "http://pbs.twimg.com/media/A0sN3aeCcAABGZ7.png",
        "id_str" : "237298651016359936",
        "id" : 237298651016359936,
        "media_url_https" : "https://pbs.twimg.com/media/A0sN3aeCcAABGZ7.png",
        "sizes" : [ {
          "h" : 704,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/V0FliRoB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "237298651007971329",
    "text" : "and meanwhile, this is the. best. thing. i have seen today. i clearly should have done today's triathalon. @andyreagan http://t.co/V0FliRoB",
    "id" : 237298651007971329,
    "created_at" : "Sun Aug 19 21:23:02 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 237302751745413120,
  "created_at" : "Sun Aug 19 21:39:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237300040496975872",
  "geo" : {
  },
  "id_str" : "237300349239705600",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I had to search and find that segment. man you must have sprinted! totally could have won the triathlon today",
  "id" : 237300349239705600,
  "in_reply_to_status_id" : 237300040496975872,
  "created_at" : "Sun Aug 19 21:29:46 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Johnson",
      "screen_name" : "iamscratchbob",
      "indices" : [ 0, 14 ],
      "id_str" : "298873947",
      "id" : 298873947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237219969941782528",
  "geo" : {
  },
  "id_str" : "237292243575259136",
  "in_reply_to_user_id" : 298873947,
  "text" : "@iamscratchbob glad you liked it!! Tri's are just fun, you could always sign up under a pseudonym...Bob Jugernaut's got some ring to it",
  "id" : 237292243575259136,
  "in_reply_to_status_id" : 237219969941782528,
  "created_at" : "Sun Aug 19 20:57:34 +0000 2012",
  "in_reply_to_screen_name" : "iamscratchbob",
  "in_reply_to_user_id_str" : "298873947",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237285651140202496",
  "geo" : {
  },
  "id_str" : "237289982400794624",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser I sure hope so! also, booked to Raleigh for Sept, that should be fun!",
  "id" : 237289982400794624,
  "in_reply_to_status_id" : 237285651140202496,
  "created_at" : "Sun Aug 19 20:48:35 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 113, 120 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237284949810634754",
  "text" : "booked my flight for Thanksgiving break to CHILE!! (pronounced chill-lay) Ever heard of Patagonia, it's a place! @sspis1",
  "id" : 237284949810634754,
  "created_at" : "Sun Aug 19 20:28:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Bruce Van Horn",
      "screen_name" : "BruceVH",
      "indices" : [ 76, 84 ],
      "id_str" : "57497901",
      "id" : 57497901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/SiWR5t6j",
      "expanded_url" : "http://www.brucevanhorn.com/2012/08/the-road-to-richmond-week-13-long-run.html",
      "display_url" : "brucevanhorn.com/2012/08/the-ro…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237218019405885440",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 read this before your next long run! http://t.co/SiWR5t6j thanks to @BruceVH",
  "id" : 237218019405885440,
  "created_at" : "Sun Aug 19 16:02:37 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twobikesonerider",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237216144124157952",
  "text" : "riding home with on my commuter bike with wetsuit in pannier, transition bag on back, and race bike in my right hand #twobikesonerider",
  "id" : 237216144124157952,
  "created_at" : "Sun Aug 19 15:55:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/MqtXyOXx",
      "expanded_url" : "http://twitpic.com/aldqmg",
      "display_url" : "twitpic.com/aldqmg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237194418275377154",
  "text" : "finished #USATAGNC12 in (very unofficially) 1:14! http://t.co/MqtXyOXx",
  "id" : 237194418275377154,
  "created_at" : "Sun Aug 19 14:28:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/CPXP9WFT",
      "expanded_url" : "http://twitpic.com/albef5",
      "display_url" : "twitpic.com/albef5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237147554532425729",
  "text" : "transition set! #USATAGNC12 http://t.co/CPXP9WFT",
  "id" : 237147554532425729,
  "created_at" : "Sun Aug 19 11:22:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/AgEcMK5h",
      "expanded_url" : "http://twitpic.com/alb2wx",
      "display_url" : "twitpic.com/alb2wx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237140383103066114",
  "text" : "numba 3678 coming for the win! #USATAGNC12 http://t.co/AgEcMK5h",
  "id" : 237140383103066114,
  "created_at" : "Sun Aug 19 10:54:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 38, 45 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237036276639993856",
  "text" : "a very happy chilean birthday wish to @sspis1!!!",
  "id" : 237036276639993856,
  "created_at" : "Sun Aug 19 04:00:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "local",
      "indices" : [ 46, 52 ]
    }, {
      "text" : "USATAGNC12",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236918556393082881",
  "text" : "riding to the bike drop-off and running home  #local #USATAGNC12",
  "id" : 236918556393082881,
  "created_at" : "Sat Aug 18 20:12:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pikes Peak Marathon",
      "screen_name" : "PikesPeakRun",
      "indices" : [ 0, 13 ],
      "id_str" : "485150622",
      "id" : 485150622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236812577181691905",
  "geo" : {
  },
  "id_str" : "236867278833065984",
  "in_reply_to_user_id" : 485150622,
  "text" : "@PikesPeakRun and the top ghost!!",
  "id" : 236867278833065984,
  "in_reply_to_status_id" : 236812577181691905,
  "created_at" : "Sat Aug 18 16:48:54 +0000 2012",
  "in_reply_to_screen_name" : "PikesPeakRun",
  "in_reply_to_user_id_str" : "485150622",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 0, 12 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236833658193989632",
  "geo" : {
  },
  "id_str" : "236866741848903680",
  "in_reply_to_user_id" : 66689453,
  "text" : "@runfasteraw let me know when you start planning that next trip!",
  "id" : 236866741848903680,
  "in_reply_to_status_id" : 236833658193989632,
  "created_at" : "Sat Aug 18 16:46:46 +0000 2012",
  "in_reply_to_screen_name" : "runfasteraw",
  "in_reply_to_user_id_str" : "66689453",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Cyclist",
      "screen_name" : "fatcyclist",
      "indices" : [ 0, 11 ],
      "id_str" : "15408193",
      "id" : 15408193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236844039826202625",
  "geo" : {
  },
  "id_str" : "236866541273096192",
  "in_reply_to_user_id" : 15408193,
  "text" : "@fatcyclist I knocked on wood for you, thank me later",
  "id" : 236866541273096192,
  "in_reply_to_status_id" : 236844039826202625,
  "created_at" : "Sat Aug 18 16:45:58 +0000 2012",
  "in_reply_to_screen_name" : "fatcyclist",
  "in_reply_to_user_id_str" : "15408193",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Local Motion",
      "screen_name" : "LocalMotionVT",
      "indices" : [ 13, 27 ],
      "id_str" : "87290140",
      "id" : 87290140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236866144454189056",
  "text" : "shout out to @LocalMotionVT for the free bike parking today at #USATAGNC12! Passed abt 200 cars enjoying the ride home",
  "id" : 236866144454189056,
  "created_at" : "Sat Aug 18 16:44:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Gittelman",
      "screen_name" : "racingtales",
      "indices" : [ 0, 12 ],
      "id_str" : "44921557",
      "id" : 44921557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236865014152192000",
  "geo" : {
  },
  "id_str" : "236865691460980736",
  "in_reply_to_user_id" : 44921557,
  "text" : "@racingtales awesome race!",
  "id" : 236865691460980736,
  "in_reply_to_status_id" : 236865014152192000,
  "created_at" : "Sat Aug 18 16:42:36 +0000 2012",
  "in_reply_to_screen_name" : "racingtales",
  "in_reply_to_user_id_str" : "44921557",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 69, 77 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236865309921927168",
  "text" : "one of the best parts of volunteering foe the triathlon this year... @Moes_HQ  burritos! #USATAGNC12",
  "id" : 236865309921927168,
  "created_at" : "Sat Aug 18 16:41:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/C0b3CvgC",
      "expanded_url" : "http://twitpic.com/aky55c",
      "display_url" : "twitpic.com/aky55c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236830723498192896",
  "text" : "some amazing performances coming through #USATAGNC12 http://t.co/C0b3CvgC",
  "id" : 236830723498192896,
  "created_at" : "Sat Aug 18 14:23:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/eKAEITEy",
      "expanded_url" : "http://twitpic.com/akxinc",
      "display_url" : "twitpic.com/akxinc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236819464400826369",
  "text" : "check out it this finish line!! #USATAGNC12 http://t.co/eKAEITEy",
  "id" : 236819464400826369,
  "created_at" : "Sat Aug 18 13:38:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "うさだ",
      "screen_name" : "usada",
      "indices" : [ 19, 25 ],
      "id_str" : "14989553",
      "id" : 14989553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGN12",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/dnDmDZIa",
      "expanded_url" : "http://twitpic.com/akwjhs",
      "display_url" : "twitpic.com/akwjhs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236800946993242112",
  "text" : "is working for the @usada today, ensuring a clean triathlon today!! #USATAGN12 http://t.co/dnDmDZIa",
  "id" : 236800946993242112,
  "created_at" : "Sat Aug 18 12:25:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillian Cowell",
      "screen_name" : "3tribe",
      "indices" : [ 34, 41 ],
      "id_str" : "265226752",
      "id" : 265226752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGN12",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/0BvGmZlx",
      "expanded_url" : "http://twitpic.com/akwfr1",
      "display_url" : "twitpic.com/akwfr1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236798840898998273",
  "text" : "volunteers looking good thanks to @3tribe! #USATAGN12 http://t.co/0BvGmZlx",
  "id" : 236798840898998273,
  "created_at" : "Sat Aug 18 12:16:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 9, 22 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236796556177727488",
  "text" : "just saw @UVMTriathlon 's Ike Tucker ready to race in an hour!!",
  "id" : 236796556177727488,
  "created_at" : "Sat Aug 18 12:07:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 38, 50 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Lynn Monty ",
      "screen_name" : "VermontSongbird",
      "indices" : [ 52, 68 ],
      "id_str" : "21343505",
      "id" : 21343505
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 96, 109 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usatagnc12",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "btv",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "vt",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/adY32nhp",
      "expanded_url" : "http://instagr.am/p/Od9envNBAz/",
      "display_url" : "instagr.am/p/Od9envNBAz/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236793582172925952",
  "text" : "headed down 2 volunteer! good luck to @VTTriathlon \"@VermontSongbird: They are off! #usatagnc12 @usatriathlon #btv #vt http://t.co/adY32nhp\"",
  "id" : 236793582172925952,
  "created_at" : "Sat Aug 18 11:56:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cutaway Clothing",
      "screen_name" : "CutawayClothing",
      "indices" : [ 35, 51 ],
      "id_str" : "46107320",
      "id" : 46107320
    }, {
      "name" : "Ted King",
      "screen_name" : "iamtedking",
      "indices" : [ 74, 85 ],
      "id_str" : "23695888",
      "id" : 23695888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "200NotOn100",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/sECLqY75",
      "expanded_url" : "http://twitpic.com/akoint",
      "display_url" : "twitpic.com/akoint"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236609517050273792",
  "text" : "digging my #200NotOn100 shirt from @CutawayClothing!! I think I earned it @iamtedking http://t.co/sECLqY75",
  "id" : 236609517050273792,
  "created_at" : "Fri Aug 17 23:44:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/VcSb9mav",
      "expanded_url" : "http://avitzur.hax.com/2007/01/the_library_of_babel_function.html",
      "display_url" : "avitzur.hax.com/2007/01/the_li…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236454583331864576",
  "text" : "RT @stevenstrogatz: Tupper's self-referential formula contains all of Shakespeare too. How it works: http://t.co/VcSb9mav",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http://t.co/VcSb9mav",
        "expanded_url" : "http://avitzur.hax.com/2007/01/the_library_of_babel_function.html",
        "display_url" : "avitzur.hax.com/2007/01/the_li…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "236438358539264000",
    "text" : "Tupper's self-referential formula contains all of Shakespeare too. How it works: http://t.co/VcSb9mav",
    "id" : 236438358539264000,
    "created_at" : "Fri Aug 17 12:24:32 +0000 2012",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 236454583331864576,
  "created_at" : "Fri Aug 17 13:29:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 8, 17 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236317498612535296",
  "geo" : {
  },
  "id_str" : "236318108552425472",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 @DKnick88 which I'll assume means you played two games",
  "id" : 236318108552425472,
  "in_reply_to_status_id" : 236317498612535296,
  "created_at" : "Fri Aug 17 04:26:42 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 99, 112 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazytrikidprobz",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236317061268254720",
  "text" : "putting on new helmet numbers is easy when the old helmet numbers are still there #lazytrikidprobz @UVMTriathlon",
  "id" : 236317061268254720,
  "created_at" : "Fri Aug 17 04:22:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 10, 17 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rough",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236258315246653440",
  "geo" : {
  },
  "id_str" : "236313919365447681",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 @DZdan1 I'm the one who's jealous!! mexican food an no invite #rough",
  "id" : 236313919365447681,
  "in_reply_to_status_id" : 236258315246653440,
  "created_at" : "Fri Aug 17 04:10:03 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 29, 38 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 39, 50 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236313742835597312",
  "text" : "he knows me alll too well RT @vmhilljr @andyreagan Nope. Thinking about burritos and beer.",
  "id" : 236313742835597312,
  "created_at" : "Fri Aug 17 04:09:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236226709710581760",
  "text" : "north beach swimming w Grayson! So many triathletes",
  "id" : 236226709710581760,
  "created_at" : "Thu Aug 16 22:23:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236172455578836992",
  "text" : "thinking about the natural dimension of logic? #storylab",
  "id" : 236172455578836992,
  "created_at" : "Thu Aug 16 18:47:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/tZhKl80y",
      "expanded_url" : "http://www.kb6nu.com/wp-content/uploads/2010/06/2010_Tech_Study_Guide.pdf",
      "display_url" : "kb6nu.com/wp-content/upl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236135024062238720",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin http://t.co/tZhKl80y",
  "id" : 236135024062238720,
  "created_at" : "Thu Aug 16 16:19:11 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 0, 9 ],
      "id_str" : "195438525",
      "id" : 195438525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236134617080528898",
  "in_reply_to_user_id" : 195438525,
  "text" : "@cafeZulu sorry for being such a debbie downer though, you should go for it!",
  "id" : 236134617080528898,
  "created_at" : "Thu Aug 16 16:17:34 +0000 2012",
  "in_reply_to_screen_name" : "cafeZulu",
  "in_reply_to_user_id_str" : "195438525",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 0, 9 ],
      "id_str" : "195438525",
      "id" : 195438525
    }, {
      "name" : "Alex Roth",
      "screen_name" : "alexroth",
      "indices" : [ 10, 19 ],
      "id_str" : "27814254",
      "id" : 27814254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236132861516840960",
  "geo" : {
  },
  "id_str" : "236134257750315008",
  "in_reply_to_user_id" : 195438525,
  "text" : "@cafeZulu @alexroth but it's misleading...they're just spinning the roaster by bike, the roasting is done by a flame",
  "id" : 236134257750315008,
  "in_reply_to_status_id" : 236132861516840960,
  "created_at" : "Thu Aug 16 16:16:08 +0000 2012",
  "in_reply_to_screen_name" : "cafeZulu",
  "in_reply_to_user_id_str" : "195438525",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 0, 10 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 32 ],
      "url" : "https://t.co/Ve4blVvC",
      "expanded_url" : "https://maps.google.com/maps/ms?msid=208687371047587284823.0004c5cf45301551b8692&msa=0",
      "display_url" : "maps.google.com/maps/ms?msid=2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236121481405411328",
  "in_reply_to_user_id" : 528928681,
  "text" : "@jcusick13 https://t.co/Ve4blVvC",
  "id" : 236121481405411328,
  "created_at" : "Thu Aug 16 15:25:22 +0000 2012",
  "in_reply_to_screen_name" : "jcusick13",
  "in_reply_to_user_id_str" : "528928681",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kati Span",
      "screen_name" : "cafeZulu",
      "indices" : [ 0, 9 ],
      "id_str" : "195438525",
      "id" : 195438525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "impossible",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236089319528480768",
  "geo" : {
  },
  "id_str" : "236111822686662657",
  "in_reply_to_user_id" : 195438525,
  "text" : "@cafeZulu its #impossible ;)",
  "id" : 236111822686662657,
  "in_reply_to_status_id" : 236089319528480768,
  "created_at" : "Thu Aug 16 14:46:59 +0000 2012",
  "in_reply_to_screen_name" : "cafeZulu",
  "in_reply_to_user_id_str" : "195438525",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 28, 40 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashing",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "hooked",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235926897165484032",
  "text" : "#hashing was great! #hooked @mrfrank5790",
  "id" : 235926897165484032,
  "created_at" : "Thu Aug 16 02:32:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 0, 12 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235860830317584385",
  "geo" : {
  },
  "id_str" : "235926673172873218",
  "in_reply_to_user_id" : 276236513,
  "text" : "@bikingbiebs nerrrrrds",
  "id" : 235926673172873218,
  "in_reply_to_status_id" : 235860830317584385,
  "created_at" : "Thu Aug 16 02:31:16 +0000 2012",
  "in_reply_to_screen_name" : "bikingbiebs",
  "in_reply_to_user_id_str" : "276236513",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burlington Hash",
      "screen_name" : "BurlingtonHash",
      "indices" : [ 19, 34 ],
      "id_str" : "320947874",
      "id" : 320947874
    }, {
      "name" : "Morgan Frank",
      "screen_name" : "mrfrank5790",
      "indices" : [ 59, 71 ],
      "id_str" : "468499498",
      "id" : 468499498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hash",
      "indices" : [ 8, 13 ]
    }, {
      "text" : "hashhouseharriers",
      "indices" : [ 35, 53 ]
    }, {
      "text" : "HHH",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235862147991756801",
  "text" : "time to #hash with @BurlingtonHash #hashhouseharriers #HHH @mrfrank5790",
  "id" : 235862147991756801,
  "created_at" : "Wed Aug 15 22:14:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 27, 41 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "wigglewigglewiggle",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/Myn15wQe",
      "expanded_url" : "http://bit.ly/Pd4ajz",
      "display_url" : "bit.ly/Pd4ajz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235853372333387776",
  "text" : "almost too corny to watch \"@MarsCuriosity: This fan-made video is AWESOME (and I know it). http://t.co/Myn15wQe #MSL #wigglewigglewiggle\"",
  "id" : 235853372333387776,
  "created_at" : "Wed Aug 15 21:40:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235800685738868736",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth approx 25.5...I'll give you a half",
  "id" : 235800685738868736,
  "created_at" : "Wed Aug 15 18:10:39 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RunVermont",
      "screen_name" : "RunVermont",
      "indices" : [ 1, 12 ],
      "id_str" : "82933544",
      "id" : 82933544
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 55, 68 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATAGNC12",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "BTV",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/1K75J0xf",
      "expanded_url" : "http://www.runvermont.org/usat",
      "display_url" : "runvermont.org/usat"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235774313175842817",
  "text" : ".@RunVermont still needs volunteers for this weekend's @usatriathlon #USATAGNC12 #BTV, it'll be fun! http://t.co/1K75J0xf",
  "id" : 235774313175842817,
  "created_at" : "Wed Aug 15 16:25:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 0, 14 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stumpkam",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235773334091096064",
  "in_reply_to_user_id" : 301579658,
  "text" : "@ChrisDanforth I'll relay any killer questions you have for Kam for his defense at 1 via twitter! #stumpkam",
  "id" : 235773334091096064,
  "created_at" : "Wed Aug 15 16:21:57 +0000 2012",
  "in_reply_to_screen_name" : "ChrisDanforth",
  "in_reply_to_user_id_str" : "301579658",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/FSfbaYcn",
      "expanded_url" : "http://www.kickstarter.com/projects/1640002012/the-jiggernaut-bringing-bicycle-frame-building-to",
      "display_url" : "kickstarter.com/projects/16400…"
    } ]
  },
  "in_reply_to_status_id_str" : "235478316260405248",
  "geo" : {
  },
  "id_str" : "235770152183013376",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris that would be the \"jiggernaut,\" a wooden jig. got it from kickstarter: http://t.co/FSfbaYcn",
  "id" : 235770152183013376,
  "in_reply_to_status_id" : 235478316260405248,
  "created_at" : "Wed Aug 15 16:09:19 +0000 2012",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235751276607062016",
  "geo" : {
  },
  "id_str" : "235769716268990464",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 had two this very AM!!",
  "id" : 235769716268990464,
  "in_reply_to_status_id" : 235751276607062016,
  "created_at" : "Wed Aug 15 16:07:35 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo",
      "screen_name" : "bollive",
      "indices" : [ 0, 8 ],
      "id_str" : "607367268",
      "id" : 607367268
    }, {
      "name" : "SBryan",
      "screen_name" : "Sassy_SouthernB",
      "indices" : [ 9, 25 ],
      "id_str" : "703775042",
      "id" : 703775042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/zZgoj8tl",
      "expanded_url" : "http://usatriathlon.volunteerlocal.com/volunteer/?id=1059",
      "display_url" : "usatriathlon.volunteerlocal.com/volunteer/?id=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235550488408498176",
  "in_reply_to_user_id" : 607367268,
  "text" : "@bollive @Sassy_SouthernB wrong link http://t.co/zZgoj8tl",
  "id" : 235550488408498176,
  "created_at" : "Wed Aug 15 01:36:27 +0000 2012",
  "in_reply_to_screen_name" : "bollive",
  "in_reply_to_user_id_str" : "607367268",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo",
      "screen_name" : "bollive",
      "indices" : [ 0, 8 ],
      "id_str" : "607367268",
      "id" : 607367268
    }, {
      "name" : "SBryan",
      "screen_name" : "Sassy_SouthernB",
      "indices" : [ 9, 25 ],
      "id_str" : "703775042",
      "id" : 703775042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235550308502233088",
  "in_reply_to_user_id" : 607367268,
  "text" : "@bollive @Sassy_SouthernB did 'all ask for this? yhttp://t.co/zZgoj8tl",
  "id" : 235550308502233088,
  "created_at" : "Wed Aug 15 01:35:44 +0000 2012",
  "in_reply_to_screen_name" : "bollive",
  "in_reply_to_user_id_str" : "607367268",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 62, 74 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 95, 106 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235549742426382336",
  "text" : "drinkin beers and playing with power tools in the MAN garage \"@runfasteraw: In Burlington with @andyreagan !\"",
  "id" : 235549742426382336,
  "created_at" : "Wed Aug 15 01:33:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/8drQxVKz",
      "expanded_url" : "http://twitpic.com/ajfy0h",
      "display_url" : "twitpic.com/ajfy0h"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235464483458412544",
  "text" : "mitering complete! starting to look like a bike frame http://t.co/8drQxVKz",
  "id" : 235464483458412544,
  "created_at" : "Tue Aug 14 19:54:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 13, 25 ],
      "id_str" : "75351547",
      "id" : 75351547
    }, {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 26, 35 ],
      "id_str" : "64328794",
      "id" : 64328794
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 36, 43 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/3IodiNfa",
      "expanded_url" : "http://twitpic.com/aj6d7z",
      "display_url" : "twitpic.com/aj6d7z"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235233237348278272",
  "text" : "YES #america @UVM_cycling @RBSherfy @sspis1 http://t.co/3IodiNfa",
  "id" : 235233237348278272,
  "created_at" : "Tue Aug 14 04:35:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo",
      "screen_name" : "bollive",
      "indices" : [ 0, 8 ],
      "id_str" : "607367268",
      "id" : 607367268
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 10, 18 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 20, 31 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/FGmioW8G",
      "expanded_url" : "http://www.youtube.com/watch?v=6nR5Ax4DjFw",
      "display_url" : "youtube.com/watch?v=6nR5Ax…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235212191429705729",
  "in_reply_to_user_id" : 607367268,
  "text" : "@bollive \"@Karo1yn: @andyreagan \"These beats are DOPE.\" http://t.co/FGmioW8G\"",
  "id" : 235212191429705729,
  "created_at" : "Tue Aug 14 03:12:11 +0000 2012",
  "in_reply_to_screen_name" : "bollive",
  "in_reply_to_user_id_str" : "607367268",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/4h4kpFjm",
      "expanded_url" : "http://twitpic.com/aj4rlo",
      "display_url" : "twitpic.com/aj4rlo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235194889887940608",
  "text" : "family dinner from the garden! http://t.co/4h4kpFjm",
  "id" : 235194889887940608,
  "created_at" : "Tue Aug 14 02:03:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 72, 79 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 81, 93 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/P4yGUWMc",
      "expanded_url" : "http://twitpic.com/aj3czy",
      "display_url" : "twitpic.com/aj3czy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235155401954435072",
  "text" : "my bicycle is about to represent everything that is #america, thanks to @sspis1! @UVM_cycling will approve http://t.co/P4yGUWMc",
  "id" : 235155401954435072,
  "created_at" : "Mon Aug 13 23:26:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 78, 86 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235098965308227584",
  "text" : "fighting the waves at North Beach: felt like ashton kutcher in \"the gaurdian\" @Karo1yn",
  "id" : 235098965308227584,
  "created_at" : "Mon Aug 13 19:42:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234830929410011136",
  "text" : "having a tough time deciding whether to put aerobars and forward seatpost on my road bike for upcoming tri's...no practice in them",
  "id" : 234830929410011136,
  "created_at" : "Mon Aug 13 01:57:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Miller",
      "screen_name" : "ttmill",
      "indices" : [ 121, 128 ],
      "id_str" : "549461514",
      "id" : 549461514
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 129, 137 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "legit",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "nextyearwillrock",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234801297537245184",
  "text" : "heard some sweet jams echoing from the backyard, followed the music...our neighbors have a band #legit #nextyearwillrock @ttmill @Karo1yn",
  "id" : 234801297537245184,
  "created_at" : "Sun Aug 12 23:59:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234800334244020224",
  "text" : "went for a solid brick workout, stole a strava segment on the bike! first time running with music via yurbuds...not too bad",
  "id" : 234800334244020224,
  "created_at" : "Sun Aug 12 23:55:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/234757871722700800/photo/1",
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/B8nsNB6H",
      "media_url" : "http://pbs.twimg.com/media/A0IHCmDCIAA7BZK.jpg",
      "id_str" : "234757871731089408",
      "id" : 234757871731089408,
      "media_url_https" : "https://pbs.twimg.com/media/A0IHCmDCIAA7BZK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com/B8nsNB6H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234757871722700800",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 uh oh, you better watch out http://t.co/B8nsNB6H",
  "id" : 234757871722700800,
  "created_at" : "Sun Aug 12 21:06:53 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Coleman",
      "screen_name" : "Haydocktor",
      "indices" : [ 15, 26 ],
      "id_str" : "167971811",
      "id" : 167971811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LT100",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/sdrenB7v",
      "expanded_url" : "http://twitter.com/Haydocktor/status/234751352222388226/photo/1",
      "display_url" : "pic.twitter.com/sdrenB7v"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234757588271628288",
  "text" : "so awesome! RT @Haydocktor I plundered the booty I came for #LT100 http://t.co/sdrenB7v",
  "id" : 234757588271628288,
  "created_at" : "Sun Aug 12 21:05:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer ☮",
      "screen_name" : "davewiner",
      "indices" : [ 3, 13 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/43y0AMDY",
      "expanded_url" : "http://7i.r2.ly/",
      "display_url" : "7i.r2.ly"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234722753608040448",
  "text" : "RT @davewiner: Snow storms are socialist.  http://t.co/43y0AMDY",
  "retweeted_status" : {
    "source" : "<a href=\"http://docs.reallysimple.org/\" rel=\"nofollow\">Radio2</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http://t.co/43y0AMDY",
        "expanded_url" : "http://7i.r2.ly/",
        "display_url" : "7i.r2.ly"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234702818899017728",
    "text" : "Snow storms are socialist.  http://t.co/43y0AMDY",
    "id" : 234702818899017728,
    "created_at" : "Sun Aug 12 17:28:07 +0000 2012",
    "user" : {
      "name" : "Dave Winer ☮",
      "screen_name" : "davewiner",
      "protected" : false,
      "id_str" : "3839",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3292247198/656d982219b1058820a9fb640109fd57_normal.png",
      "id" : 3839,
      "verified" : true
    }
  },
  "id" : 234722753608040448,
  "created_at" : "Sun Aug 12 18:47:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Martin",
      "screen_name" : "a_martin00",
      "indices" : [ 0, 11 ],
      "id_str" : "254218062",
      "id" : 254218062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234707274839519233",
  "geo" : {
  },
  "id_str" : "234713161188638720",
  "in_reply_to_user_id" : 254218062,
  "text" : "@a_martin00 congrats!!",
  "id" : 234713161188638720,
  "in_reply_to_status_id" : 234707274839519233,
  "created_at" : "Sun Aug 12 18:09:13 +0000 2012",
  "in_reply_to_screen_name" : "a_martin00",
  "in_reply_to_user_id_str" : "254218062",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/cgOHxrqf",
      "expanded_url" : "http://www.velocipedesalon.com/forum/f22/gaulzetti-cicli-17026.html",
      "display_url" : "velocipedesalon.com/forum/f22/gaul…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234712963670495232",
  "text" : "great post \"So what the hell am I doing making bikes?\" http://t.co/cgOHxrqf",
  "id" : 234712963670495232,
  "created_at" : "Sun Aug 12 18:08:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/zZgoj8tl",
      "expanded_url" : "http://usatriathlon.volunteerlocal.com/volunteer/?id=1059",
      "display_url" : "usatriathlon.volunteerlocal.com/volunteer/?id=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234712545083154432",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 http://t.co/zZgoj8tl",
  "id" : 234712545083154432,
  "created_at" : "Sun Aug 12 18:06:46 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lindz",
      "screen_name" : "lindzshark",
      "indices" : [ 0, 11 ],
      "id_str" : "230893616",
      "id" : 230893616
    }, {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 12, 22 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234624377952555008",
  "geo" : {
  },
  "id_str" : "234658239453728769",
  "in_reply_to_user_id" : 230893616,
  "text" : "@lindzshark @SH13LDS21 we should be defending that title today!!",
  "id" : 234658239453728769,
  "in_reply_to_status_id" : 234624377952555008,
  "created_at" : "Sun Aug 12 14:30:58 +0000 2012",
  "in_reply_to_screen_name" : "lindzshark",
  "in_reply_to_user_id_str" : "230893616",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/lYaO6C78",
      "expanded_url" : "http://twitpic.com/aid3hv",
      "display_url" : "twitpic.com/aid3hv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234505627555205121",
  "text" : "today's frame template! hitting the lanes w @SuMillie http://t.co/lYaO6C78",
  "id" : 234505627555205121,
  "created_at" : "Sun Aug 12 04:24:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "4g",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234363159845158912",
  "geo" : {
  },
  "id_str" : "234364435932786688",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie oh, I'm sorry your phone can't keep up...I already replied before you tweeted #boom sounds like someone has some #4g envy",
  "id" : 234364435932786688,
  "in_reply_to_status_id" : 234363159845158912,
  "created_at" : "Sat Aug 11 19:03:30 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetdump",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "200NotOn100",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234363686683287552",
  "text" : "#tweetdump complete! finishing my own #200NotOn100 vid and my bike frame design",
  "id" : 234363686683287552,
  "created_at" : "Sat Aug 11 19:00:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/234361879894564864/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/R8lFN1df",
      "media_url" : "http://pbs.twimg.com/media/A0Ce41iCIAAx0TS.jpg",
      "id_str" : "234361879902953472",
      "id" : 234361879902953472,
      "media_url_https" : "https://pbs.twimg.com/media/A0Ce41iCIAAx0TS.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/R8lFN1df"
    } ],
    "hashtags" : [ {
      "text" : "conquered",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "200noton100",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "slowbutsteady",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361879894564864",
  "text" : "Kancamagus Pass #conquered #200noton100 #slowbutsteady http://t.co/R8lFN1df",
  "id" : 234361879894564864,
  "created_at" : "Sat Aug 11 18:53:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/234361758205227009/photo/1",
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/3LY4Y31g",
      "media_url" : "http://pbs.twimg.com/media/A0CexwMCMAMXLGB.jpg",
      "id_str" : "234361758209421315",
      "id" : 234361758209421315,
      "media_url_https" : "https://pbs.twimg.com/media/A0CexwMCMAMXLGB.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/3LY4Y31g"
    } ],
    "hashtags" : [ {
      "text" : "conquered",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "200noton100",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "slowbutsteady",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361758205227009",
  "text" : "Kancamagus Pass #conquered #200noton100 #slowbutsteady http://t.co/3LY4Y31g",
  "id" : 234361758205227009,
  "created_at" : "Sat Aug 11 18:52:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creepedout",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361668744933376",
  "text" : "neighbors porch light keeps turning on and off. did while I walked on porch. switch, just inside front door, was off, and works #creepedout",
  "id" : 234361668744933376,
  "created_at" : "Sat Aug 11 18:52:30 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dmb",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "dmb",
      "indices" : [ 5, 9 ]
    }, {
      "text" : "dmb",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361662122106880",
  "text" : "#dmb #dmb #dmb",
  "id" : 234361662122106880,
  "created_at" : "Sat Aug 11 18:52:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361653930639360",
  "text" : "the Green Mtns are, as the name would suggest, very green!",
  "id" : 234361653930639360,
  "created_at" : "Sat Aug 11 18:52:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "durpmobile",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234361646552854528",
  "text" : "cruisin home in the #durpmobile after a royal a$$ kicking in a really hard 5k... note to self: don't go out at 5:20 pace on hilly trails",
  "id" : 234361646552854528,
  "created_at" : "Sat Aug 11 18:52:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "draftdump",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "watchout",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "youvebeenwarned",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820993167, -73.2029993333 ]
  },
  "id_str" : "234361347524149248",
  "text" : "going to attempt sending all my drafts from the old phone over wifi #draftdump #watchout #youvebeenwarned",
  "id" : 234361347524149248,
  "created_at" : "Sat Aug 11 18:51:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james farrell",
      "screen_name" : "jamesfarrell__",
      "indices" : [ 0, 15 ],
      "id_str" : "309741214",
      "id" : 309741214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retweet",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234338784676823040",
  "geo" : {
  },
  "id_str" : "234358016382758913",
  "in_reply_to_user_id" : 309741214,
  "text" : "@jamesfarrell__ I tried to retweet your retweet but twitter just couldn't handle it #retweet^2",
  "id" : 234358016382758913,
  "in_reply_to_status_id" : 234338784676823040,
  "created_at" : "Sat Aug 11 18:37:59 +0000 2012",
  "in_reply_to_screen_name" : "jamesfarrell__",
  "in_reply_to_user_id_str" : "309741214",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 1, 13 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 35, 46 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 56, 67 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cuse",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "marathon",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234357645891493888",
  "text" : ".@VTTriathlon represents in #cuse \"@skholden17: Wearing @andyreagan Hokie Triathlon shirt for this early morning long run! #marathon\"",
  "id" : 234357645891493888,
  "created_at" : "Sat Aug 11 18:36:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234356770842218496",
  "text" : "survived the whitecaps at north beach...bring it on open water swimming",
  "id" : 234356770842218496,
  "created_at" : "Sat Aug 11 18:33:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AGNats12",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234336116390625280",
  "text" : "here's to still hoping just more swimming will make me a better swimmer, north beach wetsuit action. too bad the #AGNats12 course ins't here",
  "id" : 234336116390625280,
  "created_at" : "Sat Aug 11 17:10:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firsttweet",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234334803086954497",
  "text" : "the droid pro kicked the bucket...now rockin the samsung galaxy #firsttweet",
  "id" : 234334803086954497,
  "created_at" : "Sat Aug 11 17:05:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howdidthathappen",
      "indices" : [ 87, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234297482018951169",
  "text" : "fall triathlon and MTB races in my calendar now...racing a tri the next three weekends #howdidthathappen",
  "id" : 234297482018951169,
  "created_at" : "Sat Aug 11 14:37:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/234088993904529408/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/UXs4RsUi",
      "media_url" : "http://pbs.twimg.com/media/Az-msx_CEAIepXz.jpg",
      "id_str" : "234088993908723714",
      "id" : 234088993908723714,
      "media_url_https" : "https://pbs.twimg.com/media/Az-msx_CEAIepXz.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/UXs4RsUi"
    } ],
    "hashtags" : [ {
      "text" : "framebuilding",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4819293167, -73.2029280833 ]
  },
  "id_str" : "234088993904529408",
  "text" : "brazing progress #framebuilding http://t.co/UXs4RsUi",
  "id" : 234088993904529408,
  "created_at" : "Sat Aug 11 00:49:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Coleman",
      "screen_name" : "Haydocktor",
      "indices" : [ 0, 11 ],
      "id_str" : "167971811",
      "id" : 167971811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LT100",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48187075, -73.20303565 ]
  },
  "id_str" : "234067484939001856",
  "in_reply_to_user_id" : 167971811,
  "text" : "@Haydocktor best of luck tomorrow sir! #LT100",
  "id" : 234067484939001856,
  "created_at" : "Fri Aug 10 23:23:31 +0000 2012",
  "in_reply_to_screen_name" : "Haydocktor",
  "in_reply_to_user_id_str" : "167971811",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry ChaBOOM",
      "screen_name" : "closethedoor",
      "indices" : [ 0, 13 ],
      "id_str" : "19867945",
      "id" : 19867945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233992586828865536",
  "geo" : {
  },
  "id_str" : "234066509863997440",
  "in_reply_to_user_id" : 19867945,
  "text" : "@closethedoor do you like it??",
  "id" : 234066509863997440,
  "in_reply_to_status_id" : 233992586828865536,
  "created_at" : "Fri Aug 10 23:19:39 +0000 2012",
  "in_reply_to_screen_name" : "closethedoor",
  "in_reply_to_user_id_str" : "19867945",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233955851734503424",
  "geo" : {
  },
  "id_str" : "233960056020934656",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy wringing it out also feel pretty badass...just sayin",
  "id" : 233960056020934656,
  "in_reply_to_status_id" : 233955851734503424,
  "created_at" : "Fri Aug 10 16:16:38 +0000 2012",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature Staff",
      "screen_name" : "heardatnature",
      "indices" : [ 18, 32 ],
      "id_str" : "250137376",
      "id" : 250137376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233958270333755396",
  "text" : "certainly not! RT @heardatnature “I don’t want my Olympics to be too deterministic.”",
  "id" : 233958270333755396,
  "created_at" : "Fri Aug 10 16:09:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mooreslaw",
      "indices" : [ 123, 133 ]
    }, {
      "text" : "imold",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233957908096876544",
  "text" : "the Samsung Galaxy III (phone!) has a dual core 1.5Ghz processor, and I remember the days I built slower top-shelf desktop #mooreslaw #imold",
  "id" : 233957908096876544,
  "created_at" : "Fri Aug 10 16:08:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/KDSOLBQj",
      "expanded_url" : "http://connect.garmin.com/course/1844928#.UCUxIsO2Fig.twitter",
      "display_url" : "connect.garmin.com/course/1844928…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233957180330618880",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 8 miles! http://t.co/KDSOLBQj",
  "id" : 233957180330618880,
  "created_at" : "Fri Aug 10 16:05:13 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 76, 83 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233955100824047617",
  "geo" : {
  },
  "id_str" : "233955849050157057",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 well when I run with the Garmin, I use their Garmin Connect and @strava. You should check out strava!! It's cool",
  "id" : 233955849050157057,
  "in_reply_to_status_id" : 233955100824047617,
  "created_at" : "Fri Aug 10 15:59:55 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/q23UOaWl",
      "expanded_url" : "http://www.youtube.com/watch?v=Wgr-Z0M1kmY&feature=player_embedded",
      "display_url" : "youtube.com/watch?v=Wgr-Z0…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233954967411625984",
  "text" : "my roommate's cousins sail a catamaran across lake george in about 60sec on one hull #awesome: http://t.co/q23UOaWl",
  "id" : 233954967411625984,
  "created_at" : "Fri Aug 10 15:56:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/QYFymTPK",
      "expanded_url" : "http://nike.com",
      "display_url" : "nike.com"
    } ]
  },
  "in_reply_to_status_id_str" : "233954154773635072",
  "geo" : {
  },
  "id_str" : "233954579912462336",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 awesome! where do you upload your runs, http://t.co/QYFymTPK?",
  "id" : 233954579912462336,
  "in_reply_to_status_id" : 233954154773635072,
  "created_at" : "Fri Aug 10 15:54:53 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233953032012976128",
  "geo" : {
  },
  "id_str" : "233953676312576000",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 no Garmin, so I don't know!",
  "id" : 233953676312576000,
  "in_reply_to_status_id" : 233953032012976128,
  "created_at" : "Fri Aug 10 15:51:17 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmi",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233945340154347521",
  "text" : "reminder to self: when you think running 90min in a cotton shirt will be oh fine, think again. wrung out like a half gallon #tmi",
  "id" : 233945340154347521,
  "created_at" : "Fri Aug 10 15:18:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 18, 25 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 38, 45 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233785477013069824",
  "text" : "that's my girl RT @sspis1 seeing what @strava records i can beat in chile",
  "id" : 233785477013069824,
  "created_at" : "Fri Aug 10 04:42:55 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/233719266942263296/photo/1",
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/gTUil0XK",
      "media_url" : "http://pbs.twimg.com/media/Az5Wb1uCIAED3LL.jpg",
      "id_str" : "233719266946457601",
      "id" : 233719266946457601,
      "media_url_https" : "https://pbs.twimg.com/media/Az5Wb1uCIAED3LL.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/gTUil0XK"
    } ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4853625667, -73.2205405333 ]
  },
  "id_str" : "233719266942263296",
  "text" : "the height of Huntington Gorge via the #storylab @SuMillie http://t.co/gTUil0XK",
  "id" : 233719266942263296,
  "created_at" : "Fri Aug 10 00:19:51 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233435214741901312",
  "geo" : {
  },
  "id_str" : "233657618923667456",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 yummm",
  "id" : 233657618923667456,
  "in_reply_to_status_id" : 233435214741901312,
  "created_at" : "Thu Aug 09 20:14:52 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/233638472970280960/photo/1",
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/8IFVj4Kg",
      "media_url" : "http://pbs.twimg.com/media/Az4M9AuCIAEiL0o.jpg",
      "id_str" : "233638472974475265",
      "id" : 233638472974475265,
      "media_url_https" : "https://pbs.twimg.com/media/Az4M9AuCIAEiL0o.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/8IFVj4Kg"
    } ],
    "hashtags" : [ {
      "text" : "roadtrip",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4818672833, -73.2028720667 ]
  },
  "id_str" : "233638472970280960",
  "text" : "saddlebags for the motorcycle, need to plan a #roadtrip http://t.co/8IFVj4Kg",
  "id" : 233638472970280960,
  "created_at" : "Thu Aug 09 18:58:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 108, 115 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4633531167, -73.1857178167 ]
  },
  "id_str" : "233345476261457921",
  "text" : "I'm thinking about bringing the avacado to hand fruit status. Can only imagine how good they fresh in Chile @sspis1",
  "id" : 233345476261457921,
  "created_at" : "Wed Aug 08 23:34:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821792333, -73.2031295667 ]
  },
  "id_str" : "233340469139099648",
  "text" : "simple and awesome burrito: whole wheat wrap, rice, beans, salsa, and avacado. chili powder and cumin optional. #yum",
  "id" : 233340469139099648,
  "created_at" : "Wed Aug 08 23:14:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233339291747643393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821743, -73.2031278167 ]
  },
  "id_str" : "233340026929422336",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud hahah :)",
  "id" : 233340026929422336,
  "in_reply_to_status_id" : 233339291747643393,
  "created_at" : "Wed Aug 08 23:12:52 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233333300582821888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821720833, -73.2031300167 ]
  },
  "id_str" : "233338670978068481",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud what'd ya get??",
  "id" : 233338670978068481,
  "in_reply_to_status_id" : 233333300582821888,
  "created_at" : "Wed Aug 08 23:07:29 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4824177833, -73.20302605 ]
  },
  "id_str" : "233334645058588672",
  "text" : "went for a longer swim at north beach today, got megafoned at for swimming out past the buoys....whoops",
  "id" : 233334645058588672,
  "created_at" : "Wed Aug 08 22:51:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232880863694704640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820912833, -73.2030058833 ]
  },
  "id_str" : "233281715815206912",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr I wouldn't mind!",
  "id" : 233281715815206912,
  "in_reply_to_status_id" : 232880863694704640,
  "created_at" : "Wed Aug 08 19:21:09 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821234, -73.2030464833 ]
  },
  "id_str" : "233281583132602369",
  "text" : "rewiring the electricity in an ancient house to power the garage for welding: success!",
  "id" : 233281583132602369,
  "created_at" : "Wed Aug 08 19:20:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 10, 19 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233238265250078720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821546333, -73.2030289833 ]
  },
  "id_str" : "233281296917479424",
  "in_reply_to_user_id" : 320551143,
  "text" : "@SuMillie @dr_pyser pick me pick me!",
  "id" : 233281296917479424,
  "in_reply_to_status_id" : 233238265250078720,
  "created_at" : "Wed Aug 08 19:19:29 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excellent",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232986919791906816",
  "text" : "rode 106 miles, ate ben and jerrys and jumped in the huntington gorge en route #excellent",
  "id" : 232986919791906816,
  "created_at" : "Tue Aug 07 23:49:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    }, {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 19, 30 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/6BNkJqny",
      "expanded_url" : "http://www.nytimes.com/2012/08/05/business/of-luck-and-success-economic-view.html?ref=science",
      "display_url" : "nytimes.com/2012/08/05/bus…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232878228270878720",
  "text" : "RT @ChrisDanforth: @peterdodds getting some good love from the Sunday NYT today.  Well done!  http://t.co/6BNkJqny",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Sheridan Dodds",
        "screen_name" : "peterdodds",
        "indices" : [ 0, 11 ],
        "id_str" : "16174144",
        "id" : 16174144
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/6BNkJqny",
        "expanded_url" : "http://www.nytimes.com/2012/08/05/business/of-luck-and-success-economic-view.html?ref=science",
        "display_url" : "nytimes.com/2012/08/05/bus…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232093209839407104",
    "in_reply_to_user_id" : 16174144,
    "text" : "@peterdodds getting some good love from the Sunday NYT today.  Well done!  http://t.co/6BNkJqny",
    "id" : 232093209839407104,
    "created_at" : "Sun Aug 05 12:38:27 +0000 2012",
    "in_reply_to_screen_name" : "peterdodds",
    "in_reply_to_user_id_str" : "16174144",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 232878228270878720,
  "created_at" : "Tue Aug 07 16:37:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 16, 27 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/gttNVrgR",
      "expanded_url" : "http://goo.gl/meRb0",
      "display_url" : "goo.gl/meRb0"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2604108333, -72.5751711167 ]
  },
  "id_str" : "232872362150858752",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 whoops \"@bakadesuyo: How vital is a good mattress to quality sleep? http://t.co/gttNVrgR\"",
  "id" : 232872362150858752,
  "created_at" : "Tue Aug 07 16:14:32 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill",
      "screen_name" : "jill_brandy",
      "indices" : [ 0, 12 ],
      "id_str" : "49206838",
      "id" : 49206838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laxitives",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232871191231217666",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2604112167, -72.5751575667 ]
  },
  "id_str" : "232872056683917314",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jill_brandy #laxitives",
  "id" : 232872056683917314,
  "in_reply_to_status_id" : 232871191231217666,
  "created_at" : "Tue Aug 07 16:13:19 +0000 2012",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232853871494578176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2604137833, -72.5751832667 ]
  },
  "id_str" : "232871682593939456",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 twas the oakleys...new lenses shoulda got here yesterday too, get it together mail guy",
  "id" : 232871682593939456,
  "in_reply_to_status_id" : 232853871494578176,
  "created_at" : "Tue Aug 07 16:11:50 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232845589073772544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2604099333, -72.5752167333 ]
  },
  "id_str" : "232871503371325440",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr I see how this works... I visit, you stay away!",
  "id" : 232871503371325440,
  "in_reply_to_status_id" : 232845589073772544,
  "created_at" : "Tue Aug 07 16:11:07 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.2604605667, -72.5750169167 ]
  },
  "id_str" : "232871287536623616",
  "text" : "casual 2hr ride and I'm in Montpelier, cool town!",
  "id" : 232871287536623616,
  "created_at" : "Tue Aug 07 16:10:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821045833, -73.2030445167 ]
  },
  "id_str" : "232830538300420097",
  "text" : "annie's breakfast burrito: yum. could I eat a burrito for every meal? yes",
  "id" : 232830538300420097,
  "created_at" : "Tue Aug 07 13:28:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/232826158121631744/photo/1",
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/s6TOB0I6",
      "media_url" : "http://pbs.twimg.com/media/AzsqKEHCQAEObCo.jpg",
      "id_str" : "232826158130020353",
      "id" : 232826158130020353,
      "media_url_https" : "https://pbs.twimg.com/media/AzsqKEHCQAEObCo.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/s6TOB0I6"
    } ],
    "hashtags" : [ {
      "text" : "macgyver",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820906667, -73.2031287 ]
  },
  "id_str" : "232826158121631744",
  "text" : "pin fell out of sunglasses hinge...using a staple #macgyver http://t.co/s6TOB0I6",
  "id" : 232826158121631744,
  "created_at" : "Tue Aug 07 13:10:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232824969950810112",
  "text" : "riding my bike to Montpelier to meet David for lunch!",
  "id" : 232824969950810112,
  "created_at" : "Tue Aug 07 13:06:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 3, 11 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Bo",
      "screen_name" : "bollive",
      "indices" : [ 34, 42 ],
      "id_str" : "607367268",
      "id" : 607367268
    }, {
      "name" : "Alisa McGowan",
      "screen_name" : "AMCG913",
      "indices" : [ 43, 51 ],
      "id_str" : "351965147",
      "id" : 351965147
    }, {
      "name" : "SBryan",
      "screen_name" : "Sassy_SouthernB",
      "indices" : [ 52, 68 ],
      "id_str" : "703775042",
      "id" : 703775042
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 69, 80 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232671237426511872",
  "text" : "RT @Karo1yn: DRANK WIT DA LAYDEEZ @bollive @AMCG913 @Sassy_SouthernB @andyreagan",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bo",
        "screen_name" : "bollive",
        "indices" : [ 21, 29 ],
        "id_str" : "607367268",
        "id" : 607367268
      }, {
        "name" : "Alisa McGowan",
        "screen_name" : "AMCG913",
        "indices" : [ 30, 38 ],
        "id_str" : "351965147",
        "id" : 351965147
      }, {
        "name" : "SBryan",
        "screen_name" : "Sassy_SouthernB",
        "indices" : [ 39, 55 ],
        "id_str" : "703775042",
        "id" : 703775042
      }, {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 56, 67 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232671177003393024",
    "text" : "DRANK WIT DA LAYDEEZ @bollive @AMCG913 @Sassy_SouthernB @andyreagan",
    "id" : 232671177003393024,
    "created_at" : "Tue Aug 07 02:55:06 +0000 2012",
    "user" : {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "protected" : true,
      "id_str" : "101351006",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2080762059/derpyyy_normal.jpg",
      "id" : 101351006,
      "verified" : false
    }
  },
  "id" : 232671237426511872,
  "created_at" : "Tue Aug 07 02:55:20 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4919780833, -73.2386991333 ]
  },
  "id_str" : "232618023587049472",
  "text" : "that guy floundering in a wetsuit at north beach? yup that's me",
  "id" : 232618023587049472,
  "created_at" : "Mon Aug 06 23:23:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/232459567005569024/photo/1",
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/nqnUZExi",
      "media_url" : "http://pbs.twimg.com/media/AzncvpxCEAA_rSZ.jpg",
      "id_str" : "232459567009763328",
      "id" : 232459567009763328,
      "media_url_https" : "https://pbs.twimg.com/media/AzncvpxCEAA_rSZ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/nqnUZExi"
    } ],
    "hashtags" : [ {
      "text" : "brazing",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "framebuilding",
      "indices" : [ 34, 48 ]
    }, {
      "text" : "advancedweldinginstitute",
      "indices" : [ 49, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4556354, -73.1394847833 ]
  },
  "id_str" : "232459567005569024",
  "text" : "fillet braze number one! #brazing #framebuilding #advancedweldinginstitute http://t.co/nqnUZExi",
  "id" : 232459567005569024,
  "created_at" : "Mon Aug 06 12:54:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232348440208748546",
  "text" : "RT @MarsCuriosity: I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232348380431544320",
    "text" : "I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
    "id" : 232348380431544320,
    "created_at" : "Mon Aug 06 05:32:25 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232348440208748546,
  "created_at" : "Mon Aug 06 05:32:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/XhtvI5Pn",
      "expanded_url" : "http://www.nasa.gov/externalflash/mars/curiosity_news3.html",
      "display_url" : "nasa.gov/externalflash/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232348079318249472",
  "text" : "watch: http://t.co/XhtvI5Pn",
  "id" : 232348079318249472,
  "created_at" : "Mon Aug 06 05:31:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 51, 65 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "osheaga",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232347131002896384",
  "text" : "RT @dr_pyser: home from #osheaga, just in time for @MarsCuriosity landing! gogo rover!",
  "retweeted_status" : {
    "source" : "<a href=\"https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\">Silver Bird</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 37, 51 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "osheaga",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232346827255603200",
    "text" : "home from #osheaga, just in time for @MarsCuriosity landing! gogo rover!",
    "id" : 232346827255603200,
    "created_at" : "Mon Aug 06 05:26:15 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 232347131002896384,
  "created_at" : "Mon Aug 06 05:27:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232207171583094784",
  "geo" : {
  },
  "id_str" : "232347082680332288",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 how many over par??",
  "id" : 232347082680332288,
  "in_reply_to_status_id" : 232207171583094784,
  "created_at" : "Mon Aug 06 05:27:15 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "osheaga",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821155333, -73.202972 ]
  },
  "id_str" : "232346016324669442",
  "text" : "#osheaga was amazing. reached a new level of tired, and class at 7am here we go",
  "id" : 232346016324669442,
  "created_at" : "Mon Aug 06 05:23:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamblingtweet",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.00901115, -73.4518765667 ]
  },
  "id_str" : "232144874407874561",
  "text" : "in line at the canadian border!! #gamblingtweet",
  "id" : 232144874407874561,
  "created_at" : "Sun Aug 05 16:03:45 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "indices" : [ 3, 15 ],
      "id_str" : "19368361",
      "id" : 19368361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/kx7N9Mfg",
      "expanded_url" : "http://www.nytimes.com/2012/08/05/opinion/sunday/if-kant-were-a-new-york-cyclist.htm?_r=1",
      "display_url" : "nytimes.com/2012/08/05/opi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232141817829789696",
  "text" : "RT @bikesnobnyc: Kant stop, won't stop: http://t.co/kx7N9Mfg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http://t.co/kx7N9Mfg",
        "expanded_url" : "http://www.nytimes.com/2012/08/05/opinion/sunday/if-kant-were-a-new-york-cyclist.htm?_r=1",
        "display_url" : "nytimes.com/2012/08/05/opi…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232117488387756033",
    "text" : "Kant stop, won't stop: http://t.co/kx7N9Mfg",
    "id" : 232117488387756033,
    "created_at" : "Sun Aug 05 14:14:56 +0000 2012",
    "user" : {
      "name" : "Bike Snob NYC",
      "screen_name" : "bikesnobnyc",
      "protected" : false,
      "id_str" : "19368361",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/700549149/Seal-2009-Combo-REF_normal.jpg",
      "id" : 19368361,
      "verified" : false
    }
  },
  "id" : 232141817829789696,
  "created_at" : "Sun Aug 05 15:51:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 61, 70 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "osheaga",
      "indices" : [ 10, 18 ]
    }, {
      "text" : "btv",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4888082167, -73.2020607667 ]
  },
  "id_str" : "232122960645849089",
  "text" : "headed to #osheaga from the #btv with Team Farrell @SuMillie @dr_pyser and Carrie and Benj",
  "id" : 232122960645849089,
  "created_at" : "Sun Aug 05 14:36:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 13, 20 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231965786061807616",
  "text" : "skyping with @sspis1 from CHILE!!!",
  "id" : 231965786061807616,
  "created_at" : "Sun Aug 05 04:12:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231965625696784384",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 found. darts. rooms.",
  "id" : 231965625696784384,
  "created_at" : "Sun Aug 05 04:11:29 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4765631167, -73.2143094 ]
  },
  "id_str" : "231933215408005120",
  "text" : "showing a friend around town for the night off to a great start: Founder's Porter at the Farmhouse and the Afternooner from Zero Gravity",
  "id" : 231933215408005120,
  "created_at" : "Sun Aug 05 02:02:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryank",
      "screen_name" : "ryantkelly",
      "indices" : [ 0, 11 ],
      "id_str" : "14462349",
      "id" : 14462349
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 105, 115 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231897852299857920",
  "geo" : {
  },
  "id_str" : "231901319949074432",
  "in_reply_to_user_id" : 14462349,
  "text" : "@ryantkelly email waterbottles@specialized.com, I worked with Louie Folena last year to order a bunch of @VTCycling bottles",
  "id" : 231901319949074432,
  "in_reply_to_status_id" : 231897852299857920,
  "created_at" : "Sat Aug 04 23:55:57 +0000 2012",
  "in_reply_to_screen_name" : "ryantkelly",
  "in_reply_to_user_id_str" : "14462349",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/231862941253763073/photo/1",
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/w4QhLTFk",
      "media_url" : "http://pbs.twimg.com/media/Aze-HdrCAAASwJG.jpg",
      "id_str" : "231862941266345984",
      "id" : 231862941266345984,
      "media_url_https" : "https://pbs.twimg.com/media/Aze-HdrCAAASwJG.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/w4QhLTFk"
    } ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 8, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820936167, -73.2030527167 ]
  },
  "id_str" : "231862941253763073",
  "text" : "back in #btv. stopped at Little City Cycles on the way, really cool bike shop, had a trailer full of bikes: http://t.co/w4QhLTFk",
  "id" : 231862941253763073,
  "created_at" : "Sat Aug 04 21:23:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.0893369333, -73.30240605 ]
  },
  "id_str" : "231833445385531393",
  "text" : "back in Vermont! I now understand why motorcycle riders have foot pegs for straightening the legs out front...",
  "id" : 231833445385531393,
  "created_at" : "Sat Aug 04 19:26:15 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 70, 81 ],
      "id_str" : "55931868",
      "id" : 55931868
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 82, 91 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 92, 103 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231598726437801985",
  "text" : "RT @dzdan1: breaking in the new place with beer and ice cream. thanks @andyreagan @DKnick88 @skholden17",
  "id" : 231598726437801985,
  "created_at" : "Sat Aug 04 03:53:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 24, 31 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 41, 52 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231597737299300352",
  "text" : "no mercy earlier today \"@dzdan1: lost to @andyreagan by one* stroke in disc golf despite my first hole in one\"",
  "id" : 231597737299300352,
  "created_at" : "Sat Aug 04 03:49:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Empire Brewing Co.",
      "screen_name" : "empirebrew",
      "indices" : [ 29, 40 ],
      "id_str" : "290517255",
      "id" : 290517255
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 53, 69 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 74, 83 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0544778, -76.1582395833 ]
  },
  "id_str" : "231536356113924096",
  "text" : "yet another excellent dinner @empirebrew! that's how @RumblinStumblin and @dmreagan are going to have to keep bribing me to come home",
  "id" : 231536356113924096,
  "created_at" : "Fri Aug 03 23:45:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 3, 14 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/AOp1F32v",
      "expanded_url" : "http://goo.gl/P28gD",
      "display_url" : "goo.gl/P28gD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231129400584855552",
  "text" : "RT @bakadesuyo: Do stories rule our lives? Would that be good or bad? http://t.co/AOp1F32v",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http://t.co/AOp1F32v",
        "expanded_url" : "http://goo.gl/P28gD",
        "display_url" : "goo.gl/P28gD"
      } ]
    },
    "geo" : {
    },
    "id_str" : "231117273753059328",
    "text" : "Do stories rule our lives? Would that be good or bad? http://t.co/AOp1F32v",
    "id" : 231117273753059328,
    "created_at" : "Thu Aug 02 20:00:26 +0000 2012",
    "user" : {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "protected" : false,
      "id_str" : "21424637",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/80769311/MyPicture_normal.jpg",
      "id" : 21424637,
      "verified" : false
    }
  },
  "id" : 231129400584855552,
  "created_at" : "Thu Aug 02 20:48:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 67, 74 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jamesvillebeachdisc",
      "indices" : [ 75, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9661722, -76.0693957833 ]
  },
  "id_str" : "231103338685546496",
  "text" : "out-drove and out-putted but still conceded the disc golf match to @DZdan1 #jamesvillebeachdisc",
  "id" : 231103338685546496,
  "created_at" : "Thu Aug 02 19:05:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 37, 44 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230888954545700865",
  "in_reply_to_user_id" : 179724560,
  "text" : "@thereal_timkoes the tables moves... @DZdan1",
  "id" : 230888954545700865,
  "created_at" : "Thu Aug 02 04:53:11 +0000 2012",
  "in_reply_to_screen_name" : "therealtimkoes",
  "in_reply_to_user_id_str" : "179724560",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 56, 63 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 64, 73 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flipnight",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230872361161875458",
  "text" : "currently flipping 7/11 free beers: suck it probability @DZdan1 @DKnick88 #flipnight",
  "id" : 230872361161875458,
  "created_at" : "Thu Aug 02 03:47:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 75, 86 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230872079417872384",
  "text" : "RT @DZdan1 \"there a whole lot of USA chant potential in the room tonight\" -@andyreagan",
  "id" : 230872079417872384,
  "created_at" : "Thu Aug 02 03:46:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230859955996090368",
  "text" : "that awkward moment when you forget the fastest ways around your hometown... downtown syr didnt use to take 45min",
  "id" : 230859955996090368,
  "created_at" : "Thu Aug 02 02:57:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]