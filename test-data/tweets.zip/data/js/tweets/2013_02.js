Grailbird.data.tweets_2013_02 = 
[ {
  "source" : "<a href=\"http://www.thomhoekstra.nl/pdsm/\" rel=\"nofollow\">Been there, done that</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.54321211557256, -72.81450425097654 ]
  },
  "id_str" : "306521774517022721",
  "text" : "hiking with twitter: here's one from the top of Mt. Mansfield",
  "id" : 306521774517022721,
  "created_at" : "Tue Feb 26 21:51:00 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http://t.co/ukXIGXnyej",
      "expanded_url" : "http://connect.garmin.com/activity/278019385",
      "display_url" : "connect.garmin.com/activity/27801…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "306512996694372353",
  "text" : "#btv: great running weather out there, puddles notwithstanding http://t.co/ukXIGXnyej",
  "id" : 306512996694372353,
  "created_at" : "Tue Feb 26 21:16:07 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 72, 84 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48002432, -73.19744581 ]
  },
  "id_str" : "306457493536645121",
  "text" : "\"this class would be useful if you were trying to take over the world\" -@SumaNMNDesu #springpocs2013",
  "id" : 306457493536645121,
  "created_at" : "Tue Feb 26 17:35:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 61, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47996113, -73.19759967 ]
  },
  "id_str" : "306449261468475392",
  "text" : "\"we're very stupid for not inventing facebook along the way\" #springpocs2013",
  "id" : 306449261468475392,
  "created_at" : "Tue Feb 26 17:02:52 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http://t.co/YY76M0uX0t",
      "expanded_url" : "http://twitpic.com/c71mil",
      "display_url" : "twitpic.com/c71mil"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4800912, -73.19766095 ]
  },
  "id_str" : "306442000192917504",
  "text" : "\"I heffalumped myself right about here over the weekend\" #springpocs2013 http://t.co/YY76M0uX0t",
  "id" : 306442000192917504,
  "created_at" : "Tue Feb 26 16:34:00 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 87, 100 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "training",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "roadtoCollNats",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http://t.co/PfKIlOBaJz",
      "expanded_url" : "http://connect.garmin.com/activity/277889277",
      "display_url" : "connect.garmin.com/activity/27788…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "306420484415815680",
  "text" : "4x1min VO2max intervals become 4 little spikes on a HR graph #training #roadtoCollNats @UVMTriathlon http://t.co/PfKIlOBaJz",
  "id" : 306420484415815680,
  "created_at" : "Tue Feb 26 15:08:31 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trinerd",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306262618820202496",
  "text" : "tomorrow morning, VO2max intervals! excited to be out of zone 3!! #trinerd",
  "id" : 306262618820202496,
  "created_at" : "Tue Feb 26 04:41:13 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306262537593303040",
  "text" : "tonight, finding the mistake in a 1999 paper by Carlson and Doyle #springpocs2013",
  "id" : 306262537593303040,
  "created_at" : "Tue Feb 26 04:40:53 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 16, 29 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Ian Tovell",
      "screen_name" : "IanTovell",
      "indices" : [ 55, 65 ],
      "id_str" : "849117444",
      "id" : 849117444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/Qe2JlSKLPB",
      "expanded_url" : "http://twitpic.com/c6vggv",
      "display_url" : "twitpic.com/c6vggv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47345311, -73.19580656 ]
  },
  "id_str" : "306223842492313600",
  "text" : "none other than @UVMTriathlon filling up the lanes! cc @IanTovell http://t.co/Qe2JlSKLPB",
  "id" : 306223842492313600,
  "created_at" : "Tue Feb 26 02:07:08 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "DATTTAAAAA",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306165238410145792",
  "text" : "fresh data at the #storylab and the excitement can be heard for miles! #DATTTAAAAA (think William Wallace shouting freedom)",
  "id" : 306165238410145792,
  "created_at" : "Mon Feb 25 22:14:15 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 32, 39 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 40, 48 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 49, 61 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http://t.co/m3Lt4hznEI",
      "expanded_url" : "http://www.youtube.com/watch?v=cpfQSqfpuac",
      "display_url" : "youtube.com/watch?v=cpfQSq…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "306081208692006912",
  "text" : "so funny http://t.co/m3Lt4hznEI @sspis1 @Karo1yn @SumaNMNDesu",
  "id" : 306081208692006912,
  "created_at" : "Mon Feb 25 16:40:21 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geographyofhappiness",
      "indices" : [ 84, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "306078561553494016",
  "text" : "RT @dr_pyser: my follow-up to last week's mega-blog post: What makes a city happy? (#geographyofhappiness, part 2) http://t.co/akgbgxzVV ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geographyofhappiness",
        "indices" : [ 70, 91 ]
      }, {
        "text" : "storylab",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http://t.co/akgbgxzVV0",
        "expanded_url" : "http://wp.me/p1vafz-bf",
        "display_url" : "wp.me/p1vafz-bf"
      } ]
    },
    "geo" : {
    },
    "id_str" : "306045583536300032",
    "text" : "my follow-up to last week's mega-blog post: What makes a city happy? (#geographyofhappiness, part 2) http://t.co/akgbgxzVV0 #storylab",
    "id" : 306045583536300032,
    "created_at" : "Mon Feb 25 14:18:47 +0000 2013",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 306078561553494016,
  "created_at" : "Mon Feb 25 16:29:50 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatsatoaster",
      "indices" : [ 36, 50 ]
    }, {
      "text" : "utilitybike",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http://t.co/15uVm1ETwQ",
      "expanded_url" : "http://twitpic.com/c6n5wn",
      "display_url" : "twitpic.com/c6n5wn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821005, -73.2030828 ]
  },
  "id_str" : "305894801184813057",
  "text" : "stretchy bike cargo net for the win #thatsatoaster #utilitybike http://t.co/15uVm1ETwQ",
  "id" : 305894801184813057,
  "created_at" : "Mon Feb 25 04:19:38 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 67, 77 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solid",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "USATCNC13",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "305891791163510784",
  "text" : "garmin data uploaded...11 hour training week #solid #USATCNC13 via @conneryVT",
  "id" : 305891791163510784,
  "created_at" : "Mon Feb 25 04:07:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifihadglass",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "SASQUATCHLIVES",
      "indices" : [ 47, 62 ]
    }, {
      "text" : "FREESASQUATCH",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/8Hghsux9cA",
      "expanded_url" : "http://www.nbcnews.com/video/nbc-news/50017372",
      "display_url" : "nbcnews.com/video/nbc-news…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "305887669748109312",
  "text" : "#ifihadglass  someone would FINALLY BELIEVE ME #SASQUATCHLIVES  #FREESASQUATCH  http://t.co/8Hghsux9cA",
  "id" : 305887669748109312,
  "created_at" : "Mon Feb 25 03:51:18 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 23, 31 ],
      "id_str" : "101351006",
      "id" : 101351006
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 32, 39 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Brie Timm",
      "screen_name" : "KaluYala_BrieT",
      "indices" : [ 40, 55 ],
      "id_str" : "304504811",
      "id" : 304504811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recorderjams",
      "indices" : [ 9, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/Hpcuu7jTk8",
      "expanded_url" : "http://www.youtube.com/watch?v=NGwwJEE7k48",
      "display_url" : "youtube.com/watch?v=NGwwJE…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "305876640221761538",
  "text" : "hahahaha #recorderjams @Karo1yn @sspis1 @KaluYala_BrieT http://t.co/Hpcuu7jTk8",
  "id" : 305876640221761538,
  "created_at" : "Mon Feb 25 03:07:28 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cusick",
      "screen_name" : "jcusick13",
      "indices" : [ 31, 41 ],
      "id_str" : "528928681",
      "id" : 528928681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http://t.co/kPmLLS6Rnw",
      "expanded_url" : "http://www.youtube.com/watch?v=Ugl_eAm2OGY",
      "display_url" : "youtube.com/watch?v=Ugl_eA…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "305020727323660288",
  "text" : "the best harlem shake yet, via @jcusick13 http://t.co/kPmLLS6Rnw",
  "id" : 305020727323660288,
  "created_at" : "Fri Feb 22 18:26:23 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 17, 28 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "googleeasteregg",
      "indices" : [ 77, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https://t.co/p4zH1Otac8",
      "expanded_url" : "https://www.google.com/search?q=recursion&rlz=1C1AFAB_enUS484US524&aq=f&oq=recursion&sourceid=chrome&ie=UTF-8#hl=en&rlz=1C1AFAB_enUS484US524&spell=1&q=recursion&sa=X&ei=bFAmUYq0OKXE0AHU64DQCg&ved=0CC0QBSgA&bav=on.2,or.r_gc.r_pw.r_cp.r_qf.&bvm=bv.42661473,d.dmQ&fp=f390761bf81efa0e&biw=1034&bih=875",
      "display_url" : "google.com/search?q=recur…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304634563647373315",
  "text" : "RT @SumaNMNDesu: @andyreagan https://t.co/p4zH1Otac8 Did you mean recursion? #googleeasteregg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "googleeasteregg",
        "indices" : [ 60, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https://t.co/p4zH1Otac8",
        "expanded_url" : "https://www.google.com/search?q=recursion&rlz=1C1AFAB_enUS484US524&aq=f&oq=recursion&sourceid=chrome&ie=UTF-8#hl=en&rlz=1C1AFAB_enUS484US524&spell=1&q=recursion&sa=X&ei=bFAmUYq0OKXE0AHU64DQCg&ved=0CC0QBSgA&bav=on.2,or.r_gc.r_pw.r_cp.r_qf.&bvm=bv.42661473,d.dmQ&fp=f390761bf81efa0e&biw=1034&bih=875",
        "display_url" : "google.com/search?q=recur…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "304634489936703488",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan https://t.co/p4zH1Otac8 Did you mean recursion? #googleeasteregg",
    "id" : 304634489936703488,
    "created_at" : "Thu Feb 21 16:51:36 +0000 2013",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 304634563647373315,
  "created_at" : "Thu Feb 21 16:51:54 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 75, 87 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 4, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304633787717935105",
  "text" : "\"is #springpocs2013 just one really long episode of the magic schoolbus?\" -@SumaNMNDesu",
  "id" : 304633787717935105,
  "created_at" : "Thu Feb 21 16:48:49 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "springpocs2013",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304630657840214017",
  "text" : "showing a video in class of a video of last class, so #meta #springpocs2013",
  "id" : 304630657840214017,
  "created_at" : "Thu Feb 21 16:36:23 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca K. Miller",
      "screen_name" : "rebeccakmiller",
      "indices" : [ 0, 15 ],
      "id_str" : "63190013",
      "id" : 63190013
    }, {
      "name" : "David Henry",
      "screen_name" : "D_AHenry",
      "indices" : [ 16, 25 ],
      "id_str" : "1116151178",
      "id" : 1116151178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304600663831216128",
  "geo" : {
  },
  "id_str" : "304613145580802048",
  "in_reply_to_user_id" : 63190013,
  "text" : "@rebeccakmiller @D_AHenry that's how to crowdsource information, right there",
  "id" : 304613145580802048,
  "in_reply_to_status_id" : 304600663831216128,
  "created_at" : "Thu Feb 21 15:26:48 +0000 2013",
  "in_reply_to_screen_name" : "rebeccakmiller",
  "in_reply_to_user_id_str" : "63190013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/nA1ljS1rbY",
      "expanded_url" : "http://www.youtube.com/watch?v=B4UGZEjG02s",
      "display_url" : "youtube.com/watch?v=B4UGZE…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304612676691169281",
  "text" : "the Hairy Ball Thm also tells us that there is ALWAYS a place on Earth with no wind, hint its not #btv. watch (1min): http://t.co/nA1ljS1rbY",
  "id" : 304612676691169281,
  "created_at" : "Thu Feb 21 15:24:56 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nervousstudents",
      "indices" : [ 52, 68 ]
    }, {
      "text" : "springChaos2013",
      "indices" : [ 72, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "304611590743928833",
  "text" : "about to watch a video about the Hairy Ball Theorem #nervousstudents in #springChaos2013",
  "id" : 304611590743928833,
  "created_at" : "Thu Feb 21 15:20:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Bits Blog",
      "screen_name" : "nytimesbits",
      "indices" : [ 3, 15 ],
      "id_str" : "14434070",
      "id" : 14434070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/RTvKCQFc",
      "expanded_url" : "http://nyti.ms/Zh9XHJ",
      "display_url" : "nyti.ms/Zh9XHJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "304314056465072128",
  "text" : "RT @nytimesbits: Google Will Offer Its Glasses to Select Few http://t.co/RTvKCQFc",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.nytimes.com/twitter\" rel=\"nofollow\">The New York Times</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/RTvKCQFc",
        "expanded_url" : "http://nyti.ms/Zh9XHJ",
        "display_url" : "nyti.ms/Zh9XHJ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "304303379960700928",
    "text" : "Google Will Offer Its Glasses to Select Few http://t.co/RTvKCQFc",
    "id" : 304303379960700928,
    "created_at" : "Wed Feb 20 18:55:54 +0000 2013",
    "user" : {
      "name" : "NYT Bits Blog",
      "screen_name" : "nytimesbits",
      "protected" : false,
      "id_str" : "14434070",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2078138859/NYT_Twitter_bits_normal.png",
      "id" : 14434070,
      "verified" : true
    }
  },
  "id" : 304314056465072128,
  "created_at" : "Wed Feb 20 19:38:19 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/TTkZZDpn",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=b24E-hZcAIA",
      "display_url" : "youtube.com/watch?feature=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303894275891032066",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/TTkZZDpn",
  "id" : 303894275891032066,
  "created_at" : "Tue Feb 19 15:50:16 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 0, 11 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/oFwLZlJ9",
      "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
      "display_url" : "onehappybird.com/2013/02/18/whe…"
    } ]
  },
  "in_reply_to_status_id_str" : "303564595656794112",
  "geo" : {
  },
  "id_str" : "303571884283416577",
  "in_reply_to_user_id" : 21424637,
  "text" : "@bakadesuyo you'll love this: http://t.co/oFwLZlJ9",
  "id" : 303571884283416577,
  "in_reply_to_status_id" : 303564595656794112,
  "created_at" : "Mon Feb 18 18:29:11 +0000 2013",
  "in_reply_to_screen_name" : "bakadesuyo",
  "in_reply_to_user_id_str" : "21424637",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Wolfers",
      "screen_name" : "justinwolfers",
      "indices" : [ 0, 14 ],
      "id_str" : "327577091",
      "id" : 327577091
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 98, 107 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/oFwLZlJ9",
      "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
      "display_url" : "onehappybird.com/2013/02/18/whe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303571677651038208",
  "in_reply_to_user_id" : 327577091,
  "text" : "@justinwolfers quantifying the happiness of cities: you might like this: http://t.co/oFwLZlJ9 via @dr_pyser",
  "id" : 303571677651038208,
  "created_at" : "Mon Feb 18 18:28:22 +0000 2013",
  "in_reply_to_screen_name" : "justinwolfers",
  "in_reply_to_user_id_str" : "327577091",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 0, 15 ],
      "id_str" : "579299426",
      "id" : 579299426
    }, {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 58, 67 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/oFwLZlJ9",
      "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
      "display_url" : "onehappybird.com/2013/02/18/whe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303571180567277569",
  "in_reply_to_user_id" : 579299426,
  "text" : "@stevenstrogatz more awesome stuff from the #storylab and @dr_pyser: http://t.co/oFwLZlJ9",
  "id" : 303571180567277569,
  "created_at" : "Mon Feb 18 18:26:24 +0000 2013",
  "in_reply_to_screen_name" : "stevenstrogatz",
  "in_reply_to_user_id_str" : "579299426",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 17, 31 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/oFwLZlJ9",
      "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
      "display_url" : "onehappybird.com/2013/02/18/whe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303570937700315136",
  "text" : "awesome stuff RT @ChrisDanforth What is the happiest city in the US? We used 10 million tweets to find out. http://t.co/oFwLZlJ9",
  "id" : 303570937700315136,
  "created_at" : "Mon Feb 18 18:25:26 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAUSAUSA",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "storylab",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/x1OTooPD",
      "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
      "display_url" : "onehappybird.com/2013/02/18/whe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303539871891472386",
  "text" : "RT @SumaNMNDesu: What IS the happiest city in the USA? #USAUSAUSA http://t.co/x1OTooPD #storylab",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAUSAUSA",
        "indices" : [ 38, 48 ]
      }, {
        "text" : "storylab",
        "indices" : [ 70, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/x1OTooPD",
        "expanded_url" : "http://onehappybird.com/2013/02/18/where-is-the-happiest-city-in-the-usa/",
        "display_url" : "onehappybird.com/2013/02/18/whe…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "303525517909454849",
    "text" : "What IS the happiest city in the USA? #USAUSAUSA http://t.co/x1OTooPD #storylab",
    "id" : 303525517909454849,
    "created_at" : "Mon Feb 18 15:24:57 +0000 2013",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 303539871891472386,
  "created_at" : "Mon Feb 18 16:21:59 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/LqBAnKNl",
      "expanded_url" : "http://twitpic.com/c4pfyx",
      "display_url" : "twitpic.com/c4pfyx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821516, -73.2030257 ]
  },
  "id_str" : "303338092230750209",
  "text" : "modern fireplace up in here! complete with sound http://t.co/LqBAnKNl",
  "id" : 303338092230750209,
  "created_at" : "Mon Feb 18 03:00:11 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Boloco Church Street",
      "screen_name" : "bolocochurchst",
      "indices" : [ 35, 50 ],
      "id_str" : "211284212",
      "id" : 211284212
    }, {
      "name" : "Lund",
      "screen_name" : "LundVT",
      "indices" : [ 115, 122 ],
      "id_str" : "95026680",
      "id" : 95026680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "303214585098428416",
  "text" : "RT @UVMTriathlon: huge shoutout to @bolocochurchst for making our 24HR Ride a great success!! Over $500 raised for @LundVT!!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boloco Church Street",
        "screen_name" : "bolocochurchst",
        "indices" : [ 17, 32 ],
        "id_str" : "211284212",
        "id" : 211284212
      }, {
        "name" : "Lund",
        "screen_name" : "LundVT",
        "indices" : [ 97, 104 ],
        "id_str" : "95026680",
        "id" : 95026680
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "303213279642255360",
    "text" : "huge shoutout to @bolocochurchst for making our 24HR Ride a great success!! Over $500 raised for @LundVT!!",
    "id" : 303213279642255360,
    "created_at" : "Sun Feb 17 18:44:13 +0000 2013",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 303214585098428416,
  "created_at" : "Sun Feb 17 18:49:25 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "comevisit",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/TkGuZLdJ",
      "expanded_url" : "http://twitpic.com/c4fwd6",
      "display_url" : "twitpic.com/c4fwd6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "303012211603931136",
  "text" : "RT @UVMTriathlon: we're keeping Church St lit down here! 12 more hours! #comevisit http://t.co/TkGuZLdJ",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "comevisit",
        "indices" : [ 54, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http://t.co/TkGuZLdJ",
        "expanded_url" : "http://twitpic.com/c4fwd6",
        "display_url" : "twitpic.com/c4fwd6"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 44.47776744, -73.21250196 ]
    },
    "id_str" : "303011594923814912",
    "text" : "we're keeping Church St lit down here! 12 more hours! #comevisit http://t.co/TkGuZLdJ",
    "id" : 303011594923814912,
    "created_at" : "Sun Feb 17 05:22:48 +0000 2013",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 303012211603931136,
  "created_at" : "Sun Feb 17 05:25:15 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 25, 33 ],
      "id_str" : "300735398",
      "id" : 300735398
    }, {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 48, 63 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/UxlN0fvE",
      "expanded_url" : "http://bit.ly/UstZju",
      "display_url" : "bit.ly/UstZju"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4778969, -73.2123995 ]
  },
  "id_str" : "302929481918713856",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 future children \"@aatishb: Holy WOW. RT @stevesilberman: Well, this 8 year old is one hell of a banjo picker http://t.co/UxlN0fvE\"",
  "id" : 302929481918713856,
  "created_at" : "Sat Feb 16 23:56:31 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302907685777580032",
  "text" : "RT @UVMTriathlon: we're on Church St, 4.5 hours into out 24 hour ride: raising money for the Lund Family Center! c'mon down http://t.co/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http://t.co/GK0b2Z6J",
        "expanded_url" : "http://twitpic.com/c4cqbt",
        "display_url" : "twitpic.com/c4cqbt"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 44.4779189, -73.2124548 ]
    },
    "id_str" : "302892692654940160",
    "text" : "we're on Church St, 4.5 hours into out 24 hour ride: raising money for the Lund Family Center! c'mon down http://t.co/GK0b2Z6J",
    "id" : 302892692654940160,
    "created_at" : "Sat Feb 16 21:30:20 +0000 2013",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 302907685777580032,
  "created_at" : "Sat Feb 16 22:29:54 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 69, 80 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "24hourride",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/6whVizeh",
      "expanded_url" : "http://twitter.com/UVMTriathlon/status/302903497844744193/photo/1",
      "display_url" : "pic.twitter.com/6whVizeh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "302907602885562369",
  "text" : "RT @UVMTriathlon: 30 degrees and on the rollers, its a heat wave for @andyreagan! #24hourride http://t.co/6whVizeh",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 51, 62 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/UVMTriathlon/status/302903497844744193/photo/1",
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/6whVizeh",
        "media_url" : "http://pbs.twimg.com/media/BDQhIF7CYAES9-X.jpg",
        "id_str" : "302903497853132801",
        "id" : 302903497853132801,
        "media_url_https" : "https://pbs.twimg.com/media/BDQhIF7CYAES9-X.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com/6whVizeh"
      } ],
      "hashtags" : [ {
        "text" : "24hourride",
        "indices" : [ 64, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "302903497844744193",
    "text" : "30 degrees and on the rollers, its a heat wave for @andyreagan! #24hourride http://t.co/6whVizeh",
    "id" : 302903497844744193,
    "created_at" : "Sat Feb 16 22:13:16 +0000 2013",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 302907602885562369,
  "created_at" : "Sat Feb 16 22:29:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 89, 100 ],
      "id_str" : "16174144",
      "id" : 16174144
    }, {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 122, 136 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uhoh",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302792285152743425",
  "text" : "attention UVM grad students: graduation requirements are now 2 written exams AND besting @peterdodds in a triathlon #uhoh @ChrisDanforth",
  "id" : 302792285152743425,
  "created_at" : "Sat Feb 16 14:51:21 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 96 ],
      "url" : "https://t.co/yadgHyUt",
      "expanded_url" : "https://new.livestream.com/tedx/manhattan2013",
      "display_url" : "new.livestream.com/tedx/manhattan…"
    } ]
  },
  "in_reply_to_status_id_str" : "302787280211419140",
  "geo" : {
  },
  "id_str" : "302791484594335744",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 not sure I'm trekking to campus, but it's streamed online. go here https://t.co/yadgHyUt",
  "id" : 302791484594335744,
  "in_reply_to_status_id" : 302787280211419140,
  "created_at" : "Sat Feb 16 14:48:10 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 3, 17 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "302786549999861760",
  "text" : "RT @ChrisDanforth: 1.4 million pounds, 40,000 mph, 50 ft in diameter, 20 times the energy released in Hiroshima, lucky so few were hurt. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/VDUDdjJY",
        "expanded_url" : "http://www.nytimes.com/2013/02/16/science/space/size-of-blast-and-number-of-injuries-are-seen-as-rare-for-a-rock-from-space.html?hp&_r=0",
        "display_url" : "nytimes.com/2013/02/16/sci…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "302754608902705152",
    "text" : "1.4 million pounds, 40,000 mph, 50 ft in diameter, 20 times the energy released in Hiroshima, lucky so few were hurt. http://t.co/VDUDdjJY",
    "id" : 302754608902705152,
    "created_at" : "Sat Feb 16 12:21:38 +0000 2013",
    "user" : {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "protected" : false,
      "id_str" : "301579658",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600263910/twitter-profile-pic_normal.jpg",
      "id" : 301579658,
      "verified" : false
    }
  },
  "id" : 302786549999861760,
  "created_at" : "Sat Feb 16 14:28:33 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slow Food Vermont",
      "screen_name" : "SlowFoodVT",
      "indices" : [ 3, 14 ],
      "id_str" : "104062768",
      "id" : 104062768
    }, {
      "name" : "TEDxManhattan",
      "screen_name" : "TEDxManhattan",
      "indices" : [ 47, 61 ],
      "id_str" : "179288122",
      "id" : 179288122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/kO7LsMdn",
      "expanded_url" : "http://ow.ly/hC8a9",
      "display_url" : "ow.ly/hC8a9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "302784478563168256",
  "text" : "RT @SlowFoodVT: Lafayette Rm. 207 at UVM today @TEDxManhattan live webcast of Changing the Way We Eat conference! http://t.co/kO7LsMdn # ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxManhattan",
        "screen_name" : "TEDxManhattan",
        "indices" : [ 31, 45 ],
        "id_str" : "179288122",
        "id" : 179288122
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vt",
        "indices" : [ 119, 122 ]
      }, {
        "text" : "slowfood",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/kO7LsMdn",
        "expanded_url" : "http://ow.ly/hC8a9",
        "display_url" : "ow.ly/hC8a9"
      } ]
    },
    "geo" : {
    },
    "id_str" : "302779649564483584",
    "text" : "Lafayette Rm. 207 at UVM today @TEDxManhattan live webcast of Changing the Way We Eat conference! http://t.co/kO7LsMdn #vt #slowfood",
    "id" : 302779649564483584,
    "created_at" : "Sat Feb 16 14:01:08 +0000 2013",
    "user" : {
      "name" : "Slow Food Vermont",
      "screen_name" : "SlowFoodVT",
      "protected" : false,
      "id_str" : "104062768",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/682132200/sfvt_logo_tm_normal.jpg",
      "id" : 104062768,
      "verified" : false
    }
  },
  "id" : 302784478563168256,
  "created_at" : "Sat Feb 16 14:20:19 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "need",
      "indices" : [ 8, 13 ]
    }, {
      "text" : "more",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "paul",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "pictures",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "on",
      "indices" : [ 36, 39 ]
    }, {
      "text" : "twitter",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "hashtag",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302668840742055937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48213603, -73.20297372 ]
  },
  "id_str" : "302669399150710784",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e #need #more #paul #pictures #on #twitter #hashtag",
  "id" : 302669399150710784,
  "in_reply_to_status_id" : 302668840742055937,
  "created_at" : "Sat Feb 16 06:43:02 +0000 2013",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sspis1",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/QCqcJz7O",
      "expanded_url" : "http://twitpic.com/c45kmh",
      "display_url" : "twitpic.com/c45kmh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48210008, -73.2029826 ]
  },
  "id_str" : "302668566891741184",
  "text" : "look at this one and dont mouth \"awww,\" I dare you #sspis1 http://t.co/QCqcJz7O",
  "id" : 302668566891741184,
  "created_at" : "Sat Feb 16 06:39:44 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 37, 41 ]
    }, {
      "text" : "solid",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "cuties",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/NuDHKwLs",
      "expanded_url" : "http://twitpic.com/c45k3j",
      "display_url" : "twitpic.com/c45k3j"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48208341, -73.20299664 ]
  },
  "id_str" : "302668061608116224",
  "text" : "new record spear-dorset loop from dt #btv in 57min today, barefoot run bc i forgot shoes #solid, and these 2: #cuties http://t.co/NuDHKwLs",
  "id" : 302668061608116224,
  "created_at" : "Sat Feb 16 06:37:43 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storyofourweek",
      "indices" : [ 8, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302644256290508800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48211182, -73.20300991 ]
  },
  "id_str" : "302667333170774016",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 #storyofourweek",
  "id" : 302667333170774016,
  "in_reply_to_status_id" : 302644256290508800,
  "created_at" : "Sat Feb 16 06:34:50 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/YoRMzzMC",
      "expanded_url" : "http://twitpic.com/c3rttp",
      "display_url" : "twitpic.com/c3rttp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822278, -73.2031212 ]
  },
  "id_str" : "302170031326892033",
  "text" : "got a bike frame for valentines day! thanks Cecil! http://t.co/YoRMzzMC",
  "id" : 302170031326892033,
  "created_at" : "Thu Feb 14 21:38:44 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jakewilliamsays",
      "indices" : [ 44, 60 ]
    }, {
      "text" : "springpocs2013",
      "indices" : [ 61, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47992634, -73.19767206 ]
  },
  "id_str" : "302106467484442625",
  "text" : "\"everything looks peachy...its a power law\" #jakewilliamsays #springpocs2013",
  "id" : 302106467484442625,
  "created_at" : "Thu Feb 14 17:26:09 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jakewiliamsays",
      "indices" : [ 23, 38 ]
    }, {
      "text" : "springpocs2013",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48034, -73.1971962 ]
  },
  "id_str" : "302106070439063552",
  "text" : "\"the prime number few\" #jakewiliamsays #springpocs2013",
  "id" : 302106070439063552,
  "created_at" : "Thu Feb 14 17:24:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47991317, -73.19768969 ]
  },
  "id_str" : "302105512466587650",
  "text" : "#btv folks: great resources for startups at the Entrepreneur Day in the Davis Center...and free cabot cheese",
  "id" : 302105512466587650,
  "created_at" : "Thu Feb 14 17:22:21 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/PXpdH1Fk",
      "expanded_url" : "http://twitpic.com/c3h3cn",
      "display_url" : "twitpic.com/c3h3cn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820884, -73.2030283 ]
  },
  "id_str" : "301849516703895553",
  "text" : "this tweet fits the trend http://t.co/PXpdH1Fk",
  "id" : 301849516703895553,
  "created_at" : "Thu Feb 14 00:25:07 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Triathlete Magazine",
      "screen_name" : "TriathleteMag",
      "indices" : [ 67, 81 ],
      "id_str" : "14400787",
      "id" : 14400787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/KcnO2Zcp",
      "expanded_url" : "http://ow.ly/hH4Qz",
      "display_url" : "ow.ly/hH4Qz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301848418802888705",
  "in_reply_to_user_id" : 14400787,
  "text" : "shocking, we haven't out engineering the human body on recovery: \"\n@TriathleteMag \nice and ibuprofen for recovery? http://t.co/KcnO2Zcp \"",
  "id" : 301848418802888705,
  "created_at" : "Thu Feb 14 00:20:45 +0000 2013",
  "in_reply_to_screen_name" : "TriathleteMag",
  "in_reply_to_user_id_str" : "14400787",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301846876410494976",
  "text" : "forever alone day, pro tip: verify your online identity so somebody will text you",
  "id" : 301846876410494976,
  "created_at" : "Thu Feb 14 00:14:38 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 86, 99 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCNC13",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "301846429528371203",
  "text" : "RT @UVMTriathlon: 8 weeks and 3 days until nats! crunch time! (literally?) #USATCNC13 @usatriathlon",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA Triathlon",
        "screen_name" : "usatriathlon",
        "indices" : [ 68, 81 ],
        "id_str" : "14630047",
        "id" : 14630047
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USATCNC13",
        "indices" : [ 57, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "301846361081524225",
    "text" : "8 weeks and 3 days until nats! crunch time! (literally?) #USATCNC13 @usatriathlon",
    "id" : 301846361081524225,
    "created_at" : "Thu Feb 14 00:12:35 +0000 2013",
    "user" : {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "protected" : false,
      "id_str" : "546451472",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2047165212/307250_10150317308790872_587400871_8584685_1602746145_n_normal.jpg",
      "id" : 546451472,
      "verified" : false
    }
  },
  "id" : 301846429528371203,
  "created_at" : "Thu Feb 14 00:12:51 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 76, 89 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "champstatus",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48206074, -73.20324152 ]
  },
  "id_str" : "301778650448146432",
  "text" : "below 40º, cyclists forgoe the brotherly head nod for a salute #champstatus @DaBrownNoise",
  "id" : 301778650448146432,
  "created_at" : "Wed Feb 13 19:43:31 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 23, 30 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/zhdgLd6Z",
      "expanded_url" : "http://twitpic.com/c3fhwf",
      "display_url" : "twitpic.com/c3fhwf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820874, -73.2030254 ]
  },
  "id_str" : "301777385265713152",
  "text" : "post ride panini yummm @sspis1 http://t.co/zhdgLd6Z",
  "id" : 301777385265713152,
  "created_at" : "Wed Feb 13 19:38:30 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vermontcycling",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/CBe4fBq3",
      "expanded_url" : "http://twitpic.com/c3f5jx",
      "display_url" : "twitpic.com/c3f5jx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.42762033, -73.19408974 ]
  },
  "id_str" : "301761863568474112",
  "text" : "40 degrees feels like summer! #vermontcycling http://t.co/CBe4fBq3",
  "id" : 301761863568474112,
  "created_at" : "Wed Feb 13 18:36:49 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Spisiak",
      "screen_name" : "withane271",
      "indices" : [ 0, 11 ],
      "id_str" : "606793907",
      "id" : 606793907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/h7NaKE0P",
      "expanded_url" : "http://www.sugarbush.com/vermont-skiing-snowboarding/ticket-prices/lift-ticket-pricing",
      "display_url" : "sugarbush.com/vermont-skiing…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "301523894567845888",
  "in_reply_to_user_id" : 606793907,
  "text" : "@withane271 the full day online isn't much more than a half day. i could bring sam back earlier to work http://t.co/h7NaKE0P",
  "id" : 301523894567845888,
  "created_at" : "Wed Feb 13 02:51:13 +0000 2013",
  "in_reply_to_screen_name" : "withane271",
  "in_reply_to_user_id_str" : "606793907",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/cPNRLyhT",
      "expanded_url" : "http://twitpic.com/c37a9p",
      "display_url" : "twitpic.com/c37a9p"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.531639, -73.2507428 ]
  },
  "id_str" : "301498373356269568",
  "text" : "if your car looks like this, you might have a problem driving: #ouch http://t.co/cPNRLyhT",
  "id" : 301498373356269568,
  "created_at" : "Wed Feb 13 01:09:48 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300779741470924801",
  "geo" : {
  },
  "id_str" : "300784164171571200",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy make sure not to run any extra next time",
  "id" : 300784164171571200,
  "in_reply_to_status_id" : 300779741470924801,
  "created_at" : "Mon Feb 11 01:51:47 +0000 2013",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "skiVT",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4219253, -72.8522015 ]
  },
  "id_str" : "300683083018014721",
  "text" : "bolton xc action #free thanks BlueCross #skiVT",
  "id" : 300683083018014721,
  "created_at" : "Sun Feb 10 19:10:08 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beersnobs",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "btv",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "zerogravity",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/oPSBo9B7",
      "expanded_url" : "http://twitpic.com/c2dn41",
      "display_url" : "twitpic.com/c2dn41"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48203836, -73.20312734 ]
  },
  "id_str" : "300478630256066560",
  "text" : "5 points if you can guess which one is the snifter: #beersnobs #btv #zerogravity http://t.co/oPSBo9B7",
  "id" : 300478630256066560,
  "created_at" : "Sun Feb 10 05:37:42 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "teletherm",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/jpGrW04C",
      "expanded_url" : "http://twitpic.com/c2btjk",
      "display_url" : "twitpic.com/c2btjk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48221807, -73.20311575 ]
  },
  "id_str" : "300425070340354048",
  "text" : "successful debut for the bike cargo net and celebration of the #btv winter #teletherm http://t.co/jpGrW04C",
  "id" : 300425070340354048,
  "created_at" : "Sun Feb 10 02:04:53 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/300345511989362688/photo/1",
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/xG5ceA5k",
      "media_url" : "http://pbs.twimg.com/media/BCsKpuCCQAAMiWQ.jpg",
      "id_str" : "300345511997751296",
      "id" : 300345511997751296,
      "media_url_https" : "https://pbs.twimg.com/media/BCsKpuCCQAAMiWQ.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/xG5ceA5k"
    } ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300345511989362688",
  "text" : "going in the oven now: cinnamon sugar bread. hope the #storylab is ready! http://t.co/xG5ceA5k",
  "id" : 300345511989362688,
  "created_at" : "Sat Feb 09 20:48:45 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "intervale",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "deeppowder",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "btv",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "neededwater",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300316369700933633",
  "text" : "excellent 10 miles on the XC skis!! #intervale #deeppowder #btv #neededwater",
  "id" : 300316369700933633,
  "created_at" : "Sat Feb 09 18:52:56 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Otto the Ottoman",
      "screen_name" : "ottotheotto",
      "indices" : [ 21, 33 ],
      "id_str" : "865842546",
      "id" : 865842546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/WHQ6cUQX",
      "expanded_url" : "http://www.youtube.com/watch?v=lpzqQst-Sg8",
      "display_url" : "youtube.com/watch?v=lpzqQs…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "300072069708783616",
  "in_reply_to_user_id" : 228268171,
  "text" : "@dzdan1 i heard from @ottotheotto that this song is on repeat? http://t.co/WHQ6cUQX",
  "id" : 300072069708783616,
  "created_at" : "Sat Feb 09 02:42:11 +0000 2013",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killinit",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "300069777324523523",
  "text" : "I'm decidedly too competitive to run on the indoor track. 5 mile run turned into 32 minute sprint #killinit",
  "id" : 300069777324523523,
  "created_at" : "Sat Feb 09 02:33:04 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Culture Cycles",
      "screen_name" : "CultureCycles",
      "indices" : [ 25, 39 ],
      "id_str" : "39440392",
      "id" : 39440392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/H0MOhDVz",
      "expanded_url" : "http://twitpic.com/c1wr0n",
      "display_url" : "twitpic.com/c1wr0n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4832862, -73.1936157 ]
  },
  "id_str" : "299909597186121728",
  "text" : "this is how we roll #btv @CultureCycles http://t.co/H0MOhDVz",
  "id" : 299909597186121728,
  "created_at" : "Fri Feb 08 15:56:34 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allterrainvehicle",
      "indices" : [ 56, 74 ]
    }, {
      "text" : "carwithsnowtiresmyass",
      "indices" : [ 75, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.48193123, -73.20324956 ]
  },
  "id_str" : "299905610667929600",
  "text" : "snowing hard out there = need to take the bike to work! #allterrainvehicle #carwithsnowtiresmyass",
  "id" : 299905610667929600,
  "created_at" : "Fri Feb 08 15:40:44 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikes",
      "indices" : [ 26, 32 ]
    }, {
      "text" : "btv",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/NwuE629v",
      "expanded_url" : "http://twitpic.com/c1rq19",
      "display_url" : "twitpic.com/c1rq19"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820879, -73.2030269 ]
  },
  "id_str" : "299751131276533760",
  "text" : "the ladies are a paintin' #bikes #btv http://t.co/NwuE629v",
  "id" : 299751131276533760,
  "created_at" : "Fri Feb 08 05:26:53 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadtocollnats",
      "indices" : [ 20, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/zFnYmPQa",
      "expanded_url" : "http://twitpic.com/c1r0qq",
      "display_url" : "twitpic.com/c1r0qq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4820889, -73.2030283 ]
  },
  "id_str" : "299723736616157186",
  "text" : "it was a swim night #roadtocollnats http://t.co/zFnYmPQa",
  "id" : 299723736616157186,
  "created_at" : "Fri Feb 08 03:38:02 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/sE6Vxqgp",
      "expanded_url" : "http://onehappybird.com/2013/02/07/the-daily-unraveling-of-the-human-mind/",
      "display_url" : "onehappybird.com/2013/02/07/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299644511607480323",
  "text" : "RT @stevenstrogatz: Daily tweet rhythms of human happiness and frustration http://t.co/sE6Vxqgp",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http://t.co/sE6Vxqgp",
        "expanded_url" : "http://onehappybird.com/2013/02/07/the-daily-unraveling-of-the-human-mind/",
        "display_url" : "onehappybird.com/2013/02/07/the…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "299642769524269056",
    "text" : "Daily tweet rhythms of human happiness and frustration http://t.co/sE6Vxqgp",
    "id" : 299642769524269056,
    "created_at" : "Thu Feb 07 22:16:18 +0000 2013",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 299644511607480323,
  "created_at" : "Thu Feb 07 22:23:13 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatisafalafel",
      "indices" : [ 50, 65 ]
    }, {
      "text" : "jakewilliamsays",
      "indices" : [ 66, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299611406750339072",
  "text" : "vermont, the cultural center for arabian burritos #whatisafalafel #jakewilliamsays",
  "id" : 299611406750339072,
  "created_at" : "Thu Feb 07 20:11:40 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "indices" : [ 3, 11 ],
      "id_str" : "811907299",
      "id" : 811907299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "totalchaos",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "homoclinic",
      "indices" : [ 76, 87 ]
    }, {
      "text" : "littleballs",
      "indices" : [ 88, 100 ]
    }, {
      "text" : "mindblown",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/COYqEOLv",
      "expanded_url" : "http://twitter.com/linzvee/status/299602021416321024/photo/1",
      "display_url" : "pic.twitter.com/COYqEOLv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299602401969721345",
  "text" : "RT @linzvee: Complexity.  Don't try to draw this at home, kids. #totalchaos #homoclinic #littleballs #mindblown http://t.co/COYqEOLv",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/linzvee/status/299602021416321024/photo/1",
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/COYqEOLv",
        "media_url" : "http://pbs.twimg.com/media/BChmc30CQAAZ1ci.jpg",
        "id_str" : "299602021424709632",
        "id" : 299602021424709632,
        "media_url_https" : "https://pbs.twimg.com/media/BChmc30CQAAZ1ci.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/COYqEOLv"
      } ],
      "hashtags" : [ {
        "text" : "totalchaos",
        "indices" : [ 51, 62 ]
      }, {
        "text" : "homoclinic",
        "indices" : [ 63, 74 ]
      }, {
        "text" : "littleballs",
        "indices" : [ 75, 87 ]
      }, {
        "text" : "mindblown",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "299602021416321024",
    "text" : "Complexity.  Don't try to draw this at home, kids. #totalchaos #homoclinic #littleballs #mindblown http://t.co/COYqEOLv",
    "id" : 299602021416321024,
    "created_at" : "Thu Feb 07 19:34:23 +0000 2013",
    "user" : {
      "name" : "Lindsay Van Leir",
      "screen_name" : "linzvee",
      "protected" : false,
      "id_str" : "811907299",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2609674893/816m0iuvbbybuvqvb8io_normal.jpeg",
      "id" : 811907299,
      "verified" : false
    }
  },
  "id" : 299602401969721345,
  "created_at" : "Thu Feb 07 19:35:53 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 1, 10 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slamthatstem",
      "indices" : [ 67, 80 ]
    }, {
      "text" : "slamming",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/I5r7vqyC",
      "expanded_url" : "http://slamthatstem.com/",
      "display_url" : "slamthatstem.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299574254486290433",
  "text" : ".@dr_pyser there's a wealth of knowledge here http://t.co/I5r7vqyC #slamthatstem #slamming",
  "id" : 299574254486290433,
  "created_at" : "Thu Feb 07 17:44:02 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 8, 19 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299571570706358272",
  "geo" : {
  },
  "id_str" : "299573355961524224",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @kreagannet excuse me? maybe she was sleeping when I left this morning...tan leather boots, dark jeans, and an eddie bauer sweater",
  "id" : 299573355961524224,
  "in_reply_to_status_id" : 299571570706358272,
  "created_at" : "Thu Feb 07 17:40:28 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "indices" : [ 3, 15 ],
      "id_str" : "320551143",
      "id" : 320551143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storylab",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/eGlNCZ0d",
      "expanded_url" : "http://onehappybird.com/2013/02/07/the-daily-unraveling-of-the-human-mind/",
      "display_url" : "onehappybird.com/2013/02/07/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "299562690630787073",
  "text" : "RT @SumaNMNDesu: My very first  blogpost \"The Daily Unraveling of the Human Mind\" http://t.co/eGlNCZ0d #storylab",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storylab",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http://t.co/eGlNCZ0d",
        "expanded_url" : "http://onehappybird.com/2013/02/07/the-daily-unraveling-of-the-human-mind/",
        "display_url" : "onehappybird.com/2013/02/07/the…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "299520272845922304",
    "text" : "My very first  blogpost \"The Daily Unraveling of the Human Mind\" http://t.co/eGlNCZ0d #storylab",
    "id" : 299520272845922304,
    "created_at" : "Thu Feb 07 14:09:32 +0000 2013",
    "user" : {
      "name" : "Suma",
      "screen_name" : "SumaNMNDesu",
      "protected" : false,
      "id_str" : "320551143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2625558466/569jcg7wn866bcjtlz37_normal.jpeg",
      "id" : 320551143,
      "verified" : false
    }
  },
  "id" : 299562690630787073,
  "created_at" : "Thu Feb 07 16:58:05 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springchaos2013",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299549720152530944",
  "text" : "\"this figure only hints at the complexity\" #springchaos2013",
  "id" : 299549720152530944,
  "created_at" : "Thu Feb 07 16:06:33 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unixcommandlinemadness",
      "indices" : [ 13, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "299181128638681088",
  "text" : "less is more #unixcommandlinemadness",
  "id" : 299181128638681088,
  "created_at" : "Wed Feb 06 15:41:54 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cabot Cheese",
      "screen_name" : "CabotCoop",
      "indices" : [ 4, 14 ],
      "id_str" : "16121039",
      "id" : 16121039
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 25, 32 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "VTcheese",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/FIPfy3pR",
      "expanded_url" : "http://twitpic.com/c18y6w",
      "display_url" : "twitpic.com/c18y6w"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482089, -73.2030279 ]
  },
  "id_str" : "298998969776889859",
  "text" : "the @CabotCoop cheese on @sspis1's homemade bean burger looks like vermont!! #btv #VTcheese http://t.co/FIPfy3pR",
  "id" : 298998969776889859,
  "created_at" : "Wed Feb 06 03:38:04 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298957871335489536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4694214, -73.194322 ]
  },
  "id_str" : "298981656407203840",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy in fact, I listened to it on audible for free, sign up and get one free!",
  "id" : 298981656407203840,
  "in_reply_to_status_id" : 298957871335489536,
  "created_at" : "Wed Feb 06 02:29:16 +0000 2013",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298957871335489536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46933093, -73.19509094 ]
  },
  "id_str" : "298959777701195776",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy most definitely! most recently I read nate silver's \"the signal and the noise\" and very much enjoyed.",
  "id" : 298959777701195776,
  "in_reply_to_status_id" : 298957871335489536,
  "created_at" : "Wed Feb 06 01:02:20 +0000 2013",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "springpocs2013",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298933821808709632",
  "text" : "listening to \"the invention of money\" on the trainer, via #springpocs2013's old blog. the class might have heard the start of it today...",
  "id" : 298933821808709632,
  "created_at" : "Tue Feb 05 23:19:11 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298924956610347008",
  "text" : "what not to do: start downloading the whole month's training data right before wanting to ride",
  "id" : 298924956610347008,
  "created_at" : "Tue Feb 05 22:43:58 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "City Market",
      "screen_name" : "CityMarket",
      "indices" : [ 27, 38 ],
      "id_str" : "39795528",
      "id" : 39795528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btv",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "298839007767437313",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 is it free? \"Go to @CityMarket, get the raspberry XOXO chocolate - so good! (also the perfect valentine's day chocolate!) #btv\"",
  "id" : 298839007767437313,
  "created_at" : "Tue Feb 05 17:02:26 +0000 2013",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 63, 68 ]
    }, {
      "text" : "TeX",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "LaTeX",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/kS5UyIz2",
      "expanded_url" : "http://www.youtube.com/watch?v=WDSV1WfBqMo",
      "display_url" : "youtube.com/watch?v=WDSV1W…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "298590163108519936",
  "text" : "my recent LaTeX seminar, in video format: http://t.co/kS5UyIz2 #math #TeX #LaTeX",
  "id" : 298590163108519936,
  "created_at" : "Tue Feb 05 00:33:37 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Herkenham",
      "screen_name" : "Karo1yn",
      "indices" : [ 0, 8 ],
      "id_str" : "101351006",
      "id" : 101351006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298236039439474691",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.46935867, -73.1953911 ]
  },
  "id_str" : "298241097593913346",
  "in_reply_to_user_id" : 101351006,
  "text" : "@Karo1yn save me sommmmme :)",
  "id" : 298241097593913346,
  "in_reply_to_status_id" : 298236039439474691,
  "created_at" : "Mon Feb 04 01:26:33 +0000 2013",
  "in_reply_to_screen_name" : "Karo1yn",
  "in_reply_to_user_id_str" : "101351006",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Triathlon",
      "screen_name" : "UVMTriathlon",
      "indices" : [ 68, 81 ],
      "id_str" : "546451472",
      "id" : 546451472
    }, {
      "name" : "David Connery",
      "screen_name" : "conneryVT",
      "indices" : [ 82, 92 ],
      "id_str" : "363086298",
      "id" : 363086298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dedication",
      "indices" : [ 44, 55 ]
    }, {
      "text" : "unamerican",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "realathletes",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/5AlwfSrF",
      "expanded_url" : "http://twitpic.com/c0q4l6",
      "display_url" : "twitpic.com/c0q4l6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4689931, -73.1946222 ]
  },
  "id_str" : "298219558811090945",
  "text" : "no better time than now for a brick workout #dedication #unamerican @UVMTriathlon @conneryVT #realathletes http://t.co/5AlwfSrF",
  "id" : 298219558811090945,
  "created_at" : "Mon Feb 04 00:00:58 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icesculptures",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "btv",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "winterfest",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/3rbvr1l4",
      "expanded_url" : "http://twitpic.com/c0nxrg",
      "display_url" : "twitpic.com/c0nxrg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47482112, -73.21770278 ]
  },
  "id_str" : "298115894649954304",
  "text" : "#icesculptures #btv #winterfest http://t.co/3rbvr1l4",
  "id" : 298115894649954304,
  "created_at" : "Sun Feb 03 17:09:02 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Brown",
      "screen_name" : "DaBrownNoise",
      "indices" : [ 0, 13 ],
      "id_str" : "328777340",
      "id" : 328777340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297808079544807424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4822796, -73.2031239 ]
  },
  "id_str" : "297811966301462529",
  "in_reply_to_user_id" : 328777340,
  "text" : "@DaBrownNoise live streams on live streams",
  "id" : 297811966301462529,
  "in_reply_to_status_id" : 297808079544807424,
  "created_at" : "Sat Feb 02 21:01:20 +0000 2013",
  "in_reply_to_screen_name" : "DaBrownNoise",
  "in_reply_to_user_id_str" : "328777340",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.4821421, -73.2030779 ]
  },
  "id_str" : "297810211337535488",
  "text" : "watching the 2013 cyclocross world champs while riding indoors, makes me want one of those sierra nevada pale ales!",
  "id" : 297810211337535488,
  "created_at" : "Sat Feb 02 20:54:22 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winterfest",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/tTcwXaSo",
      "expanded_url" : "http://twitpic.com/c0d7k5",
      "display_url" : "twitpic.com/c0d7k5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.47826595, -73.21275349 ]
  },
  "id_str" : "297759564491792385",
  "text" : "a frosty mug #winterfest http://t.co/tTcwXaSo",
  "id" : 297759564491792385,
  "created_at" : "Sat Feb 02 17:33:06 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/HkqZ9cBI",
      "expanded_url" : "http://twitpic.com/c04lhk",
      "display_url" : "twitpic.com/c04lhk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 44.482398, -73.2029282 ]
  },
  "id_str" : "297486307880472576",
  "text" : "the one year old likes to brush her teeth more than I do! http://t.co/HkqZ9cBI",
  "id" : 297486307880472576,
  "created_at" : "Fri Feb 01 23:27:17 +0000 2013",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]