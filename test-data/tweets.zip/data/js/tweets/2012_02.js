Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "175055462465679361",
  "text" : "just took my take home real analysis test, and now only one homework between me and spring break!",
  "id" : 175055462465679361,
  "created_at" : "Thu Mar 01 03:10:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174967345691893760",
  "text" : "applied math seminar is from Paul Hines on \"The (applied) Mathematics of Simulating Power Grids\"",
  "id" : 174967345691893760,
  "created_at" : "Wed Feb 29 21:20:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Mitchell",
      "screen_name" : "specialized",
      "indices" : [ 105, 117 ],
      "id_str" : "4879271",
      "id" : 4879271
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/174926644841168896/photo/1",
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/Sh74AJUU",
      "media_url" : "http://pbs.twimg.com/media/Am1221ACQAAIdqN.jpg",
      "id_str" : "174926644849557504",
      "id" : 174926644849557504,
      "media_url_https" : "https://pbs.twimg.com/media/Am1221ACQAAIdqN.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/Sh74AJUU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174926644841168896",
  "text" : "got my new cycling shoes last night, they look awesome and felt great on ride #1. digging the BOA so far @specialized http://t.co/Sh74AJUU",
  "id" : 174926644841168896,
  "created_at" : "Wed Feb 29 18:38:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 0, 9 ],
      "id_str" : "25850390",
      "id" : 25850390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174896274124976128",
  "geo" : {
  },
  "id_str" : "174911837517783043",
  "in_reply_to_user_id" : 25850390,
  "text" : "@jdbrunnr oh good, I can do that in the 8 weeks I have before tri nats",
  "id" : 174911837517783043,
  "in_reply_to_status_id" : 174896274124976128,
  "created_at" : "Wed Feb 29 17:40:06 +0000 2012",
  "in_reply_to_screen_name" : "jdbrunnr",
  "in_reply_to_user_id_str" : "25850390",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174671804483371008",
  "geo" : {
  },
  "id_str" : "174908812044668929",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy wow that's awesome. are you planning to start building many frames?",
  "id" : 174908812044668929,
  "in_reply_to_status_id" : 174671804483371008,
  "created_at" : "Wed Feb 29 17:28:05 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeb Vance King",
      "screen_name" : "Zeb_King",
      "indices" : [ 0, 9 ],
      "id_str" : "317552757",
      "id" : 317552757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/fvqugBkL",
      "expanded_url" : "http://van.physics.illinois.edu/qa/listing.php?id=765",
      "display_url" : "van.physics.illinois.edu/qa/listing.php…"
    } ]
  },
  "in_reply_to_status_id_str" : "174903053613416449",
  "geo" : {
  },
  "id_str" : "174903654099337216",
  "in_reply_to_user_id" : 317552757,
  "text" : "@Zeb_King http://t.co/fvqugBkL",
  "id" : 174903654099337216,
  "in_reply_to_status_id" : 174903053613416449,
  "created_at" : "Wed Feb 29 17:07:35 +0000 2012",
  "in_reply_to_screen_name" : "Zeb_King",
  "in_reply_to_user_id_str" : "317552757",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Perry",
      "screen_name" : "Kevin_Perry12",
      "indices" : [ 0, 14 ],
      "id_str" : "374679730",
      "id" : 374679730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174658833128488961",
  "in_reply_to_user_id" : 374679730,
  "text" : "@Kevin_Perry12 yo you're in Burlington, right? Hit me up if you want to grab a beer tomorrow or thurs! 3154815570",
  "id" : 174658833128488961,
  "created_at" : "Wed Feb 29 00:54:45 +0000 2012",
  "in_reply_to_screen_name" : "Kevin_Perry12",
  "in_reply_to_user_id_str" : "374679730",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/174637005676883968/photo/1",
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/ScnOUfce",
      "media_url" : "http://pbs.twimg.com/media/AmxvbnBCMAEWNm5.jpg",
      "id_str" : "174637005681078273",
      "id" : 174637005681078273,
      "media_url_https" : "https://pbs.twimg.com/media/AmxvbnBCMAEWNm5.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1371,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/ScnOUfce"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174637005676883968",
  "text" : "present for me at home! just double checking...owning these makes me a better swimmer right? so I'm done now? http://t.co/ScnOUfce",
  "id" : 174637005676883968,
  "created_at" : "Tue Feb 28 23:28:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolights",
      "screen_name" : "revolights",
      "indices" : [ 3, 14 ],
      "id_str" : "348667248",
      "id" : 348667248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174618226746073090",
  "text" : "RT @revolights: What do you think? Is it a good or bad idea for municipalities to adopt \"The Idaho Stop\"? - Raise the Hammer http://t.co ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.stumbleupon.com/\" rel=\"nofollow\">StumbleUpon iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/pH6w5Obw",
        "expanded_url" : "http://su.pr/7EVdCQ",
        "display_url" : "su.pr/7EVdCQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "174616750170714112",
    "text" : "What do you think? Is it a good or bad idea for municipalities to adopt \"The Idaho Stop\"? - Raise the Hammer http://t.co/pH6w5Obw",
    "id" : 174616750170714112,
    "created_at" : "Tue Feb 28 22:07:32 +0000 2012",
    "user" : {
      "name" : "Revolights",
      "screen_name" : "revolights",
      "protected" : false,
      "id_str" : "348667248",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2577004341/x8xf6d6g70c8phdx158c_normal.jpeg",
      "id" : 348667248,
      "verified" : false
    }
  },
  "id" : 174618226746073090,
  "created_at" : "Tue Feb 28 22:13:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 104 ],
      "url" : "https://t.co/Yb9vXSbF",
      "expanded_url" : "https://twitter.com/#!/jack/status/174591902635663360",
      "display_url" : "twitter.com/#!/jack/status…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "174610350426169344",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 you left this at my place, at least someone likes it (twitter founder guy) https://t.co/Yb9vXSbF",
  "id" : 174610350426169344,
  "created_at" : "Tue Feb 28 21:42:06 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174609994879205378",
  "text" : "just signed up our intramural basketball team, named \"No game this week\"",
  "id" : 174609994879205378,
  "created_at" : "Tue Feb 28 21:40:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 1, 14 ],
      "id_str" : "25713870",
      "id" : 25713870
    }, {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 15, 24 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/FSffIydh",
      "expanded_url" : "http://www.kickstarter.com/projects/1640002012/the-jiggernaut-bringing-bicycle-frame-building-to",
      "display_url" : "kickstarter.com/projects/16400…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "174560892774658048",
  "text" : ".@williamenium @RBSherfy we should go in for one of these: http://t.co/FSffIydh",
  "id" : 174560892774658048,
  "created_at" : "Tue Feb 28 18:25:34 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 3, 10 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174519113262182400",
  "text" : "RT @DZdan1: Received notification yesterday that I am a recipient of the 2012 SUNY Chancellors Award! So cool! Grateful for all my mento ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "College at Brockport",
        "screen_name" : "Brockport",
        "indices" : [ 127, 137 ],
        "id_str" : "29124946",
        "id" : 29124946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "174499554689945601",
    "text" : "Received notification yesterday that I am a recipient of the 2012 SUNY Chancellors Award! So cool! Grateful for all my mentors @Brockport!",
    "id" : 174499554689945601,
    "created_at" : "Tue Feb 28 14:21:50 +0000 2012",
    "user" : {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "protected" : true,
      "id_str" : "228268171",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062236076/cb53d557e0549649af0f56aa07a11277_normal.jpeg",
      "id" : 228268171,
      "verified" : false
    }
  },
  "id" : 174519113262182400,
  "created_at" : "Tue Feb 28 15:39:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 74, 85 ],
      "id_str" : "355569678",
      "id" : 355569678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174361868603891712",
  "text" : "files being served up from the basement, check it out! http://24.91.2.112 @erik_ryden",
  "id" : 174361868603891712,
  "created_at" : "Tue Feb 28 05:14:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gradstudentproblems",
      "indices" : [ 76, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "174279562828578816",
  "text" : "eating leftover pizza from unknown meeting as dinner for a late night of hw #gradstudentproblems",
  "id" : 174279562828578816,
  "created_at" : "Mon Feb 27 23:47:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 53, 69 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 70, 79 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 86, 93 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/QRg4XgC9",
      "expanded_url" : "http://www.youtube.com/watch?v=VaJPw7shWkw&feature=youtu.be",
      "display_url" : "youtube.com/watch?v=VaJPw7…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "174240087255691265",
  "text" : "my VaTech graduation is online! (proof it happened!) @RumblinStumblin @dmreagan thx 2 @rkay21 filming + Paul uploading! http://t.co/QRg4XgC9",
  "id" : 174240087255691265,
  "created_at" : "Mon Feb 27 21:10:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174230804229144576",
  "geo" : {
  },
  "id_str" : "174239090999439360",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud if living is the goal, doesn't look like you're procrastinating anything!",
  "id" : 174239090999439360,
  "in_reply_to_status_id" : 174230804229144576,
  "created_at" : "Mon Feb 27 21:06:51 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 3, 14 ],
      "id_str" : "355569678",
      "id" : 355569678
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 16, 27 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173998604984389632",
  "text" : "RT @erik_ryden: @andyreagan and I just made some computer magic and set up a successful server! Aptly named skynet for when it inevitabl ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "173998517654794240",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan and I just made some computer magic and set up a successful server! Aptly named skynet for when it inevitably turns on us.",
    "id" : 173998517654794240,
    "created_at" : "Mon Feb 27 05:10:54 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "protected" : false,
      "id_str" : "355569678",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1499094307/me_twitpic_normal.JPG",
      "id" : 355569678,
      "verified" : false
    }
  },
  "id" : 173998604984389632,
  "created_at" : "Mon Feb 27 05:11:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 13, 20 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 89, 97 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/H3hHvcqi",
      "expanded_url" : "http://connect.garmin.com/activity/152856869#.T0p01fn_82g.twitter",
      "display_url" : "connect.garmin.com/activity/15285…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "173831605494882306",
  "text" : "Quick 6 with @sspis1 by andyreagan at Garmin Connect - Details: http://t.co/H3hHvcqi via @AddThis",
  "id" : 173831605494882306,
  "created_at" : "Sun Feb 26 18:07:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173641426041700352",
  "text" : "get busy living",
  "id" : 173641426041700352,
  "created_at" : "Sun Feb 26 05:31:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 1, 8 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173284722288500736",
  "text" : ".@sspis1 is here!!!!",
  "id" : 173284722288500736,
  "created_at" : "Sat Feb 25 05:54:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 16, 27 ],
      "id_str" : "18855629",
      "id" : 18855629
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 72, 84 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikes",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173176285227524097",
  "text" : "just renewed my @usacycling collegiate license and can't wait to race w @UVM_cycling!! #bikes",
  "id" : 173176285227524097,
  "created_at" : "Fri Feb 24 22:43:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "John Beatty",
      "screen_name" : "jpbeatty",
      "indices" : [ 34, 43 ],
      "id_str" : "23640974",
      "id" : 23640974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173173134587998208",
  "geo" : {
  },
  "id_str" : "173173369565491208",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e what a lucky man you are, @jpbeatty!",
  "id" : 173173369565491208,
  "in_reply_to_status_id" : 173173134587998208,
  "created_at" : "Fri Feb 24 22:32:03 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Joe Friel",
      "screen_name" : "jfriel",
      "indices" : [ 9, 16 ],
      "id_str" : "18436210",
      "id" : 18436210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173150188309970944",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@jfriel: Train hard. Rest harder.\"",
  "id" : 173150188309970944,
  "created_at" : "Fri Feb 24 20:59:56 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173149997842448384",
  "in_reply_to_user_id" : 320551143,
  "text" : "@sumillie tweet by text!",
  "id" : 173149997842448384,
  "created_at" : "Fri Feb 24 20:59:11 +0000 2012",
  "in_reply_to_screen_name" : "SumaNMNDesu",
  "in_reply_to_user_id_str" : "320551143",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173101152416694272",
  "geo" : {
  },
  "id_str" : "173115491232137216",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis per your recommendation, I ate TWO :P",
  "id" : 173115491232137216,
  "in_reply_to_status_id" : 173101152416694272,
  "created_at" : "Fri Feb 24 18:42:04 +0000 2012",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nomnomnom",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "fatty",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173104708586704897",
  "geo" : {
  },
  "id_str" : "173114145284161536",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e I ate two #nomnomnom #fatty",
  "id" : 173114145284161536,
  "in_reply_to_status_id" : 173104708586704897,
  "created_at" : "Fri Feb 24 18:36:43 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173111476050079744",
  "geo" : {
  },
  "id_str" : "173114044646047745",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 get it!",
  "id" : 173114044646047745,
  "in_reply_to_status_id" : 173111476050079744,
  "created_at" : "Fri Feb 24 18:36:19 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "likeaboss",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173113973649063936",
  "text" : "making corrections in real analysis #likeaboss",
  "id" : 173113973649063936,
  "created_at" : "Fri Feb 24 18:36:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173105294191247360",
  "text" : "motivation",
  "id" : 173105294191247360,
  "created_at" : "Fri Feb 24 18:01:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/173098346817388544/photo/1",
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/iVlHNDtF",
      "media_url" : "http://pbs.twimg.com/media/Amb4B4GCAAA12Ad.jpg",
      "id_str" : "173098346821582848",
      "id" : 173098346821582848,
      "media_url_https" : "https://pbs.twimg.com/media/Amb4B4GCAAA12Ad.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/iVlHNDtF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173098346817388544",
  "text" : "and the picture http://t.co/iVlHNDtF",
  "id" : 173098346817388544,
  "created_at" : "Fri Feb 24 17:33:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173091308037095424",
  "text" : "cupcake deliciousness",
  "id" : 173091308037095424,
  "created_at" : "Fri Feb 24 17:05:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 3, 14 ],
      "id_str" : "214582389",
      "id" : 214582389
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 16, 25 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173039822678663168",
  "text" : "RT @skholden17: @DKnick88 typical, im up you're  just going to bed.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetcaster.com\" rel=\"nofollow\">TweetCaster for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Knickerbocker",
        "screen_name" : "DKnick88",
        "indices" : [ 0, 9 ],
        "id_str" : "204631321",
        "id" : 204631321
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "173013767314079744",
    "geo" : {
    },
    "id_str" : "173025233593311232",
    "in_reply_to_user_id" : 204631321,
    "text" : "@DKnick88 typical, im up you're  just going to bed.",
    "id" : 173025233593311232,
    "in_reply_to_status_id" : 173013767314079744,
    "created_at" : "Fri Feb 24 12:43:24 +0000 2012",
    "in_reply_to_screen_name" : "DKnick88",
    "in_reply_to_user_id_str" : "204631321",
    "user" : {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "protected" : false,
      "id_str" : "214582389",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3122605201/bbe442be6791d79c0b7662898c2dcd57_normal.png",
      "id" : 214582389,
      "verified" : false
    }
  },
  "id" : 173039822678663168,
  "created_at" : "Fri Feb 24 13:41:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "173012731211956224",
  "text" : "7AM swim time!",
  "id" : 173012731211956224,
  "created_at" : "Fri Feb 24 11:53:44 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 101, 109 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/etCo0LlP",
      "expanded_url" : "http://bit.ly/AwiLKi",
      "display_url" : "bit.ly/AwiLKi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172842073303691264",
  "text" : "tonight's easy run of 8.8mi: 8@8 by andyreagan at Garmin Connect - Details: http://t.co/etCo0LlP via @AddThis",
  "id" : 172842073303691264,
  "created_at" : "Fri Feb 24 00:35:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 0, 11 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172801989191806977",
  "geo" : {
  },
  "id_str" : "172837292107509760",
  "in_reply_to_user_id" : 16174144,
  "text" : "@peterdodds hey I posted that link yesterday!",
  "id" : 172837292107509760,
  "in_reply_to_status_id" : 172801989191806977,
  "created_at" : "Fri Feb 24 00:16:36 +0000 2012",
  "in_reply_to_screen_name" : "peterdodds",
  "in_reply_to_user_id_str" : "16174144",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172836789080428544",
  "text" : "experienced my first tinge of frostbite on a run tonight: out for an hour and my pinkie splint was have been cutting off circ, and isolating",
  "id" : 172836789080428544,
  "created_at" : "Fri Feb 24 00:14:36 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 10, 26 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/6L0bV1Lj",
      "expanded_url" : "http://reason.com/archives/2012/02/13/triumph-of-the-willpower?utm_source=twitterfeed&utm_medium=twitter",
      "display_url" : "reason.com/archives/2012/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172731753604186112",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan @RumblinStumblin maybe this is why being \"stubborn\" is good: http://t.co/6L0bV1Lj",
  "id" : 172731753604186112,
  "created_at" : "Thu Feb 23 17:17:13 +0000 2012",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/pyAXKPYD",
      "expanded_url" : "http://www.raleighusa.com/bikes/steel-road/furley-12/",
      "display_url" : "raleighusa.com/bikes/steel-ro…"
    } ]
  },
  "in_reply_to_status_id_str" : "172708493168623616",
  "geo" : {
  },
  "id_str" : "172711419610021888",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy if only this had a belt: http://t.co/pyAXKPYD",
  "id" : 172711419610021888,
  "in_reply_to_status_id" : 172708493168623616,
  "created_at" : "Thu Feb 23 15:56:25 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172708493168623616",
  "geo" : {
  },
  "id_str" : "172709717246877696",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy it really does!! I just think I may want skinnier tires to commute, and rack mounts are the ONLY things holding me back",
  "id" : 172709717246877696,
  "in_reply_to_status_id" : 172708493168623616,
  "created_at" : "Thu Feb 23 15:49:40 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/qbYhtqH7",
      "expanded_url" : "http://andyreagan.com/2012/02/23/no-riding-to-class-today/",
      "display_url" : "andyreagan.com/2012/02/23/no-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172701794202435584",
  "text" : "my commuting bike is down for the count...and that may be a long count before I find a welder: http://t.co/qbYhtqH7",
  "id" : 172701794202435584,
  "created_at" : "Thu Feb 23 15:18:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172535182014951424",
  "text" : "5 hrs of complex analysis and throwing in the white towel. need food.",
  "id" : 172535182014951424,
  "created_at" : "Thu Feb 23 04:16:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/ixeNBGMM",
      "expanded_url" : "http://www.stanford.edu/group/uq/pdfs/journals/ijouq_pade_2011.pdf",
      "display_url" : "stanford.edu/group/uq/pdfs/…"
    } ]
  },
  "in_reply_to_status_id_str" : "172531821161099265",
  "geo" : {
  },
  "id_str" : "172534513166057473",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 previous link is just cool. next I need a summary of this: http://t.co/ixeNBGMM",
  "id" : 172534513166057473,
  "in_reply_to_status_id" : 172531821161099265,
  "created_at" : "Thu Feb 23 04:13:28 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/N8VEBAiM",
      "expanded_url" : "http://newscenter.berkeley.edu/2011/09/22/brain-movies/",
      "display_url" : "newscenter.berkeley.edu/2011/09/22/bra…"
    } ]
  },
  "in_reply_to_status_id_str" : "172531821161099265",
  "geo" : {
  },
  "id_str" : "172534230293819392",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 http://t.co/N8VEBAiM",
  "id" : 172534230293819392,
  "in_reply_to_status_id" : 172531821161099265,
  "created_at" : "Thu Feb 23 04:12:20 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172473168215289857",
  "geo" : {
  },
  "id_str" : "172475154230812672",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C dude thanks for thinking about me! grad school is year round thing though",
  "id" : 172475154230812672,
  "in_reply_to_status_id" : 172473168215289857,
  "created_at" : "Thu Feb 23 00:17:35 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 129, 137 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/g6TBYE9l",
      "expanded_url" : "http://bit.ly/wEdQGR",
      "display_url" : "bit.ly/wEdQGR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172463047452012544",
  "text" : "got out for my first ride back, solid 25mi! Group ride w UVM by andyreagan at Garmin Connect - Details: http://t.co/g6TBYE9l via @AddThis",
  "id" : 172463047452012544,
  "created_at" : "Wed Feb 22 23:29:29 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 92, 105 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/8uKce5Dw",
      "expanded_url" : "http://thebestpageintheuniverse.net/c.cgi?u=math",
      "display_url" : "thebestpageintheuniverse.net/c.cgi?u=math"
    } ]
  },
  "geo" : {
  },
  "id_str" : "172456798656270336",
  "text" : "teaching a math class? show them this: \"math doesn't suck, you do\" http://t.co/8uKce5Dw via @williamenium",
  "id" : 172456798656270336,
  "created_at" : "Wed Feb 22 23:04:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172328618737930240",
  "text" : "7AM swim was good, did 2000m or so. now trying to keep up TeXing notes with broken pinkie!",
  "id" : 172328618737930240,
  "created_at" : "Wed Feb 22 14:35:19 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172282749233795073",
  "text" : "has discovered the magic formula for weight gain: don't ride bike, drink beer",
  "id" : 172282749233795073,
  "created_at" : "Wed Feb 22 11:33:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172102101609099264",
  "geo" : {
  },
  "id_str" : "172104746067427328",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 gross",
  "id" : 172104746067427328,
  "in_reply_to_status_id" : 172102101609099264,
  "created_at" : "Tue Feb 21 23:45:43 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172104618510254081",
  "text" : "UVM offers 'triathlon,' 'cycling' and 'jogging for fitness' class. I could teach these: \"hey you, ride your bike more! hey you, run faster!\"",
  "id" : 172104618510254081,
  "created_at" : "Tue Feb 21 23:45:13 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171547790424555520",
  "geo" : {
  },
  "id_str" : "172063786491068417",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e in no regard is buying a motorcycle a very rational decision, but don't worry I'm not anytime too soon",
  "id" : 172063786491068417,
  "in_reply_to_status_id" : 171547790424555520,
  "created_at" : "Tue Feb 21 21:02:58 +0000 2012",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/172005454942175232/photo/1",
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/LyNA54sG",
      "media_url" : "http://pbs.twimg.com/media/AmMWDMmCAAEYlnS.jpg",
      "id_str" : "172005454946369537",
      "id" : 172005454946369537,
      "media_url_https" : "https://pbs.twimg.com/media/AmMWDMmCAAEYlnS.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LyNA54sG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "172005454942175232",
  "text" : "out of salad dressing so an experiment: 1 splash canola oil, 1 splash maple syrup, 1 pinch grnd black pepper http://t.co/LyNA54sG",
  "id" : 172005454942175232,
  "created_at" : "Tue Feb 21 17:11:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "ltapp11",
      "indices" : [ 0, 8 ],
      "id_str" : "112279071",
      "id" : 112279071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/Qcqzk4X9",
      "expanded_url" : "http://www.msnbc.msn.com/id/46453802/ns/local_news-detroit_mi/#.T0KruErTTw4",
      "display_url" : "msnbc.msn.com/id/46453802/ns…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171692294255280128",
  "in_reply_to_user_id" : 112279071,
  "text" : "@ltapp11 http://t.co/Qcqzk4X9",
  "id" : 171692294255280128,
  "created_at" : "Mon Feb 20 20:26:47 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171692252861693953",
  "text" : "got in a solid 2500m in the pool!",
  "id" : 171692252861693953,
  "created_at" : "Mon Feb 20 20:26:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 16, 23 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171429483004444674",
  "geo" : {
  },
  "id_str" : "171459363502952448",
  "in_reply_to_user_id" : 29055432,
  "text" : "@Eric_Wagner_71 @sspis1 chalk another up for ritz, at least one of you two has got some sense :P",
  "id" : 171459363502952448,
  "in_reply_to_status_id" : 171429483004444674,
  "created_at" : "Mon Feb 20 05:01:12 +0000 2012",
  "in_reply_to_screen_name" : "ewags71",
  "in_reply_to_user_id_str" : "29055432",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 3, 16 ],
      "id_str" : "14630047",
      "id" : 14630047
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 18, 29 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USATCN12",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171459060787458048",
  "text" : "RT @usatriathlon: @andyreagan Awesome! We'll see you in Tuscaloosa! #USATCN12",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Reagan",
        "screen_name" : "andyreagan",
        "indices" : [ 0, 11 ],
        "id_str" : "55931868",
        "id" : 55931868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USATCN12",
        "indices" : [ 50, 59 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "170642135979274240",
    "geo" : {
    },
    "id_str" : "171434651485872129",
    "in_reply_to_user_id" : 55931868,
    "text" : "@andyreagan Awesome! We'll see you in Tuscaloosa! #USATCN12",
    "id" : 171434651485872129,
    "in_reply_to_status_id" : 170642135979274240,
    "created_at" : "Mon Feb 20 03:23:00 +0000 2012",
    "in_reply_to_screen_name" : "andyreagan",
    "in_reply_to_user_id_str" : "55931868",
    "user" : {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "protected" : false,
      "id_str" : "14630047",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/612604968/sqaure_1_USAT10LogoWO_normal.jpg",
      "id" : 14630047,
      "verified" : true
    }
  },
  "id" : 171459060787458048,
  "created_at" : "Mon Feb 20 05:00:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/xSutslel",
      "expanded_url" : "http://dmv.vermont.gov/sites/dmv/files/pdf/DMV-VN007a-Motorcycle_Manual.pdf",
      "display_url" : "dmv.vermont.gov/sites/dmv/file…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171457657507549184",
  "text" : "the Vermont Motorcycle Manual: (permit test is only $7) http://t.co/xSutslel",
  "id" : 171457657507549184,
  "created_at" : "Mon Feb 20 04:54:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171456443986358272",
  "geo" : {
  },
  "id_str" : "171456652992720896",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 if I trow in a couple to Buffalo, it'd be paying me!",
  "id" : 171456652992720896,
  "in_reply_to_status_id" : 171456443986358272,
  "created_at" : "Mon Feb 20 04:50:26 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "randomtweets",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171456518993096705",
  "text" : "it's definitely official, my bikes are worth more than my car: KBB puts the Honda at 2400 these days #randomtweets",
  "id" : 171456518993096705,
  "created_at" : "Mon Feb 20 04:49:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/QJpGpl4b",
      "expanded_url" : "http://burlington.craigslist.org/mcy/2860154738.html",
      "display_url" : "burlington.craigslist.org/mcy/2860154738…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171456031321362432",
  "text" : "with 45 round trips to Syracuse, this would pay for itself! http://t.co/QJpGpl4b",
  "id" : 171456031321362432,
  "created_at" : "Mon Feb 20 04:47:58 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171424191332093952",
  "text" : "just caught some of Amazing Race on TV...I need to get on the ball! Def need motorcycle lic, pilots lic, and to learn how to sail!",
  "id" : 171424191332093952,
  "created_at" : "Mon Feb 20 02:41:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 21, 28 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "triscuts",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "ritz",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171415118930915328",
  "text" : "lets hear it folks! \"@sspis1 which are better, #triscuts or #ritz, let's settle this once for all\"",
  "id" : 171415118930915328,
  "created_at" : "Mon Feb 20 02:05:23 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171414657637154816",
  "text" : "RT @UVM_cycling: Two weeks till the Eastern Collegiate Cycling Conference (ECCC) season kicks off at Rutgers and then our spring... http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http://t.co/8aOGHe5V",
        "expanded_url" : "http://fb.me/1Btd8JCJY",
        "display_url" : "fb.me/1Btd8JCJY"
      } ]
    },
    "geo" : {
    },
    "id_str" : "171405227994525696",
    "text" : "Two weeks till the Eastern Collegiate Cycling Conference (ECCC) season kicks off at Rutgers and then our spring... http://t.co/8aOGHe5V",
    "id" : 171405227994525696,
    "created_at" : "Mon Feb 20 01:26:05 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 171414657637154816,
  "created_at" : "Mon Feb 20 02:03:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Reagan",
      "screen_name" : "JMReagan219",
      "indices" : [ 0, 12 ],
      "id_str" : "66257838",
      "id" : 66257838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171376228845096960",
  "geo" : {
  },
  "id_str" : "171376464296558593",
  "in_reply_to_user_id" : 66257838,
  "text" : "@JMReagan219 I'll let ya know if she heard! and Happy Birthday!!",
  "id" : 171376464296558593,
  "in_reply_to_status_id" : 171376228845096960,
  "created_at" : "Sun Feb 19 23:31:47 +0000 2012",
  "in_reply_to_screen_name" : "JMReagan219",
  "in_reply_to_user_id_str" : "66257838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/3dDOrKBi",
      "expanded_url" : "http://www.adkultracycling.com/adk540/details.htm",
      "display_url" : "adkultracycling.com/adk540/details…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171370640551579649",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 you got my support vehicle? http://t.co/3dDOrKBi",
  "id" : 171370640551579649,
  "created_at" : "Sun Feb 19 23:08:39 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/yHvb5SCe",
      "expanded_url" : "http://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=0CC4QFjAB&url=http%3A%2F%2Fwww.raceacrossamerica.org%2Fraam%2Fresources%2Farticles%2FBudgetSamples.pdf&ei=jHRBT7eeN-be0QHSme3PBw&usg=AFQjCNGBnmPTCfr7P0lUNN0WfU0uyikeVQ",
      "display_url" : "google.com/url?sa=t&rct=j…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "171358832122007552",
  "text" : "RAAM 2013... http://t.co/yHvb5SCe",
  "id" : 171358832122007552,
  "created_at" : "Sun Feb 19 22:21:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACC Cycling",
      "screen_name" : "ACCCycling",
      "indices" : [ 0, 11 ],
      "id_str" : "111463102",
      "id" : 111463102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171271617287163905",
  "geo" : {
  },
  "id_str" : "171283422071881729",
  "in_reply_to_user_id" : 111463102,
  "text" : "@ACCCycling keep the updates coming!",
  "id" : 171283422071881729,
  "in_reply_to_status_id" : 171271617287163905,
  "created_at" : "Sun Feb 19 17:22:04 +0000 2012",
  "in_reply_to_screen_name" : "ACCCycling",
  "in_reply_to_user_id_str" : "111463102",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Reagan",
      "screen_name" : "JMReagan219",
      "indices" : [ 0, 12 ],
      "id_str" : "66257838",
      "id" : 66257838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171074089199484928",
  "geo" : {
  },
  "id_str" : "171074595154182145",
  "in_reply_to_user_id" : 66257838,
  "text" : "@JMReagan219 yo shoot me a txt 3154815570",
  "id" : 171074595154182145,
  "in_reply_to_status_id" : 171074089199484928,
  "created_at" : "Sun Feb 19 03:32:16 +0000 2012",
  "in_reply_to_screen_name" : "JMReagan219",
  "in_reply_to_user_id_str" : "66257838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Reagan",
      "screen_name" : "JMReagan219",
      "indices" : [ 0, 12 ],
      "id_str" : "66257838",
      "id" : 66257838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171025290255015937",
  "geo" : {
  },
  "id_str" : "171044783492571137",
  "in_reply_to_user_id" : 66257838,
  "text" : "@JMReagan219 are you at brockport??",
  "id" : 171044783492571137,
  "in_reply_to_status_id" : 171025290255015937,
  "created_at" : "Sun Feb 19 01:33:48 +0000 2012",
  "in_reply_to_screen_name" : "JMReagan219",
  "in_reply_to_user_id_str" : "66257838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "171016367460454400",
  "text" : "feeling good after 1500m in the pool (first swim in ...months) and a big salad w oatmeal porter on the side!",
  "id" : 171016367460454400,
  "created_at" : "Sat Feb 18 23:40:53 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170710768692625408",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons you don't tweet too much, but I could do without the astrology lol",
  "id" : 170710768692625408,
  "created_at" : "Sat Feb 18 03:26:33 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/qUFBMdw0",
      "expanded_url" : "http://depts.washington.edu/amath/courses/301-autumn-2003/301lec19.pdf",
      "display_url" : "depts.washington.edu/amath/courses/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "170696556637462528",
  "text" : "i found this helpful implementing Fast Fourier Transform in MATLAB: http://t.co/qUFBMdw0",
  "id" : 170696556637462528,
  "created_at" : "Sat Feb 18 02:30:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170692614822166530",
  "geo" : {
  },
  "id_str" : "170694479647481856",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser there is room for approx 3 signatures! yeah I'm good, lucky really. walkin to farrell for a few weeks for sure though!",
  "id" : 170694479647481856,
  "in_reply_to_status_id" : 170692614822166530,
  "created_at" : "Sat Feb 18 02:21:49 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/170645183040454656/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/iP7mwi4B",
      "media_url" : "http://pbs.twimg.com/media/Al5A484CAAAOK_y.jpg",
      "id_str" : "170645183044648960",
      "id" : 170645183044648960,
      "media_url_https" : "https://pbs.twimg.com/media/Al5A484CAAAOK_y.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/iP7mwi4B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170645183040454656",
  "text" : "fancy finger splint! http://t.co/iP7mwi4B",
  "id" : 170645183040454656,
  "created_at" : "Fri Feb 17 23:05:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 49, 62 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170642135979274240",
  "text" : "with the bad, comes the great: I'm going to race @usatriathlon Collegiate National Championships with UVM Triathlon!",
  "id" : 170642135979274240,
  "created_at" : "Fri Feb 17 22:53:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170636836450996226",
  "geo" : {
  },
  "id_str" : "170639670479290368",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 easy now...",
  "id" : 170639670479290368,
  "in_reply_to_status_id" : 170636836450996226,
  "created_at" : "Fri Feb 17 22:44:02 +0000 2012",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170636459752173568",
  "text" : "crashed my bike commuting (fail) and am totally fine in the important ways #phew.but may have broken my first bone, a small chip on my pinky",
  "id" : 170636459752173568,
  "created_at" : "Fri Feb 17 22:31:16 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 18, 27 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170575349694992386",
  "text" : "\"@Eric_Wagner_71: @DKnick88 picks things up and puts them down\" if you replace 'things' with 'small buildings' he sure does, son",
  "id" : 170575349694992386,
  "created_at" : "Fri Feb 17 18:28:27 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Holden",
      "screen_name" : "skholden17",
      "indices" : [ 0, 11 ],
      "id_str" : "214582389",
      "id" : 214582389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170573717569667072",
  "geo" : {
  },
  "id_str" : "170574858672021504",
  "in_reply_to_user_id" : 214582389,
  "text" : "@skholden17 ummmm idk! depends how often I race bikes really. gilette stadium is still on my calendar though!! how is the knee?",
  "id" : 170574858672021504,
  "in_reply_to_status_id" : 170573717569667072,
  "created_at" : "Fri Feb 17 18:26:30 +0000 2012",
  "in_reply_to_screen_name" : "skholden17",
  "in_reply_to_user_id_str" : "214582389",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170293153386070016",
  "geo" : {
  },
  "id_str" : "170571552318951424",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin I got your tweet when you sent it, apology 4 slow response. bummed youre not going to make it, you'll have 2 come 2 a race!",
  "id" : 170571552318951424,
  "in_reply_to_status_id" : 170293153386070016,
  "created_at" : "Fri Feb 17 18:13:21 +0000 2012",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170570219838906368",
  "geo" : {
  },
  "id_str" : "170571117440937984",
  "in_reply_to_user_id" : 91222764,
  "text" : "@MathewFox1 I'll also settle for anything but pop...",
  "id" : 170571117440937984,
  "in_reply_to_status_id" : 170570219838906368,
  "created_at" : "Fri Feb 17 18:11:38 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/1iysV5lQ",
      "expanded_url" : "http://strangemaps.files.wordpress.com/2008/08/popvssodamap.gif",
      "display_url" : "strangemaps.files.wordpress.com/2008/08/popvss…"
    } ]
  },
  "in_reply_to_status_id_str" : "170566391601172480",
  "geo" : {
  },
  "id_str" : "170569277752090625",
  "in_reply_to_user_id" : 91222764,
  "text" : ".@MathewFox1 check it out: http://t.co/1iysV5lQ",
  "id" : 170569277752090625,
  "in_reply_to_status_id" : 170566391601172480,
  "created_at" : "Fri Feb 17 18:04:19 +0000 2012",
  "in_reply_to_screen_name" : "El__Capitan1",
  "in_reply_to_user_id_str" : "91222764",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmonguy",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "latin",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170568624183054336",
  "text" : "if you're going to write QED in binary at the end of proof, you should at least know what it stands for! #cmonguy it's #latin",
  "id" : 170568624183054336,
  "created_at" : "Fri Feb 17 18:01:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/170567784449835008/photo/1",
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/8Pzbxs14",
      "media_url" : "http://pbs.twimg.com/media/Al36fwqCAAETOFT.jpg",
      "id_str" : "170567784454029313",
      "id" : 170567784454029313,
      "media_url_https" : "https://pbs.twimg.com/media/Al36fwqCAAETOFT.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com/8Pzbxs14"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170567784449835008",
  "text" : "an expensive piece of paper to commemorate 3.5 years of successful learning, living and loving in Blacksburg! http://t.co/8Pzbxs14",
  "id" : 170567784449835008,
  "created_at" : "Fri Feb 17 17:58:24 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170333324261330944",
  "text" : "OD just put on some bluegrass, wow I missed SW VA apparently!!",
  "id" : 170333324261330944,
  "created_at" : "Fri Feb 17 02:26:43 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Brilliant Women",
      "screen_name" : "Epic_Women",
      "indices" : [ 9, 20 ],
      "id_str" : "169291609",
      "id" : 169291609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170325273907175424",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 \"@Epic_Women: People too weak to follow their own dreams will always find a way to discourage yours.\"",
  "id" : 170325273907175424,
  "created_at" : "Fri Feb 17 01:54:44 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/170321769335504896/photo/1",
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/iCpO5PPd",
      "media_url" : "http://pbs.twimg.com/media/Al0avy8CQAA72k9.jpg",
      "id_str" : "170321769339699200",
      "id" : 170321769339699200,
      "media_url_https" : "https://pbs.twimg.com/media/Al0avy8CQAA72k9.jpg",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/iCpO5PPd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170321769335504896",
  "text" : "matlab success, time to go out! http://t.co/iCpO5PPd",
  "id" : 170321769335504896,
  "created_at" : "Fri Feb 17 01:40:49 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takethatmatlab",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "170294937919827968",
  "text" : "how to turn mood around when you get home: have fresh bread baked and your oatmeal porter carbonated! #takethatmatlab",
  "id" : 170294937919827968,
  "created_at" : "Thu Feb 16 23:54:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/169988908568936448/photo/1",
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/LKe5x3xo",
      "media_url" : "http://pbs.twimg.com/media/AlvsAv9CAAITa5h.jpg",
      "id_str" : "169988908573130754",
      "id" : 169988908573130754,
      "media_url_https" : "https://pbs.twimg.com/media/AlvsAv9CAAITa5h.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/LKe5x3xo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169988908568936448",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson sweet!! you need to get a bread machine! i havent had mine a year and im almost at 60 http://t.co/LKe5x3xo",
  "id" : 169988908568936448,
  "created_at" : "Thu Feb 16 03:38:09 +0000 2012",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 129, 137 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/GzAUMDez",
      "expanded_url" : "http://bit.ly/zgyDZk",
      "display_url" : "bit.ly/zgyDZk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169973050731794432",
  "text" : "today's ride snuck in 35 miles in 30's and rain! to Mt Philo by andyreagan at Garmin Connect - Details: http://t.co/GzAUMDez via @AddThis",
  "id" : 169973050731794432,
  "created_at" : "Thu Feb 16 02:35:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/v4hQaCno",
      "expanded_url" : "http://www.flickr.com/photos/walkingsf/5010997834/",
      "display_url" : "flickr.com/photos/walking…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169972748066619392",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 http://t.co/v4hQaCno",
  "id" : 169972748066619392,
  "created_at" : "Thu Feb 16 02:33:55 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 8, 15 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/UFRQ0U5r",
      "expanded_url" : "http://www.flickr.com/photos/walkingsf/5559859651/",
      "display_url" : "flickr.com/photos/walking…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169971943263571968",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 @DZdan1 since you're about the only rochester-ites I know, pretty cool maps: http://t.co/UFRQ0U5r",
  "id" : 169971943263571968,
  "created_at" : "Thu Feb 16 02:30:43 +0000 2012",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 0, 11 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169898825685803008",
  "geo" : {
  },
  "id_str" : "169971727697321984",
  "in_reply_to_user_id" : 16353686,
  "text" : "@angryasian tried them today, and was good for 2:15 in mid-30's and rain. thanks for the tip!! excited for what else you've got up ur sleeve",
  "id" : 169971727697321984,
  "in_reply_to_status_id" : 169898825685803008,
  "created_at" : "Thu Feb 16 02:29:52 +0000 2012",
  "in_reply_to_screen_name" : "angryasian",
  "in_reply_to_user_id_str" : "16353686",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 47, 54 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 107, 115 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/qAupDJRN",
      "expanded_url" : "http://bit.ly/x3GmkJ",
      "display_url" : "bit.ly/x3GmkJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169495026013966336",
  "text" : "on today's bike ride my hands were warm thx to @sspis1! Garmin Connect - Details: http://t.co/qAupDJRN via @AddThis",
  "id" : 169495026013966336,
  "created_at" : "Tue Feb 14 18:55:37 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/sCbuYdAh",
      "expanded_url" : "http://i.imgur.com/nXICJ.jpg",
      "display_url" : "i.imgur.com/nXICJ.jpg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169485327826825217",
  "text" : "to engineering/math/science followers: http://t.co/sCbuYdAh",
  "id" : 169485327826825217,
  "created_at" : "Tue Feb 14 18:17:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "please",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169293948769157120",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons because it takes a real man to push down a gas pedal! #please",
  "id" : 169293948769157120,
  "created_at" : "Tue Feb 14 05:36:37 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/KGLdXF5h",
      "expanded_url" : "http://www.scottaaronson.com/writings/bignumbers.html",
      "display_url" : "scottaaronson.com/writings/bignu…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "169258197901787137",
  "text" : "great essay on big numbers: http://t.co/KGLdXF5h",
  "id" : 169258197901787137,
  "created_at" : "Tue Feb 14 03:14:33 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/169116868198666241/photo/1",
      "indices" : [ 6, 26 ],
      "url" : "http://t.co/14PwL5Tp",
      "media_url" : "http://pbs.twimg.com/media/AljS5UaCEAIXeO0.jpg",
      "id_str" : "169116868198666242",
      "id" : 169116868198666242,
      "media_url_https" : "https://pbs.twimg.com/media/AljS5UaCEAIXeO0.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/14PwL5Tp"
    } ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "169116868198666241",
  "text" : "#boom http://t.co/14PwL5Tp",
  "id" : 169116868198666241,
  "created_at" : "Mon Feb 13 17:53:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 102, 110 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/MbE9CBF9",
      "expanded_url" : "http://bit.ly/A80mYb",
      "display_url" : "bit.ly/A80mYb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "168897087193350144",
  "text" : "Today's run: Burlington TRAIL RUN by andyreagan at Garmin Connect - Details: http://t.co/MbE9CBF9 via @AddThis",
  "id" : 168897087193350144,
  "created_at" : "Mon Feb 13 03:19:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168817914118541312",
  "text" : "never say its too cold to run! -15C and I found TRAILS at the \"intervale\" for an awesome 11.3 miles of dirt (albeit frozen) and no exhaust",
  "id" : 168817914118541312,
  "created_at" : "Sun Feb 12 22:05:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 0, 9 ],
      "id_str" : "104673361",
      "id" : 104673361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168778445092950016",
  "geo" : {
  },
  "id_str" : "168779632932433920",
  "in_reply_to_user_id" : 104673361,
  "text" : "@vmhilljr break a few records along the way, no big deal. next weekend?",
  "id" : 168779632932433920,
  "in_reply_to_status_id" : 168778445092950016,
  "created_at" : "Sun Feb 12 19:32:54 +0000 2012",
  "in_reply_to_screen_name" : "vmhilljr",
  "in_reply_to_user_id_str" : "104673361",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168777238764982272",
  "geo" : {
  },
  "id_str" : "168777719658721280",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy did someone say collegiate nationals for UVM?",
  "id" : 168777719658721280,
  "in_reply_to_status_id" : 168777238764982272,
  "created_at" : "Sun Feb 12 19:25:18 +0000 2012",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168775660448399361",
  "text" : "9deg and overcast = digging deep for motivation to run for two hours. oh blacksburg, i miss your 31 and sunny",
  "id" : 168775660448399361,
  "created_at" : "Sun Feb 12 19:17:07 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaTeX",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168537485423554560",
  "text" : "a very excellent LaTeX amsthm package overview: ftp://ftp.ams.org/ams/doc/amscls/amsthdoc.pdf #LaTeX",
  "id" : 168537485423554560,
  "created_at" : "Sun Feb 12 03:30:42 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 107, 114 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168407841168826369",
  "text" : "just accepted a credit card donation for the Lund Family Center at UVM Triathlon's 24 hour fundraiser with @square!!",
  "id" : 168407841168826369,
  "created_at" : "Sat Feb 11 18:55:32 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 131, 138 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168390010511429632",
  "text" : "not even 20deg, snow on the roads, and im off on my road bike w rollers on my shoulder, dbl strength gatorade (so wont freeze) and @square!!",
  "id" : 168390010511429632,
  "created_at" : "Sat Feb 11 17:44:41 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 5, 15 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "NCSU Cycling Club",
      "screen_name" : "NCStateCycling",
      "indices" : [ 41, 56 ],
      "id_str" : "292063766",
      "id" : 292063766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168385098100645890",
  "text" : "hope @VTCycling is owning shit right now @NCStateCycling!! wish I was racing this weekend, but it's roller times for me",
  "id" : 168385098100645890,
  "created_at" : "Sat Feb 11 17:25:10 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168225495169769472",
  "geo" : {
  },
  "id_str" : "168244203732738048",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan the gutter? what you talkin bout... I meant tots, ms greek!",
  "id" : 168244203732738048,
  "in_reply_to_status_id" : 168225495169769472,
  "created_at" : "Sat Feb 11 08:05:18 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168215997390655488",
  "geo" : {
  },
  "id_str" : "168225072555888640",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan and i thought you'd never",
  "id" : 168225072555888640,
  "in_reply_to_status_id" : 168215997390655488,
  "created_at" : "Sat Feb 11 06:49:17 +0000 2012",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168217733870264320",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C tell me about general lees toliet",
  "id" : 168217733870264320,
  "created_at" : "Sat Feb 11 06:20:07 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168129140887797760",
  "text" : "go cats go! and free scarves okay okayy",
  "id" : 168129140887797760,
  "created_at" : "Sat Feb 11 00:28:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VeloNews",
      "screen_name" : "velonews",
      "indices" : [ 3, 12 ],
      "id_str" : "5569742",
      "id" : 5569742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/vdLjxVgf",
      "expanded_url" : "http://bit.ly/yXeDh2",
      "display_url" : "bit.ly/yXeDh2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "168056056734433281",
  "text" : "RT @velonews: Opinion: Doping cases, like life itself, are rarely black and white. http://t.co/vdLjxVgf",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http://t.co/vdLjxVgf",
        "expanded_url" : "http://bit.ly/yXeDh2",
        "display_url" : "bit.ly/yXeDh2"
      } ]
    },
    "geo" : {
    },
    "id_str" : "168051907103956993",
    "text" : "Opinion: Doping cases, like life itself, are rarely black and white. http://t.co/vdLjxVgf",
    "id" : 168051907103956993,
    "created_at" : "Fri Feb 10 19:21:11 +0000 2012",
    "user" : {
      "name" : "VeloNews",
      "screen_name" : "velonews",
      "protected" : false,
      "id_str" : "5569742",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1685337825/velo-news-logo_normal.jpg",
      "id" : 5569742,
      "verified" : false
    }
  },
  "id" : 168056056734433281,
  "created_at" : "Fri Feb 10 19:37:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 0, 10 ],
      "id_str" : "313762318",
      "id" : 313762318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168050545804853248",
  "geo" : {
  },
  "id_str" : "168052855733882881",
  "in_reply_to_user_id" : 313762318,
  "text" : "@Crispy__C yo! yeah I sold it to a friend on the triathlon team. it's most likely at d2 every day!!",
  "id" : 168052855733882881,
  "in_reply_to_status_id" : 168050545804853248,
  "created_at" : "Fri Feb 10 19:24:57 +0000 2012",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "America Bikes",
      "screen_name" : "AmericaBikes",
      "indices" : [ 3, 16 ],
      "id_str" : "390979912",
      "id" : 390979912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bikenomics",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "168048002181767168",
  "text" : "RT @AmericaBikes: Cost of all bike infrastructure in Portland = construction cost of 1 mile of interstate highway. #bikenomics",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bikenomics",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "167712395530223616",
    "text" : "Cost of all bike infrastructure in Portland = construction cost of 1 mile of interstate highway. #bikenomics",
    "id" : 167712395530223616,
    "created_at" : "Thu Feb 09 20:52:05 +0000 2012",
    "user" : {
      "name" : "America Bikes",
      "screen_name" : "AmericaBikes",
      "protected" : false,
      "id_str" : "390979912",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1797181185/America_Bikes_sq_logo_normal.png",
      "id" : 390979912,
      "verified" : false
    }
  },
  "id" : 168048002181767168,
  "created_at" : "Fri Feb 10 19:05:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167950432134627329",
  "geo" : {
  },
  "id_str" : "167973700631662592",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 then that's a dress up friday, for you, right?",
  "id" : 167973700631662592,
  "in_reply_to_status_id" : 167950432134627329,
  "created_at" : "Fri Feb 10 14:10:25 +0000 2012",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167736641153282049",
  "text" : "stellar, gorgeous ride. home to fresh bread, and an open tap. life complete.",
  "id" : 167736641153282049,
  "created_at" : "Thu Feb 09 22:28:26 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 75, 87 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167699164212367360",
  "text" : "correct me if im wrong, but spring appears to have arrived. time to ride w @UVM_cycling's finest!",
  "id" : 167699164212367360,
  "created_at" : "Thu Feb 09 19:59:31 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 43, 55 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167654466777120770",
  "geo" : {
  },
  "id_str" : "167675383917977600",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD looking awesome in those pics!! (@runfasteraw I saw you too!)",
  "id" : 167675383917977600,
  "in_reply_to_status_id" : 167654466777120770,
  "created_at" : "Thu Feb 09 18:25:01 +0000 2012",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 3, 12 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/U8H5ruCN",
      "expanded_url" : "http://www.collegiatetimes.com/cms/resource/frontpagepdfs/20120207.pdf",
      "display_url" : "collegiatetimes.com/cms/resource/f…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "167674949698457600",
  "text" : "RT @aJohnnyD: Collegiate Times did and article on The Owen Cup 2012. Check page 2 of Tuesdays paper.\nhttp://t.co/U8H5ruCN",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/U8H5ruCN",
        "expanded_url" : "http://www.collegiatetimes.com/cms/resource/frontpagepdfs/20120207.pdf",
        "display_url" : "collegiatetimes.com/cms/resource/f…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "167654466777120770",
    "text" : "Collegiate Times did and article on The Owen Cup 2012. Check page 2 of Tuesdays paper.\nhttp://t.co/U8H5ruCN",
    "id" : 167654466777120770,
    "created_at" : "Thu Feb 09 17:01:54 +0000 2012",
    "user" : {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "protected" : false,
      "id_str" : "77300651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/436050487/John_D_RIDING_normal.JPG",
      "id" : 77300651,
      "verified" : false
    }
  },
  "id" : 167674949698457600,
  "created_at" : "Thu Feb 09 18:23:17 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167674108958621696",
  "text" : "now has a vermont drivers license! ...does this automatically make me more liberal? (social theory purports that it will I think)",
  "id" : 167674108958621696,
  "created_at" : "Thu Feb 09 18:19:57 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167318355894734848",
  "geo" : {
  },
  "id_str" : "167334412218929152",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy dude love it! might just have to get me one!!",
  "id" : 167334412218929152,
  "in_reply_to_status_id" : 167318355894734848,
  "created_at" : "Wed Feb 08 19:50:07 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hungry",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167305195720675328",
  "text" : "today's plan went something like meeting class meeting meeting class meeting meeting homework. but i forgot lunch! #hungry",
  "id" : 167305195720675328,
  "created_at" : "Wed Feb 08 17:54:01 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 1, 13 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167050513303617538",
  "text" : ".@uvm_cycling's meeting, complete with multimedia presentation!?",
  "id" : 167050513303617538,
  "created_at" : "Wed Feb 08 01:02:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166959642948276224",
  "geo" : {
  },
  "id_str" : "167026026432569344",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy oh word, I missed the date. I just saw the mtn lake trails and was jealous :P def will think about it!",
  "id" : 167026026432569344,
  "in_reply_to_status_id" : 166959642948276224,
  "created_at" : "Tue Feb 07 23:24:42 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turnaround",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "167023818467065857",
  "text" : "errand failure (dmv closes at 4!) but the indoor hammock stand is sweeet now and my Square card reader showed up! #turnaround",
  "id" : 167023818467065857,
  "created_at" : "Tue Feb 07 23:15:56 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166953548670705664",
  "geo" : {
  },
  "id_str" : "166959378891669504",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy looks awesome!! I am at grad school at UVM now though, so probably not. Holiday Lake is this weekend actually",
  "id" : 166959378891669504,
  "in_reply_to_status_id" : 166953548670705664,
  "created_at" : "Tue Feb 07 18:59:52 +0000 2012",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 49, 61 ],
      "id_str" : "276236513",
      "id" : 276236513
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 79, 91 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/tvlc2rhR",
      "expanded_url" : "http://app.strava.com/rides/irish-hill-hunting-3948370?ref=1MT1yaWRlX3NoYXJlOzI9dHdpdHRlcjs0PTEzNjU3Mw%3D%3D",
      "display_url" : "app.strava.com/rides/irish-hi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "166663018892107776",
  "text" : "6th overall on Irish Hill? Okayyy okay. Kudos to @bikingbiebs for the leadout. @uvm_cycling http://t.co/tvlc2rhR",
  "id" : 166663018892107776,
  "created_at" : "Mon Feb 06 23:22:14 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Matt Sutkoski ",
      "screen_name" : "vermontweather",
      "indices" : [ 1, 16 ],
      "id_str" : "14603154",
      "id" : 14603154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTV",
      "indices" : [ 46, 50 ]
    }, {
      "text" : "VT",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166653340351082496",
  "text" : "\"@vermontweather: High temp. of 50 degrees in #BTV #VT today ties record hi for the date first set in 2005. First 50 temp since 12/16/11\" ++",
  "id" : 166653340351082496,
  "created_at" : "Mon Feb 06 22:43:47 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohwell",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166612197177438208",
  "geo" : {
  },
  "id_str" : "166646189981315072",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser yeah I looked at those, but reviews from people who said theyd failed during presentations were enough to put me off... #ohwell",
  "id" : 166646189981315072,
  "in_reply_to_status_id" : 166612197177438208,
  "created_at" : "Mon Feb 06 22:15:22 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 1, 8 ],
      "id_str" : "42924530",
      "id" : 42924530
    }, {
      "name" : "Derek Harnden",
      "screen_name" : "bikingbiebs",
      "indices" : [ 28, 40 ],
      "id_str" : "276236513",
      "id" : 276236513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166610773437710337",
  "text" : ".@strava records to break w @bikingbiebs!! so nice out!",
  "id" : 166610773437710337,
  "created_at" : "Mon Feb 06 19:54:38 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fightfightfight",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166600876276985856",
  "text" : "got dem tickets for my first UVM hockey game! #fightfightfight",
  "id" : 166600876276985856,
  "created_at" : "Mon Feb 06 19:15:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maclife",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166597241665110016",
  "text" : "bought the bullet and paid $30 for a vga adapter...maybe having an 8 hour battery life is a fair compromise though #maclife",
  "id" : 166597241665110016,
  "created_at" : "Mon Feb 06 19:00:52 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166589267370450944",
  "text" : "contents of my messenger bag today: 1 macbook, 1 bag leftover chips for lunch. must be day after the super bowl...",
  "id" : 166589267370450944,
  "created_at" : "Mon Feb 06 18:29:11 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Endurance Monster",
      "screen_name" : "EnMonster",
      "indices" : [ 0, 10 ],
      "id_str" : "363191526",
      "id" : 363191526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166571897264414720",
  "geo" : {
  },
  "id_str" : "166582604756287488",
  "in_reply_to_user_id" : 363191526,
  "text" : "@EnMonster warmer weather to train in :P",
  "id" : 166582604756287488,
  "in_reply_to_status_id" : 166571897264414720,
  "created_at" : "Mon Feb 06 18:02:42 +0000 2012",
  "in_reply_to_screen_name" : "EnMonster",
  "in_reply_to_user_id_str" : "363191526",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166572653241569281",
  "geo" : {
  },
  "id_str" : "166582525890789376",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons remember not to click that new garmin on the finish line, that'll ruin any look! (can always cut the end later)",
  "id" : 166582525890789376,
  "in_reply_to_status_id" : 166572653241569281,
  "created_at" : "Mon Feb 06 18:02:23 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "indices" : [ 3, 17 ],
      "id_str" : "368379922",
      "id" : 368379922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166558277180727296",
  "text" : "RT @uvmcomplexity: Reading group Weds 11:45am Farrell Hall: `Dynamic Models of Segregation' by Nobel winner Thomas Schelling, http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/RU1tCD3p",
        "expanded_url" : "http://bit.ly/z0pygk",
        "display_url" : "bit.ly/z0pygk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "166555918375469056",
    "text" : "Reading group Weds 11:45am Farrell Hall: `Dynamic Models of Segregation' by Nobel winner Thomas Schelling, http://t.co/RU1tCD3p",
    "id" : 166555918375469056,
    "created_at" : "Mon Feb 06 16:16:40 +0000 2012",
    "user" : {
      "name" : "UVM Complex Systems",
      "screen_name" : "uvmcomplexity",
      "protected" : false,
      "id_str" : "368379922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529859022/CSC_logo_symbol_normal.png",
      "id" : 368379922,
      "verified" : false
    }
  },
  "id" : 166558277180727296,
  "created_at" : "Mon Feb 06 16:26:02 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 3, 15 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166522178412617728",
  "text" : "RT @UVM_cycling: Only one month till Rutgers!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "166519959860674560",
    "text" : "Only one month till Rutgers!",
    "id" : 166519959860674560,
    "created_at" : "Mon Feb 06 13:53:46 +0000 2012",
    "user" : {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "protected" : false,
      "id_str" : "75351547",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/523498694/n6907465_34735233_4107677_normal.jpg",
      "id" : 75351547,
      "verified" : false
    }
  },
  "id" : 166522178412617728,
  "created_at" : "Mon Feb 06 14:02:35 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166384037651423232",
  "geo" : {
  },
  "id_str" : "166385443837972481",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet I am in this exact situation",
  "id" : 166385443837972481,
  "in_reply_to_status_id" : 166384037651423232,
  "created_at" : "Mon Feb 06 04:59:15 +0000 2012",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 3, 12 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "phd",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166365574509768706",
  "text" : "RT @dr_pyser: Pretty much, just became Dr. Mitchell. Best #superbowl evar. #phd",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "superbowl",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "phd",
        "indices" : [ 61, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "166323347574108162",
    "text" : "Pretty much, just became Dr. Mitchell. Best #superbowl evar. #phd",
    "id" : 166323347574108162,
    "created_at" : "Mon Feb 06 00:52:30 +0000 2012",
    "user" : {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "protected" : false,
      "id_str" : "5548572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/22568962/tryscienceav_normal.gif",
      "id" : 5548572,
      "verified" : false
    }
  },
  "id" : 166365574509768706,
  "created_at" : "Mon Feb 06 03:40:18 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Ryden",
      "screen_name" : "erik_ryden",
      "indices" : [ 1, 12 ],
      "id_str" : "355569678",
      "id" : 355569678
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/166290200505491456/photo/1",
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/scjWYhO2",
      "media_url" : "http://pbs.twimg.com/media/Ak7IDmsCIAEFl08.jpg",
      "id_str" : "166290200509685761",
      "id" : 166290200509685761,
      "media_url_https" : "https://pbs.twimg.com/media/Ak7IDmsCIAEFl08.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/scjWYhO2"
    } ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "isforeating",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "166290200505491456",
  "text" : ".@erik_ryden's pasta turnover!! #superbowl #isforeating http://t.co/scjWYhO2",
  "id" : 166290200505491456,
  "created_at" : "Sun Feb 05 22:40:48 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 8, 15 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/165973578850910208/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/lhbfxl46",
      "media_url" : "http://pbs.twimg.com/media/Ak2oFzHCQAEtn2W.jpg",
      "id_str" : "165973578855104513",
      "id" : 165973578855104513,
      "media_url_https" : "https://pbs.twimg.com/media/Ak2oFzHCQAEtn2W.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/lhbfxl46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165973578850910208",
  "text" : "I think @sspis1 know's why I need this http://t.co/lhbfxl46",
  "id" : 165973578850910208,
  "created_at" : "Sun Feb 05 01:42:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 3, 12 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Strava",
      "screen_name" : "Strava",
      "indices" : [ 81, 88 ],
      "id_str" : "42924530",
      "id" : 42924530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/M6lyAhWM",
      "expanded_url" : "http://app.strava.com/rides/owen-cup-1st-3880171?ref=1MT1yaWRlX3NoYXJlOzI9dHdpdHRlcjs0PTE4Mjk%3D",
      "display_url" : "app.strava.com/rides/owen-cup…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165968045188194307",
  "text" : "RT @aJohnnyD: Owen Cup 1st place went for a 92.2 mile road ride. Check it out on @Strava http://t.co/M6lyAhWM",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Strava",
        "screen_name" : "Strava",
        "indices" : [ 67, 74 ],
        "id_str" : "42924530",
        "id" : 42924530
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/M6lyAhWM",
        "expanded_url" : "http://app.strava.com/rides/owen-cup-1st-3880171?ref=1MT1yaWRlX3NoYXJlOzI9dHdpdHRlcjs0PTE4Mjk%3D",
        "display_url" : "app.strava.com/rides/owen-cup…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "165908900359573504",
    "text" : "Owen Cup 1st place went for a 92.2 mile road ride. Check it out on @Strava http://t.co/M6lyAhWM",
    "id" : 165908900359573504,
    "created_at" : "Sat Feb 04 21:25:38 +0000 2012",
    "user" : {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "protected" : false,
      "id_str" : "77300651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/436050487/John_D_RIDING_normal.JPG",
      "id" : 77300651,
      "verified" : false
    }
  },
  "id" : 165968045188194307,
  "created_at" : "Sun Feb 05 01:20:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/165941947259817984/photo/1",
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/pWZmm5ig",
      "media_url" : "http://pbs.twimg.com/media/Ak2LUmQCEAA7NJA.jpg",
      "id_str" : "165941947264012288",
      "id" : 165941947264012288,
      "media_url_https" : "https://pbs.twimg.com/media/Ak2LUmQCEAA7NJA.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/pWZmm5ig"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/GGjnaZTO",
      "expanded_url" : "http://app.strava.com/rides/3883911",
      "display_url" : "app.strava.com/rides/3883911"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165941947259817984",
  "text" : "amazing snowshoe run @ Bolton Backcountry, golden snow w the low sun, ran down mtn into sunset http://t.co/GGjnaZTO http://t.co/pWZmm5ig",
  "id" : 165941947259817984,
  "created_at" : "Sat Feb 04 23:37:00 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RudyProjectNA",
      "screen_name" : "RudyProjectNA",
      "indices" : [ 27, 41 ],
      "id_str" : "16320256",
      "id" : 16320256
    }, {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 97, 109 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/andyreagan/status/165691638625214464/photo/1",
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/EL3rXsIb",
      "media_url" : "http://pbs.twimg.com/media/Akynqt7CIAA0qhi.jpg",
      "id_str" : "165691638629408768",
      "id" : 165691638629408768,
      "media_url_https" : "https://pbs.twimg.com/media/Akynqt7CIAA0qhi.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com/EL3rXsIb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165691638625214464",
  "text" : "and my new, super intense, @rudyprojectna glasses got here today! can't wait to use them!! props @UVM_cycling http://t.co/EL3rXsIb",
  "id" : 165691638625214464,
  "created_at" : "Sat Feb 04 07:02:25 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165588513687994368",
  "geo" : {
  },
  "id_str" : "165688156937666560",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser told ya.... :P",
  "id" : 165688156937666560,
  "in_reply_to_status_id" : 165588513687994368,
  "created_at" : "Sat Feb 04 06:48:29 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165687722483257344",
  "text" : "today's post-agenda: class, meeting/seminar, class, crushed some hw, and then beers in DT Burlington! twas a good day and night",
  "id" : 165687722483257344,
  "created_at" : "Sat Feb 04 06:46:46 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165687429125246976",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud sounds like an excellent night!",
  "id" : 165687429125246976,
  "created_at" : "Sat Feb 04 06:45:36 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peaceful",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165272884766445568",
  "text" : "huddling around the brew kettle bc it's 16 and snowing while I'm boiling the wort #peaceful",
  "id" : 165272884766445568,
  "created_at" : "Fri Feb 03 03:18:21 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/CfjU0mWs",
      "expanded_url" : "http://www.billmckibben.com/bio.html",
      "display_url" : "billmckibben.com/bio.html"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165204440201175040",
  "text" : "its a packed house for Bill McKibben here on UVM Campus, his talk today \"From the front lines of climate change,\" bio: http://t.co/CfjU0mWs",
  "id" : 165204440201175040,
  "created_at" : "Thu Feb 02 22:46:22 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dr_pyser",
      "screen_name" : "dr_pyser",
      "indices" : [ 0, 9 ],
      "id_str" : "5548572",
      "id" : 5548572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165201065497735170",
  "in_reply_to_user_id" : 5548572,
  "text" : "@dr_pyser hey I'm sitting in the row right above you, halfway up",
  "id" : 165201065497735170,
  "created_at" : "Thu Feb 02 22:32:57 +0000 2012",
  "in_reply_to_screen_name" : "dr_pyser",
  "in_reply_to_user_id_str" : "5548572",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatty",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "165195310077984768",
  "text" : "has got 12 pounds to lose for cycling season, tipping the scales at 7.5% BF #fatty",
  "id" : 165195310077984768,
  "created_at" : "Thu Feb 02 22:10:05 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keepingdreaming",
      "indices" : [ 69, 85 ]
    }, {
      "text" : "burrrrrlington",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/Pr9vj4hN",
      "expanded_url" : "http://www.stanford.edu/group/uq/events/AIAA_NDA.html",
      "display_url" : "stanford.edu/group/uq/event…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "165125099823955969",
  "text" : "found a UQ conference in Florida this spring... http://t.co/Pr9vj4hN #keepingdreaming #burrrrrlington",
  "id" : 165125099823955969,
  "created_at" : "Thu Feb 02 17:31:06 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164958702955278336",
  "text" : "first keg now in the kegerator, carbonating happily. oatmeal stout in secondary, and both are looking good so far",
  "id" : 164958702955278336,
  "created_at" : "Thu Feb 02 06:29:54 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/LIKqQodm",
      "expanded_url" : "http://www.kegerators.com/carbonation-table.php",
      "display_url" : "kegerators.com/carbonation-ta…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164928740223234048",
  "text" : "kegging my beer! taps will be flowing for the Super Bowl. for reference, here's a force carbonation chart: http://t.co/LIKqQodm",
  "id" : 164928740223234048,
  "created_at" : "Thu Feb 02 04:30:50 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVM Cycling",
      "screen_name" : "UVM_cycling",
      "indices" : [ 65, 77 ],
      "id_str" : "75351547",
      "id" : 75351547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164871670945955840",
  "text" : "riding indoors is more tolerable with company! trainer session w @UVM_cycling",
  "id" : 164871670945955840,
  "created_at" : "Thu Feb 02 00:44:04 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Parsons",
      "screen_name" : "HannaParsons",
      "indices" : [ 0, 13 ],
      "id_str" : "834636222",
      "id" : 834636222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164775218269794304",
  "geo" : {
  },
  "id_str" : "164777846395518977",
  "in_reply_to_user_id" : 368621257,
  "text" : "@HannaParsons actually, depends how fast you are. the front group has a shorter run, going corner to corner. in the pack, I ran 26.4",
  "id" : 164777846395518977,
  "in_reply_to_status_id" : 164775218269794304,
  "created_at" : "Wed Feb 01 18:31:14 +0000 2012",
  "in_reply_to_screen_name" : "HannaRuns2Live",
  "in_reply_to_user_id_str" : "368621257",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Sheridan Dodds",
      "screen_name" : "peterdodds",
      "indices" : [ 96, 107 ],
      "id_str" : "16174144",
      "id" : 16174144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/LSs57hKA",
      "expanded_url" : "http://bit.ly/x7ZARH",
      "display_url" : "bit.ly/x7ZARH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "164772415178678274",
  "text" : "Be Better at Twitter: The Definitive, Data-Driven Guide - The Atlantic http://t.co/LSs57hKA via @peterdodds",
  "id" : 164772415178678274,
  "created_at" : "Wed Feb 01 18:09:39 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smart",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164585534495260672",
  "text" : "at night in Burlington, the stop lights turn into yields (flashing yellow) #smart. only me and one other bike out, so quiet too",
  "id" : 164585534495260672,
  "created_at" : "Wed Feb 01 05:47:03 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "Matthis",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "youwinatlife",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164579196302147584",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis while typing #math, twitter suggested the hash tag #Matthis … #youwinatlife",
  "id" : 164579196302147584,
  "created_at" : "Wed Feb 01 05:21:52 +0000 2012",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathjokes",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "toolate",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "164578640477171712",
  "text" : "without realizing the outcome before typesetting it, fixed x=a in g(x,y) #mathjokes #toolate",
  "id" : 164578640477171712,
  "created_at" : "Wed Feb 01 05:19:40 +0000 2012",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164570239017828352",
  "geo" : {
  },
  "id_str" : "164578162477514752",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud woah looks amazing! stuffed with? recipe please?",
  "id" : 164578162477514752,
  "in_reply_to_status_id" : 164570239017828352,
  "created_at" : "Wed Feb 01 05:17:46 +0000 2012",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]