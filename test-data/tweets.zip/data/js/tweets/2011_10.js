Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sahweet",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131184206003965952",
  "text" : "excellent dinner and local brew at the Great Dane Brewing Company, everything covered but the beer #sahweet",
  "id" : 131184206003965952,
  "created_at" : "Tue Nov 01 01:42:06 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131178327120674819",
  "geo" : {
  },
  "id_str" : "131183891129176064",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy interviewing with Epic. they do health software",
  "id" : 131183891129176064,
  "in_reply_to_status_id" : 131178327120674819,
  "created_at" : "Tue Nov 01 01:40:51 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "endurance Junkie",
      "screen_name" : "enduranceJunkie",
      "indices" : [ 0, 16 ],
      "id_str" : "48311431",
      "id" : 48311431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131127476880539648",
  "geo" : {
  },
  "id_str" : "131141058678624256",
  "in_reply_to_user_id" : 46897301,
  "text" : "@EnduranceJunkie hahah oh how I know that feeling",
  "id" : 131141058678624256,
  "in_reply_to_status_id" : 131127476880539648,
  "created_at" : "Mon Oct 31 22:50:39 +0000 2011",
  "in_reply_to_screen_name" : "CoachNateC",
  "in_reply_to_user_id_str" : "46897301",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icouldgetusedtothis",
      "indices" : [ 24, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/mXjgH2sd",
      "expanded_url" : "http://twitpic.com/790w28",
      "display_url" : "twitpic.com/790w28"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131140845926748162",
  "text" : "and check out the view! #icouldgetusedtothis http://t.co/mXjgH2sd",
  "id" : 131140845926748162,
  "created_at" : "Mon Oct 31 22:49:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131140479915008001",
  "text" : "my room in the Hilton downtown is a serious upgrade from where I'm currently living...its as big as our first floor and not falling apart!",
  "id" : 131140479915008001,
  "created_at" : "Mon Oct 31 22:48:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131111280588242945",
  "text" : "landed in Madison! it's flattt in WI, views of tons of small farms coming in (as opposed to endless sprawl in chicago)",
  "id" : 131111280588242945,
  "created_at" : "Mon Oct 31 20:52:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "outrageous",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "ijustwanttosendanemail",
      "indices" : [ 38, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131084975633215488",
  "text" : "they charge for wifi here #outrageous #ijustwanttosendanemail",
  "id" : 131084975633215488,
  "created_at" : "Mon Oct 31 19:07:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131079544227643392",
  "text" : "@Tri_Gardner yessir. can't really say ive \"been\" to detroit, just this strange space of an airport",
  "id" : 131079544227643392,
  "created_at" : "Mon Oct 31 18:46:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131076397044203520",
  "text" : "landed in Chicago, an hour to burn before leaving for Madison!",
  "id" : 131076397044203520,
  "created_at" : "Mon Oct 31 18:33:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131070597282283522",
  "geo" : {
  },
  "id_str" : "131076212348026880",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs its legal, right?",
  "id" : 131076212348026880,
  "in_reply_to_status_id" : 131070597282283522,
  "created_at" : "Mon Oct 31 18:32:58 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "jbice0",
      "indices" : [ 0, 7 ],
      "id_str" : "17882551",
      "id" : 17882551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131060445414031360",
  "geo" : {
  },
  "id_str" : "131070924681261056",
  "in_reply_to_user_id" : 17882551,
  "text" : "@jbice0 haha yup. roanoke -&gt; chicago -&gt; madison, wi for a job interview",
  "id" : 131070924681261056,
  "in_reply_to_status_id" : 131060445414031360,
  "created_at" : "Mon Oct 31 18:11:58 +0000 2011",
  "in_reply_to_screen_name" : "jbice0",
  "in_reply_to_user_id_str" : "17882551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131048488434810880",
  "text" : "you know that guy sprinting (literally) through the airport? that was me! made it by like 30sec! #phew",
  "id" : 131048488434810880,
  "created_at" : "Mon Oct 31 16:42:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shit",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131033132420968449",
  "text" : "on my way to the airport, standstill on 81 #shit",
  "id" : 131033132420968449,
  "created_at" : "Mon Oct 31 15:41:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "131003533414760448",
  "text" : "senior interview complete, one step closer to graduation...",
  "id" : 131003533414760448,
  "created_at" : "Mon Oct 31 13:44:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130859119765749760",
  "text" : "long night of work, time for some sleep! traveling to Madison WI tomorrow!",
  "id" : 130859119765749760,
  "created_at" : "Mon Oct 31 04:10:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 131, 139 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughdawg",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/VBW4NS6W",
      "expanded_url" : "http://bit.ly/udBSrP",
      "display_url" : "bit.ly/udBSrP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "130734894371438592",
  "text" : "the Rowdy Dawg XXC was a really tough one for me today, now I understand why its the #toughdawg - Garmin: http://t.co/VBW4NS6W via @AddThis",
  "id" : 130734894371438592,
  "created_at" : "Sun Oct 30 19:56:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isignedupforthis",
      "indices" : [ 51, 68 ]
    }, {
      "text" : "crazy",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "toughdawg",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130618584421498880",
  "text" : "28 degrees, 36 miles of mountain biking here we go #isignedupforthis #crazy #toughdawg",
  "id" : 130618584421498880,
  "created_at" : "Sun Oct 30 12:14:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130422187470499840",
  "text" : "the Super D down Old Farm was sweet, one mistake but no crashes. Pretty sure I beat my time from the collegiate race, even in the cold",
  "id" : 130422187470499840,
  "created_at" : "Sat Oct 29 23:14:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130359004718305280",
  "text" : "warmed up and headed back to the top of the mtn - this time to race a mtb down!",
  "id" : 130359004718305280,
  "created_at" : "Sat Oct 29 19:03:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 93, 101 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughdawg",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "fb",
      "indices" : [ 113, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/uv88dP3o",
      "expanded_url" : "http://bit.ly/tj37jJ",
      "display_url" : "bit.ly/tj37jJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "130347494331777026",
  "text" : "Brush Mountain Breakdown by andyreagan at Garmin Connect - Details: http://t.co/uv88dP3o via @AddThis #toughdawg #fb",
  "id" : 130347494331777026,
  "created_at" : "Sat Oct 29 18:17:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130339404991578112",
  "geo" : {
  },
  "id_str" : "130347194174812161",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson sweet! tear it up in the hardtail 29er division for the downhill!! (even if it's not an official category haha)",
  "id" : 130347194174812161,
  "in_reply_to_status_id" : 130339404991578112,
  "created_at" : "Sat Oct 29 18:16:07 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "thawingnow",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130337629135831042",
  "text" : "that was one killer run!! trail was frozen going up jacob's ladder. congrats to all those who toughed that one out! #ouch #thawingnow",
  "id" : 130337629135831042,
  "created_at" : "Sat Oct 29 17:38:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughdawg",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130266803627765760",
  "text" : "35 and \"wintry precipitation\" for this morning's Brush Mountain Breakdown 16 mile trail race. time to be a #toughdawg",
  "id" : 130266803627765760,
  "created_at" : "Sat Oct 29 12:56:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winning",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130140504296919041",
  "text" : "5 parties and gettin 8hrs of sleep in my own bed #winning",
  "id" : 130140504296919041,
  "created_at" : "Sat Oct 29 04:34:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130054921524477952",
  "geo" : {
  },
  "id_str" : "130055379987079169",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT just remember the little girl",
  "id" : 130055379987079169,
  "in_reply_to_status_id" : 130054921524477952,
  "created_at" : "Fri Oct 28 22:56:33 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "130021349900029953",
  "text" : "@Tri_Gardner haha yeah i agree, it was funny, we're human and forcing those guys to be robots...",
  "id" : 130021349900029953,
  "created_at" : "Fri Oct 28 20:41:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129923190662242304",
  "geo" : {
  },
  "id_str" : "129984678844301312",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 you are wearing shorts today? my man, it's 35 and raining",
  "id" : 129984678844301312,
  "in_reply_to_status_id" : 129923190662242304,
  "created_at" : "Fri Oct 28 18:15:37 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatty",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "chocolateoverload",
      "indices" : [ 71, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/knnZmaDd",
      "expanded_url" : "http://twitpic.com/773bm5",
      "display_url" : "twitpic.com/773bm5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129981915360002051",
  "text" : "chocolate day at d2 has been the best and worst THREE days ever #fatty #chocolateoverload http://t.co/knnZmaDd",
  "id" : 129981915360002051,
  "created_at" : "Fri Oct 28 18:04:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 6, 22 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collnats",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/cIx7i9ym",
      "expanded_url" : "http://twitpic.com/774ayo",
      "display_url" : "twitpic.com/774ayo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129981576707715072",
  "text" : "I see @JacobnAndersson!!! \"The men's DI cross-country race is staged and will b unleashed on a muddy course #collnats http://t.co/cIx7i9ym\"",
  "id" : 129981576707715072,
  "created_at" : "Fri Oct 28 18:03:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 94, 103 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winterswag",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "bestmomever",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129921574861156352",
  "text" : "winter has arrived... and people are diggin the scarf #winterswag #bestmomever made it for me @dmreagan",
  "id" : 129921574861156352,
  "created_at" : "Fri Oct 28 14:04:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129753868824358913",
  "text" : "got carried away playin bball, 2.5 hrs and I'm whipped. forgot how much fun good pick up ball is",
  "id" : 129753868824358913,
  "created_at" : "Fri Oct 28 02:58:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 132, 140 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/sQk8HK16",
      "expanded_url" : "http://bit.ly/sWKcsU",
      "display_url" : "bit.ly/sWKcsU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129688414802026496",
  "text" : "solid 8mi tempo, w sprints at 7mi! Andy run (w Chrissy and Jan) by andyreagan at Garmin Connect - Details: http://t.co/sQk8HK16 via @AddThis",
  "id" : 129688414802026496,
  "created_at" : "Thu Oct 27 22:38:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lim",
      "screen_name" : "davidhenrylim",
      "indices" : [ 0, 14 ],
      "id_str" : "45142041",
      "id" : 45142041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129553659469107200",
  "geo" : {
  },
  "id_str" : "129573758057971713",
  "in_reply_to_user_id" : 45142041,
  "text" : "@davidhenrylim by virginia do you mean the far southwest corner of virginia? cuz emma and I are there?!",
  "id" : 129573758057971713,
  "in_reply_to_status_id" : 129553659469107200,
  "created_at" : "Thu Oct 27 15:02:45 +0000 2011",
  "in_reply_to_screen_name" : "davidhenrylim",
  "in_reply_to_user_id_str" : "45142041",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129556586275414016",
  "text" : "senior picture taken...dang time is flying. 88 on my graduate modeling exam :)",
  "id" : 129556586275414016,
  "created_at" : "Thu Oct 27 13:54:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noleftovers4lunch",
      "indices" : [ 60, 78 ]
    }, {
      "text" : "fatass",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129335290337820672",
  "text" : "the problem with cooking 1lb of pasta...I always eat it all #noleftovers4lunch #fatass",
  "id" : 129335290337820672,
  "created_at" : "Wed Oct 26 23:15:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Tock",
      "screen_name" : "tick3tock3",
      "indices" : [ 0, 11 ],
      "id_str" : "223308471",
      "id" : 223308471
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "childrenplease",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129334659506122752",
  "geo" : {
  },
  "id_str" : "129335081771876352",
  "in_reply_to_user_id" : 223308471,
  "text" : "@tick3tock3 haha no... never been to a restaurant with a 21 year old? #childrenplease",
  "id" : 129335081771876352,
  "in_reply_to_status_id" : 129334659506122752,
  "created_at" : "Wed Oct 26 23:14:21 +0000 2011",
  "in_reply_to_screen_name" : "tick3tock3",
  "in_reply_to_user_id_str" : "223308471",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129311718089297920",
  "geo" : {
  },
  "id_str" : "129321909467873280",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson safe travels and enjoy that call-up!!",
  "id" : 129321909467873280,
  "in_reply_to_status_id" : 129311718089297920,
  "created_at" : "Wed Oct 26 22:22:00 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathbyalgebra",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129289147272802304",
  "text" : "real analysis HW done, almost thought one of the problems was wrong though. time for #deathbyalgebra",
  "id" : 129289147272802304,
  "created_at" : "Wed Oct 26 20:11:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 3, 18 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/q2HfvaqT",
      "expanded_url" : "http://money.cnn.com/2011/10/26/news/economy/occupy_wall_street_backlash/?hpt=hp_p1&iref=NS1",
      "display_url" : "money.cnn.com/2011/10/26/new…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129274260979068928",
  "text" : "RT @ryandelgiudice: http://t.co/q2HfvaqT",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http://t.co/q2HfvaqT",
        "expanded_url" : "http://money.cnn.com/2011/10/26/news/economy/occupy_wall_street_backlash/?hpt=hp_p1&iref=NS1",
        "display_url" : "money.cnn.com/2011/10/26/new…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "129272666132721665",
    "text" : "http://t.co/q2HfvaqT",
    "id" : 129272666132721665,
    "created_at" : "Wed Oct 26 19:06:20 +0000 2011",
    "user" : {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "protected" : true,
      "id_str" : "44471444",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1264948750/DSC00020_normal.jpg",
      "id" : 44471444,
      "verified" : false
    }
  },
  "id" : 129274260979068928,
  "created_at" : "Wed Oct 26 19:12:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129270172665135104",
  "geo" : {
  },
  "id_str" : "129272051189030912",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT here's a thought: p-chem or being forced to do nothing? i'd take the class. hang in there, you're not old yet!",
  "id" : 129272051189030912,
  "in_reply_to_status_id" : 129270172665135104,
  "created_at" : "Wed Oct 26 19:03:53 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/eJqX57HP",
      "expanded_url" : "http://twitpic.com/75uwzt",
      "display_url" : "twitpic.com/75uwzt"
    }, {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/0rFw4b2p",
      "expanded_url" : "http://twitpic.com/75ux4q",
      "display_url" : "twitpic.com/75ux4q"
    }, {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/vdvEa4HP",
      "expanded_url" : "http://twitpic.com/75ux8z",
      "display_url" : "twitpic.com/75ux8z"
    } ]
  },
  "geo" : {
  },
  "id_str" : "129027061246459905",
  "text" : "couldnt pick just 1 picture of the day. sunset, record 16 @ rnd tble, skillz http://t.co/eJqX57HP http://t.co/0rFw4b2p http://t.co/vdvEa4HP",
  "id" : 129027061246459905,
  "created_at" : "Wed Oct 26 02:50:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 0, 9 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129013052522774528",
  "geo" : {
  },
  "id_str" : "129016641798418433",
  "in_reply_to_user_id" : 204631321,
  "text" : "@DKnick88 hell yeah you do what lol?",
  "id" : 129016641798418433,
  "in_reply_to_status_id" : 129013052522774528,
  "created_at" : "Wed Oct 26 02:08:59 +0000 2011",
  "in_reply_to_screen_name" : "DKnick88",
  "in_reply_to_user_id_str" : "204631321",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    }, {
      "name" : "Blacksburg Stuff",
      "screen_name" : "BlacksburgStuff",
      "indices" : [ 40, 56 ],
      "id_str" : "226946313",
      "id" : 226946313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "129009043825115137",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT i know where to find you now \"@blacksburgstuff Look at that! It's time for TOTS Tuesday! :D\"",
  "id" : 129009043825115137,
  "created_at" : "Wed Oct 26 01:38:47 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BikeReg",
      "screen_name" : "BikeReg",
      "indices" : [ 5, 13 ],
      "id_str" : "83747010",
      "id" : 83747010
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 74, 86 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TOUGHDAWG",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "fb",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/gAgD0AQQ",
      "expanded_url" : "http://www.BikeReg.com/events/register.asp?EventID=14297",
      "display_url" : "BikeReg.com/events/registe…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128980473652330496",
  "text" : "just @BikeReg'd for Rowdy Dawg 2011 XXC - http://t.co/gAgD0AQQ #TOUGHDAWG @runfasteraw #fb",
  "id" : 128980473652330496,
  "created_at" : "Tue Oct 25 23:45:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 36, 43 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campushobochallenge",
      "indices" : [ 8, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/Ci7nayYT",
      "expanded_url" : "http://andyreagan.com/2011/10/25/the-campus-hobo-challenge/",
      "display_url" : "andyreagan.com/2011/10/25/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128977529850699776",
  "text" : "let the #campushobochallenge begin! @sspis1 http://t.co/Ci7nayYT",
  "id" : 128977529850699776,
  "created_at" : "Tue Oct 25 23:33:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 104, 112 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/DTgasORK",
      "expanded_url" : "http://bit.ly/sphgo8",
      "display_url" : "bit.ly/sphgo8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128969302366879744",
  "text" : "sweet run today \"Through the fields by andyreagan at Garmin Connect - Details: http://t.co/DTgasORK via @AddThis\"",
  "id" : 128969302366879744,
  "created_at" : "Tue Oct 25 23:00:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 3, 17 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128965678391771136",
  "text" : "RT @BlackSheep_VT: If you have to suck in during every picture you take, avoid showing your midriff at Halloween costumes.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "128948477966299137",
    "text" : "If you have to suck in during every picture you take, avoid showing your midriff at Halloween costumes.",
    "id" : 128948477966299137,
    "created_at" : "Tue Oct 25 21:38:07 +0000 2011",
    "user" : {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "protected" : false,
      "id_str" : "326870950",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1440736506/sheepbeerhat5_normal.jpg",
      "id" : 326870950,
      "verified" : false
    }
  },
  "id" : 128965678391771136,
  "created_at" : "Tue Oct 25 22:46:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128937280239964160",
  "text" : "gorgeous 70 and sunny outside = goin for a run w Chrissy and Rachel!",
  "id" : 128937280239964160,
  "created_at" : "Tue Oct 25 20:53:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 60, 67 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128920830750105601",
  "text" : "good news all around! heading to Madison WI for Tuesday and @DZdan1's got my back",
  "id" : 128920830750105601,
  "created_at" : "Tue Oct 25 19:48:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128859468413935616",
  "geo" : {
  },
  "id_str" : "128860722473091072",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 not so much that I care, and it won't help you not get lost, but let you know after how fast you ran",
  "id" : 128860722473091072,
  "in_reply_to_status_id" : 128859468413935616,
  "created_at" : "Tue Oct 25 15:49:25 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vernon Hill",
      "screen_name" : "vmhilljr",
      "indices" : [ 1, 10 ],
      "id_str" : "104673361",
      "id" : 104673361
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 12, 23 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/arb5LEzi",
      "expanded_url" : "http://twitter.com/vmhilljr/status/128682468453785601/photo/1",
      "display_url" : "pic.twitter.com/arb5LEzi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128858628743626752",
  "text" : "\"@vmhilljr: @andyreagan As cool as this? I don't think so! http://t.co/arb5LEzi\" only a little bit cooler, i suppose :-P",
  "id" : 128858628743626752,
  "created_at" : "Tue Oct 25 15:41:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 9, 16 ],
      "id_str" : "15324722",
      "id" : 15324722
    }, {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 55, 62 ],
      "id_str" : "15324722",
      "id" : 15324722
    }, {
      "name" : "ANT+ Alliance",
      "screen_name" : "ANTPlus",
      "indices" : [ 73, 81 ],
      "id_str" : "18386549",
      "id" : 18386549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "running",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/omUb7BSC",
      "expanded_url" : "http://bit.ly/uLHd3x",
      "display_url" : "bit.ly/uLHd3x"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128856205698416640",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 \"@Garmin: New in fitness: http://t.co/omUb7BSC @Garmin Fit App & @AntPlus Adapter Keep You Connected and On The Move #running\"",
  "id" : 128856205698416640,
  "created_at" : "Tue Oct 25 15:31:28 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bam",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128855411880235008",
  "text" : "exam down, project turned in #bam",
  "id" : 128855411880235008,
  "created_at" : "Tue Oct 25 15:28:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsgo",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128825567805054977",
  "text" : "presentation success! midterm exam time #letsgo",
  "id" : 128825567805054977,
  "created_at" : "Tue Oct 25 13:29:43 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/RnU22Akn",
      "expanded_url" : "http://twitpic.com/75fixv",
      "display_url" : "twitpic.com/75fixv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128681407517175808",
  "text" : "coolest tie ever http://t.co/RnU22Akn",
  "id" : 128681407517175808,
  "created_at" : "Tue Oct 25 03:56:52 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whynot",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128679516703948800",
  "text" : "just course requested for the spring #whynot",
  "id" : 128679516703948800,
  "created_at" : "Tue Oct 25 03:49:22 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 22, 31 ],
      "id_str" : "77300651",
      "id" : 77300651
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 52, 62 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Jacob Aber",
      "screen_name" : "jabervt",
      "indices" : [ 116, 124 ],
      "id_str" : "370283022",
      "id" : 370283022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128648661465964544",
  "text" : "solid presentation by @aJohnnyD and Scotland at the @vtcycling meeting, as well as championship ice cream cake from @jabervt!!",
  "id" : 128648661465964544,
  "created_at" : "Tue Oct 25 01:46:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin H. Johnson",
      "screen_name" : "BioInfo",
      "indices" : [ 1, 9 ],
      "id_str" : "30005585",
      "id" : 30005585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schweet",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/Z73kAOGZ",
      "expanded_url" : "http://ping.fm/BHQxe",
      "display_url" : "ping.fm/BHQxe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128628367825174528",
  "text" : "\"@BioInfo: Google+ to Support Google Apps in Next Few Days http://t.co/Z73kAOGZ\" yessss #schweet",
  "id" : 128628367825174528,
  "created_at" : "Tue Oct 25 00:26:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 90, 98 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/jJsnbqEP",
      "expanded_url" : "http://bit.ly/uCitf9",
      "display_url" : "bit.ly/uCitf9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128603279553855488",
  "text" : "quick run down. \"barely counts\" run on Garmin Connect - Details: http://t.co/jJsnbqEP via @AddThis",
  "id" : 128603279553855488,
  "created_at" : "Mon Oct 24 22:46:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 108, 118 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128595126586056704",
  "text" : "presentation drafted, code written = sneaking quick run in. then getting my suit tailored and frozen treats @vtcycling's meeting",
  "id" : 128595126586056704,
  "created_at" : "Mon Oct 24 22:14:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 32, 39 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128594945463418880",
  "text" : "cinnamon raisin bread success!! @rkay21's bday present. next up: sundried tomato and mozzarella.",
  "id" : 128594945463418880,
  "created_at" : "Mon Oct 24 22:13:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bike League ",
      "screen_name" : "BikeLeague",
      "indices" : [ 3, 14 ],
      "id_str" : "25085215",
      "id" : 25085215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/9sV6XjKg",
      "expanded_url" : "http://nblo.gs/oVbMV",
      "display_url" : "nblo.gs/oVbMV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128575746548568064",
  "text" : "RT @BikeLeague: Giant flips the script on GM http://t.co/9sV6XjKg",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.networkedblogs.com/\" rel=\"nofollow\">NetworkedBlogs</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/9sV6XjKg",
        "expanded_url" : "http://nblo.gs/oVbMV",
        "display_url" : "nblo.gs/oVbMV"
      } ]
    },
    "geo" : {
    },
    "id_str" : "128574442619158528",
    "text" : "Giant flips the script on GM http://t.co/9sV6XjKg",
    "id" : 128574442619158528,
    "created_at" : "Mon Oct 24 20:51:50 +0000 2011",
    "user" : {
      "name" : "Bike League ",
      "screen_name" : "BikeLeague",
      "protected" : false,
      "id_str" : "25085215",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2535763440/43lymnprc1a5etd5bfk9_normal.jpeg",
      "id" : 25085215,
      "verified" : false
    }
  },
  "id" : 128575746548568064,
  "created_at" : "Mon Oct 24 20:57:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notimetorun",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128562779740323840",
  "text" : "starting my presentation for tomorrow and my numerical analysis project #notimetorun",
  "id" : 128562779740323840,
  "created_at" : "Mon Oct 24 20:05:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkaboutthatone",
      "indices" : [ 99, 117 ]
    }, {
      "text" : "deep",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128493421966004224",
  "text" : "a conditionally convergent series can be rearranged to add up to ANY real number (and infinity)... #thinkaboutthatone #deep",
  "id" : 128493421966004224,
  "created_at" : "Mon Oct 24 15:29:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hustlerproblems",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128312826036109312",
  "text" : "excited to sleep in till 7am tomorrow #hustlerproblems",
  "id" : 128312826036109312,
  "created_at" : "Mon Oct 24 03:32:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 0, 14 ],
      "id_str" : "326870950",
      "id" : 326870950
    }, {
      "name" : "William D French Jr",
      "screen_name" : "MechE_Hokie",
      "indices" : [ 55, 67 ],
      "id_str" : "219863324",
      "id" : 219863324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128305341841686528",
  "geo" : {
  },
  "id_str" : "128306012036939776",
  "in_reply_to_user_id" : 326870950,
  "text" : "@BlackSheep_VT hahah i like it! correct answer goes to @MechE_Hokie: Diwali, festival of lights. It's a Hindu holiday",
  "id" : 128306012036939776,
  "in_reply_to_status_id" : 128305341841686528,
  "created_at" : "Mon Oct 24 03:05:11 +0000 2011",
  "in_reply_to_screen_name" : "BlackSheep_VT",
  "in_reply_to_user_id_str" : "326870950",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 0, 14 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/4ZwLDxa0",
      "expanded_url" : "http://andyreagan.com/wp-content/uploads/2010/06/017.jpg",
      "display_url" : "andyreagan.com/wp-content/upl…"
    } ]
  },
  "in_reply_to_status_id_str" : "128302312497229824",
  "geo" : {
  },
  "id_str" : "128305146819125248",
  "in_reply_to_user_id" : 326870950,
  "text" : "@BlackSheep_VT hard to imagine in blacksburg (possible even?) but think kansas: http://t.co/4ZwLDxa0",
  "id" : 128305146819125248,
  "in_reply_to_status_id" : 128302312497229824,
  "created_at" : "Mon Oct 24 03:01:45 +0000 2011",
  "in_reply_to_screen_name" : "BlackSheep_VT",
  "in_reply_to_user_id_str" : "326870950",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 0, 14 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128299228396134401",
  "geo" : {
  },
  "id_str" : "128300595231727616",
  "in_reply_to_user_id" : 326870950,
  "text" : "@BlackSheep_VT ha beats me...",
  "id" : 128300595231727616,
  "in_reply_to_status_id" : 128299228396134401,
  "created_at" : "Mon Oct 24 02:43:40 +0000 2011",
  "in_reply_to_screen_name" : "BlackSheep_VT",
  "in_reply_to_user_id_str" : "326870950",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128299319173464066",
  "text" : "@Tri_Gardner yo, I left my phone there, could you bring it to the cycling meeting tomorrow? or if you drove drop by my house (523 jackson)",
  "id" : 128299319173464066,
  "created_at" : "Mon Oct 24 02:38:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 35, 44 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 58, 67 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 68, 80 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128299160758792192",
  "text" : "back to the books after some MNF w @Run_Rudy @Tri_Gardner @Run_Rudy @OGfromtheOB",
  "id" : 128299160758792192,
  "created_at" : "Mon Oct 24 02:37:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128280076113559552",
  "geo" : {
  },
  "id_str" : "128299033038028802",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris wow that's awesome",
  "id" : 128299033038028802,
  "in_reply_to_status_id" : 128280076113559552,
  "created_at" : "Mon Oct 24 02:37:27 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Sheep VT",
      "screen_name" : "BlackSheep_VT",
      "indices" : [ 0, 14 ],
      "id_str" : "326870950",
      "id" : 326870950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128255665528516608",
  "geo" : {
  },
  "id_str" : "128298881174863872",
  "in_reply_to_user_id" : 326870950,
  "text" : "@BlackSheep_VT homecoming?",
  "id" : 128298881174863872,
  "in_reply_to_status_id" : 128255665528516608,
  "created_at" : "Mon Oct 24 02:36:51 +0000 2011",
  "in_reply_to_screen_name" : "BlackSheep_VT",
  "in_reply_to_user_id_str" : "326870950",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/EhzQa7AR",
      "expanded_url" : "http://bit.ly/oeLI9y",
      "display_url" : "bit.ly/oeLI9y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128248447437520897",
  "text" : "fun, easy-ish 13 mile trail run (as easy as running up the Beast can be) http://t.co/EhzQa7AR",
  "id" : 128248447437520897,
  "created_at" : "Sun Oct 23 23:16:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "behindtherabbit",
      "screen_name" : "behindtherabbit",
      "indices" : [ 0, 16 ],
      "id_str" : "14315146",
      "id" : 14315146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128228823073427456",
  "geo" : {
  },
  "id_str" : "128242879146622976",
  "in_reply_to_user_id" : 14315146,
  "text" : "@behindtherabbit that's why you go up Beast, down Snake! I must've just missed you actually",
  "id" : 128242879146622976,
  "in_reply_to_status_id" : 128228823073427456,
  "created_at" : "Sun Oct 23 22:54:19 +0000 2011",
  "in_reply_to_screen_name" : "behindtherabbit",
  "in_reply_to_user_id_str" : "14315146",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 99, 106 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 107, 114 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "forreal",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "neverheardofit",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128188606954225664",
  "text" : "just pulled up behind a car with a \"suny college at brockport\" sticker... #forreal #neverheardofit @sspis1 @DZdan1",
  "id" : 128188606954225664,
  "created_at" : "Sun Oct 23 19:18:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "128187923844694017",
  "text" : "real analysis conquered, time to hit the trails! warmed up to be a nice day",
  "id" : 128187923844694017,
  "created_at" : "Sun Oct 23 19:15:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/FMzW0HVm",
      "expanded_url" : "http://www.youtube.com/watch?v=6J7bqMUaBE4",
      "display_url" : "youtube.com/watch?v=6J7bqM…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128091797552513024",
  "text" : "been up since 6:30 this morning...why? to shoot a time lapse of the sunrise over Paris Mtn! Overexposed it though http://t.co/FMzW0HVm",
  "id" : 128091797552513024,
  "created_at" : "Sun Oct 23 12:53:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 0, 7 ],
      "id_str" : "282847130",
      "id" : 282847130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/FMzW0HVm",
      "expanded_url" : "http://www.youtube.com/watch?v=6J7bqMUaBE4",
      "display_url" : "youtube.com/watch?v=6J7bqM…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "128091576563023872",
  "in_reply_to_user_id" : 282847130,
  "text" : "@sspis1 i tried my hand at some time lapse photography: http://t.co/FMzW0HVm",
  "id" : 128091576563023872,
  "created_at" : "Sun Oct 23 12:53:06 +0000 2011",
  "in_reply_to_screen_name" : "sspis1",
  "in_reply_to_user_id_str" : "282847130",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127591347459850240",
  "geo" : {
  },
  "id_str" : "127956921335545856",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e haha veryyy distantly, we've traced back to the same county in ireland lol",
  "id" : 127956921335545856,
  "in_reply_to_status_id" : 127591347459850240,
  "created_at" : "Sun Oct 23 03:58:02 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 0, 8 ],
      "id_str" : "86132431",
      "id" : 86132431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itbetterbe",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127953986199367680",
  "geo" : {
  },
  "id_str" : "127956507609403392",
  "in_reply_to_user_id" : 86132431,
  "text" : "@bricec5 yeah out at rivermill :( it'll be back #itbetterbe",
  "id" : 127956507609403392,
  "in_reply_to_status_id" : 127953986199367680,
  "created_at" : "Sun Oct 23 03:56:23 +0000 2011",
  "in_reply_to_screen_name" : "bricec5",
  "in_reply_to_user_id_str" : "86132431",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lefthandmilkstout",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127947044101951488",
  "text" : "#lefthandmilkstout tapped out!?",
  "id" : 127947044101951488,
  "created_at" : "Sun Oct 23 03:18:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127937006595612672",
  "text" : "wheel doctor at your service! got daniel's new spoke in, good luck to him on his 57mi ride tomorrow",
  "id" : 127937006595612672,
  "created_at" : "Sun Oct 23 02:38:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127926002339938304",
  "text" : "stadium cleaned. conclusion: humans are gross.",
  "id" : 127926002339938304,
  "created_at" : "Sun Oct 23 01:55:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 72, 84 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127893915176144896",
  "text" : "3 days off and my legs had a mind of their own...7 7:30's! goin to help @VTTriathlon fundraise",
  "id" : 127893915176144896,
  "created_at" : "Sat Oct 22 23:47:40 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hokies",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127864463910117376",
  "text" : "back in town. good job #hokies on some quick scores so i can run at ease!",
  "id" : 127864463910117376,
  "created_at" : "Sat Oct 22 21:50:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/3Ij0SDjN",
      "expanded_url" : "http://twitpic.com/745jqo",
      "display_url" : "twitpic.com/745jqo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "127789030275416064",
  "text" : "solid conference, peace Knoxville! http://t.co/3Ij0SDjN",
  "id" : 127789030275416064,
  "created_at" : "Sat Oct 22 16:50:53 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127774252878409728",
  "text" : "presentation went well this morning!! lunch time and then back to #blacksburg",
  "id" : 127774252878409728,
  "created_at" : "Sat Oct 22 15:52:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "travelling",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127708120007983104",
  "text" : "met a couple here for a golf tournament, girl for a wedding, and thousands for knoxville's race for the cure this morning #travelling",
  "id" : 127708120007983104,
  "created_at" : "Sat Oct 22 11:29:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 0, 14 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127596708350799873",
  "geo" : {
  },
  "id_str" : "127601019206119425",
  "in_reply_to_user_id" : 26010551,
  "text" : "@Thundercoffer twitpic this hat!",
  "id" : 127601019206119425,
  "in_reply_to_status_id" : 127596708350799873,
  "created_at" : "Sat Oct 22 04:23:48 +0000 2011",
  "in_reply_to_screen_name" : "Thundercoffer",
  "in_reply_to_user_id_str" : "26010551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brunner",
      "screen_name" : "jdbrunnr",
      "indices" : [ 83, 92 ],
      "id_str" : "25850390",
      "id" : 25850390
    }, {
      "name" : "Canaan Coppola",
      "screen_name" : "canaanco",
      "indices" : [ 93, 102 ],
      "id_str" : "322700889",
      "id" : 322700889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lame",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "vrazysecfootballfans",
      "indices" : [ 61, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127600875727368192",
  "text" : "apparently the whole town goes to away football games? #lame #vrazysecfootballfans @jdbrunnr @canaanco @iron_cycle",
  "id" : 127600875727368192,
  "created_at" : "Sat Oct 22 04:23:14 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 27, 38 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127377743800315904",
  "geo" : {
  },
  "id_str" : "127570462761955328",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e and not his nephew @andyreagan?",
  "id" : 127570462761955328,
  "in_reply_to_status_id" : 127377743800315904,
  "created_at" : "Sat Oct 22 02:22:23 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 0, 7 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 32, 39 ],
      "id_str" : "46970249",
      "id" : 46970249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127543637310574592",
  "in_reply_to_user_id" : 46970249,
  "text" : "@rkay21 and a happy birthday to @rkay21!! shenanigans will be happening tmrw when @iron_cyclone and i return!",
  "id" : 127543637310574592,
  "created_at" : "Sat Oct 22 00:35:47 +0000 2011",
  "in_reply_to_screen_name" : "rkay21",
  "in_reply_to_user_id_str" : "46970249",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127543004276850688",
  "text" : "solid poster session, time to check out dtown knoxville!",
  "id" : 127543004276850688,
  "created_at" : "Sat Oct 22 00:33:16 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwish",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127495079618289664",
  "text" : "there is a sam adams beer tasting starting in the next conference room!! #iwish",
  "id" : 127495079618289664,
  "created_at" : "Fri Oct 21 21:22:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NIMBioS",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127480469443981312",
  "text" : "great talks so far from Dr Carl Panetta and Dr John Jungck! #NIMBioS",
  "id" : 127480469443981312,
  "created_at" : "Fri Oct 21 20:24:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mustbeTN",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127413014235328512",
  "text" : "billboards for moonshine #mustbeTN",
  "id" : 127413014235328512,
  "created_at" : "Fri Oct 21 15:56:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127359969552105472",
  "text" : "off to Knoxville!!",
  "id" : 127359969552105472,
  "created_at" : "Fri Oct 21 12:25:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "indices" : [ 3, 17 ],
      "id_str" : "131853207",
      "id" : 131853207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127186120453787648",
  "text" : "RT @Fake_Dispatch: BREAKING: Gaddafi, bin Laden and Hussein walk into a bar.  The bartender says, \"It's kinda dead in here tonight.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "127183337528893440",
    "text" : "BREAKING: Gaddafi, bin Laden and Hussein walk into a bar.  The bartender says, \"It's kinda dead in here tonight.\"",
    "id" : 127183337528893440,
    "created_at" : "Fri Oct 21 00:44:05 +0000 2011",
    "user" : {
      "name" : "Fake Dispatch",
      "screen_name" : "Fake_Dispatch",
      "protected" : false,
      "id_str" : "131853207",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2013633039/fake-dispatch__1__normal.jpg",
      "id" : 131853207,
      "verified" : false
    }
  },
  "id" : 127186120453787648,
  "created_at" : "Fri Oct 21 00:55:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127155769094311937",
  "geo" : {
  },
  "id_str" : "127159412744916992",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT I like it!",
  "id" : 127159412744916992,
  "in_reply_to_status_id" : 127155769094311937,
  "created_at" : "Thu Oct 20 23:09:01 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127152963054616576",
  "geo" : {
  },
  "id_str" : "127153280546643968",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT haha it's true! (I can't speak to the success part yet haha)",
  "id" : 127153280546643968,
  "in_reply_to_status_id" : 127152963054616576,
  "created_at" : "Thu Oct 20 22:44:39 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alwaysmoretolearn",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127152967869673472",
  "text" : "at LaTeX 101 by Dr. Rogers, its a packed house!! #alwaysmoretolearn",
  "id" : 127152967869673472,
  "created_at" : "Thu Oct 20 22:43:24 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 49, 60 ],
      "id_str" : "21424637",
      "id" : 21424637
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 62, 78 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beingtall",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/TIZnxPPA",
      "expanded_url" : "http://ht.ly/7397e",
      "display_url" : "ht.ly/7397e"
    } ]
  },
  "geo" : {
  },
  "id_str" : "127143341522550787",
  "text" : "#beingtall for the win: http://t.co/TIZnxPPA via @bakadesuyo. @RumblinStumblin gotta read this",
  "id" : 127143341522550787,
  "created_at" : "Thu Oct 20 22:05:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 28, 35 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 36, 45 ],
      "id_str" : "204631321",
      "id" : 204631321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127141089772707840",
  "geo" : {
  },
  "id_str" : "127141853920362496",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice i wonder if @DZdan1 @DKnick88 have suits. we could have a wine and cheese party lol",
  "id" : 127141853920362496,
  "in_reply_to_status_id" : 127141089772707840,
  "created_at" : "Thu Oct 20 21:59:14 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127139053677191169",
  "geo" : {
  },
  "id_str" : "127140432340713472",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice yeah \"tailored fit\". i'm a 39 long haha skinny guy",
  "id" : 127140432340713472,
  "in_reply_to_status_id" : 127139053677191169,
  "created_at" : "Thu Oct 20 21:53:35 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "127138431770959872",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice just bought my first suit, feel like you would be proud lol",
  "id" : 127138431770959872,
  "created_at" : "Thu Oct 20 21:45:38 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 14, 30 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "professional",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/OEWexipA",
      "expanded_url" : "http://twitpic.com/737zp4",
      "display_url" : "twitpic.com/737zp4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "127109224957358080",
  "text" : "#professional @RumblinStumblin http://t.co/OEWexipA",
  "id" : 127109224957358080,
  "created_at" : "Thu Oct 20 19:49:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "enoughprocrastinationalready",
      "indices" : [ 66, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126748399159619584",
  "text" : "could rent a bike for the same price as a car in Madison, WI #win #enoughprocrastinationalready",
  "id" : 126748399159619584,
  "created_at" : "Wed Oct 19 19:55:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldman",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "officially",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126745923106775040",
  "text" : "I thought the only milestone left was legally renting cars when I turned 25...that too passed when I turned 21! #oldman #officially",
  "id" : 126745923106775040,
  "created_at" : "Wed Oct 19 19:45:57 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126745536253538304",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin over 21 can rent cars, it's just $10/day extra than over 25",
  "id" : 126745536253538304,
  "created_at" : "Wed Oct 19 19:44:25 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "indices" : [ 3, 14 ],
      "id_str" : "16353686",
      "id" : 16353686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126719144379957248",
  "text" : "RT @angryasian: For the last time, folks, road/CX brakes aren't about more power; it's about better control. Tire traction will aways be ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "126718725352198144",
    "text" : "For the last time, folks, road/CX brakes aren't about more power; it's about better control. Tire traction will aways be limiting factor.",
    "id" : 126718725352198144,
    "created_at" : "Wed Oct 19 17:57:53 +0000 2011",
    "user" : {
      "name" : "James Huang",
      "screen_name" : "angryasian",
      "protected" : false,
      "id_str" : "16353686",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/904017577/105073547_normal.jpg",
      "id" : 16353686,
      "verified" : false
    }
  },
  "id" : 126719144379957248,
  "created_at" : "Wed Oct 19 17:59:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    }, {
      "name" : "USA Cycling",
      "screen_name" : "usacycling",
      "indices" : [ 20, 31 ],
      "id_str" : "18855629",
      "id" : 18855629
    }, {
      "name" : "USAC Collegiate",
      "screen_name" : "USACcollegiate",
      "indices" : [ 48, 63 ],
      "id_str" : "63491769",
      "id" : 63491769
    }, {
      "name" : "Angel Fire Resort",
      "screen_name" : "AngelFireResort",
      "indices" : [ 120, 136 ],
      "id_str" : "26343212",
      "id" : 26343212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollNats",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/b3nO0eQL",
      "expanded_url" : "http://bit.ly/pAlOLf",
      "display_url" : "bit.ly/pAlOLf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126717346533478400",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson RT @usacycling Course maps for @USACcollegiate MTB Nats are now posted: http://t.co/b3nO0eQL #CollNats @angelfireresort",
  "id" : 126717346533478400,
  "created_at" : "Wed Oct 19 17:52:24 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldbetch",
      "indices" : [ 11, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126711495970131970",
  "geo" : {
  },
  "id_str" : "126717256456617984",
  "in_reply_to_user_id" : 49206838,
  "text" : "@jcreichel #firstworldbetch lol",
  "id" : 126717256456617984,
  "in_reply_to_status_id" : 126711495970131970,
  "created_at" : "Wed Oct 19 17:52:02 +0000 2011",
  "in_reply_to_screen_name" : "jill_brandy",
  "in_reply_to_user_id_str" : "49206838",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126695893155057664",
  "text" : "needs to get a suit!",
  "id" : 126695893155057664,
  "created_at" : "Wed Oct 19 16:27:09 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 40, 49 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126505535053893632",
  "text" : "unless the only oatmeal left is banana \"@Run_Rudy: around 11pm, I start looking fwrd to the following morning for the sole purpose of brkfst",
  "id" : 126505535053893632,
  "created_at" : "Wed Oct 19 03:50:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 10, 22 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 31, 39 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sleep",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "yess",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "finally",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126503947258179584",
  "text" : "impromptu @VTTriathlon meeting @Moes_HQ was a success! finished my work and sleeping in till 8am tmrw?! #sleep #yess #finally",
  "id" : 126503947258179584,
  "created_at" : "Wed Oct 19 03:44:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Danforth",
      "screen_name" : "ChrisDanforth",
      "indices" : [ 60, 74 ],
      "id_str" : "301579658",
      "id" : 301579658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/CUk4rP7W",
      "expanded_url" : "http://bit.ly/4Ij9c",
      "display_url" : "bit.ly/4Ij9c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126489702126718977",
  "text" : "wow, really neat tool. added to my LaTeX tutorial page! \"RT @ChrisDanforth Thank you Detexify http://t.co/CUk4rP7W\"",
  "id" : 126489702126718977,
  "created_at" : "Wed Oct 19 02:47:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 26, 35 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 36, 46 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 47, 59 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 112, 120 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/r4F9QlxR",
      "expanded_url" : "http://bit.ly/n8iyoj",
      "display_url" : "bit.ly/n8iyoj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126451639912640512",
  "text" : "super awesome trail run w @Run_Rudy @WyattLoud @OGfromtheOB! Garmin Connect - Details: http://t.co/r4F9QlxR via @AddThis",
  "id" : 126451639912640512,
  "created_at" : "Wed Oct 19 00:16:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126424998436020224",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy headed your way now",
  "id" : 126424998436020224,
  "created_at" : "Tue Oct 18 22:30:43 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 0, 9 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126418999608213506",
  "geo" : {
  },
  "id_str" : "126422838994403329",
  "in_reply_to_user_id" : 342318092,
  "text" : "@Run_Rudy watching then headed to your place!",
  "id" : 126422838994403329,
  "in_reply_to_status_id" : 126418999608213506,
  "created_at" : "Tue Oct 18 22:22:08 +0000 2011",
  "in_reply_to_screen_name" : "Run_Rudy",
  "in_reply_to_user_id_str" : "342318092",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 1, 13 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 25, 34 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 35, 45 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "USA Triathlon",
      "screen_name" : "usatriathlon",
      "indices" : [ 65, 78 ],
      "id_str" : "14630047",
      "id" : 14630047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/cSmaOXAM",
      "expanded_url" : "http://twitpic.com/72b9sm",
      "display_url" : "twitpic.com/72b9sm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126385143190523904",
  "text" : ".@vttriathlon's very own @Run_Rudy @WyattLoud in the most recent @usatriathlon magazine!! (p78) http://t.co/cSmaOXAM",
  "id" : 126385143190523904,
  "created_at" : "Tue Oct 18 19:52:20 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126193932731285505",
  "geo" : {
  },
  "id_str" : "126351381333426176",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e solving cubics, quartics like the italians. i love the course. are you coming through bburg today??",
  "id" : 126351381333426176,
  "in_reply_to_status_id" : 126193932731285505,
  "created_at" : "Tue Oct 18 17:38:11 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homecomingproblems",
      "indices" : [ 70, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126333349336854528",
  "text" : "the full force of greek obnoxiousness has been unleashed on vt campus #homecomingproblems",
  "id" : 126333349336854528,
  "created_at" : "Tue Oct 18 16:26:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126168926760611840",
  "text" : "well that history of math took longer than expected! 5.5hrs of sleep before 8AM meeting",
  "id" : 126168926760611840,
  "created_at" : "Tue Oct 18 05:33:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 96, 104 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/eNpnL9tR",
      "expanded_url" : "http://bit.ly/nn9AqD",
      "display_url" : "bit.ly/nn9AqD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126119998132469760",
  "text" : "fun Night Coal Miner's Loop by andyreagan at Garmin Connect - Details: http://t.co/eNpnL9tR via @AddThis",
  "id" : 126119998132469760,
  "created_at" : "Tue Oct 18 02:18:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 31, 43 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 103, 114 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126069979241127936",
  "text" : "how about the TOUGH DAWG?! \"RT @runfasteraw Just signed up for the Brush Mountain Breakdown (16 miler) @andyreagan\"",
  "id" : 126069979241127936,
  "created_at" : "Mon Oct 17 22:59:59 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 15, 31 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 32, 41 ],
      "id_str" : "70117835",
      "id" : 70117835
    }, {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 42, 53 ],
      "id_str" : "68794179",
      "id" : 68794179
    }, {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 54, 61 ],
      "id_str" : "228268171",
      "id" : 228268171
    }, {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 62, 77 ],
      "id_str" : "44471444",
      "id" : 44471444
    }, {
      "name" : "Daniel Knickerbocker",
      "screen_name" : "DKnick88",
      "indices" : [ 78, 87 ],
      "id_str" : "204631321",
      "id" : 204631321
    }, {
      "name" : "Sam Spisiak",
      "screen_name" : "sspis1",
      "indices" : [ 88, 95 ],
      "id_str" : "282847130",
      "id" : 282847130
    }, {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 96, 108 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "126058415616307200",
  "text" : "just signed up @RumblinStumblin @dmreagan @kreagannet @DZdan1 @ryandelgiudice @DKnick88 @sspis1 @runfasteraw for txt marathon updates!!",
  "id" : 126058415616307200,
  "created_at" : "Mon Oct 17 22:14:02 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 37, 44 ],
      "id_str" : "15324722",
      "id" : 15324722
    }, {
      "name" : "New Belgium Brewing",
      "screen_name" : "newbelgium",
      "indices" : [ 57, 68 ],
      "id_str" : "18057459",
      "id" : 18057459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/zLSC2TuU",
      "expanded_url" : "http://twitpic.com/71vzt9",
      "display_url" : "twitpic.com/71vzt9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "126041649632649216",
  "text" : "new compass crowding old the old one @Garmin. Along with @newbelgium on the stem, of course! http://t.co/zLSC2TuU",
  "id" : 126041649632649216,
  "created_at" : "Mon Oct 17 21:07:25 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 18, 34 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/P3aAQMoc",
      "expanded_url" : "http://twitpic.com/71spjf",
      "display_url" : "twitpic.com/71spjf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "125968553491968000",
  "text" : "the D2 McGangbang @JacobnAndersson http://t.co/P3aAQMoc",
  "id" : 125968553491968000,
  "created_at" : "Mon Oct 17 16:16:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 52, 64 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hwtimeallnight",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125763141412982784",
  "text" : "individually I took 2nd place in Men's B to our own @runfasteraw. probably less than 5 points separated us (400 to 399?). #hwtimeallnight",
  "id" : 125763141412982784,
  "created_at" : "Mon Oct 17 02:40:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 3, 13 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dom",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125762754379395072",
  "text" : "RT @VTCycling: we won the ACCC MTB Championship this weekend!! And took 1st Men's A, 1-2-3 Men's B, 1st Men's C, and 1st Women's A! #dom ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "domination",
        "indices" : [ 117, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "125762441673060352",
    "text" : "we won the ACCC MTB Championship this weekend!! And took 1st Men's A, 1-2-3 Men's B, 1st Men's C, and 1st Women's A! #domination",
    "id" : 125762441673060352,
    "created_at" : "Mon Oct 17 02:37:57 +0000 2011",
    "user" : {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "protected" : false,
      "id_str" : "117782776",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/720825145/vt_normal.JPG",
      "id" : 117782776,
      "verified" : false
    }
  },
  "id" : 125762754379395072,
  "created_at" : "Mon Oct 17 02:39:11 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 99, 109 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125761850544635904",
  "text" : "back in Blacksburg after a fun, and final weekend of MTB racing! We won the ACCC MTB Championship! @vtcycling",
  "id" : 125761850544635904,
  "created_at" : "Mon Oct 17 02:35:36 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bettersafethansorry",
      "indices" : [ 21, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125344391161319425",
  "text" : "clean bill of health #bettersafethansorry (better than clean really, bp 110/65)",
  "id" : 125344391161319425,
  "created_at" : "Sat Oct 15 22:56:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodnews",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125339353642831872",
  "text" : "no concussion #goodnews",
  "id" : 125339353642831872,
  "created_at" : "Sat Oct 15 22:36:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125331901388046336",
  "text" : "maybe i should pick up knitting...or just stick to the events that dont involve racing jumps down ski slopes",
  "id" : 125331901388046336,
  "created_at" : "Sat Oct 15 22:07:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 65, 75 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125329077723873280",
  "text" : "got 4th in the XC this morning and 2nd in the ST this afternoon! @vtcycling dominating! but crashed in downhill, quick ER visit to be safe",
  "id" : 125329077723873280,
  "created_at" : "Sat Oct 15 21:55:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125188925131202561",
  "text" : "40deg and extremely windy on top of Wisp, time to attempt to warm up on the bike!",
  "id" : 125188925131202561,
  "created_at" : "Sat Oct 15 12:39:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vtcycling",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "125021574976901121",
  "text" : "a moon rainbow!! woah #vtcycling",
  "id" : 125021574976901121,
  "created_at" : "Sat Oct 15 01:34:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efficiency",
      "indices" : [ 57, 68 ]
    }, {
      "text" : "not",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124992823941545984",
  "text" : "shopping for the weekends food in walmart with 25 people #efficiency #not",
  "id" : 124992823941545984,
  "created_at" : "Fri Oct 14 23:39:46 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 77, 87 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/fZp8LD4d",
      "expanded_url" : "http://twitpic.com/70c0oa",
      "display_url" : "twitpic.com/70c0oa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124977494150488064",
  "text" : "put together my new Garmin quick release/ bike mount! almost to harrisonburg @VTCycling http://t.co/fZp8LD4d",
  "id" : 124977494150488064,
  "created_at" : "Fri Oct 14 22:38:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124973834200825856",
  "geo" : {
  },
  "id_str" : "124974020083978240",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e ill be around on Tuesday yeah!",
  "id" : 124974020083978240,
  "in_reply_to_status_id" : 124973834200825856,
  "created_at" : "Fri Oct 14 22:25:02 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124948113050959872",
  "geo" : {
  },
  "id_str" : "124973446747795456",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e i knowwww! why did you pick the weekend of conf champs?!",
  "id" : 124973446747795456,
  "in_reply_to_status_id" : 124948113050959872,
  "created_at" : "Fri Oct 14 22:22:46 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 0, 13 ],
      "id_str" : "787544966",
      "id" : 787544966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124945288526962689",
  "geo" : {
  },
  "id_str" : "124973092572368896",
  "in_reply_to_user_id" : 112279071,
  "text" : "@laurentappan haha was she serious? these girls were really interested...",
  "id" : 124973092572368896,
  "in_reply_to_status_id" : 124945288526962689,
  "created_at" : "Fri Oct 14 22:21:21 +0000 2011",
  "in_reply_to_screen_name" : "ltapp11",
  "in_reply_to_user_id_str" : "112279071",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "random",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124932362869026816",
  "text" : "pumping up a tire in the front yard, girls in car ask me who is renting this house next year. a house tour later, got some digits #random",
  "id" : 124932362869026816,
  "created_at" : "Fri Oct 14 19:39:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/BHgE2yIa",
      "expanded_url" : "http://twitpic.com/709ry7",
      "display_url" : "twitpic.com/709ry7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124931388595126273",
  "text" : "new freewheel on the single speed, 44-18 sooo much better in #blacksburg than 46-16 http://t.co/BHgE2yIa",
  "id" : 124931388595126273,
  "created_at" : "Fri Oct 14 19:35:38 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 3, 18 ],
      "id_str" : "208127016",
      "id" : 208127016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124916496580354048",
  "text" : "RT @BRMSBlacksburg: Did you run in the Mtn Top Trot at @mtnlake & not get your Tshirt? They have arrived here for pick up http://t.co/HL ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitpic.com\" rel=\"nofollow\">Twitpic</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http://t.co/HLBo5Bpu",
        "expanded_url" : "http://twitpic.com/7079v4",
        "display_url" : "twitpic.com/7079v4"
      } ]
    },
    "geo" : {
    },
    "id_str" : "124883233526644736",
    "text" : "Did you run in the Mtn Top Trot at @mtnlake & not get your Tshirt? They have arrived here for pick up http://t.co/HLBo5Bpu",
    "id" : 124883233526644736,
    "created_at" : "Fri Oct 14 16:24:17 +0000 2011",
    "user" : {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "protected" : false,
      "id_str" : "208127016",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1305562262/New_Image_normal.JPG",
      "id" : 208127016,
      "verified" : false
    }
  },
  "id" : 124916496580354048,
  "created_at" : "Fri Oct 14 18:36:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chilichallenge",
      "indices" : [ 5, 20 ]
    }, {
      "text" : "champion",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/ZTuGnx65",
      "expanded_url" : "http://twitpic.com/7091c0",
      "display_url" : "twitpic.com/7091c0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124916337561710594",
  "text" : "2011 #chilichallenge #champion http://t.co/ZTuGnx65",
  "id" : 124916337561710594,
  "created_at" : "Fri Oct 14 18:35:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 40, 52 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124639240243003393",
  "text" : "farm ride was great, joined by Codu and @runfasteraw! laundry in, stopped at the co-op, pickin up pasta to make dinner then hw jam",
  "id" : 124639240243003393,
  "created_at" : "Fri Oct 14 00:14:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 0, 9 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124617267957874688",
  "geo" : {
  },
  "id_str" : "124619225858969600",
  "in_reply_to_user_id" : 70117835,
  "text" : "@dmreagan i've been to their original brew pub! it's in rehoboth beach, DE. they were the brewery featured in that movie \"beer wars\"",
  "id" : 124619225858969600,
  "in_reply_to_status_id" : 124617267957874688,
  "created_at" : "Thu Oct 13 22:55:13 +0000 2011",
  "in_reply_to_screen_name" : "dmreagan",
  "in_reply_to_user_id_str" : "70117835",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 11, 23 ],
      "id_str" : "70417462",
      "id" : 70417462
    }, {
      "name" : "Justin Morrison",
      "screen_name" : "jpmor06",
      "indices" : [ 98, 106 ],
      "id_str" : "178447765",
      "id" : 178447765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124583141661868034",
  "text" : "aligned by @LeeRMatthis and as ready as ill ever be for the fabled 5X Farm! this ride inspired by @jpmor06, hope OCS is going well for him",
  "id" : 124583141661868034,
  "created_at" : "Thu Oct 13 20:31:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chilichallenge",
      "indices" : [ 28, 43 ]
    }, {
      "text" : "capsaicin",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124522120058376192",
  "text" : "day four, turnin up da heat #chilichallenge #capsaicin",
  "id" : 124522120058376192,
  "created_at" : "Thu Oct 13 16:29:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 10, 17 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Brooks Running",
      "screen_name" : "brooksrunning",
      "indices" : [ 19, 33 ],
      "id_str" : "25138463",
      "id" : 25138463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tip",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "advice",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "running",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/XVYxW32K",
      "expanded_url" : "http://talk.brooksrunning.com/2011/10/13/5-tips-for-running-your-first-half-marathon/",
      "display_url" : "talk.brooksrunning.com/2011/10/13/5-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124521633519112192",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT @rkay21 \"@brooksrunning: 5 Tips for Running Your First Half-Marathon | Brooks Blog http://t.co/XVYxW32K #tip #advice #running\"",
  "id" : 124521633519112192,
  "created_at" : "Thu Oct 13 16:27:25 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Matthis, DC",
      "screen_name" : "LeeRMatthis",
      "indices" : [ 0, 12 ],
      "id_str" : "70417462",
      "id" : 70417462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124332149242462208",
  "in_reply_to_user_id" : 70417462,
  "text" : "@LeeRMatthis expect a visit from yours truly at the duck pond tomorrow!",
  "id" : 124332149242462208,
  "created_at" : "Thu Oct 13 03:54:29 +0000 2011",
  "in_reply_to_screen_name" : "LeeRMatthis",
  "in_reply_to_user_id_str" : "70417462",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ithinknot",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/4hnD49MZ",
      "expanded_url" : "http://twitpic.com/6zh2bm",
      "display_url" : "twitpic.com/6zh2bm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124294397222326272",
  "text" : "does it get any better? #ithinknot http://t.co/4hnD49MZ",
  "id" : 124294397222326272,
  "created_at" : "Thu Oct 13 01:24:28 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124266458732699648",
  "text" : "over the ridge, into the golden sunset. switchback down the mountain, a brilliant orange and red blaze",
  "id" : 124266458732699648,
  "created_at" : "Wed Oct 12 23:33:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124244341358206976",
  "text" : "great meeting w Julia abt this semesters research, time to hit the trails before faith sharing! up farm we go",
  "id" : 124244341358206976,
  "created_at" : "Wed Oct 12 22:05:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124217146669670401",
  "text" : "got a job interview :-O",
  "id" : 124217146669670401,
  "created_at" : "Wed Oct 12 20:17:30 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124212595602358272",
  "geo" : {
  },
  "id_str" : "124213847224631296",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT okay cool, i'll probs see you out there. print out that map and take one w you!",
  "id" : 124213847224631296,
  "in_reply_to_status_id" : 124212595602358272,
  "created_at" : "Wed Oct 12 20:04:23 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124201531946958848",
  "geo" : {
  },
  "id_str" : "124202281779470336",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs sorta? hard to ever say you're ready to run 26 miles at 7:30min/mi",
  "id" : 124202281779470336,
  "in_reply_to_status_id" : 124201531946958848,
  "created_at" : "Wed Oct 12 19:18:26 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124198421509844992",
  "geo" : {
  },
  "id_str" : "124201341655592960",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs 30 days, 16 hours, 45 min, and 23sec. i have a countdown on my desktop lol. so soon!",
  "id" : 124201341655592960,
  "in_reply_to_status_id" : 124198421509844992,
  "created_at" : "Wed Oct 12 19:14:42 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124200138821476352",
  "geo" : {
  },
  "id_str" : "124201026201980928",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT hahahah i really should've added tots. trail running tonight?",
  "id" : 124201026201980928,
  "in_reply_to_status_id" : 124200138821476352,
  "created_at" : "Wed Oct 12 19:13:26 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/giPAAB8G",
      "expanded_url" : "http://www.fs.fed.us/outernet/r8/gwj/easterndivide/recreation/hiking/images/2007-poverty-lg.jpg",
      "display_url" : "fs.fed.us/outernet/r8/gw…"
    } ]
  },
  "in_reply_to_status_id_str" : "124192891194183680",
  "geo" : {
  },
  "id_str" : "124194619092242432",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs i've been spending all my free time here lol: http://t.co/giPAAB8G",
  "id" : 124194619092242432,
  "in_reply_to_status_id" : 124192891194183680,
  "created_at" : "Wed Oct 12 18:47:59 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124192028778184707",
  "geo" : {
  },
  "id_str" : "124192598335303681",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs i thought it was just supposed to be ironic, because of the total and how i felt the three times i watched it",
  "id" : 124192598335303681,
  "in_reply_to_status_id" : 124192028778184707,
  "created_at" : "Wed Oct 12 18:39:57 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/8ItHXEod",
      "expanded_url" : "http://andyreagan.com/wp-content/uploads/2011/10/2007-poverty-lg_expanded.jpg",
      "display_url" : "andyreagan.com/wp-content/upl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124191272356417536",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT I expanded it when I got home, maybe this makes more sense lol http://t.co/8ItHXEod",
  "id" : 124191272356417536,
  "created_at" : "Wed Oct 12 18:34:41 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "richmondmarathon",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "124146285900079105",
  "text" : "counting down: 30 days and change till Richmond Marathon!! #richmondmarathon",
  "id" : 124146285900079105,
  "created_at" : "Wed Oct 12 15:35:55 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon dublin",
      "screen_name" : "shaydubbs",
      "indices" : [ 0, 10 ],
      "id_str" : "389499772",
      "id" : 389499772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124135272769269760",
  "geo" : {
  },
  "id_str" : "124145617932005378",
  "in_reply_to_user_id" : 389499772,
  "text" : "@shaydubbs bummer, maybe now you'll actually use it haha?",
  "id" : 124145617932005378,
  "in_reply_to_status_id" : 124135272769269760,
  "created_at" : "Wed Oct 12 15:33:16 +0000 2011",
  "in_reply_to_screen_name" : "shaydubbs",
  "in_reply_to_user_id_str" : "389499772",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DeLong",
      "screen_name" : "aJohnnyD",
      "indices" : [ 0, 9 ],
      "id_str" : "77300651",
      "id" : 77300651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124120375108964352",
  "geo" : {
  },
  "id_str" : "124142091390554113",
  "in_reply_to_user_id" : 77300651,
  "text" : "@aJohnnyD EPIC!",
  "id" : 124142091390554113,
  "in_reply_to_status_id" : 124120375108964352,
  "created_at" : "Wed Oct 12 15:19:15 +0000 2011",
  "in_reply_to_screen_name" : "aJohnnyD",
  "in_reply_to_user_id_str" : "77300651",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/giPAAB8G",
      "expanded_url" : "http://www.fs.fed.us/outernet/r8/gwj/easterndivide/recreation/hiking/images/2007-poverty-lg.jpg",
      "display_url" : "fs.fed.us/outernet/r8/gw…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "124141015429955584",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT check this out lol: http://t.co/giPAAB8G",
  "id" : 124141015429955584,
  "created_at" : "Wed Oct 12 15:14:59 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collegiate Times",
      "screen_name" : "CollegiateTimes",
      "indices" : [ 3, 19 ],
      "id_str" : "45960001",
      "id" : 45960001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/QZiuMtXj",
      "expanded_url" : "http://bit.ly/oVh6wU",
      "display_url" : "bit.ly/oVh6wU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123968747416465410",
  "text" : "RT @CollegiateTimes: The coffee pedalers http://t.co/QZiuMtXj",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http://t.co/QZiuMtXj",
        "expanded_url" : "http://bit.ly/oVh6wU",
        "display_url" : "bit.ly/oVh6wU"
      } ]
    },
    "geo" : {
    },
    "id_str" : "123967807380656128",
    "text" : "The coffee pedalers http://t.co/QZiuMtXj",
    "id" : 123967807380656128,
    "created_at" : "Wed Oct 12 03:46:43 +0000 2011",
    "user" : {
      "name" : "Collegiate Times",
      "screen_name" : "CollegiateTimes",
      "protected" : false,
      "id_str" : "45960001",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2559994692/xhtj16ss7b2q5d6rrb99_normal.png",
      "id" : 45960001,
      "verified" : false
    }
  },
  "id" : 123968747416465410,
  "created_at" : "Wed Oct 12 03:50:27 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Morrison",
      "screen_name" : "jpmor06",
      "indices" : [ 100, 108 ],
      "id_str" : "178447765",
      "id" : 178447765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughdawg",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123967771116711936",
  "text" : "next is to sign up for Rowdy Dawg XXC 36mi MTB race the day after, to compete for the \"Tough Dawg.\" @jpmor06 is the reigning #toughdawg",
  "id" : 123967771116711936,
  "created_at" : "Wed Oct 12 03:46:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excited",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "trailrunning",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/r6hfn5T5",
      "expanded_url" : "http://www.runaboutsports.com/",
      "display_url" : "runaboutsports.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123966557012500481",
  "text" : "signed up for the Brush Mountain Breakdown 16-miler today! #excited #trailrunning http://t.co/r6hfn5T5",
  "id" : 123966557012500481,
  "created_at" : "Wed Oct 12 03:41:45 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Barker",
      "screen_name" : "bakadesuyo",
      "indices" : [ 0, 11 ],
      "id_str" : "21424637",
      "id" : 21424637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123940980238983170",
  "geo" : {
  },
  "id_str" : "123945186614198272",
  "in_reply_to_user_id" : 21424637,
  "text" : "@bakadesuyo I think they should ride mountain bikes!",
  "id" : 123945186614198272,
  "in_reply_to_status_id" : 123940980238983170,
  "created_at" : "Wed Oct 12 02:16:49 +0000 2011",
  "in_reply_to_screen_name" : "bakadesuyo",
  "in_reply_to_user_id_str" : "21424637",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 4, 16 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 49, 61 ],
      "id_str" : "774471674",
      "id" : 774471674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/SdEsMVhS",
      "expanded_url" : "http://twitpic.com/6z15pk",
      "display_url" : "twitpic.com/6z15pk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123938843983482880",
  "text" : "new @VTTriathlon shirts are AWESOME! designed by @OGfromtheOB, nice job dude. Check 'em out: http://t.co/SdEsMVhS",
  "id" : 123938843983482880,
  "created_at" : "Wed Oct 12 01:51:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chilichallenge",
      "indices" : [ 8, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/zUJbUSCm",
      "expanded_url" : "http://twitpic.com/6yuin6",
      "display_url" : "twitpic.com/6yuin6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123797652075851778",
  "text" : "day two #chilichallenge http://t.co/zUJbUSCm",
  "id" : 123797652075851778,
  "created_at" : "Tue Oct 11 16:30:34 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pledge2Pedal",
      "screen_name" : "Pledge2Pedal",
      "indices" : [ 3, 16 ],
      "id_str" : "370447197",
      "id" : 370447197
    }, {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 26, 36 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pledge",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123573234623971328",
  "text" : "RT @Pledge2Pedal: thanks! @VTCycling, for hearing me out!  you all are awesome and look great in those wristbands!  stay tuned!  #Pledge ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Virginia Tech ",
        "screen_name" : "VTCycling",
        "indices" : [ 8, 18 ],
        "id_str" : "117782776",
        "id" : 117782776
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pledge2Pedal",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "123572355938258945",
    "text" : "thanks! @VTCycling, for hearing me out!  you all are awesome and look great in those wristbands!  stay tuned!  #Pledge2Pedal",
    "id" : 123572355938258945,
    "created_at" : "Tue Oct 11 01:35:20 +0000 2011",
    "user" : {
      "name" : "Pledge2Pedal",
      "screen_name" : "Pledge2Pedal",
      "protected" : false,
      "id_str" : "370447197",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2136572820/RSCN6859_normal.JPG",
      "id" : 370447197,
      "verified" : false
    }
  },
  "id" : 123573234623971328,
  "created_at" : "Tue Oct 11 01:38:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123567076882395137",
  "text" : "@Tri_Gardner just got your tweet, my phone is being slow this week... woulda brought you chips!",
  "id" : 123567076882395137,
  "created_at" : "Tue Oct 11 01:14:21 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 4, 14 ],
      "id_str" : "117782776",
      "id" : 117782776
    }, {
      "name" : "Moes Southwest Grill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 23, 31 ],
      "id_str" : "84075278",
      "id" : 84075278
    }, {
      "name" : "Will Massey",
      "screen_name" : "williamenium",
      "indices" : [ 34, 47 ],
      "id_str" : "25713870",
      "id" : 25713870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tradition",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123556628548165632",
  "text" : "pre @vtcycling meeting @moes_hq w @williamenium was excellent #tradition",
  "id" : 123556628548165632,
  "created_at" : "Tue Oct 11 00:32:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 12, 24 ],
      "id_str" : "66689453",
      "id" : 66689453
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 29, 38 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 107, 115 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/9KHdji2Q",
      "expanded_url" : "http://bit.ly/nDKj0a",
      "display_url" : "bit.ly/nDKj0a"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123482602295406592",
  "text" : "SAYG Loop w @runfasteraw and @run_rudy by andyreagan at Garmin Connect - Details: http://t.co/9KHdji2Q via @AddThis",
  "id" : 123482602295406592,
  "created_at" : "Mon Oct 10 19:38:41 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeMasi",
      "screen_name" : "Crispy__C",
      "indices" : [ 17, 27 ],
      "id_str" : "313762318",
      "id" : 313762318
    }, {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 63, 74 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "success",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123450836406898688",
  "geo" : {
  },
  "id_str" : "123481647730540545",
  "in_reply_to_user_id" : 313762318,
  "text" : "you bet I am! RT @Crispy__C D2 Chili Challenge Day 1: #success @andyreagan you doing it?",
  "id" : 123481647730540545,
  "in_reply_to_status_id" : 123450836406898688,
  "created_at" : "Mon Oct 10 19:34:53 +0000 2011",
  "in_reply_to_screen_name" : "Crispy__C",
  "in_reply_to_user_id_str" : "313762318",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 0, 16 ],
      "id_str" : "78184204",
      "id" : 78184204
    }, {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 17, 26 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123379115691737088",
  "in_reply_to_user_id" : 78184204,
  "text" : "@RumblinStumblin @dmreagan skype tonight 6pm? i wanna hear about how your trip went!",
  "id" : 123379115691737088,
  "created_at" : "Mon Oct 10 12:47:28 +0000 2011",
  "in_reply_to_screen_name" : "RumblinStumblin",
  "in_reply_to_user_id_str" : "78184204",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Finlon",
      "screen_name" : "joefinlon",
      "indices" : [ 3, 13 ],
      "id_str" : "20873549",
      "id" : 20873549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/3Vw9ScQv",
      "expanded_url" : "http://yfrog.com/g0ocnp",
      "display_url" : "yfrog.com/g0ocnp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "123240106961276928",
  "text" : "RT @joefinlon: I knew reading the Digg headlines would pay off. http://t.co/3Vw9ScQv",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/3Vw9ScQv",
        "expanded_url" : "http://yfrog.com/g0ocnp",
        "display_url" : "yfrog.com/g0ocnp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "123238226474450944",
    "text" : "I knew reading the Digg headlines would pay off. http://t.co/3Vw9ScQv",
    "id" : 123238226474450944,
    "created_at" : "Mon Oct 10 03:27:37 +0000 2011",
    "user" : {
      "name" : "Joe Finlon",
      "screen_name" : "joefinlon",
      "protected" : false,
      "id_str" : "20873549",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2887903177/8b819735dd4ce49e1f5dd22dfa6f0032_normal.jpeg",
      "id" : 20873549,
      "verified" : false
    }
  },
  "id" : 123240106961276928,
  "created_at" : "Mon Oct 10 03:35:05 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "123133091807117312",
  "text" : "back in #blacksburg. races today were sweet. WON the TT today!! *preliminary timing results though. waiting on the Super D times",
  "id" : 123133091807117312,
  "created_at" : "Sun Oct 09 20:29:51 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 1, 11 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122995570083241984",
  "text" : ".@vtcycling up early from some crazy nights and headed to Rocky Knob to race bikes!",
  "id" : 122995570083241984,
  "created_at" : "Sun Oct 09 11:23:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Wentzel",
      "screen_name" : "runfasteraw",
      "indices" : [ 65, 77 ],
      "id_str" : "66689453",
      "id" : 66689453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122857969229627393",
  "text" : "post-race Black Cat burrito was amazing, and a nice 7.5 run with @runfasteraw and Wilson exploring Boone's greenway system!",
  "id" : 122857969229627393,
  "created_at" : "Sun Oct 09 02:16:37 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Tappan",
      "screen_name" : "LaurenTappan",
      "indices" : [ 11, 24 ],
      "id_str" : "787544966",
      "id" : 787544966
    }, {
      "name" : "Ashley smith",
      "screen_name" : "ashleyy_smith",
      "indices" : [ 25, 39 ],
      "id_str" : "819931518",
      "id" : 819931518
    }, {
      "name" : "Ashley smith",
      "screen_name" : "ashleyy_smith",
      "indices" : [ 55, 69 ],
      "id_str" : "819931518",
      "id" : 819931518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122854515912343552",
  "geo" : {
  },
  "id_str" : "122857199428055040",
  "in_reply_to_user_id" : 70474456,
  "text" : "@bpolson89 @laurentappan @ashleyy_smith Happy Birthday @ashleyy_smith, and we'll drink dtown dry when im home for a weekend!!",
  "id" : 122857199428055040,
  "in_reply_to_status_id" : 122854515912343552,
  "created_at" : "Sun Oct 09 02:13:33 +0000 2011",
  "in_reply_to_screen_name" : "britty_kitty89",
  "in_reply_to_user_id_str" : "70474456",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frustrating",
      "indices" : [ 114, 126 ]
    }, {
      "text" : "thatsracing",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122743634146754560",
  "text" : "got 5th in the XC race, and had the ST race WON with a huge lead and 2 laps left...then my chain broke- extremely #frustrating #thatsracing",
  "id" : 122743634146754560,
  "created_at" : "Sat Oct 08 18:42:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122669085690576896",
  "text" : "beautiful fall mountain views from the highest town on the east coast: Beech Mtn! racing soon!",
  "id" : 122669085690576896,
  "created_at" : "Sat Oct 08 13:46:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foothills",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "yum",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/u6XzcqRX",
      "expanded_url" : "http://twitpic.com/6wq4l9",
      "display_url" : "twitpic.com/6wq4l9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "122477453812834304",
  "text" : "#foothills #yum http://t.co/u6XzcqRX",
  "id" : 122477453812834304,
  "created_at" : "Sat Oct 08 01:04:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech ",
      "screen_name" : "VTCycling",
      "indices" : [ 48, 58 ],
      "id_str" : "117782776",
      "id" : 117782776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mellowmushroom",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122456373299654659",
  "text" : "in Boone NC! #mellowmushroom for dinner, chyeah @vtcycling",
  "id" : 122456373299654659,
  "created_at" : "Fri Oct 07 23:40:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leftys MainSt Grille",
      "screen_name" : "LeftysGrille",
      "indices" : [ 16, 29 ],
      "id_str" : "108063856",
      "id" : 108063856
    }, {
      "name" : "Ruthie Kay",
      "screen_name" : "rkay21",
      "indices" : [ 32, 39 ],
      "id_str" : "46970249",
      "id" : 46970249
    }, {
      "name" : "Paul Vines",
      "screen_name" : "IronCyclone",
      "indices" : [ 40, 52 ],
      "id_str" : "349885460",
      "id" : 349885460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACCC",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122376500950482944",
  "text" : "excellent lunch @LeftysGrille w @rkay21 @IronCyclone! crankin some HW before heading to ASU to race MTB's #ACCC",
  "id" : 122376500950482944,
  "created_at" : "Fri Oct 07 18:23:26 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beatty",
      "screen_name" : "k8eb8e",
      "indices" : [ 0, 7 ],
      "id_str" : "26517690",
      "id" : 26517690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122365852212408320",
  "geo" : {
  },
  "id_str" : "122375557601165312",
  "in_reply_to_user_id" : 26517690,
  "text" : "@k8eb8e wahhh i won't be here!! leaving for WVU at 4 on friday for @vtcycing MTB Conference Championships",
  "id" : 122375557601165312,
  "in_reply_to_status_id" : 122365852212408320,
  "created_at" : "Fri Oct 07 18:19:41 +0000 2011",
  "in_reply_to_screen_name" : "k8eb8e",
  "in_reply_to_user_id_str" : "26517690",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Sherfy",
      "screen_name" : "RBSherfy",
      "indices" : [ 0, 9 ],
      "id_str" : "64328794",
      "id" : 64328794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122344088581320705",
  "geo" : {
  },
  "id_str" : "122375413149351936",
  "in_reply_to_user_id" : 64328794,
  "text" : "@RBSherfy thanks for the heads up. luckily, i'm not trying to weld it",
  "id" : 122375413149351936,
  "in_reply_to_status_id" : 122344088581320705,
  "created_at" : "Fri Oct 07 18:19:06 +0000 2011",
  "in_reply_to_screen_name" : "RBSherfy",
  "in_reply_to_user_id_str" : "64328794",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatcouldibeupto",
      "indices" : [ 104, 121 ]
    }, {
      "text" : "youllneverguess",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122340228429119488",
  "text" : "rent paid and picked up 2 10ftx2in, 4 10ftx3/4in lengths of electrical conduit, and a 1\" drillbit...hmm #whatcouldibeupto #youllneverguess",
  "id" : 122340228429119488,
  "created_at" : "Fri Oct 07 15:59:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 3, 18 ],
      "id_str" : "208127016",
      "id" : 208127016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacksburg",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122339600973824001",
  "text" : "RT @BRMSBlacksburg: sooo nice outside...must go outside!!! #blacksburg",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blacksburg",
        "indices" : [ 39, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "122336891847712770",
    "text" : "sooo nice outside...must go outside!!! #blacksburg",
    "id" : 122336891847712770,
    "created_at" : "Fri Oct 07 15:46:02 +0000 2011",
    "user" : {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "protected" : false,
      "id_str" : "208127016",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1305562262/New_Image_normal.JPG",
      "id" : 208127016,
      "verified" : false
    }
  },
  "id" : 122339600973824001,
  "created_at" : "Fri Oct 07 15:56:48 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Shields",
      "screen_name" : "SH13LDS21",
      "indices" : [ 0, 10 ],
      "id_str" : "73786966",
      "id" : 73786966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122085854364700672",
  "geo" : {
  },
  "id_str" : "122317842384289793",
  "in_reply_to_user_id" : 73786966,
  "text" : "@SH13LDS21 I don't remember that actually lol... funny though. give a brother a call sometime",
  "id" : 122317842384289793,
  "in_reply_to_status_id" : 122085854364700672,
  "created_at" : "Fri Oct 07 14:30:20 +0000 2011",
  "in_reply_to_screen_name" : "SH13LDS21",
  "in_reply_to_user_id_str" : "73786966",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Andersson",
      "screen_name" : "JacobnAndersson",
      "indices" : [ 0, 16 ],
      "id_str" : "175600046",
      "id" : 175600046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122156148211191810",
  "geo" : {
  },
  "id_str" : "122317727628144642",
  "in_reply_to_user_id" : 175600046,
  "text" : "@JacobnAndersson yessir!!",
  "id" : 122317727628144642,
  "in_reply_to_status_id" : 122156148211191810,
  "created_at" : "Fri Oct 07 14:29:53 +0000 2011",
  "in_reply_to_screen_name" : "JacobnAndersson",
  "in_reply_to_user_id_str" : "175600046",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 0, 16 ],
      "id_str" : "361582244",
      "id" : 361582244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122152460268736512",
  "geo" : {
  },
  "id_str" : "122317685265674240",
  "in_reply_to_user_id" : 361582244,
  "text" : "@peacelovinchris no offense to this semester's other participants...but we were lacking your competition!! we won w 5k points! we're ready",
  "id" : 122317685265674240,
  "in_reply_to_status_id" : 122152460268736512,
  "created_at" : "Fri Oct 07 14:29:43 +0000 2011",
  "in_reply_to_screen_name" : "peacelovinchris",
  "in_reply_to_user_id_str" : "361582244",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unbeatable",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "vigor",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122316423790985216",
  "text" : "morning ride up Farm... #unbeatable. talk about a way to get ready for a day with #vigor. and fresh bread when I get home!",
  "id" : 122316423790985216,
  "created_at" : "Fri Oct 07 14:24:42 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boogieburggggg",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "rivermill",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "milkstout",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "ftw",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122154563611533312",
  "text" : "#boogieburggggg #rivermill #milkstout #ftw",
  "id" : 122154563611533312,
  "created_at" : "Fri Oct 07 03:41:32 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garmin",
      "screen_name" : "Garmin",
      "indices" : [ 0, 7 ],
      "id_str" : "15324722",
      "id" : 15324722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122123846814941184",
  "in_reply_to_user_id" : 15324722,
  "text" : "@garmin my ant+ agent hasn't uploaded for two days because of \"server error,\" is this happening to many or just me?",
  "id" : 122123846814941184,
  "created_at" : "Fri Oct 07 01:39:28 +0000 2011",
  "in_reply_to_screen_name" : "Garmin",
  "in_reply_to_user_id_str" : "15324722",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teambiglick",
      "indices" : [ 28, 40 ]
    }, {
      "text" : "awesome",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122122152878161920",
  "text" : "'s team WON the BOOK HUNT!! #teambiglick #awesome",
  "id" : 122122152878161920,
  "created_at" : "Fri Oct 07 01:32:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Reagan",
      "screen_name" : "dmreagan",
      "indices" : [ 10, 19 ],
      "id_str" : "70117835",
      "id" : 70117835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crisis",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122084962961862656",
  "text" : "is out of @dmreagan's homemade spaghetti sauce #crisis",
  "id" : 122084962961862656,
  "created_at" : "Thu Oct 06 23:04:58 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "absentmindedstudent",
      "indices" : [ 72, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122071587309621249",
  "text" : "can't withdraw $900 from the ATM... looks like the rent's gonna be late #absentmindedstudent",
  "id" : 122071587309621249,
  "created_at" : "Thu Oct 06 22:11:49 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan DelGiudice",
      "screen_name" : "ryandelgiudice",
      "indices" : [ 0, 15 ],
      "id_str" : "44471444",
      "id" : 44471444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122052429100490752",
  "geo" : {
  },
  "id_str" : "122053132363632640",
  "in_reply_to_user_id" : 44471444,
  "text" : "@ryandelgiudice first you might wanna get those strange lumps on your arm checked out haha",
  "id" : 122053132363632640,
  "in_reply_to_status_id" : 122052429100490752,
  "created_at" : "Thu Oct 06 20:58:29 +0000 2011",
  "in_reply_to_screen_name" : "ryandelgiudice",
  "in_reply_to_user_id_str" : "44471444",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "catchmeifucan",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122049879886397440",
  "text" : "at 6'3\" 344 lbs, the Steeler's Chris Kemoeatu is my ht, and literally twice my weight! still got him by .5s in the 10yd dash #catchmeifucan",
  "id" : 122049879886397440,
  "created_at" : "Thu Oct 06 20:45:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fallbreak",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "urbanmtbing",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "122045845397975041",
  "text" : "oh hello weekend #fallbreak ...book hunt team assembled! #urbanmtbing",
  "id" : 122045845397975041,
  "created_at" : "Thu Oct 06 20:29:31 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Pagano",
      "screen_name" : "slpagsVT",
      "indices" : [ 0, 9 ],
      "id_str" : "354419350",
      "id" : 354419350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121775620727373826",
  "geo" : {
  },
  "id_str" : "121776043194462208",
  "in_reply_to_user_id" : 354419350,
  "text" : "@slpagsVT this is why i refuse to watch scary movies lol. who enjoys them??",
  "id" : 121776043194462208,
  "in_reply_to_status_id" : 121775620727373826,
  "created_at" : "Thu Oct 06 02:37:25 +0000 2011",
  "in_reply_to_screen_name" : "slpagsVT",
  "in_reply_to_user_id_str" : "354419350",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doyle",
      "screen_name" : "bdoyle613",
      "indices" : [ 0, 10 ],
      "id_str" : "45430885",
      "id" : 45430885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "d2openbar",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121774143162159104",
  "geo" : {
  },
  "id_str" : "121774489217413120",
  "in_reply_to_user_id" : 45430885,
  "text" : "@bdoyle613 you got it!! too bad they don't have it...just imagine #d2openbar",
  "id" : 121774489217413120,
  "in_reply_to_status_id" : 121774143162159104,
  "created_at" : "Thu Oct 06 02:31:15 +0000 2011",
  "in_reply_to_screen_name" : "bdoyle613",
  "in_reply_to_user_id_str" : "45430885",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/iVT0yWN1",
      "expanded_url" : "http://twitpic.com/6vrqie",
      "display_url" : "twitpic.com/6vrqie"
    } ]
  },
  "geo" : {
  },
  "id_str" : "121773713925472256",
  "text" : "from earlier today: whats missing from this picture at d2 http://t.co/iVT0yWN1",
  "id" : 121773713925472256,
  "created_at" : "Thu Oct 06 02:28:10 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lightweight",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121724375635476480",
  "text" : "drank a half gallon of water, and holding a banana with jeans and sweatshirt on... weigh 172 #lightweight",
  "id" : 121724375635476480,
  "created_at" : "Wed Oct 05 23:12:07 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feltgreat",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "ready4richmond",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121719157015326720",
  "text" : "boom! just ran 20.46 miles in 2 hours and 54 minutes! #feltgreat #ready4richmond",
  "id" : 121719157015326720,
  "created_at" : "Wed Oct 05 22:51:23 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "richmondmarathon",
      "indices" : [ 21, 38 ]
    }, {
      "text" : "37days",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121667021372014593",
  "text" : "commence 3 hour run! #richmondmarathon #37days",
  "id" : 121667021372014593,
  "created_at" : "Wed Oct 05 19:24:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Reagan",
      "screen_name" : "kreagannet",
      "indices" : [ 0, 11 ],
      "id_str" : "68794179",
      "id" : 68794179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121425539729854465",
  "geo" : {
  },
  "id_str" : "121635108452184064",
  "in_reply_to_user_id" : 68794179,
  "text" : "@kreagannet nice bro! hang in there, it gets easier. just run at a pace that feels easy, no faster",
  "id" : 121635108452184064,
  "in_reply_to_status_id" : 121425539729854465,
  "created_at" : "Wed Oct 05 17:17:24 +0000 2011",
  "in_reply_to_screen_name" : "kreagannet",
  "in_reply_to_user_id_str" : "68794179",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thundercoffer",
      "screen_name" : "Thundercoffer",
      "indices" : [ 0, 14 ],
      "id_str" : "26010551",
      "id" : 26010551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121605374867537920",
  "geo" : {
  },
  "id_str" : "121633442654986240",
  "in_reply_to_user_id" : 26010551,
  "text" : "@Thundercoffer i've always wanted to try that. let me know how goes!",
  "id" : 121633442654986240,
  "in_reply_to_status_id" : 121605374867537920,
  "created_at" : "Wed Oct 05 17:10:47 +0000 2011",
  "in_reply_to_screen_name" : "Thundercoffer",
  "in_reply_to_user_id_str" : "26010551",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121632996318134272",
  "text" : "was in court for 3.5 hours...missed both my classes. got off the ticket, but wow our judicial system is slow",
  "id" : 121632996318134272,
  "created_at" : "Wed Oct 05 17:09:00 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121405573982990337",
  "text" : "was suprised to see a huge fireworks display on campus tonight...pretty cool though! gotta be in court at 830 tmrw 4 my biking ticket...",
  "id" : 121405573982990337,
  "created_at" : "Wed Oct 05 02:05:19 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Zdanowski",
      "screen_name" : "DZdan1",
      "indices" : [ 0, 7 ],
      "id_str" : "228268171",
      "id" : 228268171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/Z3K6sOio",
      "expanded_url" : "http://www.stumbleupon.com/to/e/829847924:jzvnwd5qjop0pn17/wrec-1/t6/__eNrLKCkpsNLXLy8v1ysuKc1NykktLcjP00vOz9Uvydcv1jfMCnRzdQNcMBd7Dbc",
      "display_url" : "stumbleupon.com/to/e/829847924…"
    } ]
  },
  "in_reply_to_status_id_str" : "120970524779229184",
  "geo" : {
  },
  "id_str" : "121390654059323392",
  "in_reply_to_user_id" : 228268171,
  "text" : "@DZdan1 at least you didn't do it like these people: http://t.co/Z3K6sOio,",
  "id" : 121390654059323392,
  "in_reply_to_status_id" : 120970524779229184,
  "created_at" : "Wed Oct 05 01:06:01 +0000 2011",
  "in_reply_to_screen_name" : "DZdan1",
  "in_reply_to_user_id_str" : "228268171",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 16, 28 ],
      "id_str" : "47645908",
      "id" : 47645908
    }, {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 52, 68 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "121387612895330306",
  "text" : "fun, but chilly @VTTriathlon swim practice tonight! @RumblinStumblin get on skype",
  "id" : 121387612895330306,
  "created_at" : "Wed Oct 05 00:53:56 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/sbRq7Kjv",
      "expanded_url" : "http://bit.ly/p5VxyQ",
      "display_url" : "bit.ly/p5VxyQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "121350088277762048",
  "text" : "nice de-stressing ride! http://t.co/sbRq7Kjv",
  "id" : 121350088277762048,
  "created_at" : "Tue Oct 04 22:24:50 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120978376889610240",
  "text" : "@Tri_Gardner yeah man sounds good!",
  "id" : 120978376889610240,
  "created_at" : "Mon Oct 03 21:47:47 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Tech News",
      "screen_name" : "vtnews",
      "indices" : [ 3, 10 ],
      "id_str" : "17374056",
      "id" : 17374056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120968297373110273",
  "text" : "RT @vtnews: Check out this photo of Lane Stadium on Saturday night! http://ar.gy/d48",
  "retweeted_status" : {
    "source" : "<a href=\"http://argylesocial.com\" rel=\"nofollow\">Argyle Social</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "120954035875483648",
    "text" : "Check out this photo of Lane Stadium on Saturday night! http://ar.gy/d48",
    "id" : 120954035875483648,
    "created_at" : "Mon Oct 03 20:11:04 +0000 2011",
    "user" : {
      "name" : "Virginia Tech News",
      "screen_name" : "vtnews",
      "protected" : false,
      "id_str" : "17374056",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/65547724/twitter_vtshield_normal.jpg",
      "id" : 17374056,
      "verified" : false
    }
  },
  "id" : 120968297373110273,
  "created_at" : "Mon Oct 03 21:07:44 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 21, 30 ],
      "id_str" : "342318092",
      "id" : 342318092
    }, {
      "name" : "Crowley C",
      "screen_name" : "OGfromtheOB",
      "indices" : [ 31, 43 ],
      "id_str" : "774471674",
      "id" : 774471674
    }, {
      "name" : "Christoper Brown",
      "screen_name" : "peacelovinchris",
      "indices" : [ 44, 60 ],
      "id_str" : "361582244",
      "id" : 361582244
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 97, 109 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/RF9vhVWW",
      "expanded_url" : "http://bit.ly/oWmBBU",
      "display_url" : "bit.ly/oWmBBU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "120955284356218881",
  "text" : "ballin run up Farm w @run_rudy @ogfromtheob @peacelovinchris!! garmin data: http://t.co/RF9vhVWW @vttriathlon",
  "id" : 120955284356218881,
  "created_at" : "Mon Oct 03 20:16:01 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120861472820690944",
  "text" : "new personal record: door to door (523 jackson st to 240 mcb hall) in FOUR minutes",
  "id" : 120861472820690944,
  "created_at" : "Mon Oct 03 14:03:15 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stickaforkinmybrain",
      "indices" : [ 95, 115 ]
    }, {
      "text" : "itsdone",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120708522399891456",
  "text" : "homework in (real analysis + abstract algebra + numerical analysis + hist of math) &gt; 15 hrs #stickaforkinmybrain #itsdone",
  "id" : 120708522399891456,
  "created_at" : "Mon Oct 03 03:55:29 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Reagan",
      "screen_name" : "RumblinStumblin",
      "indices" : [ 26, 42 ],
      "id_str" : "78184204",
      "id" : 78184204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iscored125andlose",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120699994918486017",
  "text" : "damn you Aaron Rodgers... @RumblinStumblin wins in fantasy football with a lucky 47 point performance! #iscored125andlose?",
  "id" : 120699994918486017,
  "created_at" : "Mon Oct 03 03:21:35 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quaker Oats",
      "screen_name" : "QuakerOats",
      "indices" : [ 1, 12 ],
      "id_str" : "405064418",
      "id" : 405064418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120586382472261633",
  "text" : ".@QuakerOats maple brown sugar oatmeal for lunch, the reduced sugar is actually really good!",
  "id" : 120586382472261633,
  "created_at" : "Sun Oct 02 19:50:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyatt Lowdermilk",
      "screen_name" : "WyattLoud",
      "indices" : [ 0, 10 ],
      "id_str" : "61636675",
      "id" : 61636675
    }, {
      "name" : "VT Triathlon",
      "screen_name" : "VTTriathlon",
      "indices" : [ 44, 56 ],
      "id_str" : "47645908",
      "id" : 47645908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120219764957261824",
  "geo" : {
  },
  "id_str" : "120311313011445760",
  "in_reply_to_user_id" : 61636675,
  "text" : "@WyattLoud we need results results results! @VTTriathlon",
  "id" : 120311313011445760,
  "in_reply_to_status_id" : 120219764957261824,
  "created_at" : "Sun Oct 02 01:37:06 +0000 2011",
  "in_reply_to_screen_name" : "WyattLoud",
  "in_reply_to_user_id_str" : "61636675",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "indices" : [ 3, 13 ],
      "id_str" : "9463702",
      "id" : 9463702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hokies",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120310600600522752",
  "text" : "RT @NRVLiving: Sigh. #Hokies",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hokies",
        "indices" : [ 6, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "120308690778734592",
    "text" : "Sigh. #Hokies",
    "id" : 120308690778734592,
    "created_at" : "Sun Oct 02 01:26:41 +0000 2011",
    "user" : {
      "name" : "Jeremy Hart",
      "screen_name" : "NRVLiving",
      "protected" : false,
      "id_str" : "9463702",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1787766827/Jeremy_normal.jpg",
      "id" : 9463702,
      "verified" : false
    }
  },
  "id" : 120310600600522752,
  "created_at" : "Sun Oct 02 01:34:17 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/vEZO5e0T",
      "expanded_url" : "http://connect.garmin.com/activity/118340377",
      "display_url" : "connect.garmin.com/activity/11834…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "120190881394462720",
  "text" : "check out the hills on my race data from the Garmin: http://t.co/vEZO5e0T",
  "id" : 120190881394462720,
  "created_at" : "Sat Oct 01 17:38:33 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Ridge",
      "screen_name" : "BRMSBlacksburg",
      "indices" : [ 87, 102 ],
      "id_str" : "208127016",
      "id" : 208127016
    }, {
      "name" : "Brice Collamer",
      "screen_name" : "bricec5",
      "indices" : [ 114, 122 ],
      "id_str" : "86132431",
      "id" : 86132431
    }, {
      "name" : "Rudy Rutemiller",
      "screen_name" : "Run_Rudy",
      "indices" : [ 123, 132 ],
      "id_str" : "342318092",
      "id" : 342318092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120186728756678656",
  "text" : ".@mtnlake trail race was super hard, freezing and snowing and awesome! thanks again to @BRMSBlacksburg! nice jobs @bricec5 @Run_Rudy.",
  "id" : 120186728756678656,
  "created_at" : "Sat Oct 01 17:22:03 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Morrison",
      "screen_name" : "jpmor06",
      "indices" : [ 21, 29 ],
      "id_str" : "178447765",
      "id" : 178447765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120186265575489536",
  "text" : "congrats on the WIN \"@jpmor06: Still snowing on top of the world after an awesome race!\"",
  "id" : 120186265575489536,
  "created_at" : "Sat Oct 01 17:20:13 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manup",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120132936862404608",
  "text" : "its snowing @mtnlake!! only brought shorts and t shirt #manup",
  "id" : 120132936862404608,
  "created_at" : "Sat Oct 01 13:48:18 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "120097156991422464",
  "text" : "up early for the @mtnlake Mountain Top Trot 10 miler! Gonna be sweet!",
  "id" : 120097156991422464,
  "created_at" : "Sat Oct 01 11:26:08 +0000 2011",
  "user" : {
    "name" : "Andy Reagan",
    "screen_name" : "andyreagan",
    "protected" : false,
    "id_str" : "55931868",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/3268481379/3845dd7f9acdc1ffb75991bd73c694fa_normal.png",
    "id" : 55931868,
    "verified" : false
  }
} ]